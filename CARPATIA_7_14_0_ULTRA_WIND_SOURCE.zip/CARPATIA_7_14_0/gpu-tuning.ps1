﻿param([Parameter(Mandatory=$true)][string]$RequestFile)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$helper=Join-Path $PSScriptRoot 'native\gpu-tuning\bin\carpatia-gpu-tuning.exe'
if(-not (Test-Path -LiteralPath $helper -PathType Leaf)){throw 'Modulul de control hardware nu este disponibil în această instalare.'}
$request=Get-Item -LiteralPath $RequestFile -ErrorAction Stop
if($request.PSIsContainer -or $request.Length -gt 8192){throw 'Solicitare hardware invalidă.'}
$output=& $helper --request-file $request.FullName 2>&1
$code=$LASTEXITCODE
try{$result=($output -join "`n") | ConvertFrom-Json}catch{throw 'Modulul hardware nu a returnat un rezultat valid.'}
if($result.success -isnot [bool]){throw 'Rezultat hardware incomplet.'}
if($code -ne 0 -and $result.success){throw 'Procesul hardware nu a confirmat finalizarea.'}
$result | ConvertTo-Json -Depth 16 -Compress
