﻿# Typed NIC preferences. No adapter restart, display-name guessing or arbitrary keywords.
# Loaded by tweak-native-ops.ps1; Windows calls run only when an operation is invoked.
function Assert-NicOperation($o){
 if($null -eq $o -or $o.type -isnot [string] -or $o.type -cnotin @('nic-power','nic-advanced')){throw 'Operație NIC necunoscută.'}
 if($o.type -eq 'nic-power' -and ($o.value -isnot [string] -or $o.value -cne 'Disabled')){throw 'Valoare NIC Power nepermisă.'}
 if($o.type -eq 'nic-advanced' -and ($o.keyword -isnot [string] -or $o.keyword -cnotin @('*EEE','*InterruptModeration') -or $o.value -isnot [string] -or $o.value -cne '0')){throw 'Proprietate NIC avansată nepermisă.'}
}
function Convert-NicGuid($value){
 if($value -isnot [string] -or $value -notmatch '^(?:[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}|\{[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}\})$'){throw 'Identitate NIC invalidă.'}
 return ([guid]$value).ToString().ToLowerInvariant()
}
function Get-NicAdapter($o){
 $guid=Convert-NicGuid $o.adapterGuid
 $adapter=Get-AdapterByGuid $guid
 if((Convert-NicGuid ([string]$adapter.InterfaceGuid)) -cne $guid -or $adapter.Name -isnot [string] -or -not $adapter.Name -or $adapter.Name.Length -gt 256 -or $adapter.Name -match '[\r\n]'){throw 'Adaptorul NIC nu corespunde identității solicitate.'}
 return $adapter
}
function Assert-NicAdapterUnchanged($o,[string]$name){
 $current=Get-NicAdapter $o
 if($current.Name -cne $name){throw 'Numele adaptorului s-a schimbat în timpul citirii. Reanalizează; originalul este păstrat.'}
}
function Resolve-NicOperation($spec,$adapterGuid,$saved=$null){
 Assert-NicOperation $spec
 if($null -ne $saved){
  $keywordMatches=if($spec.type -ceq 'nic-advanced'){$saved.keyword -is [string] -and $saved.keyword -ceq $spec.keyword}else{$null -eq $saved.keyword}
  if($saved.type -isnot [string] -or $saved.type -cne $spec.type -or $saved.value -isnot [string] -or $saved.value -cne $spec.value -or -not $keywordMatches){throw 'Operația NIC salvată nu corespunde definiției de încredere. Originalul este păstrat.'}
 }
 $o=Copy-Object $spec
 $guid=if($null -ne $saved){$saved.adapterGuid}else{$adapterGuid}
 $canonical=Convert-NicGuid $guid
 $adapter=Get-AdapterByGuid $canonical
 if((Convert-NicGuid ([string]$adapter.InterfaceGuid)) -cne $canonical){throw 'Adaptorul original nu mai poate fi confirmat.'}
 $o | Add-Member -NotePropertyName adapterGuid -NotePropertyValue $canonical -Force
 return $o
}
function Nic-Targets($o){
 Assert-NicOperation $o
 $guid=Convert-NicGuid $o.adapterGuid
 if($o.type -eq 'nic-power'){return @('network|'+$guid+'|nic-power')}
 return @('network|'+$guid+'|advanced|'+$o.keyword.ToLowerInvariant())
}
function Get-NicValueKeys($v){
 if($null -eq $v -or $v -is [array] -or $v -is [string] -or $v -is [ValueType]){throw 'Stare NIC invalidă.'}
 if($v -is [System.Collections.IDictionary]){return @($v.Keys)}
 return @($v.PSObject.Properties.Name)
}
function Assert-NicValue($o,$v){
 Assert-NicOperation $o
 $keys=@(Get-NicValueKeys $v)
 if($o.type -eq 'nic-power'){
  $names=@('selectiveSuspend','deviceSleepOnDisconnect')
  if($keys.Count -ne 2 -or @($keys | Where-Object {$_ -cnotin $names}).Count){throw 'Original NIC Power incomplet sau cu proprietăți străine.'}
  $supported=0
  foreach($name in $names){if($null -ne $v.$name){if($v.$name -isnot [string] -or $v.$name -cnotin @('Enabled','Disabled')){throw 'Valoare NIC Power necunoscută.'};$supported++}}
  if(-not $supported){throw 'Original NIC Power fără proprietăți suportate.'}
 }else{
  if($keys.Count -ne 1 -or $keys[0] -cne 'value' -or $v.value -isnot [string] -or $v.value -notmatch '^(0|[1-9][0-9]{0,9})$' -or [decimal]$v.value -gt 4294967295){throw 'Valoare NIC avansată invalidă.'}
 }
}
function Convert-NicRegistryNumber($value){
 if($value -isnot [string] -and $value -isnot [int] -and $value -isnot [long] -and $value -isnot [uint32]){throw 'Driverul NIC a returnat un tip numeric necunoscut.'}
 $text=[string]$value
 if($text -notmatch '^(0|[1-9][0-9]{0,9})$' -or [decimal]$text -gt 4294967295){throw 'Driverul NIC a returnat o valoare necunoscută.'}
 return $text
}
function Test-NicMissingPropertyError($errorRecord){
 return ($errorRecord.FullyQualifiedErrorId -like 'CmdletizationQuery_NotFound*' -or $errorRecord.FullyQualifiedErrorId -like 'NoMatchingMSFT_NetAdapterAdvancedPropertySettingData*' -or $errorRecord.FullyQualifiedErrorId -like 'NoMatchingMSFT_NetAdapterPowerManagementSettingData*')
}
function Read-NicPower($o){
 $adapter=Get-NicAdapter $o
 try{$rows=@(Get-NetAdapterPowerManagement -Name ([WildcardPattern]::Escape($adapter.Name)) -IncludeHidden -ErrorAction Stop)}
 catch{Assert-NicAdapterUnchanged $o $adapter.Name;if(Test-NicMissingPropertyError $_){return $null};throw}
 Assert-NicAdapterUnchanged $o $adapter.Name
 if(-not $rows.Count){return $null}
 if($rows.Count -ne 1 -or $rows[0].Name -cne $adapter.Name){throw 'Proprietățile NIC Power nu corespund exact adaptorului ales.'}
 $row=$rows[0];$state=@{selectiveSuspend=$null;deviceSleepOnDisconnect=$null}
 foreach($pair in @(@('selectiveSuspend','SelectiveSuspend'),@('deviceSleepOnDisconnect','DeviceSleepOnDisconnect'))){
  $raw=$row.($pair[1])
  if($null -eq $raw -or [string]$raw -ceq 'Unsupported'){continue}
  if([string]$raw -cnotin @('Enabled','Disabled')){throw 'Driverul NIC a returnat o stare Power necunoscută.'}
  $state[$pair[0]]=[string]$raw
 }
 return @{row=$row;state=$state}
}
function Read-NicAdvanced($o){
 $adapter=Get-NicAdapter $o
 try{$all=@(Get-NetAdapterAdvancedProperty -Name ([WildcardPattern]::Escape($adapter.Name)) -IncludeHidden -AllProperties -ErrorAction Stop)}
 catch{Assert-NicAdapterUnchanged $o $adapter.Name;if(Test-NicMissingPropertyError $_){return $null};throw}
 Assert-NicAdapterUnchanged $o $adapter.Name
 if(@($all | Where-Object {$_.Name -cne $adapter.Name}).Count){throw 'Inventarul NIC avansat conține un alt adaptor.'}
 $matches=@($all | Where-Object {$_.RegistryKeyword -is [string] -and $_.RegistryKeyword -ceq $o.keyword})
 if(-not $matches.Count){return $null}
 if($matches.Count -ne 1){throw 'Proprietate NIC avansată ambiguă.'}
 $row=$matches[0];$original=@($row.RegistryValue)
 if($original.Count -ne 1){throw 'Proprietate NIC avansată cu mai multe valori; originalul nu poate fi confirmat.'}
 $value=Convert-NicRegistryNumber $original[0]
 $rawValid=@($row.ValidRegistryValues)
 if($rawValid.Count -eq 1 -and $null -eq $rawValid[0]){$rawValid=@()}
 if(-not $rawValid.Count){return @{row=$row;value=$value;supported=$false;reason='Driverul nu publică valorile permise pentru această proprietate.'}}
 if($rawValid.Count -gt 12){throw 'Lista valorilor NIC avansate este necunoscută.'}
 $valid=@($rawValid | ForEach-Object {Convert-NicRegistryNumber $_})
 if(@($valid | Select-Object -Unique).Count -ne $valid.Count){throw 'Lista valorilor NIC avansate este ambiguă.'}
 if($value -cnotin $valid){throw 'Valoarea NIC curentă nu se regăsește în lista publicată de driver.'}
 return @{row=$row;value=$value;valid=$valid;supported=($valid -ccontains '0');reason='Driverul nu oferă valoarea dezactivată pentru această proprietate.'}
}
function Get-NicApplicability($o){
 Assert-NicOperation $o
 if($o.type -eq 'nic-power'){
  if(-not (Get-Command Get-NetAdapterPowerManagement -ErrorAction SilentlyContinue)){return @{applicable=$false;message='Interfața NIC Power nu este disponibilă în Windows.'}}
  $read=Read-NicPower $o
  if($null -eq $read -or ($null -eq $read.state.selectiveSuspend -and $null -eq $read.state.deviceSleepOnDisconnect)){return @{applicable=$false;message='Driverul nu oferă Selective Suspend sau Device Sleep modificabile.'}}
 }else{
  if(-not (Get-Command Get-NetAdapterAdvancedProperty -ErrorAction SilentlyContinue)){return @{applicable=$false;message='Interfața NIC avansată nu este disponibilă în Windows.'}}
  $read=Read-NicAdvanced $o
  if($null -eq $read){return @{applicable=$false;message=('Driverul nu oferă proprietatea standard '+$o.keyword+'.')}}
  if(-not $read.supported){return @{applicable=$false;message=$read.reason}}
 }
 return @{applicable=$true}
}
function Capture-NicValue($o){
 Assert-NicOperation $o
 if($o.type -eq 'nic-power'){$read=Read-NicPower $o;if($null -eq $read){throw 'Proprietățile NIC Power nu sunt disponibile.'};$state=$read.state}
 else{$read=Read-NicAdvanced $o;if($null -eq $read -or -not $read.supported){throw 'Proprietatea NIC avansată nu poate fi confirmată.'};$state=@{value=$read.value}}
 Assert-NicValue $o $state
 return $state
}
function Desired-NicValue($o,$before){
 Assert-NicValue $o $before
 if($o.type -eq 'nic-advanced'){return @{value='0'}}
 $desired=@{selectiveSuspend=$null;deviceSleepOnDisconnect=$null}
 foreach($name in @('selectiveSuspend','deviceSleepOnDisconnect')){if($null -ne $before.$name){$desired[$name]='Disabled'}}
 return $desired
}
function Test-NicRestoreState($o,$current,$before,$desired){
 try{Assert-NicValue $o $current;Assert-NicValue $o $before;Assert-NicValue $o $desired}catch{return $false}
 $names=if($o.type -eq 'nic-power'){@('selectiveSuspend','deviceSleepOnDisconnect')}else{@('value')}
 foreach($name in $names){
  # Null is a captured unsupported property, never an invitation to write a
  # newly exposed property after a driver change.
  if(($null -eq $before.$name) -ne ($null -eq $desired.$name)){return $false}
  if($current.$name -cne $before.$name -and $current.$name -cne $desired.$name){return $false}
 }
 return $true
}
function Write-NicValue($o,$v){
 Assert-NicValue $o $v
 if($o.type -eq 'nic-power'){
  $read=Read-NicPower $o;if($null -eq $read){throw 'Driverul NIC Power nu mai este disponibil. Originalul este păstrat.'}
  Assert-NicValue $o $read.state
  $arguments=@{InputObject=$read.row;NoRestart=$true;ErrorAction='Stop'};$changed=$false
  foreach($pair in @(@('selectiveSuspend','SelectiveSuspend'),@('deviceSleepOnDisconnect','DeviceSleepOnDisconnect'))){
   $name=$pair[0]
   if(($null -eq $read.state.$name) -ne ($null -eq $v.$name)){throw 'Suportul driverului NIC Power s-a schimbat. Originalul este păstrat.'}
   if($null -ne $v.$name -and $v.$name -cne $read.state.$name){$arguments[$pair[1]]=$v.$name;$changed=$true}
  }
  if($changed){Set-NetAdapterPowerManagement @arguments | Out-Null}
 }else{
  $read=Read-NicAdvanced $o
  if($null -eq $read -or -not $read.supported -or $v.value -cnotin $read.valid){throw 'Driverul NIC nu mai acceptă valoarea salvată. Originalul este păstrat.'}
  if($read.value -cne $v.value){Set-NetAdapterAdvancedProperty -InputObject $read.row -RegistryValue ([string[]]@($v.value)) -NoRestart -ErrorAction Stop | Out-Null}
 }
 $after=Capture-NicValue $o
 if((Canonical-Native $after) -cne (Canonical-Native $v)){throw 'Driverul nu a confirmat configurația NIC. Originalul este păstrat; poate fi necesar restart Windows.'}
}
