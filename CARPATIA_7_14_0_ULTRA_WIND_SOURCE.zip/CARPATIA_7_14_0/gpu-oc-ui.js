'use strict';
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaGpuOc=Object.freeze(factory());
})(typeof window==='object'?window:globalThis,function(){
 const integer=value=>Number.isInteger(value)&&value>=1&&value<=10000;
 const identity=value=>typeof value==='string'&&value.trim().length>0&&value.length<=512&&!/[\u0000-\u001f\u007f]/.test(value);
 function limits(row){return !!row&&integer(row.currentMhz)&&integer(row.minMhz)&&integer(row.maxMhz)&&integer(row.stepMhz)&&row.minMhz<=row.maxMhz&&row.currentMhz>=row.minMhz&&row.currentMhz<=row.maxMhz}
 function frequency(value,row){
  if(typeof value!=='string'||!/^\d{1,5}$/.test(value.trim())||!limits(row))return null;
  const mhz=Number(value.trim());return integer(mhz)&&mhz>=row.minMhz&&mhz<=row.maxMhz&&(mhz-row.minMhz)%row.stepMhz===0?mhz:null;
 }
 function validateStatus(value){
  if(!value||value.success!==true||typeof value.available!=='boolean'||typeof value.supported!=='boolean'||!Array.isArray(value.gpus))throw Error(value?.reason||'Suportul de control hardware nu a putut fi confirmat.');
  const seen=new Set();
  for(const row of value.gpus){
   if(!row||!identity(row.gpuId)||seen.has(row.gpuId)||typeof row.supported!=='boolean'||typeof row.backup!=='boolean'||row.supported&&!limits(row))throw Error('Driverul nu a returnat limite hardware valide. Reîncearcă verificarea.');
   seen.add(row.gpuId);
  }
  return value;
 }
 function mount({api,document:doc=globalThis.document,requireNative=()=>false,task=(_,fn)=>fn(),confirmDialog=async()=>false,showToast=()=>{}}){
  const $=id=>doc.getElementById(id),panel=$('gpuOcPanel');
  let state=null,selected='',known=false,loading=false,working=false,destroyed=false,epoch=0,flight=null;
  const row=()=>state?.gpus?.find(item=>item.gpuId===selected)||null;
  const text=(id,value)=>{$(id).textContent=String(value??'—')};
  const errorText=error=>String(error?.message||error||'Operația nu a fost confirmată.').replace(/^Error invoking remote method '[^']+':\s*Error:\s*/,'');
  function message(value,tone='neutral'){if(destroyed)return;text('gpuOcMessage',value);$('gpuOcMessage').dataset.tone=tone;$('gpuOcMessage').setAttribute('role',tone==='error'?'alert':'status')}
  const writable=()=>known&&state.available===true&&state.supported===true&&row()?.supported===true&&limits(row());
  function controls(){
   if(destroyed)return;
   const item=row(),busy=working||loading,mhz=frequency($('gpuOcMhz').value,item);
   panel.setAttribute('aria-busy',String(busy));
   $('gpuOcRefresh').disabled=busy||typeof api?.gpuTuningStatus!=='function';
   $('gpuOcDevice').disabled=busy||!known||!state?.gpus.length;
   $('gpuOcMhz').disabled=busy||!writable()||item.backup;
   $('gpuOcApply').disabled=busy||!writable()||item.backup||mhz===null||mhz===item.currentMhz||typeof api?.gpuTuningPrepare!=='function'||typeof api?.gpuTuningCommit!=='function';
   $('gpuOcRestore').disabled=busy||!known||!item||item.backup!==true||typeof api?.gpuTuningRestore!=='function';
  }
  function render({resetInput=false}={}){
   if(destroyed)return;
   const item=row(),supported=writable();
   $('gpuOcControls').hidden=!supported;
   text('gpuOcBadge',supported?'CONTROL MANUAL DISPONIBIL':'CONTROL HARDWARE INDISPONIBIL');
   text('gpuOcCurrent',supported?item.currentMhz+' MHz':'—');
   text('gpuOcRange',supported?item.minMhz+'–'+item.maxMhz+' MHz · pas '+item.stepMhz+' MHz':'Limitele sunt afișate numai după confirmarea suportului driverului.');
   text('gpuOcOriginal',known&&item?item.backup?'Original salvat · restaurează înainte de o nouă aplicare.':'Niciun original CARPATIA activ pentru placa aleasă.':'Originalul nu a fost verificat.');
   if(supported){for(const name of ['min','max','step'])$('gpuOcMhz').setAttribute(name,String(item[name+'Mhz']));if(resetInput||frequency($('gpuOcMhz').value,item)===null)$('gpuOcMhz').value=String(item.currentMhz)}
   else $('gpuOcMhz').value='';
   controls();
  }
  function choices(){
   const selector=$('gpuOcDevice');selector.replaceChildren();
   for(const item of state?.gpus||[]){const option=doc.createElement('option');option.value=item.gpuId;option.textContent=String(item.name||'GPU identificat').slice(0,180)+(item.supported?'':' · control indisponibil');selector.append(option)}
   if(!state?.gpus.length){const option=doc.createElement('option');option.value='';option.textContent='Nicio placă video cu suport confirmat';selector.append(option)}
   selector.value=selected;
  }
  function reason(){
   if(!api)return 'Controlul hardware poate fi verificat în aplicația Windows. Nu s-a modificat nicio setare.';
   if(!known)return 'Verifică suportul plăcii video înainte de configurare.';
   if(!writable())return row()?.reason||state?.reason||'Driverul sau placa video nu oferă acest control. Preferințele Windows pentru jocuri rămân disponibile.';
   if(row().backup)return 'Există un original salvat. Restaurează-l înainte de o nouă modificare a limitei.';
   return 'Alege manual limita maximă GPU în intervalul raportat de driver. Frecvența instantanee variază cu sarcina și temperatura.';
  }
  async function load({internal=false,resetInput=false}={}){
   if(destroyed||working&&!internal)return state;
   if(flight)return flight;
   const request=++epoch;loading=true;controls();message('Verific suportul și limitele raportate de driver…');
   const pending=Promise.resolve().then(()=>{
    if(typeof api?.gpuTuningStatus!=='function')return {success:true,available:false,supported:false,gpus:[],reason:reason()};
    return api.gpuTuningStatus();
   }).then(value=>{
    const next=validateStatus(value);
    if(destroyed||request!==epoch)return next;
    const prior=selected;state=next;known=true;
    if(!state.gpus.some(item=>item.gpuId===selected))selected=(state.gpus.find(item=>item.supported)||state.gpus[0])?.gpuId||'';
    choices();render({resetInput:resetInput||selected!==prior});message(reason());return next;
   }).catch(error=>{
    if(!destroyed&&request===epoch){known=false;state=null;selected='';choices();render();message(errorText(error),'error')}
    return null;
   }).finally(()=>{if(!destroyed&&request===epoch){loading=false;controls()}if(flight===pending)flight=null});
   flight=pending;return pending;
  }
  async function action(label,run){
   if(destroyed||working||loading||!api)return;
   working=true;++epoch;controls();
   try{return await task(label,async()=>{try{return await run()}catch(error){if(!destroyed){message(errorText(error),'error');showToast(errorText(error))}return null}})}
   catch(error){if(!destroyed){message(errorText(error),'error');showToast(errorText(error))}return null}
   finally{if(!destroyed){working=false;controls()}}
  }
  async function apply(){
   if(destroyed||working||loading||!writable()||row().backup||!requireNative())return;
   const item={...row()},mhz=frequency($('gpuOcMhz').value,item);
   if(mhz===null){message('Introdu o valoare între limitele afișate, respectând pasul driverului.','error');return}
   if(mhz===item.currentMhz){message('Limita aleasă este deja configurată. Nu s-a modificat nimic.');return}
   return action('Limită maximă GPU',async()=>{
    const prepared=await api.gpuTuningPrepare({gpuId:item.gpuId,mhz});if(destroyed)return;
    const p=prepared?.plan;
    if(!p||p.gpuId!==item.gpuId||p.toMhz!==mhz||!limits({...p,currentMhz:p.fromMhz})||frequency(String(p.toMhz),{...p,currentMhz:p.fromMhz})===null)throw Error('Planul hardware nu corespunde plăcii sau limitei alese. Verifică din nou.');
    if(prepared.already===true){
     if(prepared.token!==null||p.fromMhz!==p.toMhz)throw Error('Planul hardware fără modificări nu poate fi confirmat.');
     await load({internal:true,resetInput:true});if(destroyed)return;
     if(!known||row()?.gpuId!==item.gpuId||row().currentMhz!==mhz)throw Error('Limita GPU s-a schimbat la recitire. Verifică din nou.');
     message('Limita aleasă este deja configurată. Nu s-a modificat nimic.');return;
    }
    if(typeof prepared?.token!=='string'||!prepared.token||prepared.token.length>4096||p.fromMhz===p.toMhz)throw Error('Confirmarea hardware nu poate fi verificată. Analizează din nou.');
    const confirm=await confirmDialog('Aplici această limită maximă GPU?','Se modifică numai limita maximă de frecvență a plăcii selectate.',String(p.name||item.name||'GPU')+'\nLimită actuală: '+p.fromMhz+' MHz\nLimită nouă: '+p.toMhz+' MHz','O limită mai mare poate crește temperatura și consumul și poate cauza instabilitate. Nu se modifică tensiunea sau ventilatoarele. Originalul va fi păstrat pentru restaurare.','APLICĂ LIMITA');
    if(!confirm||destroyed)return;
    let failure,result;
    try{result=await api.gpuTuningCommit(prepared.token);if(result?.success!==true)throw Error(result?.message||'Driverul nu a confirmat aplicarea.')}catch(error){failure=error}
    if(destroyed)return;
    await load({internal:true,resetInput:true});if(destroyed)return;
    if(failure)throw failure;
    const actual=row();
    if(!known||!actual||actual.gpuId!==item.gpuId||!actual.supported||actual.currentMhz!==mhz||actual.backup!==true)throw Error('Limita sau originalul nu sunt confirmate la recitire. Verifică starea înainte de o nouă modificare.');
    message(result.message||'Limita maximă a fost recitită și confirmată. Originalul este salvat.','success');return result;
   });
  }
  async function restore(){
   if(destroyed||working||loading||!known||row()?.backup!==true||!requireNative(true))return;
   const item={...row()};
   return action('Restaurare limită GPU',async()=>{
    if(!await confirmDialog('Restaurezi limita maximă originală?',String(item.name||'Placa video selectată'),'Se folosește originalul salvat de CARPATIA pentru această placă.','Dacă starea a fost schimbată de alt utilitar, restaurarea poate fi oprită și originalul păstrat.','RESTAUREAZĂ ORIGINALUL')||destroyed)return;
    let failure,result;
    try{result=await api.gpuTuningRestore(item.gpuId);if(result?.success!==true)throw Error(result?.message||'Restaurarea nu a fost confirmată.')}catch(error){failure=error}
    if(destroyed)return;
    await load({internal:true,resetInput:true});if(destroyed)return;
    if(failure)throw failure;
    const actual=row();if(!known||!actual||actual.gpuId!==item.gpuId||actual.backup!==false)throw Error('Restaurarea nu poate fi confirmată la recitire. Originalul trebuie reverificat.');
    message(result.message||'Limita originală a fost restaurată și starea recitită.','success');return result;
   });
  }
  $('gpuOcRefresh').onclick=()=>load();$('gpuOcApply').onclick=apply;$('gpuOcRestore').onclick=restore;
  $('gpuOcDevice').onchange=()=>{if(destroyed||working||loading)return;const candidate=$('gpuOcDevice').value;if(!state?.gpus.some(item=>item.gpuId===candidate))return;selected=candidate;render({resetInput:true});message(reason())};
  $('gpuOcMhz').oninput=()=>{if(destroyed||working||loading)return;controls();message(frequency($('gpuOcMhz').value,row())===null?'Valoarea trebuie să respecte intervalul și pasul raportate de driver.':reason(),frequency($('gpuOcMhz').value,row())===null?'error':'neutral')};
  function destroy(){if(destroyed)return;destroyed=true;++epoch;for(const id of ['gpuOcRefresh','gpuOcApply','gpuOcRestore'])$(id).onclick=null;$('gpuOcDevice').onchange=null;$('gpuOcMhz').oninput=null}
  render();message(reason());return {load,destroy,getState:()=>({known,loading,working,selected,state:state?{...state,gpus:state.gpus.map(item=>({...item}))}:null,destroyed})};
 }
 return {mount,frequency,validateStatus};
});
