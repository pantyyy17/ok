'use strict';
// An original, locally synthesized rising gust and airy trail. No media assets or loop.
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaMountainAudio=Object.freeze(factory());
})(typeof window==='object'?window:globalThis,function(){
 const STORAGE_KEY='carpatia.mountainSound';
 const IDS=['heroDebloat','heroUltra','heroNetwork'];
 // Shared with offline audio rendering for preview/verification. The caller
 // supplies its context; this function never opens an audio device itself.
 function synthesizeWind(context,destination=context.destination,{index=0,random=Math.random,noise=null,volume=.085}={}){
  index=Number.isInteger(index)?Math.max(0,Math.min(2,index)):0;
  volume=Number.isFinite(volume)?Math.max(.0001,Math.min(.12,volume)):.085;
  if(!noise){
   noise=context.createBuffer(1,Math.ceil(context.sampleRate*.9),context.sampleRate);
   const samples=noise.getChannelData(0);for(let i=0;i<samples.length;i++)samples[i]=random()*2-1;
  }
  const source=context.createBufferSource(),trail=context.createBufferSource();
  const high=context.createBiquadFilter(),body=context.createBiquadFilter(),air=context.createBiquadFilter();
  const swell=context.createGain(),fade=context.createGain(),master=context.createGain();
  const start=context.currentTime,duration=.70+index*.035,end=start+duration,shift=index*180;
  source.buffer=noise;trail.buffer=noise;
  high.type='highpass';high.frequency.setValueAtTime(120,start);high.Q.setValueAtTime(.5,start);
  body.type='lowpass';body.Q.setValueAtTime(.55,start);
  body.frequency.setValueAtTime(650+shift,start);body.frequency.exponentialRampToValueAtTime(3400+shift,start+.20);body.frequency.exponentialRampToValueAtTime(650,end);
  air.type='bandpass';air.Q.setValueAtTime(.5,start);
  air.frequency.setValueAtTime(1100+shift,start+.07);air.frequency.exponentialRampToValueAtTime(4700+shift,start+.30);air.frequency.exponentialRampToValueAtTime(1300,end);
  // A soft swell replaces the old immediate metallic attack. The delayed,
  // filtered second noise layer gives the gust a trailing rush without a tone.
  swell.gain.setValueAtTime(.0001,start);swell.gain.exponentialRampToValueAtTime(volume,start+.14);swell.gain.exponentialRampToValueAtTime(volume*.72,start+.30);swell.gain.exponentialRampToValueAtTime(.0001,end);
  fade.gain.setValueAtTime(.0001,start+.07);fade.gain.exponentialRampToValueAtTime(volume*.55,start+.26);fade.gain.exponentialRampToValueAtTime(.0001,end);
  master.gain.setValueAtTime(.9,start);
  source.connect(high);high.connect(body);body.connect(swell);swell.connect(master);
  trail.connect(air);air.connect(fade);fade.connect(master);master.connect(destination);
  source.start(start);trail.start(start+.07,.12);source.stop(end);trail.stop(end);
  return {source,sources:[source,trail],tone:null,nodes:[source,trail,high,body,air,swell,fade,master],noise,duration};
 }
 function mount({document:doc=globalThis.document,window:win=globalThis.window,AudioContext,storage,now=()=>Date.now(),random=Math.random}={}){
  const Audio=AudioContext||win?.AudioContext||win?.webkitAudioContext;
  const toggle=doc.getElementById('mountainSound'),status=doc.getElementById('mountainSoundStatus');
  const mountains=IDS.map(id=>doc.getElementById(id)).filter(Boolean),listeners=[];
  let preferences=storage,enabled=true,destroyed=false,unlocked=false,unavailable=!Audio,keyboard=false;
  let context=null,noise=null,arming=null,pending=0,generation=0,lastSound=-Infinity;
  const voices=new Set();
  try{if(preferences===undefined)preferences=win?.localStorage;enabled=preferences?.getItem(STORAGE_KEY)!=='off'}catch{}
  const listen=(target,type,handler,options)=>{target?.addEventListener(type,handler,options);listeners.push([target,type,handler,options])};
  function render(){
   if(toggle){
    if(toggle.type==='checkbox')toggle.checked=enabled;
    else{toggle.textContent=enabled?'SUNET ACTIV':'SUNET OPRIT';toggle.setAttribute('aria-pressed',String(enabled))}
    toggle.setAttribute('aria-label',enabled?'Oprește sunetul munților':'Activează sunetul munților');
   }
   if(status)status.textContent=!enabled?'Efectele sonore sunt oprite.':unavailable?'Efectele sonore nu sunt disponibile în această sesiune.':unlocked?'Rafală de vânt la atingerea munților.':'Sunetul pornește după primul clic sau prima tastă.';
  }
  function suspendIdle(){if(context&&!destroyed&&pending===0&&voices.size===0&&context.state==='running')try{Promise.resolve(context.suspend()).catch(()=>{})}catch{}}
  function clean(voice,stop=false){
   if(!voices.delete(voice))return;
   voice.source.onended=null;
   if(stop)for(const source of voice.sources)try{source.stop()}catch{}
   for(const node of voice.nodes)try{node.disconnect()}catch{}
   suspendIdle();
  }
  function stop(){generation++;for(const voice of [...voices])clean(voice,true);suspendIdle()}
  function usable(button){
   const panel=button?.closest?.('.view');
   return !destroyed&&enabled&&!unavailable&&!doc.hidden&&doc.visibilityState!=='hidden'&&button&&!button.disabled&&
    (!panel||panel.classList.contains('active'))&&!button.closest?.('[inert]')&&(!button.getClientRects||button.getClientRects().length>0);
  }
  function arm(event){
   if(destroyed||!enabled||unavailable||event?.isTrusted!==true)return Promise.resolve(false);
   if(arming)return arming;
   try{
    if(!context)context=new Audio();
    // Call resume inside the real input handler, before its user activation ends.
    const ready=context.state==='running'?Promise.resolve():Promise.resolve(context.resume());
    arming=ready.then(()=>{
     if(destroyed)return false;
     unlocked=context.state==='running';render();return unlocked;
    },()=>{unlocked=false;render();return false}).finally(()=>{arming=null;suspendIdle()});
    return arming;
   }catch{unavailable=true;unlocked=false;render();return Promise.resolve(false)}
  }
  async function play(button,event){
   if(event?.isTrusted!==true||!usable(button)||now()-lastSound<180)return;
   // Hover may resume an already-unlocked context, but cannot unlock it itself.
   if(!unlocked&&!arming)return;
   const request=generation;pending++;
   try{
    if(arming)await arming;
    else if(context.state!=='running')await context.resume();
    if(request!==generation||!unlocked||!usable(button)||now()-lastSound<180)return;
    lastSound=now();for(const old of [...voices])clean(old,true);
    const voice=synthesizeWind(context,context.destination,{noise,index:mountains.indexOf(button),random});noise=voice.noise;voices.add(voice);
    voice.source.onended=()=>clean(voice);
   }catch{for(const voice of [...voices])clean(voice,true)}
   finally{pending--;suspendIdle()}
  }
  function setEnabled(value){
   enabled=Boolean(value);if(!enabled)stop();
   try{preferences?.setItem(STORAGE_KEY,enabled?'on':'off')}catch{}
   render();
  }
  function pointer(event){keyboard=false;arm(event)}
  function key(event){
   if(event.isTrusted!==true||event.repeat||event.ctrlKey||event.metaKey||event.altKey)return;
   keyboard=true;arm(event);
   if(['Enter',' '].includes(event.key)&&mountains.includes(event.target))play(event.target,event);
  }
  for(const button of mountains){
   listen(button,'pointerenter',event=>play(button,event));
   listen(button,'pointerdown',event=>{if(event.button===undefined||event.button===0)play(button,event)});
   listen(button,'focus',event=>{if(keyboard)play(button,event)});
  }
  listen(doc,'pointerdown',pointer,true);listen(doc,'keydown',key,true);
  listen(doc,'visibilitychange',()=>{if(doc.hidden||doc.visibilityState==='hidden')stop()});
  listen(win,'blur',stop);listen(win,'pagehide',destroy,{once:true});
  if(toggle)listen(toggle,toggle.type==='checkbox'?'change':'click',event=>{setEnabled(toggle.type==='checkbox'?toggle.checked:!enabled);if(enabled)arm(event)});
  function destroy(){
   if(destroyed)return;stop();destroyed=true;
   for(const [target,type,handler,options] of listeners)target?.removeEventListener(type,handler,options);
   listeners.length=0;noise=null;unlocked=false;
   if(context)try{Promise.resolve(context.close()).catch(()=>{})}catch{}
  }
  render();return {setEnabled,destroy,getState:()=>({enabled,unlocked,available:!unavailable,active:voices.size,destroyed})};
 }
 return {mount,STORAGE_KEY,synthesizeWind};
});
