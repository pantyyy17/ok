'use strict';
const norm=s=>String(s).replace(/^HKCU:\\/i,'HKCU\\').replace(/^HKLM:\\/i,'HKLM\\').toLowerCase();
function resources(rule){
 const out=new Set();
 for(const e of rule.entries||[]){const p=norm(e.path);out.add('registry:'+p+'|'+String(e.name).toLowerCase());const m=p.match(/^hklm\\system\\(?:currentcontrolset|controlset\d+)\\services\\([^\\]+)/);if(m)out.add('service:'+m[1]);}
 const o=rule.operation;
 if(o?.type==='service')for(const s of o.services)out.add('service:'+s.name.toLowerCase());
 else if(o?.type==='bcd'){if(!Array.isArray(o.values)||!o.values.length)throw Error('Domeniu BCD necunoscut');for(const v of o.values){if(!v.object||!v.key)throw Error('Tinta BCD incompleta');out.add('native:bcd:'+String(v.object).toLowerCase()+'|'+String(v.key).toLowerCase())}}
 else if(o)out.add('native:'+o.type+':'+(o.type==='power-value'?o.subgroup+'|'+o.setting:o.type==='task'?o.taskPath+'|'+o.taskName:o.property||o.keyword||o.name||''));
 return [...out];
}
module.exports={norm,resources};
