#pragma once
// Original bounded flat-object protocol parser. No commands are evaluated.
#include <cctype>
#include <cstdint>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <variant>

namespace carpatia {
using Value=std::variant<std::string,std::int64_t,bool>;
using Object=std::map<std::string,Value>;
inline std::string quote(const std::string& value){
 std::string out="\"";const char* hex="0123456789abcdef";
 for(unsigned char c:value){if(c=='"'||c=='\\'){out+='\\';out+=static_cast<char>(c);}else if(c<32){out+="\\u00";out+=hex[c>>4];out+=hex[c&15];}else out+=static_cast<char>(c);}
 return out+'"';
}
class FlatParser {
 const std::string& input;std::size_t position=0;
 [[noreturn]] void bad(){throw std::runtime_error("Invalid flat JSON protocol.");}
 void space(){while(position<input.size()&&(input[position]==' '||input[position]=='\t'||input[position]=='\r'||input[position]=='\n'))++position;}
 bool take(char ch){space();if(position<input.size()&&input[position]==ch){++position;return true;}return false;}
 static int nibble(char ch){if(ch>='0'&&ch<='9')return ch-'0';if(ch>='a'&&ch<='f')return ch-'a'+10;if(ch>='A'&&ch<='F')return ch-'A'+10;return -1;}
 std::string string(){
  if(!take('"'))bad();
  std::string result;
  while(position<input.size()){
   unsigned char ch=input[position++];if(ch=='"')return result;if(ch<32)bad();
   if(ch=='\\'){
    if(position==input.size())bad();
    char escaped=input[position++];
    switch(escaped){case '"':case '\\':case '/':result+=escaped;break;case 'b':result+='\b';break;case 'f':result+='\f';break;case 'n':result+='\n';break;case 'r':result+='\r';break;case 't':result+='\t';break;
     case 'u':{
      if(position+4>input.size())bad();
      unsigned code=0;for(int i=0;i<4;i++){int n=nibble(input[position++]);if(n<0)bad();code=(code<<4)|static_cast<unsigned>(n);}
      if(code>=0xd800&&code<=0xdfff)bad();
      if(code<0x80)result+=static_cast<char>(code);else if(code<0x800){result+=static_cast<char>(0xc0|(code>>6));result+=static_cast<char>(0x80|(code&63));}else{result+=static_cast<char>(0xe0|(code>>12));result+=static_cast<char>(0x80|((code>>6)&63));result+=static_cast<char>(0x80|(code&63));}break;
     }
     default:bad();
    }
   }else result+=static_cast<char>(ch);
   if(result.size()>4096)bad();
  }
  bad();
 }
 Value value(){
  space();if(position==input.size())bad();if(input[position]=='"')return string();
  for(const auto& literal:{std::string("true"),std::string("false")})if(input.compare(position,literal.size(),literal)==0){position+=literal.size();return literal=="true";}
  bool negative=false;if(input[position]=='-'){negative=true;++position;}std::size_t begin=position;
  if(position==input.size()||!std::isdigit(static_cast<unsigned char>(input[position])))bad();
  if(input[position]=='0'&&position+1<input.size()&&std::isdigit(static_cast<unsigned char>(input[position+1])))bad();
  std::uint64_t number=0;
  while(position<input.size()&&std::isdigit(static_cast<unsigned char>(input[position]))){unsigned digit=input[position++]-'0';if(number>(static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())-digit)/10)bad();number=number*10+digit;}
  if(position==begin)bad();
  return negative?-static_cast<std::int64_t>(number):static_cast<std::int64_t>(number);
 }
public:
 explicit FlatParser(const std::string& text):input(text){if(input.size()>8192)bad();}
 Object parse(){Object result;if(!take('{'))bad();if(!take('}')){do{std::string key=string();if(!take(':')||result.count(key))bad();result.emplace(key,value());if(result.size()>16)bad();}while(take(','));if(!take('}'))bad();}space();if(position!=input.size())bad();return result;}
};
inline std::string text(const Object& object,const std::string& key){auto found=object.find(key);if(found==object.end()||!std::holds_alternative<std::string>(found->second))throw std::runtime_error("Missing or invalid string: "+key);return std::get<std::string>(found->second);}
inline int integer(const Object& object,const std::string& key){auto found=object.find(key);if(found==object.end()||!std::holds_alternative<std::int64_t>(found->second))throw std::runtime_error("Missing or invalid integer: "+key);auto number=std::get<std::int64_t>(found->second);if(number<0||number>10000)throw std::runtime_error("Integer outside supported range: "+key);return static_cast<int>(number);}
inline void exactKeys(const Object& object,std::initializer_list<const char*> required,std::initializer_list<const char*> optional={}){
 for(const auto* key:required)if(!object.count(key))throw std::runtime_error(std::string("Missing field: ")+key);
 for(const auto& item:object){bool known=false;for(const auto* key:required)known|=item.first==key;for(const auto* key:optional)known|=item.first==key;if(!known)throw std::runtime_error("Unknown field: "+item.first);}
}
inline std::string encode(const Object& object){std::string out="{";bool comma=false;for(const auto& item:object){if(comma)out+=',';comma=true;out+=quote(item.first)+':';if(auto value=std::get_if<std::string>(&item.second))out+=quote(*value);else if(auto value=std::get_if<std::int64_t>(&item.second))out+=std::to_string(*value);else out+=std::get<bool>(item.second)?"true":"false";}return out+'}';}
}
