@echo off
setlocal
cd /d "%~dp0"
where cl.exe >nul 2>&1
if errorlevel 1 (echo [ERROR] Use an x64 Native Tools Command Prompt for Visual Studio 2022 or newer. & exit /b 1)
if not defined ADLX_SDK_DIR (echo [ERROR] Set ADLX_SDK_DIR to your external, licensed AMD ADLX SDK directory. & exit /b 1)
if not exist "%ADLX_SDK_DIR%\SDK\Include\IGPUManualGFXTuning.h" (echo [ERROR] The external ADLX SDK headers were not found. & exit /b 1)
echo Read the external AMD ADLX SDK agreement and distribution requirements before building or distributing this adapter.
echo This project does not bundle AMD headers, samples, runtime DLLs or MSI code.
if not exist bin mkdir bin
cl.exe /nologo /std:c++17 /EHsc /W4 /DUNICODE /D_UNICODE /DNOMINMAX /DWIN32_LEAN_AND_MEAN policy_test.cpp /Fe:bin\policy-test.exe
if errorlevel 1 exit /b 1
bin\policy-test.exe
if errorlevel 1 exit /b 1
cl.exe /nologo /std:c++17 /EHsc /W4 /DUNICODE /D_UNICODE /DNOMINMAX /DWIN32_LEAN_AND_MEAN /I"%ADLX_SDK_DIR%\SDK\Include" main.cpp adlx_adapter.cpp /Fe:bin\carpatia-gpu-tuning.exe
if errorlevel 1 exit /b 1
echo [OK] Helper built. Real GPU query, limits, apply, readback and recovery still require validation on supported Windows AMD hardware.
endlocal
