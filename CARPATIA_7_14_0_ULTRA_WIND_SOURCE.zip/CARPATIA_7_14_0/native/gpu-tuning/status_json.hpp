#pragma once
#include "tuning_policy.hpp"

namespace carpatia {
inline std::string statusJson(const Snapshot& snapshot,const std::optional<Journal>& saved){
 if(saved)validateJournal(*saved,snapshot.gpuId);
 const bool supported=snapshot.supported,backup=saved&&saved->state!="restored";
 return std::string("{\"success\":true,\"available\":true,\"supported\":")+(supported?"true":"false")+",\"gpuId\":"+quote(snapshot.gpuId)+",\"name\":"+quote(snapshot.name)+",\"currentMhz\":"+(supported?std::to_string(snapshot.currentMhz):"null")+",\"minMhz\":"+(supported?std::to_string(snapshot.minMhz):"null")+",\"maxMhz\":"+(supported?std::to_string(snapshot.maxMhz):"null")+",\"stepMhz\":"+(supported?std::to_string(snapshot.stepMhz):"null")+",\"minOperatingMhz\":"+(supported?std::to_string(snapshot.minOperatingMhz):"null")+",\"originalMhz\":"+(saved?std::to_string(saved->originalMhz):"null")+",\"backup\":"+(backup?"true":"false")+",\"reason\":"+quote(snapshot.reason)+"}";
}
}
