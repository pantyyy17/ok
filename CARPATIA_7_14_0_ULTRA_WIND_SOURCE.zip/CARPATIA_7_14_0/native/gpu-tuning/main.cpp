#include "adlx_adapter.hpp"
#include "status_json.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#if defined(_WIN32)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif

namespace fs=std::filesystem;
namespace carpatia {
std::string readBounded(const fs::path& file){
 if(!fs::is_regular_file(file)||fs::is_symlink(file))throw std::runtime_error("Request or original must be a regular file.");
 std::ifstream input(file,std::ios::binary);if(!input)throw std::runtime_error("Request or original cannot be read.");
 std::string content(8193,'\0');input.read(content.data(),static_cast<std::streamsize>(content.size()));content.resize(static_cast<std::size_t>(input.gcount()));
 if(content.empty()||content.size()>8192||input.bad())throw std::runtime_error("Request or original is empty, oversized or unreadable.");
 return content;
}
std::string journalName(const std::string& id){
 // Hash selects a filename only. The complete PNP ID in the original is always
 // verified before any write; a collision is rejected, never treated as identity.
 std::uint64_t hash=14695981039346656037ULL;for(unsigned char ch:gpuIdentity(id)){hash^=ch;hash*=1099511628211ULL;}
 std::ostringstream output;output<<"gpu-"<<std::hex<<std::setw(16)<<std::setfill('0')<<hash;return output.str();
}
class FileStore final:public Store {
 fs::path file;
#if defined(_WIN32)
 HANDLE lock=INVALID_HANDLE_VALUE;
 static void noReparse(const fs::path& path){auto attributes=GetFileAttributesW(path.c_str());if(attributes!=INVALID_FILE_ATTRIBUTES&&(attributes&FILE_ATTRIBUTE_REPARSE_POINT))throw std::runtime_error("GPU original paths cannot be reparse points.");}
#endif
public:
 FileStore(const std::string& directory,const std::string& id){
  if(directory.empty()||directory.size()>4000||std::any_of(directory.begin(),directory.end(),[](unsigned char ch){return ch<32;}))throw std::runtime_error("GPU original directory is invalid.");
  auto root=fs::u8path(directory).lexically_normal();if(!root.is_absolute()||root==root.root_path())throw std::runtime_error("A dedicated absolute GPU original directory is required.");
#if defined(_WIN32)
  for(auto part=root;!part.empty();part=part.parent_path()){noReparse(part);if(part==part.parent_path())break;}
  fs::create_directories(root);noReparse(root);
  const auto filename=journalName(id);const fs::path lockPath=root/(filename+".lock");noReparse(lockPath);
  lock=CreateFileW(lockPath.c_str(),GENERIC_READ|GENERIC_WRITE,0,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(lock==INVALID_HANDLE_VALUE)throw std::runtime_error("GPU tuning is busy or its original directory is inaccessible.");
  file=root/(filename+".json");noReparse(file);
#else
  (void)id;throw std::runtime_error("Native GPU originals require Windows; no file was created.");
#endif
 }
 ~FileStore()override{
#if defined(_WIN32)
  if(lock!=INVALID_HANDLE_VALUE)CloseHandle(lock);
#endif
 }
 std::optional<Journal> read()override{
  if(!fs::exists(file))return std::nullopt;
  auto object=FlatParser(readBounded(file)).parse();exactKeys(object,{"version","gpuId","state","originalMhz","appliedMhz"});
  if(integer(object,"version")!=1)throw std::runtime_error("GPU original version is unknown.");
  return Journal{text(object,"gpuId"),text(object,"state"),integer(object,"originalMhz"),integer(object,"appliedMhz")};
 }
 void save(const Journal& value,bool first)override{
  const auto content=encode({{"version",std::int64_t(1)},{"gpuId",value.gpuId},{"state",value.state},{"originalMhz",std::int64_t(value.originalMhz)},{"appliedMhz",std::int64_t(value.appliedMhz)}});
#if defined(_WIN32)
  noReparse(file);const auto temporary=file.wstring()+L".new-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64());
  HANDLE handle=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,nullptr);
  if(handle==INVALID_HANDLE_VALUE)throw std::runtime_error("GPU original cannot be written; no new tuning is authorized.");
  DWORD written=0;bool okay=WriteFile(handle,content.data(),static_cast<DWORD>(content.size()),&written,nullptr)&&written==content.size()&&FlushFileBuffers(handle);CloseHandle(handle);
  if(!okay){DeleteFileW(temporary.c_str());throw std::runtime_error("GPU original could not be flushed to disk.");}
  DWORD flags=MOVEFILE_WRITE_THROUGH|(first?0:MOVEFILE_REPLACE_EXISTING);
  if(!MoveFileExW(temporary.c_str(),file.c_str(),flags)){DeleteFileW(temporary.c_str());throw std::runtime_error("GPU original could not be published atomically.");}
#else
  (void)content;(void)first;throw std::runtime_error("GPU originals are unavailable on this platform.");
#endif
 }
};
int execute(const fs::path& requestFile){
 const Object request=FlatParser(readBounded(requestFile)).parse();const auto action=text(request,"action");
 if(action=="query")exactKeys(request,{"action","backupDirectory"},{"gpuId"});
 else if(action=="apply")exactKeys(request,{"action","gpuId","mhz","expectedMhz","backupDirectory"});
 else if(action=="restore")exactKeys(request,{"action","gpuId","backupDirectory"});
 else throw std::runtime_error("Unknown GPU tuning action.");
 auto directory=text(request,"backupDirectory");std::string id=request.count("gpuId")?gpuIdentity(text(request,"gpuId")):std::string();
 // Validate all user values before asking the native driver for information.
 int mhz=0,expected=0;if(action=="apply"){mhz=integer(request,"mhz");expected=integer(request,"expectedMhz");}
 AdlxDriver driver;
 if(!driver.available()){
  if(action!="query")throw std::runtime_error(driver.reason());
  std::cout<<"{\"success\":true,\"available\":false,\"supported\":false,\"gpus\":[],\"reason\":"<<quote(driver.reason())<<"}\n";return 0;
 }
 if(action=="query"){
  if(!id.empty()){FileStore store(directory,id);std::cout<<statusJson(driver.read(id),store.read())<<'\n';return 0;}
  auto all=driver.list();std::string result="{\"success\":true,\"available\":true,\"supported\":";bool supported=false;for(const auto& gpu:all)supported|=gpu.supported;result+=supported?"true":"false";result+=",\"gpus\":[";
  bool comma=false;for(const auto& gpu:all){FileStore store(directory,gpu.gpuId);if(comma)result+=',';comma=true;result+=statusJson(gpu,store.read());}std::cout<<result<<"]}\n";return 0;
 }
 FileStore store(directory,id);Outcome outcome=action=="apply"?apply(driver,store,id,mhz,expected):restore(driver,store,id);
 std::cout<<encode({{"success",outcome.success},{"changed",outcome.changed},{"backup",outcome.backup},{"rollbackRestored",outcome.rollbackRestored},{"message",outcome.message}})<<'\n';return outcome.success?0:1;
}
}
#if defined(_WIN32)
int wmain(int argc,wchar_t** argv){
#else
int main(int argc,char** argv){
#endif
 try{
#if defined(_WIN32)
  if(argc!=3||std::wstring(argv[1])!=L"--request-file")throw std::runtime_error("Use --request-file with a bounded JSON request.");
#else
  if(argc!=3||std::string(argv[1])!="--request-file")throw std::runtime_error("Use --request-file with a bounded JSON request.");
#endif
  const fs::path requestFile(argv[2]);if(!requestFile.is_absolute())throw std::runtime_error("An absolute request-file path is required.");
  return carpatia::execute(requestFile);
 }catch(const std::exception& error){std::cout<<"{\"success\":false,\"message\":"<<carpatia::quote(error.what())<<"}\n";return 1;}
}
