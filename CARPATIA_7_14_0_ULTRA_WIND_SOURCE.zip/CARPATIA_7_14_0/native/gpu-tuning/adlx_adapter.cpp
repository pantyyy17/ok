#include "adlx_adapter.hpp"
// Linux builds check API spelling/types only. These substitutions do not test
// the Windows ABI, load a driver, or make GPU control available on Linux.
#if !defined(_WIN32)
#define ADLX_STD_CALL
#define ADLX_CDECL_CALL
#define ADLX_FAST_CALL
#define ADLX_INLINE inline
#define ADLX_FORCEINLINE inline
#define ADLX_NO_VTABLE
#define ADLX_CORE_LINK
using TCHAR=wchar_t;
#endif
#include <ADLX.h>
#include <IGPUTuning.h>
#include <IGPUManualGFXTuning.h>
#include <utility>

namespace carpatia {
namespace {
template<class T>class Reference {
 T* pointer=nullptr;
public:
 Reference()=default;Reference(const Reference&)=delete;Reference& operator=(const Reference&)=delete;
 Reference(Reference&& other)noexcept:pointer(other.pointer){other.pointer=nullptr;}
 ~Reference(){if(pointer)pointer->Release();}
 T* get()const{return pointer;}T* operator->()const{return pointer;}
 T** output(){if(pointer){pointer->Release();pointer=nullptr;}return &pointer;}
};
void checked(ADLX_RESULT result,const char* operation){if(result!=ADLX_OK)throw std::runtime_error(std::string(operation)+" failed (ADLX "+std::to_string(static_cast<int>(result))+"). No factory reset is performed.");}
struct Device {
 Reference<adlx::IADLXGPU> gpu;
 Reference<adlx::IADLXManualGraphicsTuning2_1> clock;
 Snapshot snapshot;
};
}
struct AdlxDriver::Implementation {
 adlx::IADLXSystem* system=nullptr;
 Reference<adlx::IADLXGPUTuningServices> tuning;
 bool initialized=false;std::string failure;
#if defined(_WIN32)
 HMODULE library=nullptr;ADLXTerminate_Fn terminate=nullptr;
#endif
 Implementation(){
#if defined(_WIN32)
  static_assert(sizeof(void*)==8,"Only the Windows x64 ADLX driver is supported.");
  wchar_t directory[32768];UINT length=GetSystemDirectoryW(directory,32768);
  if(!length||length>=32768){failure="Windows system directory is unavailable.";return;}
  const auto filename=std::wstring(directory,length)+L"\\amdadlx64.dll";
  library=LoadLibraryExW(filename.c_str(),nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);
  if(!library){failure="The official AMD ADLX driver is not installed in Windows System32.";return;}
  auto initialize=reinterpret_cast<ADLXInitialize_Fn>(GetProcAddress(library,ADLX_INIT_FUNCTION_NAME));
  terminate=reinterpret_cast<ADLXTerminate_Fn>(GetProcAddress(library,ADLX_TERMINATE_FUNCTION_NAME));
  if(!initialize||!terminate){failure="The installed AMD driver does not expose the documented ADLX interface.";return;}
  if(initialize(ADLX_FULL_VERSION,&system)!=ADLX_OK||!system){failure="The installed AMD driver is incompatible with this ADLX SDK build.";system=nullptr;return;}
  initialized=true;
  if(system->GetGPUTuningServices(tuning.output())!=ADLX_OK||!tuning.get())failure="The AMD driver does not provide GPU tuning services.";
#else
  failure="Native hardware tuning requires a separately built Windows x64 helper and a supported AMD driver.";
#endif
 }
 ~Implementation(){
  // Release every reference before ADLXTerminate and FreeLibrary.
  tuning.output();
#if defined(_WIN32)
  if(initialized&&terminate)terminate();if(library)FreeLibrary(library);
#endif
 }
 Device inspect(adlx::IADLXGPUList* gpus,adlx_uint index){
  Device result;checked(gpus->At(index,result.gpu.output()),"GPU enumeration");if(!result.gpu.get())throw std::runtime_error("AMD returned an empty GPU interface.");
  const char *name=nullptr,*identity=nullptr,*vendor=nullptr;
  checked(result.gpu->Name(&name),"GPU name");checked(result.gpu->PNPString(&identity),"GPU identity");checked(result.gpu->VendorId(&vendor),"GPU vendor");
  result.snapshot.name=name?std::string(name):"AMD GPU";result.snapshot.gpuId=gpuIdentity(identity?std::string(identity):std::string());
  if(!vendor||std::string(vendor)!="1002"){result.snapshot.reason="Only AMD hardware is supported by this adapter.";return result;}
  adlx_bool supported=false;
  if(!tuning.get()||tuning->IsSupportedManualGFXTuning(result.gpu.get(),&supported)!=ADLX_OK||!supported){result.snapshot.reason="This GPU, laptop firmware or driver does not expose manual graphics tuning.";return result;}
  Reference<adlx::IADLXInterface> generic;checked(tuning->GetManualGFXTuning(result.gpu.get(),generic.output()),"Manual tuning query");
  if(!generic.get()||generic->QueryInterface(adlx::IADLXManualGraphicsTuning2_1::IID(),reinterpret_cast<void**>(result.clock.output()))!=ADLX_OK||!result.clock.get()){
   result.snapshot.reason="A verified absolute-frequency interface is not available; older and unknown tuning interfaces are not used.";return result;
  }
  adlx_int factoryMaximum=0;ADLX_IntRange range{};
  checked(result.clock->GetGPUMaxFrequencyDefault(&factoryMaximum),"Default maximum frequency");
  checked(result.clock->GetGPUMaxFrequencyRange(&range),"Maximum frequency range");
  checked(result.clock->GetGPUMaxFrequency(&result.snapshot.currentMhz),"Current maximum frequency");
  checked(result.clock->GetGPUMinFrequency(&result.snapshot.minOperatingMhz),"Current minimum frequency");
  if(factoryMaximum<=0||range.minValue<=0||result.snapshot.minOperatingMhz<=0){result.snapshot.reason="Offset-based GPU clocks (including newer Navi generations) are not supported by this absolute-MHz adapter.";return result;}
  result.snapshot.minMhz=range.minValue;result.snapshot.maxMhz=range.maxValue;result.snapshot.stepMhz=range.step;result.snapshot.supported=true;
  try{validateTarget(result.snapshot,result.snapshot.currentMhz);}catch(const std::exception& error){result.snapshot.supported=false;result.snapshot.reason=error.what();}
  return result;
 }
 std::vector<Device> devices(){
  if(!initialized||!system||!tuning.get())throw std::runtime_error(failure.empty()?"ADLX tuning is unavailable.":failure);
  Reference<adlx::IADLXGPUList> gpus;checked(system->GetGPUs(gpus.output()),"GPU list");if(!gpus.get()||gpus->Size()>32)throw std::runtime_error("AMD returned an invalid GPU inventory.");
  std::vector<Device> result;for(adlx_uint i=gpus->Begin();i<gpus->End();++i)result.push_back(inspect(gpus.get(),i));return result;
 }
 Device selected(const std::string& identity){
  auto id=gpuIdentity(identity);auto all=devices();std::optional<Device> found;
  for(auto& item:all)if(item.snapshot.gpuId==id){if(found)throw std::runtime_error("GPU identity is ambiguous; no write permitted.");found.emplace(std::move(item));}
  if(!found)throw std::runtime_error("The selected physical GPU is not available.");
  return std::move(*found);
 }
};
AdlxDriver::AdlxDriver():implementation(std::make_unique<Implementation>()){}
AdlxDriver::~AdlxDriver()=default;
bool AdlxDriver::available()const{return implementation->initialized&&implementation->tuning.get();}
std::string AdlxDriver::reason()const{return implementation->failure;}
std::vector<Snapshot> AdlxDriver::list(){std::vector<Snapshot> result;for(auto& device:implementation->devices())result.push_back(std::move(device.snapshot));return result;}
Snapshot AdlxDriver::read(const std::string& id){return implementation->selected(id).snapshot;}
void AdlxDriver::setMaximum(const std::string& id,int mhz,int expectedMhz){auto device=implementation->selected(id);validateTarget(device.snapshot,mhz);if(device.snapshot.currentMhz!=expectedMhz)throw std::runtime_error("GPU clock changed before the driver write; original retained.");checked(device.clock->SetGPUMaxFrequency(mhz),"Set maximum graphics frequency");}
}
