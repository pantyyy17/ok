#pragma once
// Original maximum-clock-only transaction policy. No vendor code or voltages.
#include "flat_json.hpp"
#include <optional>
#include <string>
#include <vector>

namespace carpatia {
inline std::string gpuIdentity(std::string value){
 if(value.empty()||value.size()>512)throw std::runtime_error("GPU identity is missing or too long.");
 for(char& ch:value){auto byte=static_cast<unsigned char>(ch);if(byte<33||byte>126)throw std::runtime_error("GPU identity is invalid.");ch=static_cast<char>(std::toupper(byte));}return value;
}
struct Snapshot {std::string gpuId,name,reason;bool supported=false;int currentMhz=0,minMhz=0,maxMhz=0,stepMhz=0,minOperatingMhz=0;};
inline void validateSnapshot(const Snapshot& value){
 gpuIdentity(value.gpuId);
 if(!value.supported||value.minMhz<=0||value.maxMhz<value.minMhz||value.maxMhz>10000||value.stepMhz<=0||value.stepMhz>10000||value.minOperatingMhz<0||value.minOperatingMhz>value.maxMhz||value.currentMhz<value.minMhz||value.currentMhz>value.maxMhz)throw std::runtime_error("Driver tuning capability is unavailable or incomplete.");
}
inline void validateTarget(const Snapshot& current,int mhz){validateSnapshot(current);if(mhz<current.minMhz||mhz>current.maxMhz||mhz<current.minOperatingMhz||(mhz-current.minMhz)%current.stepMhz)throw std::runtime_error("Clock does not match the current driver range and step.");}
struct Journal {std::string gpuId,state;int originalMhz=0,appliedMhz=0;};
inline void validateJournal(const Journal& value,const std::string& expected){
 if(gpuIdentity(value.gpuId)!=gpuIdentity(expected)||value.originalMhz<=0||value.appliedMhz<=0||value.originalMhz>10000||value.appliedMhz>10000||(value.state!="prepared"&&value.state!="applied"&&value.state!="apply-failed"&&value.state!="restore-failed"&&value.state!="restored"))throw std::runtime_error("Saved GPU original is invalid; preserve it for recovery.");
}
struct Driver {virtual ~Driver()=default;virtual std::vector<Snapshot> list()=0;virtual Snapshot read(const std::string& gpuId)=0;virtual void setMaximum(const std::string& gpuId,int mhz,int expectedMhz)=0;};
struct Store {virtual ~Store()=default;virtual std::optional<Journal> read()=0;virtual void save(const Journal& value,bool first)=0;};
struct Outcome {bool success=false,changed=false,backup=false,rollbackRestored=false;std::string message;};
inline Outcome apply(Driver& driver,Store& store,const std::string& id,int requested,int expected){
 const std::string gpuId=gpuIdentity(id);Snapshot before=driver.read(gpuId);validateTarget(before,requested);validateTarget(before,before.currentMhz);
 if(gpuIdentity(before.gpuId)!=gpuId)throw std::runtime_error("Selected GPU changed.");
 if(before.currentMhz!=expected)throw std::runtime_error("GPU clock changed after preview; confirm a new query.");
 auto previous=store.read();if(previous){validateJournal(*previous,gpuId);if(previous->state!="restored")throw std::runtime_error("Restore the existing GPU original before another write.");}
 if(requested==before.currentMhz)return {true,false,false,false,"Clock was already configured; no write or original created."};
 Journal journal{gpuId,"prepared",before.currentMhz,requested};store.save(journal,!previous.has_value());
 try{
  driver.setMaximum(gpuId,requested,before.currentMhz);auto after=driver.read(gpuId);validateSnapshot(after);
  if(gpuIdentity(after.gpuId)!=gpuId||after.currentMhz!=requested)throw std::runtime_error("Driver did not confirm the requested maximum clock.");
  journal.state="applied";store.save(journal,false);return {true,true,true,false,"Maximum clock was read back; original retained."};
 }catch(const std::exception& error){
  bool restored=false;
  try{auto current=driver.read(gpuId);validateSnapshot(current);if(gpuIdentity(current.gpuId)==gpuId&&(current.currentMhz==requested||current.currentMhz==journal.originalMhz)){
    if(current.currentMhz!=journal.originalMhz){validateTarget(current,journal.originalMhz);driver.setMaximum(gpuId,journal.originalMhz,current.currentMhz);}
    auto checked=driver.read(gpuId);restored=gpuIdentity(checked.gpuId)==gpuId&&checked.currentMhz==journal.originalMhz;
  }}catch(...){}
  journal.state=restored?"restored":"apply-failed";bool journalSaved=false;try{store.save(journal,false);journalSaved=true;}catch(...){}
  return {false,true,!(restored&&journalSaved),restored,std::string(error.what())+(restored?" Original clock restored.":" Original retained; manual recovery is required.")};
 }
}
inline Outcome restore(Driver& driver,Store& store,const std::string& id){
 const auto gpuId=gpuIdentity(id);auto previous=store.read();if(!previous)throw std::runtime_error("No saved GPU original.");validateJournal(*previous,gpuId);auto journal=*previous;
 if(journal.state=="restored")return {true,false,false,false,"Original was already restored."};
 auto current=driver.read(gpuId);validateTarget(current,journal.originalMhz);
 if(gpuIdentity(current.gpuId)!=gpuId||(current.currentMhz!=journal.originalMhz&&current.currentMhz!=journal.appliedMhz))throw std::runtime_error("GPU settings changed externally; original retained.");
 try{
  const bool changed=current.currentMhz!=journal.originalMhz;if(changed)driver.setMaximum(gpuId,journal.originalMhz,current.currentMhz);
  auto checked=driver.read(gpuId);validateSnapshot(checked);if(gpuIdentity(checked.gpuId)!=gpuId||checked.currentMhz!=journal.originalMhz)throw std::runtime_error("Driver did not confirm restoration.");
  journal.state="restored";store.save(journal,false);return {true,changed,false,true,"Original maximum clock was read back."};
 }catch(...){journal.state="restore-failed";try{store.save(journal,false);}catch(...){}throw;}
}
}
