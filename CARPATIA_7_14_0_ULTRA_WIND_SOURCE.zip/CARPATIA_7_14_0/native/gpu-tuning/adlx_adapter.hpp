#pragma once
#include "tuning_policy.hpp"
#include <memory>

namespace carpatia {
// The implementation includes externally supplied AMD headers at build time.
// No SDK headers, sample implementations or AMD DLLs are redistributed here.
class AdlxDriver final:public Driver {
 struct Implementation;std::unique_ptr<Implementation> implementation;
public:
 AdlxDriver();~AdlxDriver() override;
 bool available()const;std::string reason()const;
 std::vector<Snapshot> list() override;
 Snapshot read(const std::string& gpuId) override;
 void setMaximum(const std::string& gpuId,int mhz,int expectedMhz) override;
};
}
