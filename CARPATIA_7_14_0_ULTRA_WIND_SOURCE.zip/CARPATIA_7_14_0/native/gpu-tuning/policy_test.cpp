#include "tuning_policy.hpp"
#include "status_json.hpp"
#include <iostream>
#include <functional>
using namespace carpatia;
namespace {
int assertions=0;
void require(bool value,const char* label){if(!value)throw std::runtime_error(label);++assertions;}
void rejected(const std::function<void()>& fn,const char* label){bool failed=false;try{fn();}catch(const std::exception&){failed=true;}require(failed,label);}
struct FakeDriver:Driver {
 Snapshot current{"PCI\\VEN_1002&DEV_TEST","Test GPU","",true,2000,500,3000,10,500};
 std::vector<int> writes;bool ignoreNext=false,driftNext=false,failAfterWrite=false,externalChangeBeforeWrite=false;
 std::vector<Snapshot> list()override{return {current};}
 Snapshot read(const std::string&)override{return current;}
 void setMaximum(const std::string&,int mhz,int expectedMhz)override{if(externalChangeBeforeWrite){externalChangeBeforeWrite=false;current.currentMhz=2500;}if(current.currentMhz!=expectedMhz)throw std::runtime_error("External clock changed before write");writes.push_back(mhz);if(ignoreNext){ignoreNext=false;return;}current.currentMhz=driftNext?2400:mhz;driftNext=false;if(failAfterWrite){failAfterWrite=false;throw std::runtime_error("Driver reply interrupted");}}
};
struct FakeStore:Store {
 std::optional<Journal> original;int saves=0,failOn=0;
 std::optional<Journal> read()override{return original;}
 void save(const Journal& value,bool first)override{++saves;if(saves==failOn)throw std::runtime_error("Disk write failed");if(first&&original)throw std::runtime_error("Concurrent original exists");original=value;}
};
}
int main(){try{
 for(const std::string& bad:std::vector<std::string>{"[]","{\"action\":\"query\",\"action\":\"restore\"}","{\"mhz\":1.5}","{\"mhz\":1e3}","{\"mhz\":01}","{\"mhz\":999999999999999999999999999}","{\"x\":null}","{\"x\":{}}","{} trailing",std::string("\v{}")})rejected([&]{FlatParser(bad).parse();},"Malformed protocol was accepted");
 auto parsed=FlatParser("{\"action\":\"apply\",\"mhz\":2100,\"gpuId\":\"PCI\\\\VEN_1002\"}").parse();require(integer(parsed,"mhz")==2100,"Integer parsing failed");require(text(parsed,"gpuId")=="PCI\\VEN_1002","GPU identity escaping failed");
 rejected([&]{integer(FlatParser("{\"mhz\":true}").parse(),"mhz");},"Boolean became a frequency");
 rejected([&]{exactKeys(parsed,{"action","mhz"});},"Unknown fields were accepted");
 rejected([&]{gpuIdentity("GPU\nOTHER");},"Control characters entered a GPU identity");
 require(FlatParser(encode({{"text",std::string("name\"\\value")}})).parse()==Object{{"text",std::string("name\"\\value")}},"Protocol string round trip failed");
 {
  FakeDriver driver;FakeStore store;auto result=apply(driver,store,driver.current.gpuId,2100,2000);
  require(result.success&&result.changed&&result.backup,"Verified Apply failed");require(store.original&&store.original->originalMhz==2000&&store.original->state=="applied","Original was lost");
  auto restored=restore(driver,store,driver.current.gpuId);require(restored.success&&driver.current.currentMhz==2000&&store.original->state=="restored","Exact restore failed");
 }
 for(int target:{499,3001,2101}){FakeDriver driver;FakeStore store;rejected([&]{apply(driver,store,driver.current.gpuId,target,2000);},"Driver range or step was ignored");require(driver.writes.empty()&&!store.original,"Invalid target caused a write");}
 for(int original:{2001,490}){FakeDriver driver;FakeStore store;driver.current.currentMhz=original;rejected([&]{apply(driver,store,driver.current.gpuId,2100,original);},"Unrestorable original was saved");require(driver.writes.empty()&&!store.original,"Unrestorable original caused a write");}
 {
  FakeDriver driver;FakeStore store;driver.current.minOperatingMhz=2200;rejected([&]{apply(driver,store,driver.current.gpuId,2300,2000);},"Original below minimum operating clock was saved");require(driver.writes.empty()&&!store.original,"Original below minimum operating clock caused a write");
 }
 {
  FakeDriver driver;FakeStore store;store.failOn=1;rejected([&]{apply(driver,store,driver.current.gpuId,2100,2000);},"Original write failure was ignored");require(driver.writes.empty(),"Hardware changed before original was durable");
 }
 {
  FakeDriver driver;FakeStore store;rejected([&]{apply(driver,store,driver.current.gpuId,2100,1900);},"Stale confirmation changed hardware");require(driver.writes.empty(),"Stale confirmation caused a write");
  rejected([&]{apply(driver,store,"PCI\\OTHER",2100,2000);},"Wrong GPU identity was accepted");
 }
 {
  FakeDriver driver;FakeStore store;store.original=Journal{driver.current.gpuId,"applied",1900,2000};rejected([&]{apply(driver,store,driver.current.gpuId,2100,2000);},"Existing original was overwritten");require(driver.writes.empty()&&store.original->originalMhz==1900,"Existing original changed");
 }
 {
  FakeDriver driver;FakeStore store;auto result=apply(driver,store,driver.current.gpuId,2000,2000);require(result.success&&!result.changed&&driver.writes.empty()&&!store.original,"Already matching value invented a backup");
 }
 {
  FakeDriver driver;FakeStore store;driver.ignoreNext=true;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&result.rollbackRestored&&driver.current.currentMhz==2000,"False native success was accepted");require(!result.backup&&store.original->state=="restored","Durably restored status reported an active original");
 }
 {
  FakeDriver driver;FakeStore store;driver.ignoreNext=true;store.failOn=2;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&result.rollbackRestored&&result.backup&&store.original->state=="prepared","Unpersisted restoration hid the retained original");
 }
 {
  FakeDriver driver;FakeStore store;store.failOn=2;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&result.rollbackRestored&&driver.current.currentMhz==2000,"Final journal write failure did not restore original");
 }
 {
  FakeDriver driver;FakeStore store;driver.failAfterWrite=true;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&result.rollbackRestored&&driver.current.currentMhz==2000,"Partial driver failure did not restore original");
 }
 {
  FakeDriver driver;FakeStore store;driver.driftNext=true;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&!result.rollbackRestored&&driver.current.currentMhz==2400&&store.original->state=="apply-failed","External drift was overwritten during rollback");
  auto count=driver.writes.size();rejected([&]{restore(driver,store,driver.current.gpuId);},"External drift was overwritten during restore");require(driver.writes.size()==count,"Restore wrote over an external value");
 }
 {
  FakeDriver driver;FakeStore store;driver.externalChangeBeforeWrite=true;auto result=apply(driver,store,driver.current.gpuId,2100,2000);require(!result.success&&!result.rollbackRestored&&driver.current.currentMhz==2500,"External change before native write was overwritten");require(driver.writes.empty()&&store.original->originalMhz==2000,"Guarded write did not preserve the original");
 }
 {
  FakeDriver driver;FakeStore store;store.original=Journal{"PCI\\OTHER","applied",2000,2100};rejected([&]{restore(driver,store,driver.current.gpuId);},"Foreign original was accepted");require(driver.writes.empty(),"Foreign original wrote hardware");
 }
 {
  FakeDriver driver;FakeStore store;driver.current.supported=false;rejected([&]{apply(driver,store,driver.current.gpuId,2100,2000);},"Unsupported hardware was written");
  driver.current.supported=true;driver.current.minMhz=-1000;driver.current.currentMhz=0;rejected([&]{apply(driver,store,driver.current.gpuId,100,0);},"Offset interface was treated as absolute frequency");
 }
 {
  FakeDriver driver;
  require(statusJson(driver.current,std::nullopt).find("\"originalMhz\":null")!=std::string::npos,"Missing original was not represented as null");
  auto active=Journal{driver.current.gpuId,"applied",1900,2000};auto status=statusJson(driver.current,active);
  require(status.find("\"originalMhz\":1900")!=std::string::npos&&status.find("\"backup\":true")!=std::string::npos,"Active original was absent from query status");
  active.state="restored";status=statusJson(driver.current,active);
  require(status.find("\"originalMhz\":1900")!=std::string::npos&&status.find("\"backup\":false")!=std::string::npos,"Restored journal lost its exact original frequency");
  driver.current.supported=false;status=statusJson(driver.current,active);
  require(status.find("\"originalMhz\":1900")!=std::string::npos&&status.find("\"currentMhz\":null")!=std::string::npos,"Unsupported GPU hid the retained journal frequency");
  active.gpuId="PCI\\OTHER";rejected([&]{statusJson(driver.current,active);},"Foreign journal frequency was exposed in status");
 }
 std::cout<<"{\"success\":true,\"assertions\":"<<assertions<<",\"scope\":\"Original policy with fake driver/store; no native GPU writes.\"}\n";return 0;
 }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
