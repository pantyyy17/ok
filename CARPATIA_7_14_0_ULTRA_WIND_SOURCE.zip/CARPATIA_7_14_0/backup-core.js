'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {snapshotRows,hash}=require('./snapshot-core');
// Capture only: this service never applies or restores a Windows setting.
function createManualSnapshot({dataDir,backupDir,catalog,ruleFor,identity,context,read,save,notify=()=>{},now=Date.now,uuid=crypto.randomUUID,copy=fs.cpSync}){
 return async function capture(){
  const id=uuid(),date=new Date(now()).toISOString(),root=path.join(dataDir(),'recovery-snapshots',id);
  const report={id,type:'manual-snapshot',date,state:'running',success:false,restorable:false,results:[]};
  const manifest={version:2,id,date,identity:null,complete:false,files:[]},captures=[];
  const persist=()=>{save(path.join(dataDir(),'recovery-reports',id+'.json'),report);try{notify({phase:'capture',detail:`${report.results.filter(r=>r.status==='captured').length} capturi salvate · ${report.results.filter(r=>r.status==='failed').length} erori`})}catch{}};
  persist();
  try{
   const host=await identity();if(typeof host!=='string'||!/^[a-f0-9]{64}$/.test(host))throw Error('Identitatea Windows este invalidă.');manifest.identity=host;save(path.join(root,'manifest.json'),manifest);
   let adapters=[];
   try{
    const c=await context();if(c?.success!==true||!Array.isArray(c.adapters))throw Error(c?.message||'Adaptoare indisponibile.');
    const seen=new Set();
    for(const adapter of c.adapters){
     if(typeof adapter?.guid!=='string'||!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(adapter.guid))throw Error('Identitate de adaptor invalidă.');
     const guid=adapter.guid.replace(/^\{(.+)\}$/,'$1').toLowerCase();if(!seen.has(guid)){seen.add(guid);adapters.push({...adapter,guid})}
    }
   }catch(e){adapters=[];report.results.push({title:'Inventar adaptoare',status:'failed',message:e.message})}
   for(const item of catalog()){
    if(!['registry','native'].includes(item.status)||item.applyBlocked){report.results.push({title:item.title,status:'skipped',message:item.applyBlocked||'Operație fără stare reversibilă.'});continue}
    const rule=ruleFor(item.id),targets=['dns','mtu','ipv6','nic-power','nic-advanced'].includes(rule.operation?.type)?adapters:[{guid:''}];
    if(!targets.length)report.results.push({title:item.title,category:item.category,status:'skipped',message:'Niciun adaptor disponibil pentru captură.'});
    for(const adapter of targets){
     try{
      const result=await read(item.id,adapter.guid);
      if(result.notApplicable){report.results.push({title:item.title,category:item.category,status:'skipped',message:result.message});continue}
      if(result.success!==true||result.current===undefined)throw Error(result.message||'Citire incompletă.');
      const capture={id:item.id,date,adapterGuid:adapter.guid,...result};snapshotRows([...captures,capture]);
      const name=item.id+(adapter.guid?'-'+adapter.guid.replace(/[^a-f0-9-]/gi,''):'')+'.json';save(path.join(root,name),capture);
      manifest.files.push({name,sha256:hash(fs.readFileSync(path.join(root,name),'utf8'))});save(path.join(root,'manifest.json'),manifest);
      captures.push(capture);
      report.results.push({title:item.title,category:item.category,adapter:adapter.name,status:'captured'});
     }catch(e){report.results.push({title:item.title,category:item.category,status:'failed',message:e.message})}
     persist();
    }
   }
   for(const [label,source] of [['registry',path.join(dataDir(),'tweak-library-backups')],['native',path.join(dataDir(),'tweak-native-backups')],['profiles',path.join(dataDir(),'dashboard-profiles')],['legacy',backupDir()]])if(fs.existsSync(source)){
    try{copy(source,path.join(root,label),{recursive:true,errorOnExist:true,force:false})}catch(e){report.results.push({title:'Originale '+label,status:'failed',message:e.message})}
   }
  }catch(e){report.results.push({title:'Creare copie',status:'failed',message:e.message})}
  report.captured=report.results.filter(r=>r.status==='captured').length;report.failed=report.results.filter(r=>r.status==='failed').length;report.skipped=report.results.filter(r=>r.status==='skipped').length;
  report.restorable=report.captured>0;report.success=report.restorable&&report.failed===0;
  report.state=report.success?'complete':report.restorable?'partial':'failed';manifest.complete=report.success;
  if(manifest.identity)save(path.join(root,'manifest.json'),manifest);
  report.message=`${report.captured} capturi salvate · ${report.failed} erori · ${report.skipped} omise. Originalele automate sunt păstrate.`;
  persist();return report;
 };
}
module.exports={createManualSnapshot};
