# GPU maximum-clock helper

CARPATIA includes original source for an optional AMD ADLX adapter. It does not
contain MSI Afterburner code, undocumented driver interfaces, a kernel driver,
AMD SDK headers, an AMD DLL, or a prebuilt hardware-control executable.

The only hardware setter is the documented `SetGPUMaxFrequency` method. Voltage,
memory clocks, power limits, minimum clocks, fans and thermal protections are
left to the installed driver. No factory reset is requested. Automatic tuning
modes which require a reset return an error instead.

## Support and validation status

The source uses `IADLXManualGraphicsTuning2_1`. It requires an AMD GPU which
exposes manual graphics tuning, a positive factory maximum, a positive minimum
frequency range and a positive minimum operating clock. Offset-based frequency
interfaces, including the documented newer Navi offset semantics, are rejected.
Clocks above 10,000 MHz and incomplete or unrestorable driver ranges are rejected.
This adapter does not implement NVIDIA or Intel overclocking. Laptop/APU support
depends on what the actual driver and firmware expose; it is never inferred from
a product name.

The policy is tested with a fake driver and store on Linux. The adapter also
compiles against the official external ADLX 2.0.0.125 headers, revision
`32b5a740d42295c5dfe9026b9f52683da0f3af91`, using Linux calling-convention shims.
That check validates API spelling and C++ types; it does not validate the Windows
ABI. Windows/MSVC compilation, real GPU queries, limits, persistence, readback,
restoration, stability and performance still require Windows hardware validation.
No FPS or stability improvement has been measured. Without the separately built
helper and a supported driver, CARPATIA must show tuning as unavailable.

## External SDK and Windows build

Obtain the [official AMD ADLX SDK](https://github.com/GPUOpen-LibrariesAndSDKs/ADLX)
separately. Read its `ADLX SDK License Agreement.pdf` before building or
distributing the adapter. The agreement is not an MIT license: sections 2(c)
and 3 impose object-code distribution and end-user agreement requirements for
covered SDK material and derivative works. This source package does not resolve
commercial distribution or EULA obligations. Review those obligations before a
commercial release; do not add the SDK headers, sample sources, PDF or driver DLL
to the CARPATIA source ZIP.

In a Windows x64 Native Tools Command Prompt for Visual Studio 2022 or newer:

```bat
set "ADLX_SDK_DIR=C:\external\ADLX"
native\gpu-tuning\build-windows.bat
```

The script runs only fake-driver policy tests, then builds
`native/gpu-tuning/bin/carpatia-gpu-tuning.exe`. It never runs hardware tuning.
The executable loads the installed `amdadlx64.dll` from Windows System32 using
`LoadLibraryExW` with `LOAD_LIBRARY_SEARCH_SYSTEM32`. It does not search the
application directory, download a runtime or install a driver.

## Fixed request protocol

The trusted main process writes a bounded JSON request in its data directory and
invokes the fixed helper executable with `--request-file ABSOLUTE_REQUEST_PATH`.
Never accept a helper executable path, request path, backup directory or action
from renderer input. Actions and fields are allowlisted; duplicate fields,
unknown fields, nested objects, arrays, null, floating-point frequencies and
out-of-range integers are rejected. GPU identities are canonical full PNP IDs,
not a changing enumeration index. The application should query again after each
operation, including failed operations.

```json
{"action":"query","backupDirectory":"C:\\fixed-app-data\\gpu-originals"}
```

Query returns `success`, `available`, `supported`, and a `gpus` array. Each row
contains `gpuId`, `name`, `supported`, `currentMhz`, `minMhz`, `maxMhz`, `stepMhz`,
`minOperatingMhz`, `originalMhz`, `backup` and `reason`. Unsupported live clock
values are null. `originalMhz` is the integer from a validated saved journal,
including after restoration and when live tuning is unsupported; it is null
when no journal exists. The application can independently confirm restoration
by comparing a supported live `currentMhz` with that retained `originalMhz` and
checking `backup:false`. Optional `gpuId` selects one exact GPU and returns its
row directly.

```json
{"action":"apply","gpuId":"FULL_PNP_ID_FROM_QUERY","mhz":2100,"expectedMhz":2000,"backupDirectory":"C:\\fixed-app-data\\gpu-originals"}
```

`mhz` and `expectedMhz` must be integer MHz; these numbers are protocol examples,
not recommended clocks. The selected target must satisfy the current driver
range, step and minimum operating frequency. `expectedMhz` must still match the
current maximum after preview and immediately before the native setter. The
original maximum must itself be restorable. The UI must require explicit user
confirmation; no profile or startup task should apply overclocking automatically.

```json
{"action":"restore","gpuId":"FULL_PNP_ID_FROM_QUERY","backupDirectory":"C:\\fixed-app-data\\gpu-originals"}
```

Apply/restore return `success`, `changed`, `backup`, `rollbackRestored` and
`message`. An error before the transaction returns `success:false` and a message.
An unsuccessful operation exits with code 1; still parse its JSON diagnostics.

## Original and rollback behavior

A per-GPU exclusive lock serializes this helper. Before the setter, the helper
flushes the original maximum to a versioned journal and publishes it with an
atomic Windows rename. Existing active originals cannot be replaced. Completed
restoration keeps the original journal and marks it restored; the next explicit
apply may start a new transaction. The complete GPU identity is checked inside
the journal even though a hash is used for its filename. Existing reparse paths
are rejected; the trusted main process must control the original directory.

The requested maximum is read back. Failure attempts restoration only while the
current maximum still equals the original or this transaction's requested value.
If an external utility changed it, the helper preserves both that setting and
the journal. The driver API offers no atomic cross-application transaction: do
not run another tuning utility concurrently. Interrupted processes and driver
resets can leave a prepared journal; restoration is always explicit. A retained
journal does not guarantee recovery after a hardware failure or OS crash.

## Reproduce the portable checks

From the CARPATIA source directory, with a C++17 compiler:

```sh
g++ -std=c++17 -Wall -Wextra -Werror native/gpu-tuning/policy_test.cpp -o /tmp/carpatia-gpu-policy-test
/tmp/carpatia-gpu-policy-test
node --test tests/native-gpu-policy.test.js
g++ -std=c++17 -Wall -Wextra -Werror -Wno-unknown-pragmas -Wno-overloaded-virtual -I/path/to/external/ADLX/SDK/Include native/gpu-tuning/main.cpp native/gpu-tuning/adlx_adapter.cpp -o /tmp/carpatia-gpu-tuning-check
```

The Node test requires child-process execution and skips only when its compiler
is absent. The Windows build script runs the same policy with MSVC. On Linux the
full helper answers query with `available:false` and does not create originals;
it cannot load or write a Windows driver.
