'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {descriptor,createProfileService,validateSession,LEVELS,GROUPS}=require('../dashboard-profiles');
const catalog=require('../tweak-library.json');
const guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const copy=x=>x===undefined?undefined:JSON.parse(JSON.stringify(x));
function harness(){
 const sessions=new Map(),states=new Map(),events=[],fail={};let time=1000,seq=0;
 const store={read:g=>copy(sessions.get(g)),write:(g,s)=>{sessions.set(g,copy(s));events.push(['save',g,s.state,...s.started])}};
 const ops={snapshot:async()=>({success:true,osBuild:22631,ramGB:16,gpu:['NVIDIA'],legacyBackup:!!fail.legacy}),status:async()=>({success:!fail.status,states:[...states.values()]}),check:async id=>{if(fail.check===id)return {success:false,message:'unsupported'};return {success:true}},apply:async id=>{
  assert.ok([...sessions.values()].some(s=>s.started.includes(id)),'journal must precede mutation');events.push(['apply',id]);
  if(fail.already===id)return {success:true,already:true};
  states.set(id,{id,state:fail.apply===id?'failed':'applied'});return {success:fail.apply!==id,message:'refused'};
 },restore:async id=>{events.push(['restore',id]);if(fail.restore===id)return {success:false,message:'locked'};states.set(id,{id,state:'restored'});return {success:true}}};
 const create=()=>createProfileService({store,ops,now:()=>time,token:()=>String(++seq)});return {service:create(),create,sessions,states,events,fail,ops,advance:()=>time+=180001};
}
test('successful summary counts changed, already configured, reused and omitted steps separately after reopen',async()=>{
 const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:7.4,gpu:['GPU']});
 h.states.set('library-cpu-005',{id:'library-cpu-005',state:'applied'});h.ops.check=async()=>({success:true,matching:true});h.fail.already='library-cpu-006';
 const plan=await h.service.prepare({group:'cpu',level:'ultra'}),result=await h.service.commit(plan.token);
 assert.equal(result.success,true);assert.deepEqual(result.summary,{changed:10,already:1,reused:1,skipped:1});
 assert.equal(h.events.filter(event=>event[0]==='apply').length,11);assert.ok(!h.events.some(event=>event[0]==='apply'&&event[1]==='library-cpu-005'));
 assert.deepEqual(h.create().status().find(row=>row.group==='cpu').summary,result.summary);
 result.summary.changed=999;assert.equal(h.create().status().find(row=>row.group==='cpu').summary.changed,10);
 assert.equal((await h.create().restore('cpu')).success,true);
});
test('an unchanged profile reports zero new changes and does not invent an active restore session',async()=>{
 const h=harness();h.ops.apply=async()=>({success:true,already:true});
 const p=await h.service.prepare({group:'gpu',level:'low'}),r=await h.service.commit(p.token);
 assert.equal(r.success,true);assert.deepEqual(r.summary,{changed:0,already:2,reused:0,skipped:0});
 const state=h.create().status().find(row=>row.group==='gpu');assert.equal(state.active,false);assert.deepEqual(state.summary,r.summary);
});
test('failed and rolled-back applies never publish a successful changes summary',async()=>{
 const h=harness();h.fail.apply='library-cpu-006';const p=await h.service.prepare({group:'cpu',level:'low'}),r=await h.service.commit(p.token);
 assert.equal(r.success,false);assert.equal(r.rollback.success,true);assert.equal(r.summary,undefined);
 assert.equal(h.sessions.get('cpu').summary,undefined);assert.equal(h.create().status().find(row=>row.group==='cpu').summary,undefined);
});
test('final journal failure preserves reused originals and discards successful result evidence',async()=>{
 const sessions=new Map(),states=new Map([['library-cpu-005',{id:'library-cpu-005',state:'applied'}]]),restored=[];let failed=false;
 const service=createProfileService({store:{read:group=>copy(sessions.get(group)),write:(group,session)=>{if(session.state==='applied'&&!failed){failed=true;throw Error('Disk full')}sessions.set(group,copy(session))}},ops:{snapshot:async()=>({success:true,osBuild:22631,ramGB:16}),status:async()=>({success:true,states:[...states.values()]}),check:async()=>({success:true,matching:true}),apply:async id=>{states.set(id,{id,state:'applied'});return {success:true}},restore:async id=>{restored.push(id);states.set(id,{id,state:'restored'});return {success:true}}}});
 const p=await service.prepare({group:'cpu',level:'low'}),r=await service.commit(p.token);
 assert.equal(r.success,false);assert.match(r.message,/Disk full/);assert.equal(r.rollback.success,true);assert.equal(r.summary,undefined);
 assert.deepEqual(restored,['library-cpu-006']);assert.equal(states.get('library-cpu-005').state,'applied');assert.equal(sessions.get('cpu').summary,undefined);
});
test('malformed display summaries do not hide valid recovery originals or create false counts',async()=>{
 for(const summary of [{changed:-1,already:0,reused:0,skipped:0},{changed:'1',already:0,reused:0,skipped:0},{changed:9999,already:0,reused:0,skipped:0},{changed:1},[1,0,0,0]]){
  const h=harness();h.sessions.set('cpu',{version:1,group:'cpu',level:'low',adapterGuid:'',state:'applied',started:['library-cpu-005'],unchanged:[],summary});h.states.set('library-cpu-005',{id:'library-cpu-005',state:'applied'});
  const state=h.service.status().find(row=>row.group==='cpu');assert.equal(state.recoverable,true);assert.equal(state.summary,undefined);assert.equal((await h.create().restore('cpu')).success,true);
 }
});
test('all 12 plans are cumulative, reversible, disjoint across subsystems and explicitly bounded',()=>{
 const targetOwners=new Map();
 for(const group of Object.keys(GROUPS)){
  let previous=[];for(const level of LEVELS){const ids=descriptor(group,level,guid).steps.map(x=>x.id);assert.ok(ids.length>previous.length);assert.ok(previous.every(id=>ids.includes(id)));previous=ids;}
  for(const step of descriptor(group,'ultra',guid).steps){
   const row=catalog.find(x=>x.id===step.id);assert.ok(['registry','native'].includes(row.status));assert.ok(!['security','boot'].includes(row.impact));
   const targets=row.entries.length?row.entries.map(x=>x.path.toLowerCase()+'|'+x.name.toLowerCase()):[JSON.stringify(row.operation)];
   for(const target of targets){assert.ok(!targetOwners.has(target),target);targetOwners.set(target,group)}
  }
 }
});
test('invalid plans and missing Internet adapter are rejected before execution',()=>{
 for(const [g,l,a] of [['bad','low',guid],['cpu','max',guid],['internet','low',''],['__proto__','low',guid]])assert.throws(()=>descriptor(g,l,a));
});
test('prepare is read-only; exact token is single-use and expired tokens cannot apply',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'low'});assert.equal(h.sessions.size,0);assert.equal(h.events.length,0);
 h.advance();await assert.rejects(h.service.commit(p.token),/expirat/);assert.equal(h.sessions.size,0);
 const q=await h.service.prepare({group:'cpu',level:'low'});await h.service.commit(q.token);await assert.rejects(h.service.commit(q.token),/expirat/);
});
test('all steps preflight before any mutation; compatibility failure leaves no session',async()=>{
 const h=harness();h.fail.check='library-cpu-054';await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/unsupported/);assert.equal(h.events.length,0);assert.equal(h.sessions.size,0);
});
test('commit rechecks backups that appeared after confirmation',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'medium'});h.states.set('unrelated',{id:'unrelated',state:'applied'});
 await assert.rejects(h.service.commit(p.token),/necunoscut/);assert.equal(h.sessions.size,0);
});
test('successful profile preserves session; changing level requires restore; restore is reverse order',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'ultra'});assert.equal((await h.service.commit(p.token)).success,true);
 await assert.rejects(h.service.prepare({group:'cpu',level:'low'}),/backup activ/);assert.throws(()=>h.service.assertClear());assert.throws(()=>h.service.assertNotOwned('library-cpu-005'));
 assert.equal((await h.service.restore('cpu')).success,true);
 const ids=descriptor('cpu','ultra').steps.map(x=>x.id);assert.deepEqual(h.events.filter(x=>x[0]==='restore').map(x=>x[1]),ids.reverse());assert.equal(h.service.status().find(x=>x.group==='cpu').active,false);
 h.service.assertClear();
});
test('failure rolls back failing step as well as previously successful steps; later steps never run',async()=>{
 const h=harness();h.fail.apply='library-cpu-006';const p=await h.service.prepare({group:'cpu',level:'ultra'}),r=await h.service.commit(p.token);
 assert.equal(r.success,false);assert.equal(r.rollback.success,true);assert.deepEqual(h.events.filter(x=>x[0]==='apply').map(x=>x[1]),['library-cpu-005','library-cpu-006']);
 assert.deepEqual(h.events.filter(x=>x[0]==='restore').map(x=>x[1]),['library-cpu-006','library-cpu-005']);
});
test('failed restoration retains outstanding IDs across restart and permits retry',async()=>{
 const h=harness();h.fail.apply='library-cpu-006';h.fail.restore='library-cpu-005';const p=await h.service.prepare({group:'cpu',level:'medium'}),r=await h.service.commit(p.token);
 assert.equal(r.rollback.success,false);assert.deepEqual(h.sessions.get('cpu').started,['library-cpu-005']);
 const restarted=h.create();await assert.rejects(restarted.prepare({group:'gpu',level:'low'}),/recuperare/);
 h.fail.restore=null;assert.equal((await restarted.restore('cpu')).success,true);
});
test('missing original backup is not reported as restored',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'low'});await h.service.commit(p.token);h.states.clear();
 const r=await h.service.restore('cpu');assert.equal(r.success,false);assert.equal(r.remaining,p.plan.steps.length);assert.match(r.results[0].message,/Backup lipsă/);
});
test('native already-correct step needs no invented backup and remains restorable as no-change',async()=>{
 const h=harness();h.fail.already='library-net-003';const p=await h.service.prepare({group:'internet',level:'low',adapterGuid:guid});await h.service.commit(p.token);
 assert.equal(h.states.has('library-net-003'),false);assert.equal((await h.service.restore('internet')).success,true);assert.ok(h.events.filter(x=>x[0]==='restore').every(x=>x[1]!=='library-net-003'));assert.ok(h.events.some(x=>x[0]==='restore'&&x[1]==='library-net-039'));
});
test('CPU and GPU profiles can coexist; restoring one preserves the other',async()=>{
 const h=harness();for(const group of ['cpu','gpu']){const p=await h.service.prepare({group,level:'medium'});await h.service.commit(p.token)}
 await h.service.restore('cpu');assert.equal(h.service.status().find(x=>x.group==='gpu').active,true);assert.equal(h.states.get('library-gpu-068').state,'applied');
});
test('tampered session cannot introduce arbitrary tweak IDs',()=>{
 assert.throws(()=>validateSession({version:1,group:'cpu',level:'low',state:'applied',started:['library-net-016'],unchanged:[]},'cpu'),/invalid/);
});
test('legacy backup reports the exact recovery destination without starting mutations',async()=>{
 const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:16,gpu:['NVIDIA'],legacyBackup:true,legacyBlockers:['ULTRA Registry — Backup & Restore']});
 await assert.rejects(h.service.prepare({group:'cpu',level:'low'}),/ULTRA Registry — Backup & Restore/);assert.equal(h.events.length,0);
});

test('failed individual restoration is actionable in the returned profile message',async()=>{
 const h=harness(),p=await h.service.prepare({group:'gpu',level:'low'});await h.service.commit(p.token);
 h.ops.restore=async()=>({success:false,message:'Registry access denied'});
 const r=await h.service.restore('gpu');assert.equal(r.success,false);assert.match(r.message,/library-gpu-068: Registry access denied/);assert.equal(h.service.status().find(x=>x.group==='gpu').state,'recovery');
});

test('all expanded profiles apply and restore every started step in reverse order',async()=>{
 for(const group of ['cpu','gpu','internet'])for(const level of LEVELS){
  const h=harness(),p=await h.service.prepare({group,level,adapterGuid:guid});const applied=await h.service.commit(p.token);assert.equal(applied.success,true);
  assert.equal((await h.service.restore(group)).success,true);
  assert.deepEqual(h.events.filter(x=>x[0]==='restore').map(x=>x[1]),p.plan.steps.map(x=>x.id).reverse());
 }
});
test('7.7.4 sessions remain recoverable without applying newly added steps',async()=>{
 const h=harness();h.sessions.set('cpu',{version:1,group:'cpu',level:'low',adapterGuid:'',state:'applied',started:['library-cpu-005'],unchanged:[]});h.states.set('library-cpu-005',{id:'library-cpu-005',state:'applied'});
 assert.equal((await h.service.restore('cpu')).success,true);assert.deepEqual(h.events.filter(x=>x[0]==='restore'),[['restore','library-cpu-005']]);assert.ok(!h.events.some(x=>x[0]==='apply'));
});

test('thrown native check names exact step and leaves all originals untouched',async()=>{
 const h=harness();h.ops.check=async id=>{if(id==='library-cpu-020')throw Error('Power API error 2');return {success:true}};
 await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/library-cpu-020.*Power API error 2/);assert.equal(h.events.length,0);assert.equal(h.sessions.size,0);
});
test('reported adv-002 backup no longer blocks any of the 12 independent profiles',async()=>{
 for(const group of Object.keys(GROUPS))for(const level of LEVELS){const h=harness();h.states.set('library-adv-002',{id:'library-adv-002',state:'applied'});const p=await h.service.prepare({group,level,adapterGuid:guid});assert.equal((await h.service.commit(p.token)).success,true);assert.equal((await h.service.restore(group)).success,true);assert.equal(h.states.get('library-adv-002').state,'applied');assert.ok(!h.events.some(x=>['apply','restore'].includes(x[0])&&x[1]==='library-adv-002'))}
});
test('same Registry target under another ID remains blocked with an actionable owner',async()=>{const h=harness();h.states.set('library-ram-006',{id:'library-ram-006',state:'applied'});await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/Conflict real.*Backup & Restore/);assert.equal(h.events.length,0)});
test('Normal TCP autotuning refuses an existing Disabled autotuning original',async()=>{const h=harness();h.states.set('library-net-012',{id:'library-net-012',state:'applied'});await assert.rejects(h.service.prepare({group:'internet',level:'medium',adapterGuid:guid}),/Conflict real.*Backup & Restore/);assert.equal(h.events.length,0)});
test('new conflict after confirmation is detected before first write',async()=>{const h=harness(),p=await h.service.prepare({group:'gpu',level:'ultra'});h.states.set('library-cpu-013',{id:'library-cpu-013',state:'applied'});await assert.rejects(h.service.commit(p.token),/Conflict real.*Backup & Restore/);assert.equal(h.sessions.size,0)});
test('persistent ledger failures are not bypassed by an empty native Status',async()=>{const h=harness();h.ops.conflicts=async()=>{throw Error('Diagnostic backup: corupt')};await assert.rejects(h.service.prepare({group:'cpu',level:'low'}),/corupt/);assert.equal(h.events.length,0)});
test('CPU Ultra adapts to 7.4 GB usable RAM without applying or inventing an original for the omitted option',async()=>{
 const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:7.4,gpu:['GPU']});
 const p=await h.service.prepare({group:'cpu',level:'ultra'});
 assert.equal(p.plan.adapted,true);assert.ok(!p.plan.steps.some(step=>step.id==='library-cpu-035'));
 assert.deepEqual(p.plan.skipped.map(step=>step.id),['library-cpu-035']);assert.match(p.plan.skipped[0].reason,/peste 8 GB.*7.4/);
 const r=await h.service.commit(p.token);assert.equal(r.success,true);assert.deepEqual(r.skipped,p.plan.skipped);
 assert.ok(!h.events.some(event=>event[0]==='apply'&&event[1]==='library-cpu-035'));assert.equal(h.states.has('library-cpu-035'),false);
 assert.equal((await h.create().restore('cpu')).success,true);assert.ok((await h.create().prepare({group:'cpu',level:'high'})).token);
});
test('unknown usable RAM omits only the optional memory setting with an explicit reason',async()=>{
 for(const ramGB of [undefined,0,NaN]){
  const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB,gpu:['GPU']});
  const p=await h.service.prepare({group:'cpu',level:'ultra'});
  assert.ok(p.plan.steps.length>0);assert.ok(!p.plan.steps.some(step=>step.id==='library-cpu-035'));assert.match(p.plan.skipped.find(step=>step.id==='library-cpu-035').reason,/nu a putut fi confirmată/);
  assert.equal(h.events.length,0);
 }
});
test('explicitly unavailable High Performance is omitted while access failures remain fatal',async()=>{
 const h=harness();h.ops.check=async id=>id==='library-cpu-002'?{success:false,notApplicable:true,message:'Planul High Performance nu este disponibil.'}:{success:true};
 const p=await h.service.prepare({group:'cpu',level:'ultra'});assert.ok(!p.plan.steps.some(step=>step.id==='library-cpu-002'));assert.match(p.plan.skipped.find(step=>step.id==='library-cpu-002').reason,/High Performance/);
 assert.equal((await h.service.commit(p.token)).success,true);assert.ok(!h.events.some(event=>event[0]==='apply'&&event[1]==='library-cpu-002'));assert.equal((await h.create().restore('cpu')).success,true);
 const denied=harness();denied.ops.check=async id=>id==='library-cpu-002'?{success:false,message:'Access denied'}:{success:true};
 await assert.rejects(denied.service.prepare({group:'cpu',level:'ultra'}),/library-cpu-002.*Access denied/);assert.equal(denied.events.length,0);assert.equal(denied.sessions.size,0);
});
test('HAGS incompatibility adapts GPU Ultra while unsupported Windows still blocks the entire profile',async()=>{
 const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:18363,ramGB:16,gpu:['GPU']});
 const p=await h.service.prepare({group:'gpu',level:'ultra'});assert.ok(!p.plan.steps.some(step=>step.id==='library-gpu-066'));assert.match(p.plan.skipped.find(step=>step.id==='library-gpu-066').reason,/19041/);assert.ok(p.plan.steps.length>0);
 const old=harness();old.ops.snapshot=async()=>({success:true,osBuild:9600,ramGB:16,gpu:['GPU']});await assert.rejects(old.service.prepare({group:'gpu',level:'ultra'}),/Windows 10\/11/);assert.equal(old.events.length,0);
});
test('changed applicability after preview requires confirmation again before any profile journal or write',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'ultra'});
 h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:7.4,gpu:['GPU']});
 await assert.rejects(h.service.commit(p.token),/Configurația s-a schimbat.*Analizează din nou/);assert.equal(h.events.length,0);assert.equal(h.sessions.size,0);
 await assert.rejects(h.service.commit(p.token),/expirat/);
});
test('a profile with no available options never creates a phantom session',async()=>{
 const h=harness();h.ops.check=async()=>({success:false,notApplicable:true,message:'Unavailable on this Windows build'});
 await assert.rejects(h.service.prepare({group:'cpu',level:'low'}),/Nicio opțiune disponibilă.*Unavailable/);assert.equal(h.events.length,0);assert.equal(h.sessions.size,0);
});
test('historical CPU Ultra originals remain restorable when current RAM would omit that option',async()=>{
 const h=harness();h.sessions.set('cpu',{version:1,group:'cpu',level:'ultra',adapterGuid:'',state:'applied',started:['library-cpu-035'],unchanged:[]});h.states.set('library-cpu-035',{id:'library-cpu-035',state:'applied'});
 h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:7.4,gpu:['GPU']});
 assert.equal((await h.create().restore('cpu')).success,true);assert.deepEqual(h.events.filter(event=>event[0]==='restore'),[['restore','library-cpu-035']]);assert.ok(!h.events.some(event=>event[0]==='apply'));
});
test('legacy conflicts are checked against adapted steps without hiding unreadable legacy scope',async()=>{
 const h=harness();h.ops.snapshot=async()=>({success:true,osBuild:22631,ramGB:7.4,gpu:['GPU'],legacyBackup:true});
 h.ops.legacyConflicts=async plan=>plan.steps.some(step=>step.id==='library-cpu-035')?['Original DisablePagingExecutive']:[];
 const p=await h.service.prepare({group:'cpu',level:'ultra'});assert.ok(p.token);assert.equal(p.plan.skipped[0].id,'library-cpu-035');assert.equal(h.events.length,0);
 h.ops.legacyConflicts=async()=>['Original Power Plan'];await assert.rejects(h.service.commit(p.token),/backupul existent.*Original Power Plan/);assert.equal(h.sessions.size,0);
 h.ops.legacyConflicts=async()=>{throw Error('Legacy original unreadable')};await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/Legacy original unreadable/);
 h.ops.legacyConflicts=async()=>null;await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/Domeniul backupurilor/);assert.equal(h.events.length,0);
});
test('verified identical individual setting is reused without duplicate write and retains original for restore',async()=>{
 const h=harness();h.states.set('library-cpu-035',{id:'library-cpu-035',state:'applied'});h.ops.check=async()=>({success:true,matching:true});h.ops.conflicts=async()=>[{id:'library-cpu-035',module:'Tweaks'}];
 const p=await h.service.prepare({group:'cpu',level:'ultra'});assert.deepEqual(p.plan.reuse,['library-cpu-035']);assert.equal((await h.service.commit(p.token)).success,true);
 assert.ok(!h.events.some(e=>e[0]==='apply'&&e[1]==='library-cpu-035'));assert.equal((await h.service.restore('cpu')).success,true);
 assert.ok(h.events.some(e=>e[0]==='restore'&&e[1]==='library-cpu-035'));
});
test('external drift on individual setting blocks reuse without overwriting original',async()=>{
 const h=harness();h.states.set('library-cpu-035',{id:'library-cpu-035',state:'applied'});h.ops.check=async()=>({success:true,matching:false});
 await assert.rejects(h.service.prepare({group:'cpu',level:'ultra'}),/Conflict real/);assert.equal(h.events.length,0);
});
test('DNS reuse requires the original and current adapter to match the selected adapter',async()=>{
 const other='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee';
 for(const [saved,current,accepted] of [[guid,guid,true],['{'+guid.toUpperCase()+'}',guid,true],[other,guid,false],[guid,other,false],[undefined,guid,false]]){
  const h=harness();
  h.states.set('library-net-003',{id:'library-net-003',state:'applied',operation:saved?{type:'dns',adapterGuid:saved}:undefined});
  h.ops.check=async id=>({success:true,matching:true,...(id==='library-net-003'?{operation:{type:'dns',adapterGuid:current}}:{})});
  if(accepted){
   const p=await h.service.prepare({group:'internet',level:'low',adapterGuid:guid});
   assert.deepEqual(p.plan.reuse,['library-net-003']);assert.equal((await h.service.commit(p.token)).success,true);
   assert.ok(!h.events.some(e=>e[0]==='apply'&&e[1]==='library-net-003'));
   assert.equal((await h.create().restore('internet')).success,true);
   assert.ok(h.events.some(e=>e[0]==='restore'&&e[1]==='library-net-003'));
  }else{
   await assert.rejects(h.service.prepare({group:'internet',level:'low',adapterGuid:guid}),/Conflict real.*Adaptorul.*Backup & Restore/);
   assert.equal(h.events.length,0);assert.equal(h.states.get('library-net-003').state,'applied');
  }
 }
});
test('power value reuse requires the saved target and the scheme the profile will actually use',async()=>{
 const rule=catalog.find(x=>x.id==='library-cpu-021'),power=catalog.find(x=>x.id==='library-cpu-002').operation.value,other='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee';
 for(const [level,saved,current,accepted,powerUnavailable] of [['medium',other,other,true],['high',power,power,true],['high',other,other,false],['medium',power,other,false],['medium',undefined,power,false],['high',other,other,true,true]]){
  const h=harness();
  h.states.set(rule.id,{id:rule.id,state:'applied',operation:saved?{...rule.operation,scheme:'{'+saved.toUpperCase()+'}'}:undefined});
  h.ops.check=async id=>powerUnavailable&&id==='library-cpu-002'?{success:false,notApplicable:true,message:'High Performance absent'}:{success:true,matching:true,...(id===rule.id?{operation:{...rule.operation,scheme:current}}:{})};
  if(accepted){
   const p=await h.service.prepare({group:'cpu',level});assert.deepEqual(p.plan.reuse,[rule.id]);
   assert.equal((await h.service.commit(p.token)).success,true);assert.ok(!h.events.some(e=>e[0]==='apply'&&e[1]===rule.id));
   assert.equal((await h.create().restore('cpu')).success,true);assert.ok(h.events.some(e=>e[0]==='restore'&&e[1]===rule.id));
  }else{
   await assert.rejects(h.service.prepare({group:'cpu',level}),/Conflict real.*planul de alimentare.*Backup & Restore/);
   assert.equal(h.events.length,0);assert.equal(h.states.get(rule.id).state,'applied');
  }
 }
});
test('a native original retargeted after preview invalidates the profile before any mutation',async()=>{
 const other='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee';
 for(const [group,level,id,operation,field] of [['internet','low','library-net-003',{type:'dns',adapterGuid:guid},'adapterGuid'],['cpu','medium','library-cpu-021',{...catalog.find(x=>x.id==='library-cpu-021').operation,scheme:guid},'scheme']]){
  const h=harness();h.states.set(id,{id,state:'applied',operation:{...operation}});
  h.ops.check=async target=>({success:true,matching:true,...(target===id?{operation:{...operation}}:{})});
  const p=await h.service.prepare({group,level,adapterGuid:guid});
  h.states.get(id).operation[field]=other;
  await assert.rejects(h.service.commit(p.token),/Conflict real.*Backup & Restore/);
  assert.equal(h.events.length,0);assert.equal(h.states.get(id).state,'applied');
 }
});
test('ULTRA apply restore reopen and reapply for all three groups',async()=>{
 for(const group of ['cpu','gpu','internet']){const h=harness();let s=h.service;for(let cycle=0;cycle<2;cycle++){const p=await s.prepare({group,level:'ultra',adapterGuid:guid});assert.equal((await s.commit(p.token)).success,true);s=h.create();assert.equal((await s.restore(group)).success,true)}}
});
test('analysis distinguishes actual partial state from saved applied journal',async()=>{
 const h=harness();const p=await h.service.prepare({group:'cpu',level:'low'});await h.service.commit(p.token);h.ops.check=async id=>({success:true,matching:id==='library-cpu-005'});
 const state=(await h.service.analyze()).find(x=>x.group==='cpu');assert.equal(state.observed,'partial');assert.equal(state.state,'applied');
});
test('an entirely unchanged profile leaves no phantom session blocking later operations',async()=>{const h=harness();h.ops.apply=async()=>({success:true,already:true});const p=await h.service.prepare({group:'cpu',level:'low'}),r=await h.service.commit(p.token);assert.equal(r.already,true);assert.equal(h.service.status().find(x=>x.group==='cpu').active,false);h.service.assertClear();assert.ok((await h.service.prepare({group:'cpu',level:'high'})).token)});

test('failed profile does not roll back reused preexisting individual originals',async()=>{
 const h=harness();
 h.states.set('library-cpu-005',{id:'library-cpu-005',state:'applied'});
 h.ops.check=async()=>({success:true,matching:true});h.fail.apply='library-cpu-006';
 const p=await h.service.prepare({group:'cpu',level:'low'}),r=await h.service.commit(p.token);
 assert.equal(r.success,false);assert.equal(r.rollback.success,true);
 assert.equal(h.states.get('library-cpu-005').state,'applied');
 assert.ok(!h.events.some(e=>e[0]==='restore'&&e[1]==='library-cpu-005'));
 assert.equal(h.service.status().find(s=>s.group==='cpu').active,false);
});
test('reopening an interrupted apply preserves reused originals during recovery',async()=>{
 const h=harness();h.states.set('library-cpu-005',{id:'library-cpu-005',state:'applied'});
 h.sessions.set('cpu',{version:1,group:'cpu',level:'low',adapterGuid:'',state:'applying',started:['library-cpu-005'],unchanged:[],reused:['library-cpu-005']});
 const r=await h.create().restore('cpu');assert.equal(r.success,true);
 assert.equal(h.states.get('library-cpu-005').state,'applied');assert.ok(!h.events.some(e=>e[0]==='restore'));
});
test('a disappearing journal after successful restore does not count as confirmation',async()=>{
 const h=harness(),p=await h.service.prepare({group:'cpu',level:'low'});await h.service.commit(p.token);
 h.ops.restore=async id=>{h.states.delete(id);return {success:true}};
 const r=await h.service.restore('cpu');assert.equal(r.success,false);assert.equal(r.remaining,p.plan.steps.length);
 assert.ok(r.results.every(x=>/nu este confirmată/.test(x.message)));
});
test('broken progress listener cannot prevent apply or rollback',async()=>{
 const h=harness(),s=createProfileService({store:{read:g=>copy(h.sessions.get(g)),write:(g,v)=>h.sessions.set(g,copy(v))},ops:h.ops,notify:()=>{throw Error('UI closed')}});
 h.fail.apply='library-cpu-006';const p=await s.prepare({group:'cpu',level:'low'}),r=await s.commit(p.token);
 assert.equal(r.success,false);assert.equal(r.rollback.success,true);
});
test('Internet adapter identifiers require paired braces',()=>{
 for(const adapter of ['{'+guid,guid+'}'])assert.throws(()=>descriptor('internet','low',adapter));
 for(const adapter of [guid,'{'+guid+'}'])assert.ok(descriptor('internet','low',adapter).steps.length);
});

test('stale applied sessions whose originals are restored can finalize and allow all three profiles again',async()=>{
 for(const group of ['cpu','gpu','internet']){
  const h=harness(),plan=descriptor(group,'low',guid);
  h.sessions.set(group,{version:1,group,level:'low',adapterGuid:group==='internet'?guid:'',state:'applied',started:plan.steps.map(x=>x.id),unchanged:[]});
  for(const step of plan.steps)h.states.set(step.id,{id:step.id,state:'restored'});
  assert.equal(h.service.status().find(x=>x.group===group).active,true);
  const r=await h.service.restore(group);assert.equal(r.success,true);assert.equal(h.events.filter(e=>e[0]==='restore').length,0);
  assert.ok((await h.service.prepare({group,level:'low',adapterGuid:guid})).token);
 }
});
test('an empty interrupted profile finalizes without inventing originals',async()=>{
 const h=harness();h.sessions.set('cpu',{version:1,group:'cpu',level:'low',adapterGuid:'',state:'applying',started:[],unchanged:[]});
 assert.equal((await h.service.restore('cpu')).success,true);assert.equal(h.service.status()[0].active,false);assert.equal(h.events.filter(x=>x[0]==='restore').length,0);
});
test('one corrupt profile remains diagnostic without hiding other profile states',async()=>{
 const h=harness();h.sessions.set('gpu',{bad:'data'});const status=await h.service.analyze();
 assert.equal(status.length,3);assert.equal(status.find(x=>x.group==='gpu').recoverable,false);assert.equal(status.find(x=>x.group==='cpu').active,false);
});
test('successful Apply replies cannot mark a profile applied while its durable journal is still failed',async()=>{
 const h=harness();h.ops.apply=async id=>{h.states.set(id,{id,state:'failed'});return {success:true}};
 const p=await h.service.prepare({group:'cpu',level:'low'}),r=await h.service.commit(p.token);
 assert.equal(r.success,false);assert.match(r.message,/nu este confirmată în jurnal/);assert.equal(r.rollback.success,true);assert.ok(!h.sessions.size||h.sessions.get('cpu').state!=='applied');
});
test('an incomplete successful Status response cannot silently replace the original inventory',async()=>{
 const h=harness();h.ops.status=async()=>({success:true});await assert.rejects(h.service.prepare({group:'cpu',level:'low'}),/Jurnalele/);assert.equal(h.events.length,0);
});
