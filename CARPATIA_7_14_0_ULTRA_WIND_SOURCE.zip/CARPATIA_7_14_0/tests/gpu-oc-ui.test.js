'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {mount,frequency,validateStatus}=require('../gpu-oc-ui');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
const flush=()=>new Promise(setImmediate);
const gpu=(extra={})=>({gpuId:'PCI\\VEN_1002&DEV_TEST',name:'GPU de test',supported:true,backup:false,currentMhz:2400,minMhz:2000,maxMhz:2800,stepMhz:25,...extra});
const status=(rows=[gpu()],extra={})=>({success:true,available:true,supported:rows.some(row=>row.supported),gpus:rows,...extra});
function harness(overrides={},options={}){
 const nodes={},calls=[],gates=[],toasts=[],confirms=[];
 class Element{constructor(id,tag='div'){this.id=id;this.tagName=tag.toUpperCase();this.value='';this.children=[];this.textContent='';this.dataset={};this.disabled=false;this.hidden=false}setAttribute(name,value){this[name]=String(value)}replaceChildren(...children){this.children=children}append(...children){this.children.push(...children)}}
 for(const match of html.matchAll(/<([\w-]+)\b([^>]*\bid="([\w-]+)"[^>]*)>/g))nodes[match[3]]=new Element(match[3],match[1]);
 const document={getElementById:id=>nodes[id],createElement:tag=>new Element('',tag)};
 let current=status();
 const api=options.preview?null:{gpuTuningStatus:async()=>{calls.push(['status']);return structuredClone(current)},gpuTuningPrepare:async request=>{calls.push(['prepare',request]);const row=current.gpus.find(row=>row.gpuId===request.gpuId);return {token:'token-test',plan:{...row,fromMhz:row.currentMhz,toMhz:request.mhz}}},gpuTuningCommit:async token=>{calls.push(['commit',token]);current.gpus[0]={...current.gpus[0],currentMhz:2600,backup:true};return {success:true}},gpuTuningRestore:async id=>{calls.push(['restore',id]);current.gpus[0]={...current.gpus[0],currentMhz:2400,backup:false};return {success:true}},...overrides};
 const page=mount({api,document,requireNative:recovery=>{gates.push(!!recovery);return true},task:options.task||((_,fn)=>fn()),confirmDialog:async(...args)=>{confirms.push(args);return options.confirmDialog?options.confirmDialog(...args):options.confirm!==false},showToast:value=>toasts.push(value)});
 return {page,nodes,api,calls,gates,toasts,confirms,get current(){return current},setStatus:value=>{current=value},input:value=>{nodes.gpuOcMhz.value=value;nodes.gpuOcMhz.oninput()},select:id=>{nodes.gpuOcDevice.value=id;nodes.gpuOcDevice.onchange()}};
}
test('hardware module does not read or write on mount and missing helper never exposes fake controls',async()=>{
 const h=harness();assert.deepEqual(h.calls,[]);h.setStatus({success:true,available:false,supported:false,gpus:[],reason:'Control indisponibil în această sesiune.'});await h.page.load();
 assert.deepEqual(h.calls,[['status']]);assert.equal(h.nodes.gpuOcControls.hidden,true);assert.equal(h.nodes.gpuOcApply.disabled,true);assert.equal(h.nodes.gpuOcRestore.disabled,true);assert.match(h.nodes.gpuOcMessage.textContent,/indisponibil/);h.page.destroy();
 const preview=harness({}, {preview:true});await preview.page.load();assert.equal(preview.nodes.gpuOcApply.disabled,true);assert.match(preview.nodes.gpuOcMessage.textContent,/Windows/);preview.page.destroy();
});
test('only complete driver limits expose a bounded input and no change is offered for the current setting',async()=>{
 const h=harness();await h.page.load();assert.equal(h.nodes.gpuOcControls.hidden,false);assert.equal(h.nodes.gpuOcMhz.min,'2000');assert.equal(h.nodes.gpuOcMhz.max,'2800');assert.equal(h.nodes.gpuOcMhz.step,'25');assert.equal(h.nodes.gpuOcMhz.value,'2400');assert.equal(h.nodes.gpuOcApply.disabled,true);h.input('2600');assert.equal(h.nodes.gpuOcApply.disabled,false);h.page.destroy();
});
test('untrusted numeric strings, step violations and out-of-range values never prepare a hardware write',async()=>{
 const h=harness();await h.page.load();
 for(const value of ['1e3','2600.5','2626','1999','2801','-1','NaN','Infinity','2600;anything','']){h.input(value);await h.nodes.gpuOcApply.onclick();assert.equal(h.nodes.gpuOcApply.disabled,true)}
 assert.equal(h.calls.filter(row=>row[0]==='prepare').length,0);assert.equal(frequency('2600',gpu()),2600);assert.equal(frequency(2600,gpu()),null);h.page.destroy();
});
test('malformed capabilities and duplicate GPU identities cannot authorize writes',async()=>{
 for(const result of [status([gpu({currentMhz:'2400'})]),status([gpu({maxMhz:10001})]),status([gpu({minMhz:3000})]),status([gpu({stepMhz:0})]),status([gpu({backup:undefined})]),status([gpu(),gpu()]),status([gpu({gpuId:'invalid\nidentity'})]),status([gpu({gpuId:' '})]),{...status(),available:'true'}]){
  const h=harness({gpuTuningStatus:async()=>result});await h.page.load();assert.equal(h.nodes.gpuOcApply.disabled,true);assert.equal(h.page.getState().known,false);assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');h.page.destroy();assert.throws(()=>validateStatus(result));
 }
});
test('prepare and explicit confirmation bind a write to the selected GPU and requested MHz',async()=>{
 const h=harness();await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();
 assert.deepEqual(h.calls.filter(row=>row[0]!=='status'),[['prepare',{gpuId:gpu().gpuId,mhz:2600}],['commit','token-test']]);assert.equal(h.confirms.length,1);assert.match(h.confirms[0][2],/2400 MHz\nLimită nouă: 2600 MHz/);assert.match(h.confirms[0][3],/temperatura/);assert.equal(h.nodes.gpuOcCurrent.textContent,'2600 MHz');assert.equal(h.nodes.gpuOcMessage.dataset.tone,'success');assert.equal(h.nodes.gpuOcApply.disabled,true);assert.equal(h.nodes.gpuOcRestore.disabled,false);h.page.destroy();
});
test('canceling or receiving a mismatched prepared plan never commits a clock change',async()=>{
 const canceled=harness({}, {confirm:false});await canceled.page.load();canceled.input('2600');await canceled.nodes.gpuOcApply.onclick();assert(!canceled.calls.some(row=>row[0]==='commit'));canceled.page.destroy();
 for(const plan of [{...gpu(),gpuId:'another-gpu',fromMhz:2400,toMhz:2600},{...gpu(),fromMhz:2400,toMhz:2700},{...gpu(),fromMhz:2400,toMhz:2600,stepMhz:175},{...gpu(),fromMhz:'2400',toMhz:2600}]){
  const h=harness({gpuTuningPrepare:async()=>({token:'token',plan})});await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();assert(!h.calls.some(row=>row[0]==='commit'));assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');h.page.destroy();
 }
});
test('freshly already configured preview reports a neutral no-op without confirmation, commit or invented original',async()=>{
 const h=harness({gpuTuningPrepare:async request=>{h.setStatus(status([gpu({currentMhz:request.mhz})]));return {already:true,token:null,plan:{...gpu(),fromMhz:request.mhz,toMhz:request.mhz}}}});
 await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();assert(!h.calls.some(row=>row[0]==='commit'));assert.equal(h.confirms.length,0);assert.equal(h.nodes.gpuOcCurrent.textContent,'2600 MHz');assert.equal(h.nodes.gpuOcRestore.disabled,true);assert.equal(h.nodes.gpuOcMessage.dataset.tone,'neutral');assert.match(h.nodes.gpuOcMessage.textContent,/deja configurată/);h.page.destroy();
});
test('malformed no-op replies and changing no-op readback cannot be presented as already configured',async()=>{
 for(const prepared of [{already:true,token:null,plan:{...gpu(),fromMhz:2400,toMhz:2600}},{already:true,token:'unexpected',plan:{...gpu(),fromMhz:2600,toMhz:2600}},{already:true,token:null,plan:{...gpu(),fromMhz:2600,toMhz:2600}}]){
  const h=harness({gpuTuningPrepare:async()=>prepared});await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();assert(!h.calls.some(row=>row[0]==='commit'));assert.equal(h.confirms.length,0);assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');h.page.destroy();
 }
});
test('a commit success without actual current setting and original readback is not presented as success',async()=>{
 for(const backup of [false,true]){
  const h=harness({gpuTuningCommit:async()=>{h.setStatus(status([gpu({backup})]));return {success:true}}});await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');assert.match(h.nodes.gpuOcMessage.textContent,/recitire/);assert.equal(h.nodes.gpuOcRestore.disabled,!backup);h.page.destroy();
 }
});
test('failed native apply rereads and exposes the original that was saved before the failure',async()=>{
 const h=harness({gpuTuningCommit:async()=>{h.setStatus(status([gpu({backup:true})]));throw Error('Readback failed; original retained')}});await h.page.load();h.input('2600');await h.nodes.gpuOcApply.onclick();assert.equal(h.nodes.gpuOcRestore.disabled,false);assert.equal(h.nodes.gpuOcApply.disabled,true);assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');assert.match(h.nodes.gpuOcMessage.textContent,/original retained/);h.page.destroy();
});
test('original restoration uses the pinned GPU and a license-independent recovery route',async()=>{
 const h=harness();h.setStatus(status([gpu({backup:true,currentMhz:2600})]));await h.page.load();await h.nodes.gpuOcRestore.onclick();assert.deepEqual(h.gates,[true]);assert.deepEqual(h.calls.filter(row=>row[0]==='restore'),[['restore',gpu().gpuId]]);assert.equal(h.nodes.gpuOcRestore.disabled,true);assert.equal(h.nodes.gpuOcCurrent.textContent,'2400 MHz');assert.equal(h.nodes.gpuOcMessage.dataset.tone,'success');h.page.destroy();
});
test('failed restoration keeps its original actionable and does not report success',async()=>{
 const h=harness({gpuTuningRestore:async()=>({success:false,message:'Another utility changed this GPU'})});h.setStatus(status([gpu({backup:true,currentMhz:2600})]));await h.page.load();await h.nodes.gpuOcRestore.onclick();assert.equal(h.nodes.gpuOcRestore.disabled,false);assert.equal(h.nodes.gpuOcApply.disabled,true);assert.equal(h.nodes.gpuOcMessage.dataset.tone,'error');assert.match(h.nodes.gpuOcMessage.textContent,/Another utility/);h.page.destroy();
});
test('GPU changes reset the input and never carry a limit across hardware identities',async()=>{
 const h=harness();h.setStatus(status([gpu(),gpu({gpuId:'PCI\\SECOND',name:'Another GPU',currentMhz:2200,minMhz:1800,maxMhz:2300,stepMhz:10})]));await h.page.load();h.input('2700');h.select('PCI\\SECOND');assert.equal(h.nodes.gpuOcMhz.value,'2200');assert.equal(h.nodes.gpuOcMhz.max,'2300');assert.equal(h.nodes.gpuOcApply.disabled,true);h.page.destroy();
});
test('an unresolved confirmation after teardown cannot trigger a late hardware write',async()=>{
 const confirmation=deferred(),h=harness({}, {confirmDialog:()=>confirmation.promise});await h.page.load();h.input('2600');const applying=h.nodes.gpuOcApply.onclick();await flush();h.page.destroy();confirmation.resolve(true);await applying;assert(!h.calls.some(row=>row[0]==='commit'));assert.equal(h.nodes.gpuOcApply.onclick,null);
});
test('concurrent page loads coalesce and destroyed reads cannot update the removed card',async()=>{
 const delayed=deferred();let count=0;const h=harness({gpuTuningStatus:()=>{count++;return delayed.promise}});const a=h.page.load(),b=h.page.load();await flush();assert.equal(count,1);h.page.destroy();delayed.resolve(status());await Promise.all([a,b]);assert.equal(h.page.getState().known,false);assert.equal(h.nodes.gpuOcDevice.onchange,null);assert.equal(h.nodes.gpuOcMhz.oninput,null);
});
