$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../nic-native-ops.ps1')
$script:assertions=0;$script:writes=@();$script:noOp=$false;$script:powerError=$false;$script:advancedError=$false;$script:renameOnRead=$false
function Assert($condition,$label){if(-not $condition){throw ('FAILED: '+$label)};$script:assertions++}
function Reject($fn,$label){$rejected=$false;try{& $fn | Out-Null}catch{$rejected=$true};Assert $rejected $label}
function Copy-Object($o){return ($o | ConvertTo-Json -Depth 16 | ConvertFrom-Json)}
function Canonical-Native($o){
 if($null -eq $o){return 'null'}
 if($o -is [array]){return '['+((@($o | ForEach-Object {Canonical-Native $_})) -join ',')+']'}
 if($o -is [string]){return 'string:'+$o}
 if($o -is [System.Collections.IDictionary]){return '{'+((@($o.Keys | Sort-Object | ForEach-Object {[string]$_+':'+(Canonical-Native $o[$_])})) -join ',')+'}'}
 if($o -is [pscustomobject]){return '{'+((@($o.PSObject.Properties.Name | Sort-Object | ForEach-Object {[string]$_+':'+(Canonical-Native $o.$_)})) -join ',')+'}'}
 return $o.GetType().FullName+':'+[string]$o
}
$guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';$other='11111111-2222-3333-4444-555555555555'
$script:adapters=@([pscustomobject]@{Name='Ethernet[1]';InterfaceGuid=$guid},[pscustomobject]@{Name='Ethernet1';InterfaceGuid=$other})
function Get-AdapterByGuid($guid){$found=@($script:adapters | Where-Object {[guid]$_.InterfaceGuid -eq [guid]$guid});if($found.Count -ne 1){throw 'Original adapter unavailable'};return $found[0]}
$script:powerRows=@([pscustomobject]@{Name='Ethernet[1]';SelectiveSuspend='Enabled';DeviceSleepOnDisconnect='Disabled'},[pscustomobject]@{Name='Ethernet1';SelectiveSuspend='Enabled';DeviceSleepOnDisconnect='Enabled'})
$script:advancedRows=@([pscustomobject]@{Name='Ethernet[1]';RegistryKeyword='*EEE';RegistryValue=@('1');ValidRegistryValues=@('0','1')},[pscustomobject]@{Name='Ethernet[1]';RegistryKeyword='*InterruptModeration';RegistryValue=@('1');ValidRegistryValues=@('0','1')},[pscustomobject]@{Name='Ethernet1';RegistryKeyword='*EEE';RegistryValue=@('1');ValidRegistryValues=@('0','1')})
function Get-NetAdapterPowerManagement {
 param($Name,[switch]$IncludeHidden,$ErrorAction)
 if($script:powerError){throw [UnauthorizedAccessException]::new('Power access denied')}
 $found=@($script:powerRows | Where-Object {$_.Name -like $Name})
 if($script:renameOnRead){$script:adapters[0].Name='Renamed after query'}
 return $found
}
function Set-NetAdapterPowerManagement {
 param($InputObject,$SelectiveSuspend,$DeviceSleepOnDisconnect,[switch]$NoRestart,$ErrorAction)
 if($null -eq $InputObject -or -not $NoRestart){throw 'Expected exact InputObject and NoRestart'}
 $script:writes+=,@{kind='power';name=$InputObject.Name;selective=$SelectiveSuspend;sleep=$DeviceSleepOnDisconnect}
 if($script:noOp){return}
 if($PSBoundParameters.ContainsKey('SelectiveSuspend')){$InputObject.SelectiveSuspend=$SelectiveSuspend}
 if($PSBoundParameters.ContainsKey('DeviceSleepOnDisconnect')){$InputObject.DeviceSleepOnDisconnect=$DeviceSleepOnDisconnect}
}
function Get-NetAdapterAdvancedProperty {
 param($Name,[switch]$IncludeHidden,[switch]$AllProperties,$ErrorAction)
 if(-not $AllProperties -or -not $IncludeHidden){throw 'Expected complete exact driver inventory'}
 if($script:advancedError){throw [UnauthorizedAccessException]::new('Advanced access denied')}
 return @($script:advancedRows | Where-Object {$_.Name -like $Name})
}
function Set-NetAdapterAdvancedProperty {
 param($InputObject,$RegistryValue,[switch]$NoRestart,$ErrorAction)
 if($null -eq $InputObject -or -not $NoRestart){throw 'Expected exact advanced InputObject and NoRestart'}
 $script:writes+=,@{kind='advanced';name=$InputObject.Name;keyword=$InputObject.RegistryKeyword;value=@($RegistryValue)}
 if(-not $script:noOp){$InputObject.RegistryValue=@($RegistryValue)}
}
$power=Resolve-NicOperation @{type='nic-power';value='Disabled'} ('{'+$guid.ToUpperInvariant()+'}')
$eee=Resolve-NicOperation @{type='nic-advanced';keyword='*EEE';value='0'} $guid
$interrupt=Resolve-NicOperation @{type='nic-advanced';keyword='*InterruptModeration';value='0'} $guid
Assert ($power.adapterGuid -ceq $guid) 'GUID case and paired braces normalize without an alias identity'
Assert (@(Nic-Targets $eee)[0] -cne @(Nic-Targets $interrupt)[0]) 'EEE and Interrupt Moderation protect separate native targets'
Assert (@(Nic-Targets $power)[0] -ceq ('network|'+$guid+'|nic-power')) 'NIC Power target pins the exact adapter'
foreach($bad in @($guid+'}','{'+$guid,'Ethernet[1]')){Reject {Resolve-NicOperation @{type='nic-power';value='Disabled'} $bad} 'malformed or alias adapter identity is rejected'}
Reject {Resolve-NicOperation @{type='nic-advanced';keyword='*SomeVendorSetting';value='0'} $guid} 'unreviewed advanced keywords cannot execute'
Reject {Resolve-NicOperation @{type='nic-power';value=@('Disabled')} $guid} 'operation values cannot coerce arrays to a writable state'

$before=Capture-NicValue $power;$desired=Desired-NicValue $power $before
Assert ($before.selectiveSuspend -ceq 'Enabled' -and $before.deviceSleepOnDisconnect -ceq 'Disabled') 'capture uses only the bracketed exact adapter'
Assert ($desired.selectiveSuspend -ceq 'Disabled' -and $before.selectiveSuspend -ceq 'Enabled') 'desired power state does not mutate its original'
Write-NicValue $power $desired
Assert ($script:writes.Count -eq 1 -and $script:writes[0].name -ceq 'Ethernet[1]') 'power setter receives only the matching CIM object'
Assert ($script:powerRows[1].SelectiveSuspend -ceq 'Enabled') 'wildcard alias neighbor is never modified'
Assert (Test-NicRestoreState $power @{selectiveSuspend='Disabled';deviceSleepOnDisconnect='Disabled'} $before $desired) 'partially changed NIC Power state remains restorable'
Write-NicValue $power $before
Assert ((Canonical-Native (Capture-NicValue $power)) -ceq (Canonical-Native $before)) 'NIC Power restores and independently reads back its exact original'
Reject {Assert-NicValue $power @{selectiveSuspend=$false;deviceSleepOnDisconnect='Disabled'}} 'boolean cannot become a power enum'
Reject {Assert-NicValue $power @{selectiveSuspend='Enabled';deviceSleepOnDisconnect='Disabled';name='foreign'}} 'saved power state rejects unowned extra properties'
Assert (-not (Test-NicRestoreState $power @{selectiveSuspend='Unknown';deviceSleepOnDisconnect='Disabled'} $before $desired)) 'unknown current power enum prevents restore'

$script:powerRows[0].DeviceSleepOnDisconnect='Unsupported';$partial=Capture-NicValue $power;$desiredPartial=Desired-NicValue $power $partial
Assert ($null -eq $partial.deviceSleepOnDisconnect -and $null -eq $desiredPartial.deviceSleepOnDisconnect) 'unsupported power field remains explicitly absent'
Assert (Get-NicApplicability $power).applicable 'one genuinely supported power field is sufficient'
Write-NicValue $power $desiredPartial
Assert ($script:powerRows[0].DeviceSleepOnDisconnect -ceq 'Unsupported') 'power setter never invents a value for unsupported fields'
$script:powerRows[0].DeviceSleepOnDisconnect='Enabled';$count=$script:writes.Count
Reject {Write-NicValue $power $partial} 'driver adding a formerly unsupported field cannot widen restoration'
Assert ($script:writes.Count -eq $count) 'changed support mask blocks before the first write'
Assert (-not (Test-NicRestoreState $power @{selectiveSuspend='Disabled';deviceSleepOnDisconnect='Enabled'} $partial $desiredPartial)) 'unsupported-to-supported driver change is external drift'
$script:powerRows[0].SelectiveSuspend='Unsupported';$script:powerRows[0].DeviceSleepOnDisconnect='Unsupported'
Assert (-not (Get-NicApplicability $power).applicable) 'fully unsupported power capability is explicitly omitted'
$script:powerRows[0].SelectiveSuspend='NewMode'
Reject {Get-NicApplicability $power} 'malformed power enum is not hidden as unsupported'
$script:powerRows[0].SelectiveSuspend='Enabled';$script:powerRows[0].DeviceSleepOnDisconnect='Disabled';$script:powerError=$true
Reject {Get-NicApplicability $power} 'power access failures remain fatal'
$script:powerError=$false;$script:renameOnRead=$true
Reject {Capture-NicValue $power} 'rename during query cannot retarget a stale alias'
$script:renameOnRead=$false;$script:adapters[0].Name='Ethernet[1]'

Assert (Get-NicApplicability $eee).applicable 'standard EEE is supported only with explicit disabled enum'
$original=Capture-NicValue $eee;Write-NicValue $eee (Desired-NicValue $eee $original)
Assert ($script:advancedRows[0].RegistryValue[0] -ceq '0' -and $script:advancedRows[2].RegistryValue[0] -ceq '1') 'advanced setter writes only the exact standard property on selected hardware'
Assert ($script:writes[-1].keyword -ceq '*EEE') 'Interrupt Moderation remains independent while EEE is modified'
Write-NicValue $eee $original
Assert ($script:advancedRows[0].RegistryValue[0] -ceq '1') 'advanced original enum is restored exactly'
Assert (Test-NicRestoreState $eee @{value='0'} @{value='1'} @{value='0'}) 'known desired advanced value is restorable'
Assert (-not (Test-NicRestoreState $eee @{value='2'} @{value='1'} @{value='0'})) 'unknown externally changed advanced value is rejected'
Reject {Assert-NicValue $eee @{value=0}} 'saved advanced value must retain canonical string type'
Reject {Assert-NicValue $eee @{value='00'}} 'noncanonical saved enum is rejected'
Reject {Assert-NicValue $eee @{value='4294967296'}} 'saved enum cannot overflow unsigned Registry range'

$script:advancedRows[0].ValidRegistryValues=@('1');Assert (-not (Get-NicApplicability $eee).applicable) 'disabled enum absent from driver list is not guessed'
$script:advancedRows[0].ValidRegistryValues=$null;Assert (-not (Get-NicApplicability $eee).applicable) 'missing driver enum metadata is explicitly unavailable'
$script:advancedRows[0].ValidRegistryValues=@('0','1','1');Reject {Get-NicApplicability $eee} 'ambiguous driver enum metadata remains an error'
$script:advancedRows[0].ValidRegistryValues=@('0',$true);Reject {Get-NicApplicability $eee} 'boolean driver metadata cannot coerce to an enum'
$script:advancedRows[0].ValidRegistryValues=@('0','1');$script:advancedRows[0].RegistryValue=@('7');Reject {Get-NicApplicability $eee} 'current driver value outside its own enum list remains an error'
$script:advancedRows[0].RegistryValue=@('1');$script:advancedError=$true;Reject {Get-NicApplicability $eee} 'advanced access failure is not suppressed'
$script:advancedError=$false;$script:advancedRows[0].RegistryKeyword='VendorEEE';Assert (-not (Get-NicApplicability $eee).applicable) 'vendor display or keyword aliases never substitute for standard EEE'
$script:advancedRows[0].RegistryKeyword='*EEE';$script:advancedRows+=,[pscustomobject]@{Name='Ethernet[1]';RegistryKeyword='*EEE';RegistryValue=@('1');ValidRegistryValues=@('0','1')}
Reject {Get-NicApplicability $eee} 'duplicate standard properties cannot choose an arbitrary original'
$script:advancedRows=$script:advancedRows[0..2];$script:noOp=$true
Reject {Write-NicValue $eee @{value='0'}} 'setter success without driver readback is never claimed applied'
$script:noOp=$false

# Restoration follows hardware GUID after a later stable rename; a replacement
# adapter holding the old alias is not the original target.
$script:adapters[0].Name='Renamed adapter';$script:powerRows[0].Name='Renamed adapter';$script:advancedRows[0].Name='Renamed adapter';$script:advancedRows[1].Name='Renamed adapter'
$resolved=Resolve-NicOperation @{type='nic-advanced';keyword='*EEE';value='0'} '' @{type='nic-advanced';keyword='*EEE';value='0';adapterGuid=$guid}
Write-NicValue $resolved @{value='0'}
Assert ($script:writes[-1].name -ceq 'Renamed adapter' -and $resolved.keyword -ceq '*EEE') 'stable rename restores by GUID and never trusts a saved keyword'
Reject {Resolve-NicOperation @{type='nic-advanced';keyword='*EEE';value='0'} '' @{type='nic-advanced';keyword='*InterruptModeration';value='0';adapterGuid=$guid}} 'saved journal cannot substitute another advanced NIC keyword'
Reject {Resolve-NicOperation @{type='nic-advanced';keyword='*EEE';value='0'} '' @{type='nic-advanced';keyword='*EEE';value='1';adapterGuid=$guid}} 'saved journal cannot substitute another fixed NIC operation value'
$script:adapters=$script:adapters[1..1];$count=$script:writes.Count
Reject {Write-NicValue $resolved @{value='1'}} 'missing original hardware cannot use a replacement alias'
Assert ($script:writes.Count -eq $count) 'missing hardware causes zero additional writes'
@{success=$true;assertions=$script:assertions;scope='Real NIC functions; Windows driver getters/setters mocked; no OS changes.'}|ConvertTo-Json -Compress
