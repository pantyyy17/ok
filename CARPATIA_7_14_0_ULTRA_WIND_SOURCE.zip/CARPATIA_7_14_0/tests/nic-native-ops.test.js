'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
test('typed NIC operations preserve physical identity, driver enums and exact originals',t=>{
 const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'nic-native-ops.ps1')],{encoding:'utf8',timeout:30000});
 if(result.error?.code==='ENOENT'){t.skip('PowerShell unavailable; set CARPATIA_PWSH for mocked native regressions.');return}
 assert.ifError(result.error);assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));assert.equal(report.success,true);assert(report.assertions>=45);
});
