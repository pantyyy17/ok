'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
test('native GPU tuning policy preserves originals, guards exact hardware and verifies rollback with a fake driver',t=>{
 const compiler=process.env.CARPATIA_CXX||'g++';
 const probe=spawnSync(compiler,['--version'],{encoding:'utf8',timeout:10000});
 if(probe.error?.code==='ENOENT'){t.skip('C++ compiler unavailable; Windows build script runs the same policy tests with MSVC.');return}
 assert.ifError(probe.error);assert.equal(probe.status,0,probe.stderr);
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-native-gpu-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
 const source=path.join(__dirname,'../native/gpu-tuning/policy_test.cpp'),binary=path.join(directory,process.platform==='win32'?'policy-test.exe':'policy-test');
 const build=spawnSync(compiler,['-std=c++17','-Wall','-Wextra','-Werror',source,'-o',binary],{encoding:'utf8',timeout:30000});assert.ifError(build.error);assert.equal(build.status,0,build.stderr);
 const result=spawnSync(binary,[],{encoding:'utf8',timeout:10000});assert.ifError(result.error);assert.equal(result.status,0,result.stderr);
 const report=JSON.parse(result.stdout);assert.equal(report.success,true);assert(report.assertions>=35);
});
