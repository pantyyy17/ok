'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {descriptor,createProfileService}=require('../dashboard-profiles'),catalog=require('../tweak-library-core'),{snapshotRows}=require('../snapshot-core');
const guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
test('Ultra extends only reversible trusted power, Game Mode and NIC controls and preserves older tiers',()=>{
 const expected={cpu:['library-cpu-frequency-cap','library-cpu-usb-awake'],gpu:['library-gpu-auto-game-mode','library-gpu-pcie-performance'],internet:['library-net-nic-power','library-net-eee-off','library-net-interrupt-off']};
 for(const [group,ids] of Object.entries(expected)){const high=descriptor(group,'high',guid),ultra=descriptor(group,'ultra',guid);for(const id of ids){assert(!high.steps.some(s=>s.id===id));assert(ultra.steps.some(s=>s.id===id));const r=catalog.getRule(id);assert(['registry','native'].includes(r.status));assert(!['security','boot'].includes(r.impact))}}
});
test('NIC snapshots preserve unsupported power fields and distinguish EEE and interrupt targets',()=>{
 const power=catalog.getRule('library-net-nic-power'),values={selectiveSuspend:'Enabled',deviceSleepOnDisconnect:null};
 const p=snapshotRows([{id:power.id,success:true,operation:{...power.operation,adapterGuid:guid},current:values}]);assert.deepEqual(p[0].target,values);
 const entries=['library-net-eee-off','library-net-interrupt-off'].map(id=>{const r=catalog.getRule(id);return {id,success:true,operation:{...r.operation,adapterGuid:guid},current:{value:'1'}}});
 const rows=snapshotRows(entries);assert.equal(rows.length,2);assert.notEqual(rows[0].resource,rows[1].resource);
 assert.throws(()=>snapshotRows([{...entries[0],current:{value:'01'}}]));assert.throws(()=>snapshotRows([{...entries[0],operation:{...entries[0].operation,keyword:'*OTHER'}}]));
});
test('unsupported NIC fields are omitted without blocking the remaining Ultra profile and reused NIC originals remain target-bound',async()=>{
 const sessions=new Map(),states=new Map();let unsupported=true;
 const ops={snapshot:async()=>({success:true,osBuild:26200,ramGB:7.4,gpu:['AMD Radeon']}),status:async()=>({success:true,states:[...states.values()]}),check:async id=>{const r=catalog.getRule(id);if(unsupported&&r.operation?.type.startsWith('nic-'))return {success:false,notApplicable:true,message:'Driverul nu oferă această opțiune.'};return {success:true,matching:true,operation:{...r.operation,adapterGuid:guid}}},apply:async id=>{states.set(id,{id,state:'applied'});return {success:true}},restore:async id=>{states.set(id,{id,state:'restored'});return {success:true}}};
 const service=()=>createProfileService({store:{read:g=>sessions.get(g),write:(g,s)=>sessions.set(g,structuredClone(s))},ops});
 let s=service(),p=await s.prepare({group:'internet',level:'ultra',adapterGuid:guid});assert.equal(p.plan.skipped.length,3);assert.equal((await s.commit(p.token)).success,true);assert.equal((await service().restore('internet')).success,true);
 unsupported=false;const r=catalog.getRule('library-net-eee-off');states.set(r.id,{id:r.id,state:'applied',operation:{...r.operation,adapterGuid:'bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee'}});
 await assert.rejects(service().prepare({group:'internet',level:'ultra',adapterGuid:guid}),/Conflict real/);
});
