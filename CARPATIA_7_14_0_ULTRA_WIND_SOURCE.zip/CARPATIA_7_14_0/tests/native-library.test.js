'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const catalog=require('../tweak-library.json');
const {authorize,engineFor,validateAdapter,isActiveState,publicCatalog}=require('../tweak-library-core');
test('every executable entry is routed to a typed engine and requires exact acknowledgement',()=>{
 let count=0;
 for(const row of catalog){
  if(!['registry','native','maintenance'].includes(row.status))continue;
  count++;assert.throws(()=>authorize(row.id,'Apply',false));
  if(row.applyBlocked){assert.throws(()=>authorize(row.id,'Apply',true),error=>error.message===row.applyBlocked);assert.equal(authorize(row.id,'Restore'),row.id)}
  else assert.equal(authorize(row.id,'Apply',true),row.id);
  assert.equal(engineFor(row.id),row.status==='registry'?'tweak-library.ps1':'tweak-native.ps1');
  if(row.status!=='registry'){assert.ok(row.operation?.type);assert.equal(row.entries.length,0)}
 }
 assert.equal(count,222);assert.equal(publicCatalog().length,222);assert.ok(publicCatalog().every(x=>['registry','native','maintenance'].includes(x.status)));
});
test('adapter boundary rejects aliases, shell strings and arbitrary values',()=>{
 for(const value of ['Ethernet','*',';whoami',{},1,'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee /foo','{aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee','aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee}'])assert.throws(()=>validateAdapter(value));
 assert.equal(validateAdapter('aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'),'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee');
 assert.equal(validateAdapter(undefined),'');
});
test('interrupted maintenance is not restorable and only maintenance accepts acknowledgement',()=>{
 for(const row of catalog){
  if(row.status==='maintenance'){assert.throws(()=>authorize(row.id,'Restore'));assert.equal(authorize(row.id,'Acknowledge'),row.id)}
  else assert.throws(()=>authorize(row.id,'Acknowledge'));
 }
 assert.ok(isActiveState('prepared'));assert.ok(isActiveState('failed'));assert.ok(!isActiveState('completed'));assert.ok(!isActiveState('restored'));
});
function mount(data,states=[],opts={}){
 class Element{constructor(tag){this.tag=tag;this.children=[];this.value='';this.listeners={};this.textContent=''}setAttribute(k,v){this[k]=v}append(...a){this.children.push(...a)}replaceChildren(...a){this.children=a}get firstChild(){return this.children[0]}addEventListener(k,v){this.listeners[k]=v}}
 const source=fs.readFileSync(path.join(__dirname,'../tweak-library-ui.js'),'utf8');
 const ids=Object.fromEntries([...source.matchAll(/\$\('([\w-]+)'\)/g)].map(m=>[m[1],new Element()]));
 for(const id of ['tweakSearch','tweakCategory','tweakStatus'])ids[id]||=new Element();
 const calls=[],recoveries=[],messages=[];
 const api={tweakLibrary:async()=>data,tweakLibraryState:async()=>({success:true,states,ownership:opts.ownership||{}}),tweakLibraryContext:async()=>({adapters:[],compatibility:opts.compatibility||{}}),tweakLibraryApply:async(...a)=>{calls.push(['apply',...a]);if(opts.fail)states.push({id:a[0],state:'failed',reversible:true});return {success:!opts.fail,message:opts.fail?'Windows refused':'verified'}},tweakLibraryRestore:async id=>{calls.push(['restore',id]);return {success:true}},tweakLibraryAcknowledge:async id=>{calls.push(['ack',id]);return {success:true}}};
 const window={};vm.runInNewContext(source,{window,document:{getElementById:id=>ids[opts.prefix&&id.startsWith(opts.prefix)?id.slice(opts.prefix.length):id],createElement:t=>new Element(t)}});
 const page=window.CarpatiaTweaks.mount({api,prefix:opts.prefix||'',onlyCategory:opts.onlyCategory||'',requireNative:recovery=>{recoveries.push(recovery);return true},task:async(_,f)=>f(),confirmDialog:async()=>opts.confirm!==false,showToast:m=>messages.push(m)});
 const buttons=()=>ids.tweakRows.children.flatMap(c=>c.children.filter(e=>e.className==='inline-actions').flatMap(e=>e.children)).filter(e=>e.tag==='button');
 return {page,ids,calls,recoveries,messages,buttons};
}
test('network apply requires explicit adapter and confirmation; cancellation does not mutate',async()=>{
 const row=publicCatalog().find(x=>x.operation?.type==='dns');const x=mount([row]);await x.page.load();await x.buttons()[0].onclick();assert.equal(x.calls.length,0);assert.match(x.messages[0],/adaptorul/);
 x.ids.tweakAdapter.value='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';await x.buttons()[0].onclick();assert.deepEqual(x.calls[0],['apply',row.id,true,x.ids.tweakAdapter.value]);
 const y=mount([row],[],{confirm:false});await y.page.load();y.ids.tweakAdapter.value=x.ids.tweakAdapter.value;await y.buttons()[0].onclick();assert.equal(y.calls.length,0);
});
test('failed native mutation reloads journal and exposes recovery without license gating',async()=>{
 const row=publicCatalog().find(x=>x.status==='native'&&x.operation.type==='service');const x=mount([row],[],{fail:true});await x.page.load();await x.buttons()[0].onclick();
 assert.equal(x.ids.tweakOperationStatus.textContent.includes('Windows refused'),true);
 const restore=x.buttons().find(x=>x.textContent==='RESTAUREAZĂ');assert.ok(restore);await restore.onclick();assert.equal(x.recoveries.at(-1),true);assert.deepEqual(x.calls.at(-1),['restore',row.id]);
});
test('interrupted irreversible operation exposes acknowledge, never restore',async()=>{
 const row=publicCatalog().find(x=>x.status==='maintenance');const x=mount([row],[{id:row.id,state:'prepared',reversible:false}]);await x.page.load();
 assert.ok(!x.buttons().some(x=>x.textContent==='RESTAUREAZĂ'));assert.ok(x.buttons()[0].disabled);
 await x.buttons().find(x=>x.textContent.includes('AM VERIFICAT')).onclick();assert.deepEqual(x.calls[0],['ack',row.id]);
});

test('Network page mounts scoped controls and only network entries, preserving Apply and Restore',async()=>{
 const data=publicCatalog(),row=data.find(x=>x.id==='library-net-004');const x=mount(data,[],{prefix:'network-',onlyCategory:'Network',fail:true});
 await x.page.load();assert.equal(x.ids.tweakRows.children.length,data.filter(x=>x.category==='Network').length);
 x.ids.tweakSearch.value=row.title;x.ids.tweakSearch.listeners.input();assert.equal(x.ids.tweakRows.children.length,1);
 await x.buttons()[0].onclick();assert.equal(x.calls[0][1],row.id);
 await x.buttons().find(x=>x.textContent==='RESTAUREAZĂ').onclick();assert.deepEqual(x.calls.at(-1),['restore',row.id]);
});

test('ownership card blocks duplicate Apply and exposes owner navigation',async()=>{
 const row=publicCatalog().find(x=>x.id==='library-ram-006');const x=mount([row],[],{ownership:{[row.id]:[{id:'library-cpu-035',module:'Tweaks',route:'tweaks'}]}});await x.page.load();assert.equal(x.buttons().find(b=>b.textContent==='APLICĂ').disabled,true);
 assert.equal(x.calls.length,0);
});
test('incompatible rows hide by default, Show all exposes them disabled, saved originals remain restorable',async()=>{
 const row=publicCatalog().find(x=>x.id==='library-gpu-003'),compatibility={[row.id]:{state:'incompatible',reason:'Necesită NVIDIA.'}};
 const x=mount([row],[],{compatibility});await x.page.load();assert.equal(x.buttons().length,0);x.ids.tweakShowAll.checked=true;x.ids.tweakShowAll.listeners.change();assert.equal(x.buttons().length,1);assert.equal(x.buttons()[0].disabled,true);
 const y=mount([row],[{id:row.id,state:'applied'}],{compatibility});await y.page.load();assert.ok(y.buttons().some(x=>x.textContent==='RESTAUREAZĂ'));assert.equal(y.ids.tweakRows.children.length,1);
});
test('unknown compatibility remains visible with explanation',async()=>{const row=publicCatalog()[0],x=mount([row],[],{compatibility:{[row.id]:{state:'unknown',reason:'Hardware necunoscut.'}}});await x.page.load();assert.equal(x.buttons().length,1);assert.ok(x.ids.tweakRows.children[0].children.some(n=>n.textContent.includes('Compatibilitate neconfirmată')))});
