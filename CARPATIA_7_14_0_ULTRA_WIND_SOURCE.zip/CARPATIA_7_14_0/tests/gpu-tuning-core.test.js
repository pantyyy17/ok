'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createGpuTuningService}=require('../gpu-tuning-core');
function fixture(overrides={}){
 let time=0;const calls=[],row={gpuId:'PCI\\VEN_1002&DEV_TEST',name:'AMD test',supported:true,backup:false,currentMhz:2000,minMhz:1500,maxMhz:2500,stepMhz:10,minOperatingMhz:1000,originalMhz:null};
 const invoke=async request=>{calls.push(request);if(overrides[request.action])return overrides[request.action](row,request);if(request.action==='query')return {success:true,available:true,supported:true,gpus:[{...row}]};if(request.action==='apply'){row.originalMhz=row.currentMhz;row.currentMhz=request.mhz;row.backup=true;return {success:true,backup:true}}row.currentMhz=row.originalMhz;row.backup=false;return {success:true}};
 return {row,calls,service:createGpuTuningService({invoke,now:()=>time}),expire:()=>time+=61000};
}
test('hardware query and preview never write and commit accepts only a single-use confirmed token',async()=>{
 const h=fixture();await h.service.status();const p=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});assert(h.calls.every(c=>c.action==='query'));assert.equal(p.plan.fromMhz,2000);assert.equal(p.plan.toMhz,2050);
 assert.equal((await h.service.commit(p.token)).success,true);assert.deepEqual(h.calls.find(c=>c.action==='apply'),{action:'apply',gpuId:h.row.gpuId,mhz:2050,expectedMhz:2000});await assert.rejects(h.service.commit(p.token),/expirat/);
 assert.equal((await h.service.restore(h.row.gpuId)).success,true);assert.equal(h.row.currentMhz,2000);
});
test('wrong range, step, payload paths and unknown GPU cannot prepare a hardware write',async()=>{
 const h=fixture();for(const request of [{gpuId:h.row.gpuId,mhz:2600},{gpuId:h.row.gpuId,mhz:2001},{gpuId:h.row.gpuId,mhz:'2050'},{gpuId:h.row.gpuId,mhz:2050,backupDirectory:'HACK'},{gpuId:'OTHER',mhz:2050}])await assert.rejects(h.service.prepare(request));assert(h.calls.every(c=>c.action==='query'));
});
test('expiry and changed driver state require new confirmation before writing',async()=>{
 const h=fixture(),p=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});h.expire();await assert.rejects(h.service.commit(p.token),/expirat/);
 const p2=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});h.row.currentMhz=2010;await assert.rejects(h.service.commit(p2.token),/schimbat/);assert(h.calls.every(c=>c.action==='query'));
});
test('unavailable helper and an unrestorable original never authorize clock changes',async()=>{
 const unavailable=createGpuTuningService({invoke:async()=>({success:true,available:false,supported:false,gpus:[],reason:'Indisponibil'})});assert.equal((await unavailable.status()).available,false);await assert.rejects(unavailable.prepare({gpuId:'AMD',mhz:2000}),/Indisponibil/);
 for(const changes of [{currentMhz:2005},{minOperatingMhz:2100},{maxMhz:10001},{backup:true}]){const h=fixture();Object.assign(h.row,changes);await assert.rejects(h.service.prepare({gpuId:h.row.gpuId,mhz:2050}));assert(h.calls.every(c=>c.action==='query'))}
});
test('an already configured preview creates no token or backup and invalidates earlier confirmation for that GPU',async()=>{
 const h=fixture(),old=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});
 const result=await h.service.prepare({gpuId:h.row.gpuId,mhz:2000});assert.equal(result.already,true);assert.equal(result.token,null);assert.equal(result.plan.fromMhz,2000);assert.equal(result.plan.toMhz,2000);
 await assert.rejects(h.service.commit(old.token),/expirat/);assert(h.calls.every(c=>c.action==='query'));assert.equal(h.row.backup,false);assert.equal(h.row.originalMhz,null);
});
test('an apply success requires independent target, original and active-backup readback',async()=>{
 for(const actual of [{currentMhz:2000,backup:false,originalMhz:null},{currentMhz:2050,backup:false,originalMhz:2000},{currentMhz:2050,backup:true,originalMhz:2010},{currentMhz:2050,backup:true,originalMhz:null}]){
  const h=fixture({apply:async row=>{Object.assign(row,actual);return {success:true}}}),plan=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});
  await assert.rejects(h.service.commit(plan.token));assert.equal(h.calls.filter(c=>c.action==='apply').length,1);assert.equal(h.calls.at(-1).action,'query');
 }
});
test('restore success requires the exact saved MHz and the active backup to be cleared',async()=>{
 for(const actual of [{currentMhz:2050,backup:false},{currentMhz:2000,backup:true}]){
  const h=fixture({restore:async row=>{Object.assign(row,actual);return {success:true}}});Object.assign(h.row,{currentMhz:2050,backup:true,originalMhz:2000});
  await assert.rejects(h.service.restore(h.row.gpuId),/recitire/);assert.equal(h.calls.at(-1).action,'query');
 }
});
test('active supported originals require a bounded integer frequency before recovery is authorized',async()=>{
 for(const originalMhz of [undefined,null,'2000',0,10001,2000.5]){
  const h=fixture();Object.assign(h.row,{backup:true,originalMhz});await assert.rejects(h.service.status(),/originală/);await assert.rejects(h.service.restore(h.row.gpuId),/originală/);assert(h.calls.every(c=>c.action==='query'));
 }
});
test('native failure diagnostics and the saved original survive unsuccessful apply and restore',async()=>{
 const h=fixture({apply:async(row,request)=>{Object.assign(row,{originalMhz:row.currentMhz,currentMhz:request.mhz,backup:true});return {success:false,message:'Driver readback failed; original retained'}},restore:async()=>({success:false,message:'External utility changed the maximum'})});
 const plan=await h.service.prepare({gpuId:h.row.gpuId,mhz:2050});await assert.rejects(h.service.commit(plan.token),/Driver readback failed; original retained/);assert.equal((await h.service.status()).gpus[0].backup,true);
 await assert.rejects(h.service.restore(h.row.gpuId),/External utility/);assert.equal(h.row.originalMhz,2000);assert.equal(h.row.backup,true);
});
