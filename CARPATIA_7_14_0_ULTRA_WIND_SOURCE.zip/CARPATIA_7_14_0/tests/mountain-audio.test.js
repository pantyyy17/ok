'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {mount,STORAGE_KEY,synthesizeWind}=require('../mountain-audio');
const flush=async()=>{for(let i=0;i<5;i++)await Promise.resolve()};
function harness({stored=null,storageFails=false,supported=true,resumeFailure=false,pendingResume=false}={}){
 const targets=[];
 class Target{
  constructor(id=''){this.id=id;this.listeners=[];this.attributes={};this.disabled=false;this.textContent='';targets.push(this)}
  addEventListener(type,handler,options){this.listeners.push({type,handler,options})}
  removeEventListener(type,handler,options){this.listeners=this.listeners.filter(x=>x.type!==type||x.handler!==handler||x.options!==options)}
  setAttribute(name,value){this.attributes[name]=value}
  emit(type,event={}){for(const item of [...this.listeners])if(item.type===type)item.handler({isTrusted:true,target:this,...event})}
 }
 const panel={active:true,classList:{contains:()=>panel.active}},ids={};
 for(const id of ['heroDebloat','heroUltra','heroNetwork','mountainSound','mountainSoundStatus']){
  ids[id]=new Target(id);ids[id].rects=[{}];ids[id].inert=false;
  ids[id].closest=selector=>selector==='.view'?panel:ids[id].inert?{}:null;
  ids[id].getClientRects=()=>ids[id].rects;
 }
 const document=new Target(),window=new Target();document.hidden=false;document.visibilityState='visible';document.getElementById=id=>ids[id];
 let time=0,releaseResume,contexts=[],buffers=0,preferences=stored;
 const storage={getItem(){if(storageFails)throw Error('Storage denied');return preferences},setItem(key,value){assert.equal(key,STORAGE_KEY);if(storageFails)throw Error('Storage denied');preferences=value}};
 const param=()=>({events:[],setValueAtTime(value,at){this.events.push({value,at})},exponentialRampToValueAtTime(value,at){this.events.push({value,at})}});
 class AudioNode{
  constructor(type){this.kind=type;this.disconnected=false;this.started=[];this.stopped=[];this.frequency=param();this.Q=param();this.gain=param()}
  connect(to){this.destination=to;return to}
  disconnect(){this.disconnected=true}
  start(at){this.started.push(at)}
  stop(at){this.stopped.push(at)}
 }
 class Audio{
  constructor(){this.state='suspended';this.sampleRate=8000;this.currentTime=0;this.destination={};this.nodes=[];this.resumes=0;this.suspends=0;this.closes=0;contexts.push(this)}
  resume(){this.resumes++;if(resumeFailure)return Promise.reject(Error('Blocked audio'));if(pendingResume)return new Promise(resolve=>{releaseResume=()=>{this.state='running';resolve()}});this.state='running';return Promise.resolve()}
  suspend(){this.suspends++;this.state='suspended';return Promise.resolve()}
  close(){this.closes++;this.state='closed';return Promise.resolve()}
  createBuffer(channels,length,sampleRate){buffers++;assert.equal(channels,1);assert.equal(sampleRate,this.sampleRate);const data=new Float32Array(length);return {getChannelData:()=>data}}
  create(kind){const node=new AudioNode(kind);this.nodes.push(node);return node}
  createBufferSource(){return this.create('noise')}
  createBiquadFilter(){return this.create('filter')}
  createGain(){return this.create('gain')}
  createOscillator(){return this.create('tone')}
 }
 if(supported)window.AudioContext=Audio;window.localStorage=storage;
 const page=mount({document,window,now:()=>time,random:()=>.75});
 return {page,ids,document,window,panel,contexts,Audio,targets,get preferences(){return preferences},get buffers(){return buffers},advance:ms=>{time+=ms},release:()=>releaseResume?.(),noise:()=>contexts.flatMap(c=>c.nodes.filter(n=>n.kind==='noise')),arm:()=>document.emit('pointerdown'),cue:(id='heroDebloat',type='pointerenter',event={})=>ids[id].emit(type,event)};
}
test('audio opens only after a trusted gesture, then hover plays one bounded two-layer gust',async()=>{
 const h=harness();assert.equal(h.contexts.length,0);assert.equal(h.page.getState().enabled,true);assert.match(h.ids.mountainSoundStatus.textContent,/primul clic/);
 h.cue();h.document.emit('pointerdown',{isTrusted:false});await flush();assert.equal(h.contexts.length,0);
 h.arm();await flush();assert.equal(h.contexts.length,1);assert.equal(h.contexts[0].state,'suspended');
 h.cue();await flush();assert.equal(h.page.getState().active,1);assert.equal(h.noise().length,2);
 assert.deepEqual(h.noise().map(source=>source.started[0]),[0,.07]);assert(h.noise().every(source=>source.stopped[0]===.7));assert.equal(h.buffers,1);
 assert(h.contexts[0].nodes.every(node=>node.kind!=='tone'),'Wind must not reintroduce a metallic oscillator');
 h.page.destroy();
});
test('hover plus click is deduplicated and moving rapidly never overlaps two voices',async()=>{
 const h=harness();h.arm();h.cue('heroDebloat','pointerdown',{button:0});await flush();assert.equal(h.noise().length,2);
 h.cue('heroUltra');h.advance(100);h.cue('heroNetwork');await flush();assert.equal(h.noise().length,2);
 h.advance(100);h.cue('heroNetwork');await flush();assert.equal(h.noise().length,4);assert.equal(h.page.getState().active,1);
 assert(h.noise().slice(0,2).every(source=>source.disconnected&&source.stopped.length===2),'Replacing a gust stops both old layers');
 assert(h.noise().slice(2).every(source=>source.stopped[0]===.77));assert.equal(h.buffers,1);
 assert(h.noise().every(source=>source.buffer===h.noise()[0].buffer),'All gusts reuse the noise buffer');
 h.page.destroy();
});
test('disabled, inert, invisible and inactive mountain controls stay silent',async()=>{
 const h=harness();h.arm();await flush();
 const button=h.ids.heroDebloat;
 for(const change of [()=>{button.disabled=true},()=>{button.disabled=false;button.inert=true},()=>{button.inert=false;button.rects=[]},()=>{button.rects=[{}];h.panel.active=false},()=>{h.panel.active=true;h.document.hidden=true}]){change();h.advance(250);h.cue();await flush();assert.equal(h.noise().length,0)}
 h.document.hidden=false;h.cue('heroDebloat','pointerenter',{isTrusted:false});await flush();assert.equal(h.noise().length,0);h.page.destroy();
});
test('mute stops current audio, persists the preference and remains usable if storage is denied',async()=>{
 const h=harness();h.arm();h.cue();await flush();h.ids.mountainSound.emit('click');await flush();
 assert.equal(h.page.getState().active,0);assert.equal(h.page.getState().enabled,false);assert.equal(h.preferences,'off');assert.equal(h.contexts[0].state,'suspended');assert.equal(h.ids.mountainSound.attributes['aria-pressed'],'false');
 assert(h.noise().every(source=>source.disconnected&&source.stopped.length===2),'Muting stops and disconnects both layers');
 h.advance(300);h.cue();await flush();assert.equal(h.noise().length,2);h.page.destroy();
 const saved=harness({stored:'off'});saved.arm();await flush();assert.equal(saved.contexts.length,0);assert.equal(saved.page.getState().enabled,false);saved.page.destroy();
 const denied=harness({storageFails:true});denied.page.setEnabled(false);assert.equal(denied.page.getState().enabled,false);denied.page.setEnabled(true);assert.equal(denied.page.getState().enabled,true);denied.page.destroy();
});
test('blur and hiding cancel sounds; natural completion disconnects nodes and suspends idle context',async()=>{
 const h=harness();h.arm();h.cue();await flush();const first=h.noise()[0];first.onended();await flush();assert.equal(h.page.getState().active,0);assert(h.contexts[0].nodes.every(n=>n.disconnected));assert.equal(h.contexts[0].state,'suspended');
 h.advance(250);h.cue();await flush();h.window.emit('blur');assert.equal(h.page.getState().active,0);assert.equal(h.contexts[0].state,'suspended');
 assert(h.noise().slice(-2).every(source=>source.stopped.length===2&&source.disconnected));
 h.advance(250);h.cue();await flush();h.document.hidden=true;h.document.emit('visibilitychange');assert.equal(h.page.getState().active,0);assert(h.noise().slice(-2).every(source=>source.stopped.length===2&&source.disconnected));h.page.destroy();
});
test('pending resume cannot play after mute or teardown and all event handlers are removed',async()=>{
 for(const action of ['mute','destroy']){
  const h=harness({pendingResume:true});h.arm();h.cue();action==='mute'?h.page.setEnabled(false):h.page.destroy();h.release();await flush();assert.equal(h.noise().length,0);assert.equal(h.page.getState().active,0);
  h.page.destroy();h.page.destroy();assert(h.targets.every(t=>t.listeners.length===0));assert.equal(h.contexts[0].closes,1);
 }
});
test('keyboard navigation plays on focus and unsupported or blocked audio leaves controls functional',async()=>{
 const h=harness();h.ids.heroUltra.emit('focus');await flush();assert.equal(h.contexts.length,0);
 h.document.emit('keydown',{key:'Tab'});h.ids.heroUltra.emit('focus');await flush();assert.equal(h.noise().length,2);h.document.emit('keydown',{key:'Enter',target:h.ids.heroUltra});await flush();assert.equal(h.noise().length,2);h.page.destroy();
 const unavailable=harness({supported:false});assert.equal(unavailable.page.getState().available,false);unavailable.arm();await flush();assert.equal(unavailable.contexts.length,0);unavailable.page.setEnabled(false);unavailable.page.destroy();
 const blocked=harness({resumeFailure:true});blocked.arm();blocked.cue();await flush();assert.equal(blocked.noise().length,0);assert.equal(blocked.page.getState().unlocked,false);blocked.page.destroy();
});
test('offline wind has no tone, a soft attack and bounded trailing envelopes without opening a device',()=>{
 const h=harness(),context=new h.Audio();const voice=synthesizeWind(context,context.destination,{index:9,volume:99,random:()=>.75});
 assert.equal(voice.duration,.77);assert.equal(voice.noise.getChannelData(0).length,7200);assert.equal(voice.sources.length,2);assert.equal(voice.tone,null);
 assert(voice.sources.every(source=>source.buffer===voice.noise&&source.stopped[0]===voice.duration));assert(voice.nodes.every(node=>node.kind!=='tone'));
 const envelopes=voice.nodes.filter(node=>node.kind==='gain'&&node.gain.events.length>1);
 assert.equal(envelopes.length,2);
 for(const envelope of envelopes){
  const events=envelope.gain.events;assert.equal(events[0].value,.0001);assert(events[1].at-events[0].at>=.1,'Attack swells instead of clicking');
  assert(events.every(event=>event.value>0&&event.value<=.12),'Volume remains bounded');assert.equal(events.at(-1).value,.0001);assert.equal(events.at(-1).at,voice.duration);
 }
 assert.equal(h.buffers,1);const again=synthesizeWind(context,context.destination,{noise:voice.noise,random:()=>{throw Error('Cached noise must be reused')}});assert.equal(again.noise,voice.noise);assert.equal(h.buffers,1);
 assert.equal(context.resumes,0);assert.equal(context.suspends,0);assert.equal(context.closes,0);h.page.destroy();context.close();
});
