'use strict';
window.CarpatiaTweaks={mount({api,requireNative,task,confirmDialog,showToast,prefix='',onlyCategory='',onOwner=null}){
 const $=id=>document.getElementById(prefix+id), rows=$('tweakRows');let compatibility={},ownership={},catalog=[],states=new Map(),categoryCounts=new Map(),renderedCategory=null,cardCache=new Map(),searchText=new Map(),catalogLoaded=false,adaptersLoaded=false,loadId=0;
 const node=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e};
 const labels={registry:'SETARE EXPERIMENTALĂ',native:'SETARE EXPERIMENTALĂ',maintenance:'FĂRĂ ANULARE',excluded:'INDISPONIBIL',unsupported:'INDISPONIBIL'};
 const riskLabels={low:'redus',medium:'mediu',high:'ridicat'};
 const stateLabels={prepared:'Operație întreruptă',applied:'Aplicat',failed:'Necesită verificare',restored:'Restaurat',completed:'Finalizat','maintenance-failed':'Operație nereușită',acknowledged:'Verificat manual'};
 const conditionLabels={'formFactor:Desktop':'PC desktop','formFactor:Laptop':'Laptop','cpu:Intel':'procesor Intel','cpu:AMD':'procesor AMD','gpu:NVIDIA':'placă video NVIDIA','gpu:AMD':'placă video AMD','gpu:Intel':'placă video Intel','storage:HDD':'hard disk','storage:SSD':'SSD','storage:NVMe':'NVMe','NVMe':'NVMe','network:Ethernet':'conexiune prin cablu','network:WiFi':'Wi-Fi','ram:>8GB':'peste 8 GB RAM','ram:>16GB':'peste 16 GB RAM','tier:LOW':'configurație entry-level','tier:HIGH':'configurație performantă','Windows 10/11; TCP global':'Windows 10/11 · toate conexiunile TCP'};
 const conditions=item=>!item.conditions||item.conditions==='always'?'':item.conditions.split(',').map(x=>conditionLabels[x]||x).join(' · ');
 const explanation=item=>item.description||(item.status==='maintenance'?'Operație punctuală, fără restaurare automată.':'Originalul este salvat înainte de modificare. Poți reveni prin Restaurare.');
 const executable=x=>['registry','native','maintenance'].includes(x.status);
 const cats={CPU:'Procesor',GPU:'Placă video',Network:'Rețea',RAM:'Memorie',Storage:'Stocare',Input:'Mouse & tastatură',Privacy:'Confidențialitate',Services:'Servicii',Gaming:'Jocuri',Windows:'Windows',Drivers:'Drivere',Advanced:'Avansat','Windows Utility':'Utilitare Windows'};
 const categoryInfo={
 CPU:['CPU','Procesor: planificarea sarcinilor, priorități și comportamentul de alimentare.'],
 GPU:['GPU','Placă video: randare, setări grafice, cache și opțiuni dependente de driver.'],
 Network:['Network','Rețea: DNS, conexiuni TCP/IP, adaptor și diagnostic de conectivitate.'],
 RAM:['RAM','Memorie: administrarea memoriei și opțiuni pentru cache și diagnostic.'],
 Storage:['Storage','Stocare: discuri, sistem de fișiere, cache și operații de întreținere.'],
 Input:['Input','Periferice: comportamentul mouse-ului, tastaturii și comenzilor de intrare.'],
 Windows:['Windows','Sistem: componente și comportamente generale ale Windows.'],
 'Windows Utility':['Windows Utility','Utilitare Windows: opțiuni pentru aplicații integrate, Explorer și funcții ale sistemului. Modificările de aspect rămân excluse.'],
 Gaming:['Gaming','Jocuri: opțiuni Windows asociate sesiunilor de joc.'],
 Privacy:['Privacy','Confidențialitate: colectarea datelor și preferințe de utilizare.'],
 Services:['Services','Servicii: procese Windows care rulează în fundal și modul lor de pornire.'],
 Drivers:['Drivers','Drivere: opțiuni legate de componentele software care controlează hardware-ul.'],
 Advanced:['Advanced','Avansat: opțiuni tehnice ale sistemului, cu compatibilitate și riscuri care trebuie verificate individual.']
 };
 function renderCategories(cat){
  if(renderedCategory===cat)return;renderedCategory=cat;
  const tabs=$('tweakCategoryTabs');tabs.replaceChildren();
  for(const key of ['',...Object.keys(categoryInfo).filter(key=>!onlyCategory||key===onlyCategory)]){
   const count=key?(categoryCounts.get(key)||0):catalog.length;
   const b=node('button','library-tab'+(cat===key?' active':''));b.type='button';
   b.setAttribute('aria-pressed',String(cat===key));
   b.append(node('span',null,key?categoryInfo[key][0]:'Toate'),node('small',null,count));
   b.onclick=()=>{$('tweakCategory').value=key;render()};tabs.append(b);
  }
  $('tweakCategoryTitle').textContent=cat?categoryInfo[cat]?.[0]||cat:'Toate categoriile';
  $('tweakCategoryHelp').textContent=cat?categoryInfo[cat]?.[1]||'':'Alege o categorie pentru a vedea doar setările componentei respective. Aplică individual setările pe care le alegi.';
 }
 async function load({refreshAdapters=false}={}){
  const request=++loadId;
  if(!catalogLoaded){const data=api?await api.tweakLibrary():window.CARPATIA_TWEAK_PREVIEW||[];if(request!==loadId)return;catalog=onlyCategory?data.filter(x=>x.category===onlyCategory):data;catalogLoaded=true;searchText=new Map(catalog.map(x=>[x.id,[x.title,x.category,cats[x.category]].join(' ').toLocaleLowerCase()]))}
  cardCache.clear();
  categoryCounts=new Map();for(const item of catalog)categoryCounts.set(item.category,(categoryCounts.get(item.category)||0)+1);renderedCategory=null;
  if(api){const r=await api.tweakLibraryState();if(request!==loadId)return;if(!r.success)showToast('Există backupuri necitibile. Aplicarea poate fi blocată.');ownership=r.ownership||{};states=new Map((r.states||[]).map(x=>[x.id,x]));
   if(!adaptersLoaded||refreshAdapters){
   const oldAdapter=$('tweakAdapter').value;
   $('tweakAdapter').replaceChildren(node('option',null,'Alege adaptorul pentru setările de rețea…'));$('tweakAdapter').firstChild.value='';
   try{const ctx=await api.tweakLibraryContext();if(request!==loadId)return;compatibility=ctx.compatibility||{};for(const a of ctx.adapters||[]){const option=node('option',null,a.name+' · '+a.status);option.value=a.guid;$('tweakAdapter').append(option)}$('tweakAdapter').value=oldAdapter;adaptersLoaded=true}catch(e){if(request!==loadId)return;showToast('Lista adaptoarelor nu este disponibilă: '+String(e.message||e))}
   }
  }
  const selected=$('tweakCategory').value;
  $('tweakCategory').replaceChildren(node('option',null,'Toate categoriile'));$('tweakCategory').firstChild.value='';
  for(const category of [...new Set(catalog.map(x=>x.category))]){const o=node('option',null,(cats[category]||category)+' ('+categoryCounts.get(category)+')');o.value=category;$('tweakCategory').append(o)}
  $('tweakCategory').value=selected;render();
 }
 function render(){
  const q=$('tweakSearch').value.trim().toLocaleLowerCase(),cat=$('tweakCategory').value,status=$('tweakStatus').value;
  renderCategories(cat);
  $('tweakAdapterWrap').hidden=!!cat&&cat!=='Network';
  const visible=catalog.filter(x=>$('tweakShowAll')?.checked||compatibility[x.id]?.state!=='incompatible'||['prepared','failed','applied'].includes(states.get(x.id)?.state));
  const filtered=visible.filter(x=>(!cat||x.category===cat)&&(!status||(status==='reversible'?['registry','native'].includes(x.status):x.status===status))&&(!q||searchText.get(x.id).includes(q)));
  $('tweakSummary').textContent=`${filtered.length} setări afișate${catalog.length-visible.length?' · '+(catalog.length-visible.length)+' incompatibile ascunse':''}`;
  rows.replaceChildren(...filtered.map(item=>{if(!cardCache.has(item.id))cardCache.set(item.id,createCard(item));return cardCache.get(item.id)}));
  if(!filtered.length)rows.append(node('p',null,'Nicio setare nu corespunde filtrelor.'));
 }
 function createCard(item){
   const card=node('article','library-row');const head=node('div','library-head');const text=node('div');text.append(node('small','library-category',cats[item.category]||item.category),node('h3',null,item.title));head.append(text,node('span','pill',labels[item.status]));card.append(head);
   card.append(node('p','library-description',explanation(item)));
   const meta=['Risc estimat: '+(riskLabels[item.risk]||'de verificat')];if(item.restart)meta.push('Necesită restart');
   card.append(node('p','library-meta',meta.join(' · ')));
   const match=item.applyBlocked?{state:'incompatible',reason:item.applyBlocked}:compatibility[item.id];if(match?.state==='incompatible')card.append(node('p','library-reason','Incompatibil cu acest PC: '+match.reason));else if(match?.state==='unknown')card.append(node('p','library-meta','Compatibilitate neconfirmată: '+match.reason));
   if(conditions(item))card.append(node('p','library-meta','Compatibilitate de verificat: '+conditions(item)));
   if(item.impact==='security')card.append(node('p','library-reason','Poate reduce protecția Windows. Verifică efectul înainte de aplicare.'));
   else if(item.impact==='boot')card.append(node('p','library-reason','Modifică pornirea Windows și poate afecta stabilitatea.'));
   if(item.reason&&item.status!=='maintenance')card.append(node('p','library-reason',item.reason));
   const actions=node('div','inline-actions');const record=states.get(item.id);const state=record?.state;
   const active=state&&['prepared','failed','applied'].includes(state);
   const hasBackup=active&&record?.reversible!==false;
   const owners=ownership[item.id]||[];
   if(owners.length){card.append(node('p','library-reason','Backup existent: '+owners.map(o=>o.module+' / '+(catalog.find(r=>r.id===o.id)?.title||'Setare salvată')).join('; ')+'. Restaurează din modulul responsabil.'));for(const owner of owners){const go=node('button','action outline','RESTAURARE: '+owner.module);go.onclick=()=>{if(onOwner){onOwner(owner);return}showToast('Deschide Backup & Restore pentru restaurarea acestei setări.')};card.append(go)}}
   if(executable(item)){
    const apply=node('button','action outline',active?(state==='applied'?'APLICAT':'NECESITĂ VERIFICARE'):item.status==='maintenance'?'EXECUTĂ':'APLICĂ');apply.disabled=!!active||owners.length>0||match?.state==='incompatible';apply.onclick=()=>act(item,'Apply');actions.append(apply);
   }
   if(hasBackup&&!owners.length){const restore=node('button','action outline','RESTAUREAZĂ');restore.onclick=()=>act(item,'Restore');actions.append(restore);}
   if(active&&record?.reversible===false){const ack=node('button','action outline','AM VERIFICAT OPERAȚIA ÎNTRERUPTĂ');ack.onclick=()=>act(item,'Acknowledge');actions.append(ack);}
   if(state)actions.append(node('small',null,stateLabels[state]||'Stare de verificat'));
   card.append(actions);return card;
 }
 async function act(item,action){
  if(!requireNative(action!=='Apply'))return;
  if(action==='Restore'&&onOwner){onOwner({id:item.id,route:'restore'});return}
  const needsAdapter=['dns','mtu','ipv6','nic-power','nic-advanced'].includes(item.operation?.type);
  const adapter=$('tweakAdapter').value;
  if(action==='Apply'&&needsAdapter&&!adapter){showToast('Selectează adaptorul de rețea înainte de aplicare.');$('tweakAdapter').scrollIntoView?.({block:'center'});$('tweakAdapter').focus?.();return}
  await task(action==='Apply'?'Aplicare tweak':'Recuperare tweak',async()=>{
   const apply=action==='Apply',ack=action==='Acknowledge',maintenance=item.status==='maintenance';
   const warning=ack?'Rezultatul operației întrerupte nu este cunoscut. Confirmă numai după ce ai verificat manual ce s-a întâmplat. Aceasta nu restaurează nimic și permite o nouă execuție.':!apply?'Se restaurează starea din backup. Modificările făcute ulterior de alte aplicații pot fi suprascrise.':maintenance?'Operație punctuală, fără anulare automată. Ștergerile de cache, copiile shadow eliminate, resetările și dezinstalările nu au restaurare garantată.':item.impact==='security'?'Această opțiune poate reduce protecția Windows ori stabilitatea. Nu este recomandată ca optimizare generală pentru jocuri. Confirmă numai dacă înțelegi efectul exact.':item.impact==='boot'?'Modificare de pornire Windows. Necesită restart și poate afecta pornirea sistemului. Backupul salvează valoarea originală; nu garantează acces la aplicație dacă Windows nu pornește.':'Se salvează originalul înainte de aplicare și se verifică rezultatul. Compatibilitatea și câștigurile de performanță depind de PC; nu sunt confirmate prin benchmark.';
   const detail=apply?[explanation(item),conditions(item)?'Compatibilitate de verificat: '+conditions(item):'',needsAdapter?'Adaptor: '+($('tweakAdapter').selectedOptions?.[0]?.textContent||'selectat'):'',item.restart?'Necesită restart.':''].filter(Boolean).join('\n'):'Se revine la valorile originale salvate pentru această setare.';
   if(!await confirmDialog(ack?'Ai verificat operația întreruptă?':apply?(maintenance?'Execuți această operație?':'Aplici această setare?'):'Restaurezi originalul?',item.title,detail,warning,ack?'CONFIRM VERIFICAREA':apply?'CONFIRM ȘI EXECUT':'RESTAUREAZĂ'))return;
   try{
    const r=ack?await api.tweakLibraryAcknowledge(item.id):apply?await api.tweakLibraryApply(item.id,true,adapter):await api.tweakLibraryRestore(item.id);
    const errors=Array.isArray(r.errors)?r.errors:[];
    const errorText=errors.length?' Erori: '+errors.slice(0,2).join('; ')+(errors.length>2?` (+${errors.length-2} în jurnal)`:''):'';
    const fileDetails=Number.isFinite(r.removed)?` Fișiere eliminate: ${r.removed}; omise: ${r.skipped||0}; blocate de alt proces: ${r.locked||0}; recent utilizate: ${r.recent||0}; legături ignorate: ${r.links||0}; octeți: ${r.bytes||0}.`:'';
    const message=(r.message||(r.success?(maintenance?'Operația s-a încheiat. Verifică rezultatul și eventualele fișiere omise.':'Starea cerută a fost verificată.'):'Operație incompletă.'))+fileDetails+errorText+((r.restartRequired||(r.success&&item.restart))?' Este necesar restart.':'');
    $('tweakOperationStatus').textContent=message;showToast(message);return r;
   }catch(e){$('tweakOperationStatus').textContent=String(e.message||e);throw e}finally{await load().catch(e=>showToast('Reîncarcă jurnalul: '+String(e.message||e)))}
  });
 }
 $('loadTweaks').onclick=()=>task('Catalog Tweaks',()=>load({refreshAdapters:true}));
 for(const id of ['tweakSearch','tweakCategory','tweakStatus'])$(id).addEventListener(id==='tweakSearch'?'input':'change',render);
 $('tweakShowAll')?.addEventListener('change',render);
 return {load,async openCategory(category){await load();$('tweakCategory').value=category;render()}};
}};
