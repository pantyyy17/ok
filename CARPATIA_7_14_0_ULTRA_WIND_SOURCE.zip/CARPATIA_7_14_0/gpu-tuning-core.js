'use strict';
const crypto=require('node:crypto');
const id=value=>typeof value==='string'&&value.length>0&&value.length<=512&&/^[\x21-\x7e]+$/.test(value);
const number=value=>Number.isInteger(value)&&value>=1&&value<=10000;
function assertRow(row){
 if(!row||!id(row.gpuId)||typeof row.supported!=='boolean'||typeof row.backup!=='boolean')throw Error('Identitatea sau originalul GPU nu poate fi confirmat.');
 if(!row.supported)return;
 if(!['currentMhz','minMhz','maxMhz','stepMhz'].every(key=>number(row[key]))||row.minMhz>row.maxMhz||row.currentMhz<row.minMhz||row.currentMhz>row.maxMhz||(row.currentMhz-row.minMhz)%row.stepMhz)throw Error('Limitele GPU nu permit o restaurare exactă.');
 if(row.minOperatingMhz!==undefined&&(!Number.isInteger(row.minOperatingMhz)||row.minOperatingMhz<0||row.minOperatingMhz>row.currentMhz))throw Error('Limita minimă GPU nu poate fi confirmată.');
 if((row.backup&&!number(row.originalMhz))||(row.originalMhz!==undefined&&row.originalMhz!==null&&!number(row.originalMhz)))throw Error('Frecvența originală GPU nu poate fi confirmată.');
}
function target(row,mhz){assertRow(row);if(!row.supported||!number(mhz)||mhz<Math.max(row.minMhz,row.minOperatingMhz||0)||mhz>row.maxMhz||(mhz-row.minMhz)%row.stepMhz)throw Error('Alege o frecvență din limitele și pasul raportate de driver.');}
function createGpuTuningService({invoke,now=Date.now,token=crypto.randomUUID}){
 const pending=new Map();
 async function status(){
  const result=await invoke({action:'query'});
  if(result?.success!==true||typeof result.available!=='boolean'||typeof result.supported!=='boolean'||!Array.isArray(result.gpus))throw Error(result?.message||result?.reason||'Controlul hardware nu a putut fi verificat.');
  const seen=new Set();for(const row of result.gpus){assertRow(row);if(seen.has(row.gpuId))throw Error('Identitate GPU duplicată.');seen.add(row.gpuId)}
  return result;
 }
 async function prepare(request){
  if(!request||typeof request!=='object'||Array.isArray(request)||Object.keys(request).some(key=>!['gpuId','mhz'].includes(key))||!id(request.gpuId)||!number(request.mhz))throw Error('Solicitare de frecvență GPU invalidă.');
  const state=await status(),row=state.gpus.find(gpu=>gpu.gpuId===request.gpuId);
  if(!state.available||!row?.supported)throw Error(row?.reason||state.reason||'Acest GPU nu permite controlul hardware solicitat.');
  target(row,request.mhz);if(row.backup)throw Error('Restaurează originalul GPU înainte de o nouă modificare.');
  const plan={gpuId:row.gpuId,name:row.name||'GPU',fromMhz:row.currentMhz,toMhz:request.mhz,minMhz:row.minMhz,maxMhz:row.maxMhz,stepMhz:row.stepMhz};
  for(const [key,item] of pending)if(item.plan.gpuId===row.gpuId||item.expires<now())pending.delete(key);
  if(plan.fromMhz===plan.toMhz)return {already:true,token:null,plan:{...plan}};
  const value=token();
  pending.set(value,{plan,expires:now()+60000});return {token:value,plan:{...plan}};
 }
 async function commit(value){
  const item=pending.get(value);pending.delete(value);
  if(!item||now()>item.expires)throw Error('Confirmarea GPU a expirat. Verifică din nou și confirmă.');
  const {plan}=item,state=await status(),row=state.gpus.find(gpu=>gpu.gpuId===plan.gpuId);
  if(!state.available||!row?.supported||row.backup||row.currentMhz!==plan.fromMhz||row.minMhz!==plan.minMhz||row.maxMhz!==plan.maxMhz||row.stepMhz!==plan.stepMhz)throw Error('Starea GPU s-a schimbat după confirmare. Analizează din nou.');
  target(row,plan.toMhz);
  const result=await invoke({action:'apply',gpuId:plan.gpuId,mhz:plan.toMhz,expectedMhz:plan.fromMhz});
  if(result?.success!==true)throw Error(result?.message||'Driverul nu a confirmat modificarea. Originalul rămâne disponibil.');
  const readback=await status(),actual=readback.gpus.find(gpu=>gpu.gpuId===plan.gpuId);
  if(!readback.available||!actual?.supported||actual.currentMhz!==plan.toMhz||actual.backup!==true||actual.originalMhz!==plan.fromMhz)throw Error('Limita sau originalul GPU nu sunt confirmate la recitire. Verifică starea înainte de o nouă modificare.');
  return {...result,message:'Frecvența maximă a fost recitită de modulul hardware. Verifică stabilitatea; originalul rămâne disponibil.'};
 }
 async function restore(gpuId){
  if(!id(gpuId))throw Error('Identitate GPU invalidă.');
  const state=await status(),row=state.gpus.find(gpu=>gpu.gpuId===gpuId);if(!state.available||!row?.backup)throw Error('Originalul GPU nu este disponibil pentru restaurare.');
  if(!number(row.originalMhz))throw Error('Frecvența originală GPU nu poate fi confirmată pentru restaurare.');
  const result=await invoke({action:'restore',gpuId});if(result?.success!==true)throw Error(result?.message||'Restaurarea hardware nu a fost confirmată. Păstrează originalul.');
  const readback=await status(),actual=readback.gpus.find(gpu=>gpu.gpuId===gpuId);
  if(!readback.available||!actual?.supported||actual.backup!==false||actual.currentMhz!==row.originalMhz)throw Error('Restaurarea limitei originale GPU nu poate fi confirmată la recitire. Păstrează originalul.');
  return {...result,message:'Limita maximă originală a fost restaurată și recitită.'};
 }
 return {status,prepare,commit,restore};
}
module.exports={createGpuTuningService};
