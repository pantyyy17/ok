# CARPATIA V7 PRO REDLINE 7.10.0

Surse pentru validare pe Windows 10/11. Interfața 7.10.0 și corecțiile blocajelor de backup sunt descrise în `RAPORT_7_10_0.md`. Livrarea nu include un EXE verificat; rapoartele 7.9.0 și anterioare sunt istorice.

## Noutăți

- Interfață Redline nouă, căutare Ctrl+K și centru de recuperare separat pe profiluri, originale și copii manuale.
- Restaurare directă CPU/GPU/Internet, inclusiv finalizarea sesiunilor rămase active după restaurare.

- Restaurare din copiile manuale: previzualizare, confirmare, verificare după scriere și jurnal persistent pentru reluare/anulare.
- Titluri și explicații în română pentru cele 210 intrări cu motoare din catalog; cinci opțiuni GPU cu ținte ambigue sunt blocate la aplicare, păstrând restaurarea, fără comenzi brute în fișele obișnuite.
- Incompatibilitățile hardware demonstrate sunt ascunse implicit; „Arată toate” le afișează. Setările cu backup activ rămân accesibile.
- Dashboard și modulele trimit restaurarea în centrul comun Backup & Restore. Catalogul Internet este accesat din catalogul comun.

Originalele se salvează automat înainte de modificare. În Backup & Restore poți restaura tot, o categorie sau o singură setare. Pentru o copie manuală, deschide Istoricul și alege „Restaurează această copie”. Dacă există originale automate active, restaurează-le întâi cu „Restaurează tot”, pentru a nu le înlocui. Istoricul permite reluarea sau anularea restaurării unei copii. Schimbările externe detectate nu sunt suprascrise automat.

## Pornire

1. Extrage proiectul într-un folder nou și păstrează backupurile existente.
2. Cu Node.js 24 sau mai nou, rulează `npm ci`, apoi `npm test`. Lockfile-ul fixează dependențele instalate.
3. Folosește `TEST_CARPATIA_WINDOWS.bat` pentru diagnostic și `TEST_UI_CARPATIA.bat` pentru interfață. Operațiile Windows necesită Administrator.
4. Validează scenariile din raport într-o mașină virtuală Windows înainte de distribuire.

`npm run dist` verifică licențierea și testele înainte de compilare. Lipsește `license-public.pem`; este necesară cheia publică pereche a cheii private originale a editorului. Nu genera o pereche nouă pentru a ocoli această lipsă. Cheia privată nu se distribuie. Detalii: `LICENTIERE.md`.

## Verificările auditului

- `npm test`: teste de logică și integrare; testele PowerShell simulate rulează dacă există Windows PowerShell sau `pwsh`. Pe Linux se poate indica executabilul prin `CARPATIA_PWSH`.
- `powershell -NoLogo -NoProfile -File tools/check-powershell.ps1`: parsează toate scripturile proiectului fără să le execute.
- `node tools/test-browser-smoke.js --output-dir /tmp/carpatia-browser-smoke`: verifică DOM-ul în Chromium cu un backend simulat. Necesită Chromium; se poate selecta prin `CHROMIUM_BIN`. Nu validează operațiile Windows.

Rezultatele păstrate sunt în `validation/`. Cheia publică originală și validarea în VM Windows rămân necesare înainte de distribuire.

Rezultatele acestei revizii: `validation/7.10.0/`. Verificarea în Chromium folosește date simulate; operațiile Windows cer validare reală.
