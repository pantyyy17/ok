'use strict';
// CARPATIA V7 PRO REDLINE: restricted IPC and native Windows operations only.
const {app,BrowserWindow,ipcMain,dialog,shell}=require('electron');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {createWindowsRunner}=require('./windows-process');
const {createOperationLog}=require('./operation-log');
const runPs=createOperationLog({directory:()=>path.join(app.getPath('userData'),'logs'),run:createWindowsRunner()});
const {pathToFileURL}=require('node:url');
const {createLicenseStore}=require('./licensing');
const smart=require('./smart-engine');
const {planOneClick,executeOneClick}=require('./oneclick-engine');
const {planNetwork,validJournalSteps}=require('./network-boost-core');
const {ORDER,buildRecoverySteps}=require('./network-recovery-core');
const {restoreComponents}=require('./operation-core');
const {fetchLocalSensors}=require('./sensor-core');
const tweakLibrary=require('./tweak-library-core');
const ledgerCore=require('./resource-ledger');
function resourceLedger(){return ledgerCore.readLedger({dataDir:app.getPath('userData'),backupDir:backupsDir()})}
async function serviceInventory(){const r=await ps('services-lab.ps1','Status');const ledger=resourceLedger();return {...r,items:(r.items||[]).map(item=>ledgerCore.serviceState(item,ledger)),diagnosticErrors:ledger.errors}}
const tweaks=JSON.parse(fs.readFileSync(path.join(__dirname,'tweaks.json'),'utf8'));
const debloatCatalog=JSON.parse(fs.readFileSync(path.join(__dirname,'debloat-catalog.json'),'utf8'));
const tweakIds=new Set(tweaks.filter(x=>!x.restoreOnly).map(x=>x.id));
const debloatIds=new Set(debloatCatalog.map(x=>x.id));
const backupFileNames={dns:'dns-latest.json',tcp:'tcp-latency.json',nicPower:'nic-power-pro.json',interrupt:'Experimental/nic_interrupt.json',eee:'Experimental/nic_eee.json'};
const backupsDir=()=>path.join(process.env.LOCALAPPDATA||app.getPath('userData'),'TweakRomania','Backups');
const networkJournal=()=>path.join(app.getPath('userData'),'redline-network-session.json');
const oldNetworkJournal=()=>path.join(app.getPath('userData'),'network-boost-session.json');
let operationHardware=null;
let busy=null,profilePending=null,networkPending=null,selectedExe=null,cpuBefore=os.cpus().map(c=>c.times);
let licenseStore=null;
// One process owns the backup files and mutation lock.
const primaryInstance=app.requestSingleInstanceLock();
if(!primaryInstance)app.quit();
else app.on('second-instance',()=>{const win=BrowserWindow.getAllWindows()[0];if(win){if(win.isMinimized())win.restore();win.focus()}});
const trustedPage=pathToFileURL(path.join(__dirname,'index.html')).href;
function trusted(event){
 const url=event?.senderFrame?.url;
 if(url!==trustedPage||event?.sender?.getURL?.()!==trustedPage)throw Error('Comandă respinsă: origine UI neautorizată.');
}
function requireActiveLicense(){if(!licenseStore?.licensed())throw Error('CARPATIA necesită o licență validă pentru folosirea funcțiilor. Deschide Activare licență.');}
function initLicensing(){
 let publicKey=null;
 try{publicKey=fs.readFileSync(path.join(__dirname,'license-public.pem'),'utf8')}catch{}
 licenseStore=createLicenseStore({directory:app.getPath('userData'),publicKey,developer:!app.isPackaged&&process.env.CARPATIA_DEV_MODE==='1'});
}

function windowsOnly(){if(process.platform!=='win32')throw Error('Comenzile native necesită Windows 10 sau 11.');}
function backupExists(kind){return fs.existsSync(path.join(backupsDir(),backupFileNames[kind]));}
function script(name,...args){if(!/^[a-z-]+\.ps1$/.test(name))throw Error('Script invalid.');const root=app.isPackaged?__dirname.replace(/app\.asar(?=[\\/]|$)/,'app.asar.unpacked'):__dirname;return ['-File',path.join(root,name),...args];}
function emit(topic,event){for(const win of BrowserWindow.getAllWindows())if(!win.isDestroyed())win.webContents.send(topic,event);}
async function ps(name,action,...params){return runPs(script(name,'-Action',action,...params));}
function assertOk(r,label){if(r?.success!==true)throw Error(`${label}: ${r?.message||JSON.stringify(r?.errors||r||'neconfirmat')}`);return r}
function lock(label,func){if(busy)throw Error(`Operația „${busy}” este în desfășurare. Așteaptă finalizarea.`);busy=label;return Promise.resolve().then(func).finally(()=>busy=null)}
function registerRead(name,fn,{recovery=false}={}){ipcMain.handle(name,async(event, ...args)=>{trusted(event);if(!recovery)requireActiveLicense();windowsOnly();return fn(...args)});}
function registerWrite(name,fn,{recovery=false}={}){ipcMain.handle(name,async(event, ...args)=>{trusted(event);if(!recovery)requireActiveLicense();windowsOnly();return lock(name,async()=>{operationHardware=null;if(!recovery&&!['snapshotCommit','snapshotResume'].includes(name)&&snapshotService.blocking().length)throw Error('Finalizează sau anulează restaurarea copiei din Istoric înainte de alte modificări.');if(['netCommit','gpuApply'].includes(name))await assertLibraryClear();try{return await fn(...args)}finally{emit('settingsChanged',{phase:'refresh',detail:'Starea setărilor s-a schimbat.'})}})});}
function createWindow(){const win=new BrowserWindow({width:1560,height:980,minWidth:1000,minHeight:710,backgroundColor:'#0b0a0e',autoHideMenuBar:true,show:false,webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}});win.once('ready-to-show',()=>win.show());win.loadFile(path.join(__dirname,'index.html'));win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.session.setPermissionRequestHandler((_wc,_perm,reply)=>reply(false));win.on('close',event=>{if(busy){event.preventDefault();dialog.showMessageBox(win,{type:'warning',title:'CARPATIA',message:'O operație Windows este încă în curs.',detail:'Nu închide programul înainte de verificare sau restaurare.',buttons:['ÎNȚELES']}).catch(()=>{})}});win.webContents.on('will-navigate',(e,url)=>{if(url!==win.webContents.getURL())e.preventDefault()})}
app.whenReady().then(()=>{if(!primaryInstance)return;initLicensing();createWindow();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)createWindow()})});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
function cpuload(){const curr=os.cpus().map(c=>c.times);let total=0,idle=0;for(let i=0;i<curr.length;i++)for(const k of Object.keys(curr[i])){const delta=curr[i][k]-(cpuBefore[i]?.[k]??curr[i][k]);if(Number.isFinite(delta)&&delta>=0){total+=delta;if(k==='idle')idle+=delta}}cpuBefore=curr.map(x=>({...x}));return total>0?Math.max(0,Math.min(100,Math.round(100-100*idle/total))):null}
ipcMain.handle('licenseStatus',(event)=>{trusted(event);return licenseStore.status()});
ipcMain.handle('licenseActivate',(event,code)=>{trusted(event);if(busy)throw Error('Nu poți activa în timpul unei modificări Windows.');return licenseStore.activate(code)});
ipcMain.handle('sys',(event)=>{trusted(event);return ({platform:process.platform,windowsVersion:os.release(),cpu:os.cpus()[0]?.model||'Indisponibil',ramGB:Math.round(os.totalmem()/1073741824*10)/10,cores:os.cpus().length})});
ipcMain.handle('metrics',(event)=>{trusted(event);requireActiveLicense();return ({cpu:cpuload(),ram:Math.round((1-os.freemem()/os.totalmem())*100),freeGB:Math.round(os.freemem()/1073741824*10)/10})});
ipcMain.handle('sensors',(event)=>{trusted(event);requireActiveLicense();return fetchLocalSensors()});
registerRead('admin',()=>runPs(script('permissions.ps1')));
registerRead('hardware',()=>runPs(script('inspect.ps1')));
registerRead('gpuList',()=>ps('gpu-lab.ps1','Inventory'));
registerRead('registryState',()=>ps('engine.ps1','Status'),{recovery:true});
registerRead('powerState',()=>ps('power.ps1','Status'),{recovery:true});
registerRead('services',serviceInventory,{recovery:true});
registerRead('network',()=>runPs(script('network.ps1')));
registerRead('catalog',()=>tweaks.filter(x=>!x.restoreOnly).map(({id,title,desc,category,risk,recommended})=>({id,title,desc,category,risk,recommended})));
registerRead('latency',async(host)=>{if(!['cloudflare','google','quad9'].includes(host))throw Error('Destinație invalidă.');const map={cloudflare:'1.1.1.1',google:'8.8.8.8',quad9:'9.9.9.9'};return runPs(script('latency.ps1','-HostIP',map[host]),35000)});
// ULTRA HIGH: server-produced plan (token cannot be altered by renderer). Retains backup compatibility.
registerRead('ultraAnalyze',async()=>{const [h,r,p]=await Promise.all([runPs(script('inspect.ps1')),ps('engine.ps1','Status'),ps('power.ps1','Status')]);return {profile:smart.plan({hardware:h,registry:r,power:p},tweaks),hardware:h,registry:r,power:p}});
registerRead('ultraPrepare',async(options)=>{
 if(busy)throw Error('Mai există o operație activă.');
 if(!options||typeof options!=='object'||!['balanced','performance','ultra'].includes(options.mode))throw Error('Alege profilul de performanță.');
 if(typeof options.riskAcknowledged!=='boolean')throw Error('Confirmarea riscului lipsește.');
 const {profile,power}=await (async()=>{const [h,r,p]=await Promise.all([runPs(script('inspect.ps1')),ps('engine.ps1','Status'),ps('power.ps1','Status')]);return {profile:smart.plan({hardware:h,registry:r,power:p},tweaks),power:p}})();
 const opt={power:options.mode==='performance'||options.mode==='ultra',sysmain:false,captureOff:false,max:options.mode==='ultra',riskAcknowledged:options.riskAcknowledged};
 const plan=planOneClick(profile,opt,power,null);const token=crypto.randomUUID();profilePending={token,plan,expires:Date.now()+180000};return {token,plan,expiresSeconds:180};
});
registerWrite('ultraCommit',async(token)=>{
 await assertLibraryClear();
 if(!profilePending||profilePending.token!==token||Date.now()>profilePending.expires){profilePending=null;throw Error('Confirmarea ULTRA a expirat; analizează din nou.')}const {plan}=profilePending;profilePending=null;
 const reg=await ps('engine.ps1','Status'),power=await ps('power.ps1','Status');if(reg.backup||plan.power&&power.backup)throw Error('Există backup ULTRA sau Power activ. Mergi la Restaurare înainte de noul profil.');
 const ops={
  applyRegistry:ids=>ps('engine.ps1','Apply','-Ids',ids.join(',')),applyPower:()=>ps('power.ps1','Apply'),
  hasBackup:async kind=>kind==='registry'?(await ps('engine.ps1','Status')).backup:(await ps('power.ps1','Status')).backup,
  restore:kind=>ps(kind==='registry'?'engine.ps1':'power.ps1','Restore'),
  verifyRestored:async kind=>{const state=await ps(kind==='registry'?'engine.ps1':'power.ps1','Status');return state?.success===true&&state.backup===false},
  verify:async(kind,plan)=>{if(kind==='registry'){const s=await ps('engine.ps1','Status');return s.success===true&&s.backup===true&&plan.ids.every(id=>(s.matchingIds||[]).includes(id))}const s=await ps('power.ps1','Status');return s.success===true&&s.backup===true&&s.active?.toLowerCase()==='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'}
 };
 return executeOneClick(plan,ops,event=>emit('ultraProgress',event));
});
registerWrite('restoreUltra',()=>restoreComponents([['power','power.ps1'],['registry','engine.ps1']],(file,action)=>ps(file,action)),{recovery:true});
// NETWORK BOOST: journal tracks each original backup across restarts and supports legacy one-click session backups.
function netInventory(){return ORDER.filter(kind=>backupExists(kind))}
function journalRead(file){if(!fs.existsSync(file))return null;const j=JSON.parse(fs.readFileSync(file,'utf8'));if(j.version!==1||!validJournalSteps(j.started))throw Error('Jurnal de rețea corupt; nu se șterge automat.');return j}
function writeJournal(file,j){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(j,null,2),{encoding:'utf8',flag:'wx'});fs.renameSync(tmp,file)}finally{try{fs.unlinkSync(tmp)}catch{}}}
function journalWrite(j){writeJournal(networkJournal(),j)}
function networkRecovery(){const journals=[journalRead(networkJournal()),journalRead(oldNetworkJournal())].filter(Boolean);const items=buildRecoverySteps(journals.flatMap(j=>j.started),netInventory());return {active:items.length>0||journals.length>0,steps:items.map(id=>({id,backupExists:backupExists(id),source:journals.some(j=>j.started.includes(id))?'INTERNET BOOST':'Setare individuală'})),journals:journals.length}}
registerRead('networkRecovery',networkRecovery,{recovery:true});
registerWrite('netClearEmptyJournal',async()=>{const r=networkRecovery();if(r.steps.length)throw Error('Există încă backupuri; restaurează-le, nu șterge jurnalul.');let cleaned=0;for(const f of [networkJournal(),oldNetworkJournal()]){if(!fs.existsSync(f))continue;const j=journalRead(f);if(j.started.length)throw Error('Jurnalul conține operații în așteptare.');fs.unlinkSync(f);cleaned++}return {success:true,cleaned,message:'Au fost arhivate logic doar jurnalele goale, fără backupuri.'}},{recovery:true});
function netStep(kind,action,adapter,provider){switch(kind){case 'dns':return ps('dns.ps1',action==='Apply'?'Set':'Restore',...(action==='Apply'?['-Adapter',adapter,'-Provider',provider]:[]));case 'tcp':return ps('tcp-latency.ps1',action,...(action==='Apply'?['-Adapter',adapter]:[]));case 'nicPower':return ps('nic-power-pro.ps1',action,...(action==='Apply'?['-Adapter',adapter]:[]));case 'interrupt':case 'eee':return ps('nicexperimental.ps1',action,'-Id',kind==='interrupt'?'nic_interrupt':'nic_eee',...(action==='Apply'?['-Adapter',adapter]:[]));default:throw Error('Setare rețea necunoscută')}}
const {capabilitiesFor}=require('./network-capabilities');
async function networkCapabilities(adapter){
 if(typeof adapter!=='string'||!adapter||adapter.length>150||/[\r\n]/.test(adapter))throw Error('Adaptor invalid.');
 const results=await Promise.allSettled([runPs(script('tcp-latency.ps1','-Action','Status','-Adapter',adapter),12000),runPs(script('nic-power-pro.ps1','-Action','Status','-Adapter',adapter),12000),runPs(script('nicexperimental.ps1','-Action','List','-Adapter',adapter,'-Id','nic_interrupt'),12000)]);
 const read=i=>results[i].status==='fulfilled'?results[i].value:null;
 return capabilitiesFor(adapter,{tcp:read(0),power:read(1),advanced:read(2)});
}
async function assertNetworkCapabilities(plan){
 if(!plan.advanced)return;
 const caps=await networkCapabilities(plan.adapter);
 for(const step of plan.actions)if(Object.hasOwn(caps.supported,step)&&!caps.supported[step])throw Error(caps.reasons[step]+' Debifează această opțiune sau actualizează lista adaptorului.');
}
registerRead('networkCapabilities',networkCapabilities);
registerRead('netPrepare',async request=>{
 if(busy)throw Error('O altă optimizare este activă.');if(networkRecovery().active)throw Error('Există backup de rețea anterior. Restaurează-l înainte de NET BOOST.');
 const net=await runPs(script('network.ps1'));const plan=planNetwork(request,net);
 await assertNetworkCapabilities(plan);

 const token=crypto.randomUUID();networkPending={token,plan,expires:Date.now()+180000};return {token,plan};
});
registerWrite('netCommit',async token=>{
 if(!networkPending||networkPending.token!==token||Date.now()>networkPending.expires){networkPending=null;throw Error('Confirmarea de rețea a expirat.')}const {plan}=networkPending;networkPending=null;
 const net=await runPs(script('network.ps1'));if(!net.adapters?.some(x=>x.name===plan.adapter&&x.ipv4?.length))throw Error('Adaptorul s-a schimbat; nu aplic nimic.');if(networkRecovery().active)throw Error('Backup rețea apărut după analiză.');
 await assertNetworkCapabilities(plan);
 const journal={version:1,adapter:plan.adapter,provider:plan.provider,started:[],createdAt:new Date().toISOString()},applied=[];journalWrite(journal);
 try{for(const step of plan.actions){if(step!=='flush'){journal.started.push(step);journalWrite(journal)}emit('netProgress',{phase:'apply',detail:`Aplic ${step}`});const r=step==='flush'?await ps('dns.ps1','Flush'):await netStep(step,'Apply',plan.adapter,plan.provider);assertOk(r,step);applied.push(step);if(step!=='flush'&&r.changed===false&&!backupExists(step)){journal.started=journal.started.filter(x=>x!==step);journalWrite(journal)}}if(!journal.started.length)fs.unlinkSync(networkJournal());emit('netProgress',{phase:'complete',detail:'NET BOOST confirmat'});return {success:true,applied};}
 catch(e){const rollback=[];for(const step of [...journal.started].reverse()){if(!backupExists(step)){rollback.push({step,success:false,message:'Backup absent: restaurare neconfirmată'});continue}try{const r=await netStep(step,'Restore');if(!r.success||backupExists(step))throw Error('Restaurare neconfirmată');rollback.push({step,success:true});journal.started=journal.started.filter(x=>x!==step);journalWrite(journal)}catch(err){rollback.push({step,success:false,message:err.message})}}if(!journal.started.length)fs.unlinkSync(networkJournal());return {success:false,error:e.message,applied,rollback}};
});
async function restoreNetworkSelection(selection){const snap=networkRecovery();if(snap.active&&!snap.steps.length){for(const f of [networkJournal(),oldNetworkJournal()]){if(!fs.existsSync(f))continue;const j=journalRead(f);if(j.started.length)throw Error('Jurnalul conține pași neterminați.');fs.unlinkSync(f)}return {success:true,steps:[],message:'Jurnalul gol a fost închis; nicio setare Windows modificată.'}}const allowed=new Set(snap.steps.map(s=>s.id));if(!Array.isArray(selection)||!selection.length||selection.some(x=>!allowed.has(x)))throw Error('Alege backupurile de rețea dorite.');const journ=[journalRead(networkJournal()),journalRead(oldNetworkJournal())].filter(Boolean);const required=new Set(journ.flatMap(j=>j.started));if([...required].some(k=>!selection.includes(k)))throw Error('Trebuie incluse toate etapele sesiunii neterminate.');const out=[];for(const step of ORDER.filter(k=>selection.includes(k))){if(!backupExists(step)){out.push({step,success:false,message:'Backup lipsă; nu pot declara restaurat'});continue}try{const r=assertOk(await netStep(step,'Restore'),'Restaurare '+step);if(backupExists(step))throw Error('Backup rămas activ');out.push({step,success:true,message:r.message})}catch(e){out.push({step,success:false,message:e.message})}}for(const file of [networkJournal(),oldNetworkJournal()]){if(!fs.existsSync(file))continue;const j=journalRead(file);j.started=j.started.filter(x=>!out.some(o=>o.step===x&&o.success));if(j.started.length)writeJournal(file,j);else fs.unlinkSync(file)}return {success:out.every(x=>x.success),steps:out}}
registerWrite('netRestore',restoreNetworkSelection,{recovery:true});
// DEBLOAT: user chooses from exact AppX allowlist. Zero automatic deletions.
registerRead('debloatScan',()=>ps('debloat.ps1','Scan'));
registerWrite('debloatRemove',async ids=>{if(!Array.isArray(ids)||ids.length<1||ids.length>debloatIds.size||new Set(ids).size!==ids.length||ids.some(x=>!debloatIds.has(x)))throw Error('Selecție Debloat nepermisă.');return ps('debloat.ps1','Remove','-Ids',ids.join(','))});
registerRead('cleanupScan',()=>ps('cleanup.ps1','Scan'));
registerWrite('cleanupRun',()=>ps('cleanup.ps1','Clean'));
registerRead('startupList',()=>ps('startup.ps1','List'),{recovery:true});
registerWrite('startupDisable',name=>{if(typeof name!=='string'||!name||name.length>150||/[\r\n]/.test(name))throw Error('Nume Startup invalid');return ps('startup.ps1','Disable','-Name',name)});
registerWrite('startupRestore',name=>{if(typeof name!=='string'||!name||name.length>150||/[\r\n]/.test(name))throw Error('Nume Startup invalid');return ps('startup.ps1','Restore','-Name',name)},{recovery:true});
registerWrite('servicesChange',async(action,id)=>{
 if(!['Apply','Restore'].includes(action)||!Object.hasOwn(ledgerCore.serviceNames,id))throw Error('Serviciu/operație necunoscută');
 if(action!=='Restore')requireActiveLicense();
 const inventory=await serviceInventory(),item=inventory.items.find(x=>x.id===id);
 if(!inventory.success||!item)throw Error('Inventarul serviciilor nu poate fi confirmat.');
 if(action==='Apply'&&item.action==='disabled')return {success:true,already:true,message:'DEJA DEZACTIVAT. Nicio modificare si niciun backup nou.'};
 if(item.action!==(action==='Apply'?'apply':'restore'))throw Error(item.label+': '+(item.reason||'Stare incompatibila.'));
 return ps('services-lab.ps1',action,'-Id',id);
},{recovery:true});
// EXPERT tweaks reuse the allowlisted 59-rule engine, one backup per session.
registerWrite('tweakApply',async ids=>{await assertLibraryClear();if(!Array.isArray(ids)||!ids.length||ids.length>tweakIds.size||new Set(ids).size!==ids.length||ids.some(x=>!tweakIds.has(x)))throw Error('Tweak-uri nepermise');return ps('engine.ps1','Apply','-Ids',ids.join(','))});
// GPU Lab: Windows preference for explicitly selected .exe; never automatic OC/undervolt/fan changes.
registerRead('gpuPick',async event=>{const win=BrowserWindow.getFocusedWindow()||BrowserWindow.getAllWindows()[0];const choice=await dialog.showOpenDialog(win,{title:'Selectează aplicația .exe',properties:['openFile'],filters:[{name:'Executabile Windows',extensions:['exe']}]});if(choice.canceled)return {cancelled:true};const target=path.resolve(choice.filePaths[0]);const windowsRoot=(process.env.WINDIR||'C:\\Windows').toLowerCase();if(path.extname(target).toLowerCase()!=='.exe'||!fs.existsSync(target)||target.toLowerCase().startsWith(windowsRoot+path.sep))throw Error('Executabil invalid sau de sistem');selectedExe=target;return {cancelled:false,name:path.basename(target)}},{recovery:true});
registerRead('gpuStatus',()=>selectedExe?ps('gpu-lab.ps1','Status','-ExePath',selectedExe):Promise.resolve({success:true,selected:false,backup:false}),{recovery:true});
registerWrite('gpuApply',()=>{if(!selectedExe)throw Error('Alege mai întâi un .exe.');return ps('gpu-lab.ps1','Apply','-ExePath',selectedExe)});
registerWrite('gpuRestore',()=>{if(!selectedExe)throw Error('Alege .exe pentru restaurare.');return ps('gpu-lab.ps1','Restore','-ExePath',selectedExe)},{recovery:true});
registerRead('openSettings',async route=>{const allowed={startup:'ms-settings:startupapps',graphics:'ms-settings:display-advancedgraphics',apps:'ms-settings:appsfeatures'};if(typeof route!=='string'||!Object.hasOwn(allowed,route))throw Error('Setare invalidă');await shell.openExternal(allowed[route]);return {success:true}});

registerRead('tweakLibrary',()=>tweakLibrary.publicCatalog(),{recovery:true});
async function libraryState(){
 const results=await Promise.all([ps('tweak-library.ps1','Status','-DataDir',app.getPath('userData')),ps('tweak-native.ps1','Status','-DataDir',app.getPath('userData'))]);
 return {success:results.every(x=>x.success===true),states:results.flatMap(x=>x.states||[]),errors:results.flatMap(x=>x.errors||[])};
}
registerRead('tweakLibraryState',async()=>{const result=await libraryState();const ledger=resourceLedger();const ownership={};for(const rule of tweakLibrary.publicCatalog()){const owners=ledgerCore.conflicts(ledger,ledgerCore.resources(tweakLibrary.getRule(rule.id)),rule.id);const own=ledger.records.find(x=>x.id===rule.id&&x.route==='dashboard');if(own)owners.push(own);if(owners.length)ownership[rule.id]=owners;}return {...result,success:result.success&&ledger.errors.length===0,ownership,diagnosticErrors:ledger.errors}},{recovery:true});
registerRead('tweakLibraryContext',async()=>{const [context,hardware]=await Promise.all([ps('tweak-native.ps1','Context','-DataDir',app.getPath('userData')),runPs(script('inspect.ps1'))]);return {...context,hardware,compatibility:Object.fromEntries(tweakLibrary.publicCatalog().map(row=>[row.id,require('./compatibility').compatibility(row,hardware)]))}},{recovery:true});
registerWrite('tweakLibraryApply',async(id,ack,adapter)=>{
 const trustedId=tweakLibrary.authorize(id,'Apply',ack),rule=tweakLibrary.getRule(trustedId);
 const old=await ps('engine.ps1','Status');
 if(old.success!==true||old.backup!==false)throw Error('Restaurează backupul Registry ULTRA existent înainte de noul catalog.');
 if(rule.operation?.type?.startsWith('power')){
  const power=await ps('power.ps1','Status');
  if(power.success!==true||power.backup)throw Error('Restaurează mai întâi backupul planului de alimentare vechi.');
 }
 if(['dns','mtu','ipv6','tcp-global','rss','tunnel'].includes(rule.operation?.type)||rule.operation?.name==='reset-network'){
  if(netInventory().length)throw Error('Există backupuri Internet în modulul Rețea. Restaurează-le înainte de acest tweak.');
 }
 if(rule.category==='Network'&&netInventory().length)throw Error('Restaurează backupurile Internet înainte de tweak-urile Registry de rețea.');
 const ledger=resourceLedger();
 if(ledger.errors.length)throw Error('Diagnostic backup necesar: '+ledger.errors.join('; '));
 const serviceTargets=ledgerCore.resources(rule);
 const owners=ledgerCore.conflicts(ledger,serviceTargets,trustedId);
 if(owners.length)throw Error('Serviciu detinut de '+owners.map(x=>x.module+' / '+x.id).join('; ')+'. Restaureaza din modulul responsabil.');
 return runLibraryOperation(trustedId,'Apply',adapter);
});
async function assertLibraryClear(){
 dashboardProfiles.assertClear();
 const s=await libraryState();
 if(s.success!==true||(s.states||[]).some(x=>tweakLibrary.isActiveState(x.state)))throw Error('Există backupuri active în pagina Tweaks. Restaurează-le înainte de profilul sau modulul vechi.');
}
registerWrite('tweakLibraryRestore',id=>{
 dashboardProfiles.assertNotOwned(id);
 const key=tweakLibrary.authorize(id,'Restore');
 const ledger=resourceLedger();if(ledger.errors.length)throw Error('Diagnostic backup necesar: '+ledger.errors.join('; '));
 const targets=ledgerCore.resources(tweakLibrary.getRule(key));
 const owners=ledgerCore.conflicts(ledger,targets,key);if(owners.length)throw Error('Restaurare blocata de backup suprapus: '+owners.map(x=>x.module+' / '+x.id).join('; '));
 return runPs(script(tweakLibrary.engineFor(key),'-Action','Restore','-Id',key,'-DataDir',app.getPath('userData')),180000);
},{recovery:true});
registerWrite('tweakLibraryAcknowledge',id=>ps('tweak-native.ps1','Acknowledge','-Id',tweakLibrary.authorize(id,'Acknowledge'),'-DataDir',app.getPath('userData')),{recovery:true});

// Dashboard profiles share the typed tweak engines and retain a session journal per subsystem.
const {createProfileService}=require('./dashboard-profiles');
const profileSessionFile=group=>path.join(app.getPath('userData'),'dashboard-profiles',group+'.json');
const dashboardProfiles=createProfileService({
 store:{read:group=>{const file=profileSessionFile(group);return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null},write:(group,session)=>writeJournal(profileSessionFile(group),session)},
 notify:event=>emit('dashboardProgress',event),
 ops:{
  status:libraryState,
  snapshot:async (group,plan)=>{
   const [hardware,admin,registry,power]=await Promise.all([runPs(script('inspect.ps1')),runPs(script('permissions.ps1')),ps('engine.ps1','Status'),ps('power.ps1','Status')]);
   if(hardware.success!==true||!admin.admin||registry.success!==true||power.success!==true)return {success:false,message:'Verifică Windows, drepturile de administrator și jurnalele existente.'};
   const blockers=[];
   if(registry.backup&&(!plan||ledgerCore.conflicts(resourceLedger(),plan.steps.flatMap(step=>ledgerCore.resources(tweakLibrary.getRule(step.id)))).some(x=>x.id==='legacy-ultra')))blockers.push('ULTRA Registry — Backup & Restore → RESTAUREAZĂ ULTRA / POWER');
   if(group==='cpu'&&power.backup)blockers.push('Power Plan — Backup & Restore → RESTAUREAZĂ ULTRA / POWER');
   if(group==='internet'){
    const net=networkRecovery();if(net.active)blockers.push('Internet '+(net.steps.map(x=>x.id).join(', ')||'(jurnal gol)')+' — Backup & Restore → RESTAUREAZĂ INTERNET');
   }
   return {...hardware,success:true,legacyBackup:blockers.length>0,legacyBlockers:blockers};
  },
  conflicts:async plan=>{const ledger=resourceLedger();if(ledger.errors.length)throw Error('Diagnostic backup: '+ledger.errors.join(' | '));return ledgerCore.conflicts(ledger,plan.steps.flatMap(step=>ledgerCore.resources(tweakLibrary.getRule(step.id))));},
  check:(id,adapter)=>runLibraryOperation(id,'Check',adapter),
  apply:(id,adapter)=>runLibraryOperation(id,'Apply',adapter),
  restore:id=>runLibraryOperation(id,'Restore')
 }
});
async function runLibraryOperation(id,action,adapter=''){
 if(action==='Apply'){const match=require('./compatibility').compatibility(tweakLibrary.getRule(id),operationHardware||(operationHardware=await runPs(script('inspect.ps1'))));if(match.state==='incompatible')throw Error(match.reason)}
 const rule=tweakLibrary.getRule(id),params=['-Id',id,'-DataDir',app.getPath('userData')];
 if(rule.status==='native')params.push('-AdapterGuid',tweakLibrary.validateAdapter(adapter));
 return runPs(script(tweakLibrary.engineFor(id),'-Action',action,...params),rule.status==='maintenance'?600000:180000);
}
registerRead('dashboardStatus',()=>dashboardProfiles.analyze(),{recovery:true});
registerRead('dashboardPrepare',request=>{if(busy)throw Error('O altă operație este în curs.');return dashboardProfiles.prepare(request)});
registerWrite('dashboardCommit',token=>dashboardProfiles.commit(token));
registerWrite('dashboardRestore',group=>dashboardProfiles.restore(group),{recovery:true});

// Recovery coordinator: same typed adapters and originals as the catalog/dashboard.
const {createRecoveryService}=require('./recovery-core');
function readRecoveryFiles(directory){
 if(!fs.existsSync(directory))return [];
 return fs.readdirSync(directory).filter(x=>x.endsWith('.json')).sort().map(name=>{
  try{const record=JSON.parse(fs.readFileSync(path.join(directory,name),'utf8').replace(/^\uFEFF/,''));if(!record||typeof record!=='object'||Array.isArray(record))throw Error('Structură JSON invalidă.');return record}
  catch(e){return {error:name+': '+e.message}}
 });
}
async function recoveryInventory(){
 const dataDir=app.getPath('userData'),ledger=resourceLedger();
 const items=[],errors=[...ledger.errors];
 for(const dir of ['tweak-library-backups','tweak-native-backups'])for(const record of readRecoveryFiles(path.join(dataDir,dir))){
  if(record.error){errors.push(record.error);continue}
  let rule;try{rule=tweakLibrary.getRule(record.id)}catch(e){errors.push(e.message);continue}
  const owner=ledger.records.find(x=>x.id===record.id);
  items.push({id:record.id,title:rule.title,category:rule.category,date:record.date,state:record.state,reversible:record.reversible!==false,restart:!!rule.restart,original:record.values||record.before,operation:record.operation,owner:owner?.module||'Catalog individual',group:owner?.group});
 }
 const addLegacy=(id,title,category,original,extra={})=>items.push({id,title,category,original,state:'applied',reversible:true,restart:true,date:original.date||original.created,owner:'Modul anterior',legacy:true,...extra});
 const legacyFiles=[['legacy-ultra','ULTRA Registry','Windows','ultra-latest.json'],['legacy-power','Plan de alimentare','CPU','power-plan.json'],['legacy-startup','Programe la pornire','Windows','startup-disabled.json']];
 for(const [id,title,category,name] of legacyFiles){const file=path.join(backupsDir(),name);if(fs.existsSync(file)){try{addLegacy(id,title,category,JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')))}catch(e){errors.push(title+': '+e.message)}}}
 for(const [id,name] of Object.entries(ledgerCore.serviceNames)){const file=path.join(backupsDir(),'services-'+id+'.json');if(fs.existsSync(file)){try{addLegacy('services:'+id,name,'Services',JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')),{serviceId:id})}catch(e){errors.push(e.message)}}}
 let net;try{net=networkRecovery()}catch(e){errors.push('Internet: '+e.message);net={active:false}}if(net.active){const original={steps:net.steps,journals:[]};for(const file of [networkJournal(),oldNetworkJournal(),...net.steps.map(x=>path.join(backupsDir(),backupFileNames[x.id]))])if(fs.existsSync(file)){try{original.journals.push(JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')))}catch(e){errors.push(e.message)}}addLegacy('legacy-network','Internet DNS / TCP / NIC','Network',original)}
 const gpuDir=path.join(process.env.LOCALAPPDATA||dataDir,'TweakRomania','Carpatia','GpuPreferenceBackups');
 for(const record of readRecoveryFiles(gpuDir)){if(record.error){errors.push(record.error);continue}if(record.version!==1||typeof record.exe!=='string'){errors.push('Backup GPU invalid');continue}addLegacy('gpu:'+crypto.createHash('sha256').update(record.exe).digest('hex'),'GPU · '+path.basename(record.exe),'GPU',record,{exe:record.exe})}
 const records=[...readRecoveryFiles(path.join(dataDir,'recovery-reports')),...readRecoveryFiles(path.join(dataDir,'backup-history'))];
 const historyErrors=records.filter(x=>x.error).map(x=>x.error);
 const history=records.filter(x=>!x.error).map(record=>({...record,results:Array.isArray(record.results)?record.results:[],rows:Array.isArray(record.rows)?record.rows:[]})).map(record=>{
  if(record.type!=='manual-snapshot')return record;
  let restorable=(Array.isArray(record.results)?record.results:[]).some(x=>x&&x.status==='captured');
  if(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(record.id||'')){
   const mf=path.join(dataDir,'recovery-snapshots',record.id,'manifest.json');
   if(fs.existsSync(mf)){try{const m=JSON.parse(fs.readFileSync(mf,'utf8'));restorable=Array.isArray(m.files)&&m.files.length>0}catch(e){historyErrors.push('Manifest '+record.id+': '+e.message);restorable=false}}
  }
  return {...record,restorable};
 }).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
 return {items,errors:[...new Set(errors)],history,historyErrors,profiles:await dashboardProfiles.analyze(),transactions:snapshotService.transactions()};
}
async function recoveryRestoreItem(item){
 if(item.legacy){
  if(item.id==='legacy-network'&&!networkRecovery().steps.length)return restoreNetworkSelection([]);
  // Mixed legacy/catalog originals must never be restored in an ambiguous order.
  const state=await libraryState();if(state.success!==true||state.states.some(x=>['prepared','failed','applied'].includes(x.state)))throw Error('Restaurează întâi backupurile catalogului; apoi repetă restaurarea modulelor anterioare.');
  const result=item.id==='legacy-ultra'?await ps('engine.ps1','Restore'):item.id==='legacy-power'?await ps('power.ps1','Restore'):item.id==='legacy-startup'?await ps('startup.ps1','RestoreAll'):item.id==='legacy-network'?await restoreNetworkSelection(networkRecovery().steps.map(x=>x.id)):item.serviceId?await ps('services-lab.ps1','Restore','-Id',item.serviceId):item.exe?await ps('gpu-lab.ps1','Restore','-ExePath',item.exe):{success:false,message:'Modul necunoscut'};
  if(result.success!==true)return result;
  if((await recoveryInventory()).items.some(x=>x.id===item.id))throw Error('Backupul rămâne activ după restaurare.');
  return result;
 }
 const ledger=resourceLedger();if(ledger.errors.length)throw Error(ledger.errors.join('; '));
 const owners=ledgerCore.conflicts(ledger,ledgerCore.resources(tweakLibrary.getRule(item.id)),item.id);
 if(owners.length)throw Error('Backupuri suprapuse: '+owners.map(x=>x.module).join(', ')+'. Este necesară verificarea originalelor.');
 const result=await runLibraryOperation(item.id,'Restore');
 if(result.success!==true)return result;
 const state=await libraryState();
 if(state.success!==true||state.states.find(x=>x.id===item.id)?.state!=='restored')throw Error('Restaurarea nu este confirmată în jurnal.');
 // Individual/category recovery also updates its profile membership, without altering level selection.
 for(const group of ['cpu','gpu','internet']){
  const file=profileSessionFile(group);if(!fs.existsSync(file))continue;
  const s=require('./dashboard-profiles').validateSession(JSON.parse(fs.readFileSync(file,'utf8')),group);
  if(!s.started.includes(item.id))continue;
  s.started=s.started.filter(id=>id!==item.id&&!s.unchanged.includes(id));s.unchanged=[];if(s.reused)s.reused=s.reused.filter(id=>s.started.includes(id));
  s.state=s.started.length?'recovery':'restored';writeJournal(file,s);
 }
 return result;
}
const recoveryService=createRecoveryService({
 inventory:recoveryInventory,
 inspect:async item=>{try{if(item.legacy){const r=item.id==='legacy-ultra'?await ps('engine.ps1','Status'):item.id==='legacy-power'?await ps('power.ps1','Status'):item.id==='legacy-startup'?await ps('startup.ps1','List'):item.id==='legacy-network'?await runPs(script('network.ps1')):item.serviceId?await ps('services-lab.ps1','Status'):await ps('gpu-lab.ps1','Status','-ExePath',item.exe);return {...r,success:r.success===true||(item.id==='legacy-network'&&Array.isArray(r.adapters)),current:item.id==='legacy-network'?{adapters:(r.adapters||[]).map(a=>({name:a.name,dns:a.dns}))}:item.serviceId?(r.items||[]).find(x=>x.id===item.serviceId)||r:r}}return await runLibraryOperation(item.id,'Check',item.operation?.adapterGuid||item.operation?.guid||'')}catch(e){return {success:false,message:e.message}}},
 restore:recoveryRestoreItem,
 persist:report=>writeJournal(path.join(app.getPath('userData'),'recovery-reports',report.id+'.json'),report)
});
registerRead('recoveryInventory',recoveryInventory,{recovery:true});
registerRead('recoveryPrepare',selection=>{if(busy)throw Error('Operație în curs.');return recoveryService.prepare(selection)},{recovery:true});
registerWrite('recoveryCommit',token=>recoveryService.commit(token),{recovery:true});
const captureManualSnapshot=require('./backup-core').createManualSnapshot({
 dataDir:()=>app.getPath('userData'),backupDir:backupsDir,catalog:()=>tweakLibrary.publicCatalog(),ruleFor:id=>tweakLibrary.getRule(id),
 identity:snapshotIdentity,context:()=>ps('tweak-native.ps1','Context','-DataDir',app.getPath('userData')),
 read:(id,adapter)=>runLibraryOperation(id,'Check',adapter),save:writeJournal,notify:event=>emit('backupProgress',event)
});
registerWrite('recoverySnapshot',captureManualSnapshot,{recovery:true});

// Manual copies have a separate persistent undo journal; no automatic original is overwritten.
const {createSnapshotService}=require('./snapshot-core');
async function snapshotIdentity(){const r=await ps('snapshot-engine.ps1','Identity');if(!r.success||!r.identity)throw Error('Identitatea Windows nu poate fi verificată.');return r.identity}
async function snapshotOperation(row,action){
 const file=path.join(app.getPath('userData'),'snapshot-requests',crypto.randomUUID()+'.json');writeJournal(file,row);
 try{return await ps('snapshot-engine.ps1',action,'-RequestFile',file)}finally{fs.rmSync(file,{force:true})}
}
async function assertSnapshotBaseline(){
 const s=await recoveryInventory();if(s.errors.length)throw Error('Verifică backupurile necitibile înainte de restaurarea copiei.');
 if(s.items.some(x=>['prepared','applied','failed'].includes(x.state)))throw Error('Există modificări cu originale automate. Folosește mai întâi „Restaurează tot”, apoi selectează copia manuală. Originalele nu vor fi înlocuite.');
}
const snapshotService=createSnapshotService({dataDir:()=>app.getPath('userData'),probe:r=>snapshotOperation(r,'Probe'),write:r=>snapshotOperation(r,'Write'),identity:snapshotIdentity,assertClear:assertSnapshotBaseline,save:writeJournal});
registerRead('snapshotPrepare',id=>{if(busy)throw Error('Operație în curs.');return snapshotService.prepare(id)},{recovery:true});
registerWrite('snapshotCommit',token=>snapshotService.commit(token),{recovery:true});
registerWrite('snapshotResume',(id,undo)=>{if(typeof undo!=='boolean')throw Error('Acțiune invalidă.');return snapshotService.resume(id,undo)},{recovery:true});
