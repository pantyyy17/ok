'use strict';
(()=>{
 const $=id=>document.getElementById(id),backdrop=$('commandBackdrop'),input=$('commandSearch'),results=$('commandResults');
 const commands=Array.from(document.querySelectorAll('#sidebarNav .nav')).map(button=>({button,title:button.querySelector('strong').textContent,subtitle:button.querySelector('small').textContent}));
 const normalize=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 let previous=null,index=0;
 function close(){backdrop.classList.add('hidden');previous?.focus()}
 function render(){
  const query=normalize(input.value.trim());results.replaceChildren();index=0;
  const choices=commands.filter(c=>normalize(c.title+' '+c.subtitle).includes(query));
  function add(title,subtitle,run){const b=document.createElement('button');b.type='button';b.className='command-result';const label=document.createElement('strong'),detail=document.createElement('small');label.textContent=title;detail.textContent=subtitle;b.append(label,detail);b.onclick=()=>{close();run()};results.append(b)}
  for(const c of choices)add(c.title,c.subtitle,()=>c.button.click());
  if(query)add('Caută în catalog: '+input.value,'Setări CPU, GPU, Internet și Windows',()=>{commands.find(c=>c.button.dataset.view==='tweaks').button.click();const search=$('tweakSearch');search.value=input.value;search.dispatchEvent(new Event('input',{bubbles:true}))});
  highlight();
 }
 function highlight(){Array.from(results.children).forEach((b,i)=>b.classList.toggle('selected',i===index))}
 function open(){previous=document.activeElement;backdrop.classList.remove('hidden');input.value='';render();input.focus()}
 $('commandOpen').onclick=open;$('commandClose').onclick=close;input.oninput=render;
 backdrop.addEventListener('click',e=>{if(e.target===backdrop)close()});
 document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){if(!$('modalBackdrop').classList.contains('hidden'))return;e.preventDefault();backdrop.classList.contains('hidden')?open():close();return}
  if(backdrop.classList.contains('hidden'))return;
  if(e.key==='Escape'){e.preventDefault();close()}
  if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();index=(index+(e.key==='ArrowDown'?1:-1)+results.children.length)%results.children.length;highlight();results.children[index]?.scrollIntoView({block:'nearest'})}
  if(e.key==='Enter'&&document.activeElement===input){e.preventDefault();results.children[index]?.click()}
  if(e.key==='Tab'){const nodes=Array.from(backdrop.querySelectorAll('button,input')),first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
 });
 for(const c of commands)c.button.addEventListener('click',()=>{if(c.button.classList.contains('active'))$('workspaceLocation').textContent=c.title});
})();
