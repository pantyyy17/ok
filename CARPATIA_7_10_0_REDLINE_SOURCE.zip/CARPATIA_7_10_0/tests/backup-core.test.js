'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createManualSnapshot}=require('../backup-core'),catalog=require('../tweak-library-core');
function fixture(t,overrides={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-capture-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const rule=catalog.getRule('library-cpu-035');
 const opts={dataDir:()=>dir,backupDir:()=>path.join(dir,'legacy'),catalog:()=>[rule],ruleFor:id=>catalog.getRule(id),identity:async()=>'a'.repeat(64),context:async()=>({success:true,adapters:[]}),read:async()=>({success:true,current:rule.entries.map(e=>({...e,exists:true,kind:'DWord',value:0}))}),save:(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(value))},...overrides};
 return {dir,capture:createManualSnapshot(opts)};
}
test('manual capture creates a hash-verified restorable snapshot and complete report',async t=>{const f=fixture(t),r=await f.capture();assert.equal(r.success,true);assert.equal(r.captured,1);assert.equal(r.restorable,true);const m=JSON.parse(fs.readFileSync(path.join(f.dir,'recovery-snapshots',r.id,'manifest.json')));assert.equal(m.complete,true);assert.equal(m.files.length,1)});
test('identity failure leaves a durable failed report with no restore action',async t=>{const f=fixture(t,{identity:async()=>{throw Error('Identity denied')}}),r=await f.capture();assert.equal(r.state,'failed');assert.equal(r.restorable,false);assert.match(r.results[0].message,/Identity denied/);assert.equal(JSON.parse(fs.readFileSync(path.join(f.dir,'recovery-reports',r.id+'.json'))).state,'failed')});
test('failure copying originals keeps valid captures restorable and reports partial state',async t=>{const f=fixture(t,{copy:()=>{throw Error('Copy denied')}});fs.mkdirSync(path.join(f.dir,'legacy'));const r=await f.capture();assert.equal(r.state,'partial');assert.equal(r.restorable,true);assert.equal(r.failed,1);assert.match(r.results.at(-1).message,/Copy denied/)});
test('progress subscriber errors do not interrupt backup creation',async t=>{const f=fixture(t,{notify:()=>{throw Error('UI gone')}});assert.equal((await f.capture()).success,true)});
