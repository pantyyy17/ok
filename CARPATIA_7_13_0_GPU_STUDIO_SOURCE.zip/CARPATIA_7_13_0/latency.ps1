﻿param([ValidateSet('1.1.1.1','8.8.8.8','9.9.9.9')][string]$HostIP='1.1.1.1')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$results=@()
$sent=6
for($i=0;$i -lt $sent;$i++){
 try {
  $reply=Test-Connection -ComputerName $HostIP -Count 1 -ErrorAction Stop
  if($reply -and $null -ne $reply.ResponseTime){$results+= [double]$reply.ResponseTime}
 }catch{}
 if($i -lt ($sent-1)){Start-Sleep -Milliseconds 250}
}
$received=$results.Count
$avg=$null;$jitter=$null
if($received -gt 0){$avg=[math]::Round((($results|Measure-Object -Average).Average),1)}
if($received -gt 1){$diffs=@();for($i=1;$i -lt $received;$i++){$diffs+=[math]::Abs($results[$i]-$results[$i-1])};$jitter=[math]::Round((($diffs|Measure-Object -Average).Average),1)}
@{host=$HostIP;sent=$sent;received=$received;avg=$avg;jitter=$jitter;loss=[math]::Round(100*($sent-$received)/$sent,1)}|ConvertTo-Json -Compress
