﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
try {
  $all=@(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' })
  $items=@(foreach($a in $all){
    $dns=@(Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object {$_.ServerAddresses})
    $ips=@(Get-NetIPAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.IPAddress -notlike '169.254.*'} | ForEach-Object {$_.IPAddress})
    [pscustomobject]@{name=$a.Name;guid=([guid]$a.InterfaceGuid).ToString();status=[string]$a.Status;linkSpeed=[string]$a.LinkSpeed;ipv4=@($ips);dns=@($dns)}
  })
  @{success=$true;adapters=@($items)} | ConvertTo-Json -Depth 5 -Compress
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}
