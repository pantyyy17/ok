@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\test-cache-lock-windows.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Testul a esuat. Trimite mesajele din consola.
if "%RC%"=="0" echo Testul cache lock a trecut.
pause
exit /b %RC%
