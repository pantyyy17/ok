﻿param([ValidateSet('List','Disable','Restore','RestoreAll')][string]$Action='List',[string]$Name='')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
# HKCU Run only. No machine startup keys, scheduled tasks, services, security tools or OS components.
$run='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
New-Item -Path $dir -ItemType Directory -Force|Out-Null
$file=Join-Path $dir 'startup-disabled.json'
$blocked='(?i)(defender|securityhealth|antivirus|antimalware|firewall|vpn|bitlocker|windows.?security|onedrive|synaptics|realtek|intel|nvidia|amd|logitech|razer|steelseries|corsair)'
function Output([hashtable]$v){$v|ConvertTo-Json -Compress -Depth 8;exit}
function Backups {
 if(!(Test-Path -LiteralPath $file)){return @()}
 $b=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json
 if($b.version -ne 1 -or $b.items -isnot [System.Array]){throw 'Backup Startup incompatibil'}
 # Validate every original before restoring the first entry. Never turn a
 # missing/non-string value into an empty command or silently merge duplicates.
 $names=@{}
 foreach($entry in $b.items){
  if($null -eq $entry -or $entry.name -isnot [string] -or [string]::IsNullOrWhiteSpace($entry.name) -or $entry.name.Length -gt 150 -or $entry.name -match '[\r\n]' -or $entry.value -isnot [string] -or $entry.kind -cnotin @('String','ExpandString') -or $names.ContainsKey($entry.name)){throw 'Backup Startup invalid sau incomplet; originalele sunt păstrate.'}
  $names[$entry.name]=$true
 }
 return @($b.items)
}
function Save($items){
 $obj=@{version=1;items=@($items)}
 $tmp=$file+'.tmp'
 $obj|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $tmp -Encoding UTF8
 Move-Item -LiteralPath $tmp -Destination $file -Force
}
$backup=@(Backups)
if($Action -eq 'List'){
 $items=@()
 if(Test-Path -LiteralPath $run){
  $key=Get-Item -LiteralPath $run
  foreach($nameItem in @($key.GetValueNames())){
   $blockedItem=($nameItem -match $blocked) -or ([string]$key.GetValue($nameItem,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) -match $blocked)
   $items+=@{name=$nameItem;command=[string]$key.GetValue($nameItem,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);protected=[bool]$blockedItem}
  }
 }
 Output @{success=$true;entries=@($items);disabled=@($backup|ForEach-Object {@{name=$_.name;command=$_.value}})}
}
if($Action -eq 'Disable'){
 if(!$Name -or $Name.Length -gt 150 -or $Name -match '[\r\n]'){throw 'Nume de program invalid'}
 if(!(Test-Path -LiteralPath $run)){throw 'Nu exista intrari Startup in profilul curent'}
 $key=Get-Item -LiteralPath $run
 if(@($key.GetValueNames()) -notcontains $Name){throw 'Intrarea nu mai exista: '+$Name}
 $value=[string]$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
 if($Name -match $blocked -or $value -match $blocked){throw 'Intrarea pare sa apartina unui driver, serviciu sau produs de securitate. Nu o dezactivam.'}
 if(@($backup|ForEach-Object {$_.name}) -contains $Name){throw 'Intrarea este deja salvata'}
 $kind=[string]$key.GetValueKind($Name)
 if($kind -notin @('String','ExpandString')){throw 'Tip de intrare Startup neacceptat'}
 $backup+=@{name=$Name;value=$value;kind=$kind}
 Save $backup  # Backup before deleting from HKCU Run
 Remove-ItemProperty -LiteralPath $run -Name $Name -ErrorAction Stop
 Output @{success=$true;message=('Dezactivat la pornirea Windows: '+$Name);disabled=@($backup).Count}
}
if($Action -eq 'Restore' -and (!$Name -or $Name.Length -gt 150)){throw 'Numele pentru restaurare este invalid'}
$restored=@();$errors=@();$remaining=@()
foreach($entry in $backup){
 if($Action -eq 'Restore' -and $entry.name -ine $Name){$remaining+=,$entry;continue}
 try{
  if(Test-Path -LiteralPath $run){
   $key=Get-Item -LiteralPath $run
   if(@($key.GetValueNames()) -contains [string]$entry.name){
    # A crash may occur after writing the original and before saving the journal.
    # Accept that exact original on retry, but never overwrite an external value.
    if([string]$key.GetValueKind([string]$entry.name) -cne [string]$entry.kind -or [string]$key.GetValue([string]$entry.name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) -cne [string]$entry.value){throw 'Există deja o intrare diferită cu același nume. Nu o suprascriem.'}
    $restored+=@([string]$entry.name);continue
   }
  }
  New-Item -Path $run -Force|Out-Null
  if([string]$entry.kind -notin @('String','ExpandString')){throw 'Tip de intrare nepermis'}
  New-ItemProperty -LiteralPath $run -Name ([string]$entry.name) -PropertyType ([string]$entry.kind) -Value ([string]$entry.value) -Force -ErrorAction Stop|Out-Null
  $verifiedKey=Get-Item -LiteralPath $run
  if([string]$verifiedKey.GetValueKind([string]$entry.name) -cne [string]$entry.kind -or [string]$verifiedKey.GetValue([string]$entry.name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) -cne [string]$entry.value){throw 'Verificarea restaurării Startup a eșuat.'}
  $restored+=@([string]$entry.name)
 }catch{$remaining+=,$entry;$errors+=@{name=$entry.name;error=$_.Exception.Message}}
}
if($Action -eq 'Restore' -and $restored.Count -eq 0 -and $errors.Count -eq 0){throw 'Nu exista backup pentru numele solicitat.'}
if($remaining.Count){Save $remaining}else{if(Test-Path -LiteralPath $file){Remove-Item -LiteralPath $file -Force}}
Output @{success=($errors.Count -eq 0);restored=@($restored);errors=@($errors);remaining=@($remaining).Count;message='Restaurarea intrarilor Startup a fost executata.'}
