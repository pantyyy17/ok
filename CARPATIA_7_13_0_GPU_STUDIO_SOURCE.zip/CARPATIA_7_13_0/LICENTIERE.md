# CARPATIA — Licențiere 7.11.0

Clientul primește un cod semnat Ed25519 după cumpărare și îl introduce în aplicație. Nu are nevoie de cont sau parolă. Aplicația verifică local semnătura și expirarea; licența validă rămâne salvată la redeschidere, inclusiv fără internet. Codurile Shopify sunt permanente; managerul permite și o dată de expirare pentru emiterea manuală.

## Prima lansare: configurarea editorului

Nu există licențe de producție emise încă. În acest mediu nu am generat o cheie de producție și nu este inclus `license-public.pem` configurat.

1. Pe PC-ul tău Windows cu Node.js 24+, extrage sursele și rulează `LICENTA_MANAGER.bat`.
2. Verifică folderul privat afișat. Trebuie să fie în afara proiectului; poți alege explicit prin `node tools/license-manager.js --private-dir "D:\CARPATIA_PRIVATE"`.
3. Apasă **CREEAZĂ CHEILE O SINGURĂ DATĂ**. Păstrează un backup criptat separat al folderului privat.
4. Apasă **COPIAZĂ CHEIA PUBLICĂ ÎN PROIECT**. Managerul arată amprenta SHA-256 și verifică potrivirea. Numai cheia publică ajunge în sursă ca `license-public.pem`; o cheie existentă diferită nu este suprascrisă.
5. Rulează `npm ci`, testele și `BUILD_INSTALLER.bat` pe Windows. Testează un cod emis cu aceeași pereche în installer înainte să-l distribui. Starea cheii din manager nu înlocuiește compilarea și testarea Windows.

După prima emitere păstrează perechea originală. Nu o schimba la actualizări sau la mutarea magazinului. Cheia privată semnează licențele și nu intră în installer, GitHub, arhiva sursă sau chat. Managerul ascultă numai pe `127.0.0.1`, cu token aleator și verificarea originilor; nu îl expune pe internet.

## Cumpărare și livrare

Pentru început poți verifica manual plata în Shopify și emite codul din manager. Livrează codul sau fișierul .txt exportat clientului. Automatizarea prin `seller/` verifică webhookul `orders/paid`, produsul și plata, emite câte un cod per unitate și trimite email prin Resend. Ghidul complet, inclusiv configurarea serverului privat, este în `GHID_SHOPIFY_7_4_4.md`.

Livrarea automată necesită găzduire persistentă, HTTPS, configurare Shopify, expeditor de email verificat și URL real către installer. Aceste servicii nu sunt conectate în sursa livrată. Nu trimite secretele prin chat.

La mutarea pe site propriu păstrezi perechea Ed25519 și baza de date. Licențele existente continuă să funcționeze. Emiterea comună este în `seller/fulfillment-core.js`; viitorul adaptor trebuie să verifice plata la furnizor înainte de emitere. Integrarea cu plata pentru site-ul viitor nu este încă implementată.

## Activarea clientului

Clientul instalează installerul, apoi lipește codul complet sau apasă **IMPORTĂ FIȘIER .TXT**. Codurile împărțite pe linii de email sunt acceptate. Un cod falsificat sau expirat este respins; o încercare greșită de înlocuire păstrează licența validă existentă. După succes vede detaliile și apasă **DESCHIDE CARPATIA**. La următoarea pornire intră direct în aplicație.

Ecranul licenței permite verificare repetată, afișarea detaliilor și introducerea unui cod nou. Restaurarea setărilor rămâne accesibilă dacă licența lipsește sau expiră. O distribuție fără cheia publică este semnalată explicit și nu permite o activare aparent reușită.

## Limite și verificări înainte de vânzare

- Licența offline poate fi copiată între PC-uri. Nu există limită tehnică per dispozitiv, cont online sau revocare automată la refund.
- `npm run release:check` trebuie să treacă după configurarea cheii publice. Distribuie clienților numai installerul verificat, nu ZIP-ul sursă cu uneltele editorului.
- Validează pe Windows 10/11 installerul, activarea, expirarea, restaurarea CPU/GPU/Internet și backupurile. Testele Linux/Chromium nu validează scrierile reale Windows sau performanța în jocuri.
- O eventuală activare online cu limite de dispozitive/revocare necesită un serviciu separat; nu este promisă de această versiune.
