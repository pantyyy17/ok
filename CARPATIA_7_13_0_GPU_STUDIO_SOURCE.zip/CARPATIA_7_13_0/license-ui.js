'use strict';
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaLicense=factory();
})(typeof window!=='undefined'?window:globalThis,function(){
 const MAX_TIMEOUT=2147483647;
 function mount({api,document:doc=globalThis.document,window:win=globalThis.window,onState=()=>{},onRecovery=()=>{},showToast=()=>{},now=()=>Date.now(),timers={setTimeout:(fn,delay)=>setTimeout(fn,delay),clearTimeout:id=>clearTimeout(id)}}){
  const $=id=>doc.getElementById(id),gate=$('licenseGate'),dialog=$('licenseDialog'),shell=doc.querySelector('.shell');
  const controls=['licenseCode','licenseActivate','licenseImport','licenseRefresh'];
  let info={active:false,reason:'checking'},busy='',destroyed=false,epoch=0,checkFlight=null,expiryTimer=null,expiryPending=false,previousFocus=null,recoveryMode=false,replacementOpen=false,lastChecked=0,hasChecked=false;
  const visible=()=>!gate.classList.contains('hidden');
  const write=(id,value)=>{$(id).textContent=String(value??'')};
  const hidden=(id,value)=>$(id).classList.toggle('hidden',!!value);
  const message=(value,tone='neutral')=>{write('licenseMessage',value);$('licenseMessage').dataset.tone=tone;$('licenseMessage').setAttribute('role',tone==='error'?'alert':'status')};
  function date(value){const timestamp=Date.parse(value);return Number.isFinite(timestamp)?new Date(timestamp).toLocaleString('ro-RO',{year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'}):'Dată indisponibilă'}
  function statusMessage(state){
   if(state.active)return state.developer?'Modul de dezvoltare este activ în această sesiune.':'Activarea este salvată pe acest calculator. La următoarea deschidere intri direct în aplicație.';
   return ({checking:'Se verifică activarea salvată…',missing_license:'Lipește codul complet din e-mailul de livrare sau importă fișierul .txt primit.',expired_license:'Licența a expirat. Introdu un cod nou pentru a continua. Setările salvate pot fi restaurate în continuare.',invalid_license:'Licența salvată nu a putut fi verificată. Introdu din nou codul complet primit după cumpărare.',invalid_license_file:'Activarea salvată nu poate fi citită. Lipește codul primit sau importă din nou fișierul .txt.',missing_publisher_key:'Activarea nu este disponibilă în această versiune. Folosește pachetul oficial actualizat sau contactează vânzătorul cu numărul comenzii.',invalid_publisher_key:'Activarea nu este disponibilă în această versiune. Folosește pachetul oficial actualizat sau contactează vânzătorul cu numărul comenzii.',status_unavailable:'Starea licenței nu a putut fi verificată. Apasă „Verifică din nou” pentru a reîncerca.'})[state.reason]||'Licența nu a putut fi verificată. Introdu codul complet primit după cumpărare.';
  }
  function activationError(error){
   const detail=String(error?.message||error||'');
   if(info.configured===false)return statusMessage(info);
   if(/expirat/i.test(detail))return 'Acest cod a expirat. Introdu codul nou primit după reînnoire.';
   if(/salv|scri|EACCES|EPERM|ENOSPC|EROFS/i.test(detail))return 'Activarea nu a putut fi salvată pe acest calculator. Verifică spațiul liber și permisiunile aplicației, apoi reîncearcă.';
   if(/fișier|fisier|\.txt|UTF|8192|lung/i.test(detail))return 'Fișierul nu conține un cod valid. Alege fișierul .txt primit la cumpărare sau lipește codul complet.';
   return 'Codul nu a putut fi activat. Copiază codul complet din e-mailul de livrare, fără text suplimentar, și reîncearcă.';
  }
  function setBusy(value){
   busy=value;dialog.setAttribute('aria-busy',value?'true':'false');
   for(const id of controls)$(id).disabled=!!value||(info.configured===false&&id!=='licenseRefresh');
   $('licenseRecovery').disabled=!!value;
   $('licenseClose').disabled=!!value;
   $('licenseReplace').disabled=!!value;
   write('licenseActivate',value==='activate'?'SE ACTIVEAZĂ…':'ACTIVEAZĂ LICENȚA');
   write('licenseImport',value==='import'?'SE DESCHIDE FIȘIERUL…':'IMPORTĂ FIȘIER .TXT');
   write('licenseRefresh',value==='checking'?'SE VERIFICĂ…':'Verifică din nou');
  }
  function focusFirst(){(info.active&&!replacementOpen?$('licenseClose'):info.configured===false?$('licenseRefresh'):$('licenseCode')).focus()}
  function setGate(open,{restoreFocus=true,focus=true}={}){
   if(open&&!visible())previousFocus=doc.activeElement;
   gate.classList.toggle('hidden',!open);doc.body.classList.toggle('license-open',open);if(shell)shell.inert=open;
   if(open&&focus)focusFirst();
   if(!open&&restoreFocus){const target=previousFocus?.isConnected&&previousFocus!==doc.body&&!previousFocus.closest?.('#licenseGate')?previousFocus:$('licenseButton');target?.focus();previousFocus=null}
  }
  function scheduleExpiry(){
   if(expiryTimer!==null)timers.clearTimeout(expiryTimer);expiryTimer=null;
   if(!info.active||!info.expiresAt)return;
   const remaining=Date.parse(info.expiresAt)-now();if(!Number.isFinite(remaining))return;
   expiryTimer=timers.setTimeout(()=>{expiryTimer=null;if(remaining>MAX_TIMEOUT)scheduleExpiry();else if(busy)expiryPending=true;else refresh({force:true})},Math.min(MAX_TIMEOUT,Math.max(0,remaining)+30));
  }
  function render(){
   const active=info.active===true,setup=info.configured===false&&!active;
   doc.body.dataset.licensed=active?'yes':'no';gate.dataset.state=active?'active':info.reason||'inactive';
   write('licenseButton',active?(info.developer?'MOD DEZVOLTARE':'LICENȚĂ ACTIVĂ'):info.reason==='expired_license'?'LICENȚĂ EXPIRATĂ':'ACTIVEAZĂ LICENȚA');
   $('licenseButton').setAttribute('aria-label',active?'Vezi detaliile licenței CARPATIA':'Activează licența CARPATIA');
   write('licenseStatusBadge',active?'ACCES ACTIV':info.reason==='expired_license'?'ACCES EXPIRAT':setup?'ACTIVARE INDISPONIBILĂ':'ACTIVARE CARPATIA');
   write('licenseTitle',active?'Ești gata de start.':info.reason==='expired_license'?'Continuă cu CARPATIA.':setup?'Actualizează aplicația.':'Activează CARPATIA.');
   write('licenseIntro',active?'Licența ta este activă. Ai acces la toate funcțiile incluse.':'Introdu licența primită după cumpărare. Nu ai nevoie de cont sau parolă.');
   write('licenseCodeLabel',active?'AI UN COD NOU?':'CODUL TĂU DE LICENȚĂ');
   hidden('licenseDetails',!active);hidden('licenseClose',!active);hidden('licenseInputHint',setup);hidden('licenseEntry',active&&!replacementOpen);hidden('licenseActivate',active&&!replacementOpen);hidden('licenseImport',(active&&!replacementOpen)||typeof api?.licenseImport!=='function');hidden('licenseReplace',!active);
   write('licenseReplace',replacementOpen?'ANULEAZĂ ÎNLOCUIREA':'INTRODU UN COD NOU');$('licenseReplace').setAttribute('aria-expanded',String(replacementOpen));
   $('licenseClose').classList.toggle('primary',!replacementOpen);$('licenseClose').classList.toggle('outline',replacementOpen);
   write('licenseRefreshHint',active?'Starea activării de pe acest calculator':'Ai activat deja pe acest calculator?');
   write('licenseCustomer',info.customer||'Client CARPATIA');write('licenseId',info.licenseId||'—');write('licenseExpiry',info.developer?'Sesiune de dezvoltare':info.expiresAt?date(info.expiresAt):'Fără termen de expirare');
   $('licenseCode').setAttribute('aria-invalid','false');
   const tone=active?'success':['missing_license','checking'].includes(info.reason)?'neutral':'error';
   message(statusMessage(info),tone);setBusy(busy);
  }
  function applyStatus(next,{initial=false,keepOpen=false}={}){
   const previous=info;info={...next,active:next?.active===true};hasChecked=true;lastChecked=now();render();scheduleExpiry();onState(info,{previous});
   if(keepOpen)setGate(true,{focus:false});
   else if(info.active){if(initial)setGate(false,{restoreFocus:false})}
   else if(!recoveryMode)setGate(true,{focus:!visible()||initial||previous.active});
  }
  async function refresh({initial=false,force=false,foreground=false}={}){
   if(!api||destroyed||busy)return info;
   if(checkFlight)return checkFlight;
   if(!force&&hasChecked&&now()-lastChecked<1000)return info;
   const request=++epoch,blocking=initial||foreground;
   if(blocking){setBusy('checking');message('Se verifică activarea salvată…')}
   const pending=Promise.resolve().then(()=>api.licenseStatus()).then(result=>{if(!destroyed&&request===epoch)applyStatus(result,{initial});return result},()=>{if(!destroyed&&request===epoch)applyStatus({active:false,reason:'status_unavailable'},{initial});return info}).finally(()=>{if(request===epoch&&blocking){setBusy('');if(visible())focusFirst()}if(checkFlight===pending)checkFlight=null});
   checkFlight=pending;return pending;
  }
  async function activate(kind='activate'){
   if(!api||busy||destroyed||info.configured===false)return;
   const code=$('licenseCode').value.trim();
   if(kind==='activate'&&!code){message('Lipește mai întâi codul primit după cumpărare.','error');$('licenseCode').setAttribute('aria-invalid','true');$('licenseCode').focus();return}
   const beforeMessage=$('licenseMessage').textContent,beforeTone=$('licenseMessage').dataset.tone;
   const request=++epoch;checkFlight=null;setBusy(kind);message(kind==='import'?'Alege fișierul .txt primit după cumpărare…':'Se verifică licența și se salvează activarea…');
   try{
    const result=await(kind==='import'?api.licenseImport():api.licenseActivate(code));
    if(destroyed||request!==epoch)return;
    if(result?.cancelled){message(beforeMessage,beforeTone);return}
    recoveryMode=false;if(result?.active===true)replacementOpen=false;applyStatus(result,{keepOpen:true});
    if(result?.active===true){$('licenseCode').value='';showToast('Licența CARPATIA a fost activată și salvată.');$('licenseCode').setAttribute('aria-invalid','false')}
   }catch(error){
    // A failed replacement leaves the stored license intact. Re-read it before
    // deciding which operations the renderer may offer.
    try{const current=await api.licenseStatus();if(!destroyed&&request===epoch)applyStatus(current,{keepOpen:true})}
    catch{if(!destroyed&&request===epoch)applyStatus({active:false,reason:'status_unavailable'},{keepOpen:true})}
    if(!destroyed&&request===epoch){message(activationError(error),'error');$('licenseCode').setAttribute('aria-invalid','true')}
   }finally{
    if(!destroyed&&request===epoch){setBusy('');focusFirst();if(expiryPending){expiryPending=false;refresh({force:true})}}
   }
  }
  function open(){if(!api||destroyed)return;recoveryMode=false;setGate(true);refresh()}
  function close(){if(info.active&&!busy){replacementOpen=false;render();setGate(false)}}
  function recover(){if(!api||busy)return;recoveryMode=true;setGate(false,{restoreFocus:false});onRecovery()}
  function replace(){if(!info.active||busy)return;replacementOpen=!replacementOpen;render();(replacementOpen?$('licenseCode'):$('licenseReplace')).focus()}
  function keydown(event){
   if(!visible())return;
   if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();event.stopImmediatePropagation();return}
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close();return}
   if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)&&doc.activeElement===$('licenseCode')){event.preventDefault();activate();return}
   if(event.key!=='Tab')return;
   const nodes=[...dialog.querySelectorAll('button,textarea,[tabindex="0"]')].filter(node=>!node.disabled&&!node.closest('.hidden'));
   if(!nodes.length){event.preventDefault();dialog.focus();return}
   const first=nodes[0],last=nodes.at(-1);
   if(event.shiftKey&&(doc.activeElement===first||!dialog.contains(doc.activeElement))){event.preventDefault();last.focus()}
   else if(!event.shiftKey&&(doc.activeElement===last||!dialog.contains(doc.activeElement))){event.preventDefault();first.focus()}
  }
  function resume(){if(doc.visibilityState!=='hidden')refresh()}
  function destroy(){destroyed=true;epoch++;if(expiryTimer!==null)timers.clearTimeout(expiryTimer);doc.removeEventListener('keydown',keydown,true);doc.removeEventListener('visibilitychange',resume);win?.removeEventListener('focus',resume);win?.removeEventListener('pagehide',destroy)}
  $('licenseButton').onclick=open;$('licenseClose').onclick=close;$('licenseRecovery').onclick=recover;$('licenseReplace').onclick=replace;
  $('licenseActivate').onclick=()=>activate();$('licenseImport').onclick=()=>activate('import');$('licenseRefresh').onclick=()=>refresh({force:true,foreground:true});
  $('licenseCode').addEventListener('input',()=>{$('licenseCode').setAttribute('aria-invalid','false')});
  doc.addEventListener('keydown',keydown,true);doc.addEventListener('visibilitychange',resume);win?.addEventListener('focus',resume);win?.addEventListener('pagehide',destroy,{once:true});
  if(!api){hidden('licenseGate',true);hidden('licenseButton',true)}
  else{render();if(typeof api.licenseImport!=='function')hidden('licenseImport',true)}
  return {init:()=>refresh({initial:true,force:true}),open,refresh,destroy,getState:()=>({...info})};
 }
 return {mount};
});
