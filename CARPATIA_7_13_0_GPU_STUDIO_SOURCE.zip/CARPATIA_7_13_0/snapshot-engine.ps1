﻿param([ValidateSet('Identity','Probe','Write')][string]$Action,[string]$RequestFile='')
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
. (Join-Path $PSScriptRoot 'registry-values.ps1')
. (Join-Path $PSScriptRoot 'tweak-native-ops.ps1')
function Emit($value){$value | ConvertTo-Json -Depth 32 -Compress}
if($Action -eq 'Identity'){
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
 $machine=Get-ItemPropertyValue -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop
 $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($machine+'|'+$sid)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
 Emit @{success=$true;identity=$hash};exit
}
$r=Get-Content -LiteralPath $RequestFile -Raw -Encoding UTF8 | ConvertFrom-Json
$catalog=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tweak-library.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$rules=@($catalog | Where-Object {$_.id -ceq $r.id});if($rules.Count -ne 1){throw 'Setare necunoscută.'};$rule=$rules[0]
function Validate-Registry($v,$e){
 Assert-RegistryValue $v
 if($v.path -ine $e.path -or $v.name -ine $e.name -or $v.exists -isnot [bool]){throw 'Țintă Registry nepermisă.'}
 if($v.exists -and ($v.kind -notin @('DWord','QWord','String','ExpandString','MultiString','Binary') -or $null -eq $v.value)){throw 'Valoare Registry incompletă.'}
 if($v.exists -and $v.kind -in @('String','ExpandString') -and $v.value -isnot [string]){throw 'Text Registry invalid.'}
 if($v.exists -and $v.kind -in @('DWord','QWord') -and $v.value -isnot [int] -and $v.value -isnot [long]){throw 'Număr Registry invalid.'}
 if($v.exists -and $v.kind -eq 'Binary'){foreach($n in $v.value){if($n -isnot [int] -and $n -isnot [long] -or $n -lt 0 -or $n -gt 255){throw 'Octet invalid.'}}}
}
function Validate-Native($o,$v){
 switch($o.type){
  {$_ -in @('defender','ipv6','task')} {if($v -isnot [bool]){throw 'Valoare booleană invalidă.'}}
  'power-active' {if([string]$v -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'Plan invalid.'}}
  'power-value' {if(($v -isnot [int] -and $v -isnot [long]) -or $v -lt 0 -or $v -gt 4294967295){throw 'Valoare de alimentare invalidă.'}}
  'service' {if(@($v).Count -ne @($o.services).Count){throw 'Servicii incomplete.'};for($i=0;$i -lt @($v).Count;$i++){$x=$v[$i];if($x.name -cne $o.services[$i].name -or $x.start -notin @(2,3,4) -or $x.running -isnot [bool] -or $x.delayedExists -isnot [bool] -or $x.delayed -notin @(0,1)){throw 'Original serviciu invalid.'}}}
  'dns' {if($v.automatic -isnot [bool] -or $v.servers -isnot [array] -or (-not $v.automatic -and @($v.servers).Count -eq 0)){throw 'DNS incomplet.'};foreach($ip in $v.servers){$address=$null;if(-not [Net.IPAddress]::TryParse([string]$ip,[ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Adresă DNS IPv4 invalidă.'}}}
  'mtu' {foreach($key in @('active','persistent')){if(($v.$key -isnot [int] -and $v.$key -isnot [long]) -or $v.$key -lt 576 -or $v.$key -gt 65535){throw 'MTU invalid.'}}}
  'firewall' {if([string]$v -notin @('True','False','NotConfigured')){throw 'Stare firewall invalidă.'}}
  'rss' {if([string]$v -notin @('Enabled','Disabled')){throw 'Stare RSS invalidă.'}}
  'tcp-global' {if([string]$v -notmatch '^[a-zA-Z0-9]+$'){throw 'Valoare TCP invalidă.'};if($o.property -eq 'initialrto' -and [string]$v -notmatch '^\d+$'){throw 'RTO invalid.'}}
  'tunnel' {if([string]$v -notmatch '^[a-zA-Z]+$'){throw 'Stare tunel invalidă.'}}
  'quota' {if($v -notin @(0,1,2)){throw 'Cotă invalidă.'}}
  'fsutil' {if(($v -isnot [int] -and $v -isnot [long]) -or $v -lt 0 -or $v -gt 4294967295){throw 'Valoare NTFS invalidă.'}}
  'bitlocker' {if([string]$v -notin @('On','Off')){throw 'Stare BitLocker invalidă.'}}
  'reserved-storage' {if([string]$v -notin @('Enabled','Disabled')){throw 'Stare spațiu rezervat invalidă.'}}
  'hibernation' {if(@($v).Count -ne 3){throw 'Captură hibernare incompletă.'};$seen=@{};foreach($x in $v){if($x.name -notin @('HibernateEnabled','HiberFileType','HiberFileSizePercent') -or $seen.ContainsKey($x.name) -or $x.exists -isnot [bool]){throw 'Captură hibernare invalidă.'};$seen[$x.name]=$true;if($x.exists -and ($x.value -isnot [int] -and $x.value -isnot [long])){throw 'Valoare hibernare invalidă.'}}}
  'bcd' {if(@($v).Count -ne @($o.values).Count){throw 'Captură BCD incompletă.'};for($i=0;$i -lt @($v).Count;$i++){$x=$v[$i];if($x.key -cne $o.values[$i].key -or $x.object -cne $o.values[$i].object -or $x.exists -isnot [bool] -or ($x.exists -and [string]$x.value -notmatch '^(Yes|No|True|False|On|Off|AlwaysOn|AlwaysOff|OptIn|OptOut|\d+)$')){throw 'Valoare BCD invalidă.'}}}
  default {throw 'Tip nativ neacceptat pentru copie.'}
 }
}
if($r.kind -eq 'registry'){
 if($rule.status -ne 'registry' -or $r.index -isnot [int] -or $r.index -lt 0 -or $r.index -ge @($rule.entries).Count){throw 'Index Registry invalid.'}
 $entry=$rule.entries[$r.index];Validate-Registry $r.target $entry
 $current=Read-Value $entry
}else{
 if($r.kind -ne 'native' -or $rule.status -ne 'native'){throw 'Tip de setare invalid.'}
 $o=Resolve-Native $rule.operation '' $r.operation
 if($r.PSObject.Properties.Name -contains 'index'){
  if($r.index -isnot [int] -or $r.index -lt 0){throw 'Index nativ invalid.'}
  if($o.type -eq 'service' -and $r.index -lt @($o.services).Count){$o.services=@($o.services[$r.index])}
  elseif($o.type -eq 'bcd' -and $r.index -lt @($o.values).Count){$o.values=@($o.values[$r.index])}
  else{throw 'Sub-operație nepermisă.'}
 }
 Validate-Native $o $r.target
 $current=Capture-Native $o
}
if($Action -eq 'Probe'){Emit @{success=$true;current=$current};exit}
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Restaurarea necesită Administrator.'}
if($r.PSObject.Properties.Name -notcontains 'expected'){throw 'Starea de comparație lipsește.'}
if($r.kind -eq 'registry'){
 Validate-Registry $r.expected $entry
 if(Same-Value $current $r.target){Emit @{success=$true;verified=$true;skipped=$true;message='Valoarea există deja.'};exit}
 if(-not (Same-Value $current $r.expected)){throw 'Valoarea s-a schimbat din exterior. Nu a fost suprascrisă.'}
 Set-Value $r.target
 if(-not (Same-Value (Read-Value $entry) $r.target)){throw 'Windows nu confirmă restaurarea Registry.'}
}else{
 Validate-Native $o $r.expected
 if((Canonical-Native $current) -ceq (Canonical-Native $r.target)){Emit @{success=$true;verified=$true;skipped=$true;message='Starea există deja.'};exit}
 # Compound native writes can stop between saved components. Resume only when
 # each component still matches its saved before or target value.
 if(-not (Test-NativeRestoreState $o $current $r.expected $r.target)){throw 'Starea s-a schimbat din exterior. Nu a fost suprascrisă.'}
 Write-Native $o $r.target
 if((Canonical-Native (Capture-Native $o)) -cne (Canonical-Native $r.target)){throw 'Windows nu confirmă restaurarea nativă.'}
}
Emit @{success=$true;verified=$true;skipped=$false;message='Restaurare verificată prin recitire.'}
