@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>&1
if errorlevel 1 (
 echo Node.js lipseste. Foloseste diagnosticul din aplicatie.
 pause
 exit /b 1
)
node tools\diagnose-recovery.js
pause
