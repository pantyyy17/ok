'use strict';
window.CarpatiaDashboardProfiles={mount({api,task,requireNative,confirmDialog,showToast,onOwner}){
 const $=id=>document.getElementById(id);let adaptersLoaded=false,lastConflict='',loadId=0;
 const groups={cpu:['CPU','heroDebloat'],gpu:['GPU','heroUltra'],internet:['INTERNET','heroNetwork']};
 const hints={cpu:{low:'Planificare foreground și priorități multimedia.',medium:'LOW + procesor maxim 100% la priză.',high:'MEDIUM + plan performant, EPP și cache de sistem.',ultra:'HIGH + boost, nuclee disponibile și opțiuni RAM compatibile.'},gpu:{low:'Game Mode și oprirea capturii Game DVR.',medium:'LOW + captură continuă/audio și aplicații UWP în fundal.',high:'MEDIUM + preferințe fullscreen.',ultra:'HIGH + HAGS unde versiunea Windows permite.'},internet:{low:'DNS ales și oprirea distribuirii P2P.',medium:'LOW + RSS și auto-tuning TCP Normal.',high:'MEDIUM + Fast Open și limitarea multimedia.',ultra:'HIGH + temporizare TCP și detectare proxy.'}};
 function tierHint(group){const target=$('profileHint-'+group);if(target)target.textContent=hints[group][$('profileLevel-'+group).value]||''}
 const node=(tag,text)=>{const n=document.createElement(tag);n.textContent=text;return n};
 function message(value){$('heroOpStatus').textContent=value}
 function summaryText(summary){
  if(!summary||['changed','already','reused','skipped'].some(key=>!Number.isInteger(summary[key])||summary[key]<0||summary[key]>1000))return '';
  return `${summary.changed} modificate · ${summary.already} deja configurate · ${summary.reused} reutilizate · ${summary.skipped} omise`;
 }
 async function load({refreshAdapters=false,skipAdapters=false}={}){
  if(!api)return;const request=++loadId;
  const status=await api.dashboardStatus();if(request!==loadId)return;
  const recovery=$('dashboardRecovery');recovery.replaceChildren();
  for(const [group,[label,buttonId]] of Object.entries(groups)){
   const state=status.find(x=>x.group===group);if(!state)throw Error('Stare Dashboard incompletă.');
   $(buttonId).disabled=state.active;
   $(buttonId).classList?.remove('is-error','is-complete');
   const hint=$(buttonId).querySelector?.('.reactor-state');if(hint)hint.textContent=state.observed==='active'?'ACTIV':state.observed==='partial'?'PARȚIAL':state.observed==='unknown'?'NEVERIFICAT':'';
   $('restoreProfile-'+group).disabled=!state.active||state.recoverable===false;
   let description=state.active?`${(state.level||'profil').toUpperCase()} · ${state.state!=='applied'?'NECESITĂ RECUPERARE':({active:'ACTIV · VERIFICAT',partial:'PARȚIAL ACTIV',inactive:'INACTIV · BACKUP PĂSTRAT',unknown:'STARE NECUNOSCUTĂ'})[state.observed]||'NEVERIFICAT'}`:'Niciun profil activ';
   if(state.active&&state.state==='applied'){
    const summary=summaryText(state.summary);if(summary)description+=' · La aplicare: '+summary;
    if(Number.isInteger(state.matching)&&Number.isInteger(state.total)&&state.total>0&&state.matching>=0&&state.matching<=state.total)description+=` · Potriviri citite acum: ${state.matching}/${state.total}`;
   }
   $('profileState-'+group).textContent=description;
   if(state.active&&state.recoverable!==false){const b=node('button','RESTAUREAZĂ '+label+' · '+(state.level||'profil').toUpperCase());b.className='action outline';b.onclick=()=>restore(group);recovery.append(b)}
  }
  if($('dashboardBackupCount'))$('dashboardBackupCount').textContent=status.filter(x=>x.active).length+' profiluri cu backup';
  if(lastConflict&&onOwner){const b=node('button','DESCHIDE BACKUP & RESTORE');b.className='action outline';b.onclick=()=>onOwner({id:lastConflict,route:'tweaks'});recovery.append(b)}
  if(!recovery.children.length)recovery.append(node('p','Nu există profiluri Dashboard active.'));
  if(skipAdapters||(adaptersLoaded&&!refreshAdapters))return;
  const select=$('dashboardAdapter'),old=select.value;
  try{
   const context=await api.tweakLibraryContext();if(request!==loadId)return;select.replaceChildren();const placeholder=node('option','Alege adaptorul…');placeholder.value='';select.append(placeholder);
   for(const adapter of context.adapters||[]){const option=node('option',adapter.name+' · '+adapter.status);option.value=adapter.guid;select.append(option)}
   select.value=old;adaptersLoaded=true;
  }catch(e){if(request!==loadId)return;showToast('Adaptoarele nu au fost încărcate: '+String(e.message||e))}
 }
 async function run(group){
  if(!requireNative())return;
  const level=$('profileLevel-'+group).value,adapterGuid=group==='internet'?$('dashboardAdapter').value:'';
  if(group==='internet'&&!adapterGuid){showToast('Alege adaptorul Internet înainte de analiză.');return}
  return task('Profil '+groups[group][0],async()=>{
   try{
    lastConflict='';
    message('Verific hardware-ul, stările originale și backupurile…');
    const options={auxiliary:$('profileAuxiliary-'+group)?.checked===true};if(group==='internet')options.dns=$('profileDns')?.value||'google';
    const request={group,level,adapterGuid};if(options.auxiliary||options.dns)request.options=options;
    const prepared=await api.dashboardPrepare(request);const plan=prepared.plan;
    const skipped=(plan.skipped||[]).map(step=>'• '+step.title+': '+step.reason);
    const details=plan.steps.map((step,i)=>`${i+1}. ${step.title}${plan.reuse?.includes(step.id)?' · deja aplicat; se păstrează originalul existent':''}${step.restart?' · restart':''}`).join('\n')+(skipped.length?'\n\nOMISE PENTRU ACEST PC:\n'+skipped.join('\n'):'')+(adapterGuid?'\nAdaptor: '+($('dashboardAdapter').selectedOptions?.[0]?.textContent||adapterGuid):'');
    message(`${plan.steps.length} opțiuni disponibile${skipped.length?' · '+skipped.length+' omise pentru compatibilitate':''}. Aștept confirmarea.`);
    if(!await confirmDialog('Aplici '+plan.title+'?',`${plan.steps.length} opțiuni disponibile. Fiecare modificare păstrează originalul pentru restaurare.`,details,plan.warning+' Performanța depinde de hardware și trebuie măsurată.','APLICĂ PROFILUL')){message('Anulat. Nicio modificare aplicată.');return}
    const result=await api.dashboardCommit(prepared.token);
    const summary=result.success===true?summaryText(result.summary):'';
    message(result.message+(summary?' Rezultat: '+summary+'.':'')+(result.restartRequired?' Repornește Windows pentru efectele care cer restart.':''));showToast(result.message);return result;
   }catch(e){const detail=String(e.message||e);if(/Conflict real:|backup|recuperare|jurnal/i.test(detail))lastConflict=detail.match(/library-[a-z0-9-]+/)?.[0]||'recovery';message(detail);throw e}finally{await load({skipAdapters:true}).catch(e=>showToast('Reîncarcă starea profilurilor: '+String(e.message||e)))}
  },groups[group][1]);
 }
 async function restore(group){
  if(!requireNative(true))return;
  return task('Restaurare '+groups[group][0],async()=>{
   if(!await confirmDialog('Restaurezi '+groups[group][0]+'?','Se revin în ordine inversă setările profilului la valorile salvate înainte de aplicare.','','Originalele sunt verificate înainte de restaurare. Conflictele sunt raportate și păstrate pentru diagnostic. Rețeaua se poate întrerupe; unele setări necesită restart.','RESTAUREAZĂ'))return;
   try{const result=await api.dashboardRestore(group);message(result.message);showToast(result.message);return result}
   finally{await load({skipAdapters:true}).catch(e=>showToast(String(e.message||e)))}
  },groups[group][1]);
 }
 for(const group of Object.keys(groups)){$('restoreProfile-'+group).onclick=()=>restore(group);$('profileLevel-'+group).addEventListener?.('change',()=>tierHint(group));tierHint(group)}
 $('refreshProfiles').onclick=()=>task('Stare profiluri',()=>load({refreshAdapters:true}));
 api?.onDashboardProgress?.(event=>message(event.detail));
 return {run,load,restore};
}};
