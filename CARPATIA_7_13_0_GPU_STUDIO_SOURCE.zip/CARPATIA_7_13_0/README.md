# CARPATIA V7 PRO REDLINE 7.13.0

Surse pentru prima lansare, de validat pe Windows 10/11. Versiunea 7.13.0 unifică Performanță & Tweaks, adaugă GPU Studio și controale separate pentru protecția Windows: `RAPORT_7_13_0.md`. Profilurile adaptive și sunetul munților rămân descrise în `RAPORT_7_12_0.md`. Activarea și Shopify rămân descrise în `RAPORT_7_11_0.md`. Butoanele CPU/GPU/Internet în formă de munte, cu animații roșii, sunt păstrate. Nu este inclus un EXE verificat.

## Noutăți

- Activare cu mesaje clare, detalii despre licență, import .txt, păstrarea activării la redeschidere și acces la restaurare fără licență.
- Emitere Shopify cu deduplicare, email persistent identic la reîncercare și protecție împotriva schimbării accidentale a cheii editorului. Instrucțiuni pentru mutarea ulterioară pe site propriu: `GHID_SHOPIFY_7_4_4.md`.
- Interfață Redline nouă, căutare Ctrl+K și centru de recuperare separat pe profiluri, originale și copii manuale.
- Restaurare directă CPU/GPU/Internet, inclusiv finalizarea sesiunilor rămase active după restaurare.

- Restaurare din copiile manuale: previzualizare, confirmare, verificare după scriere și jurnal persistent pentru reluare/anulare.
- Titluri și explicații în română pentru cele 215 intrări cu motoare din catalog; cinci opțiuni GPU cu ținte ambigue sunt blocate la aplicare, păstrând restaurarea, fără comenzi brute în fișele obișnuite.
- Incompatibilitățile hardware demonstrate sunt ascunse implicit; „Arată toate” le afișează. Setările cu backup activ rămân accesibile.
- Dashboard și modulele trimit restaurarea în centrul comun Backup & Restore. Catalogul Internet este accesat din catalogul comun.

Originalele se salvează automat înainte de modificare. În Backup & Restore poți restaura tot, o categorie sau o singură setare. Pentru o copie manuală, deschide Istoricul și alege „Restaurează această copie”. Dacă există originale automate active, restaurează-le întâi cu „Restaurează tot”, pentru a nu le înlocui. Istoricul permite reluarea sau anularea restaurării unei copii. Schimbările externe detectate nu sunt suprascrise automat.

## Pornire

1. Extrage proiectul într-un folder nou și păstrează backupurile existente.
2. Cu Node.js 24 sau mai nou, rulează `npm ci`, apoi `npm test`. Lockfile-ul fixează dependențele instalate.
3. Folosește `TEST_CARPATIA_WINDOWS.bat` pentru diagnostic și `TEST_UI_CARPATIA.bat` pentru interfață. Operațiile Windows necesită Administrator.
4. Validează scenariile din raport într-o mașină virtuală Windows înainte de distribuire.

`npm run dist` verifică licențierea și testele înainte de compilare. Pentru prima lansare pornește `LICENTA_MANAGER.bat` pe PC-ul tău, creează o singură pereche de chei într-un folder privat extern și copiază numai cheia publică în proiect. `license-public.pem` lipsește intenționat din aceste surse neconfigurate; buildul rămâne blocat până la configurare. După emiterea primelor licențe păstrează aceeași pereche, inclusiv la mutarea de pe Shopify. Cheia privată nu se distribuie. Detalii: `LICENTIERE.md`.

## Verificările auditului

- `npm test`: teste de logică și integrare; testele PowerShell simulate rulează dacă există Windows PowerShell sau `pwsh`. Pe Linux se poate indica executabilul prin `CARPATIA_PWSH`.
- `powershell -NoLogo -NoProfile -File tools/check-powershell.ps1`: parsează toate scripturile proiectului fără să le execute.
- `node tools/test-browser-smoke.js --license-flow --output-dir /tmp/carpatia-browser-smoke`: verifică DOM-ul în Chromium și activarea criptografică reală cu chei temporare de test. Operațiile Windows și selectorul nativ de fișier sunt simulate. Necesită Chromium; se poate selecta prin `CHROMIUM_BIN`.

Rezultatele păstrate sunt în `validation/`. Configurarea inițială a cheilor, găzduirea privată Shopify/email și validarea în VM Windows rămân necesare înainte de distribuire.

Rezultatele și previzualizările acestei revizii: `validation/7.13.0/`. Rapoartele mai vechi sunt păstrate ca istoric; referințele lor la o cheie „originală” lipsă sunt înlocuite de configurarea explicită pentru prima lansare.

Profilurile au opțiuni DNS și servicii auxiliare cu confirmare separată. Sunetul munților poate fi oprit din Dashboard. Pentru verificarea restaurării după restart într-o VM Windows: `VALIDARE_WINDOWS.md`; rularea fără argumente a `TEST_PROFILURI_VM.bat` afișează instrucțiunile.

GPU Studio gestionează preferința Windows pentru executabilul jocului și afișează numai senzorii disponibili. Frecvențele, consumul și ventilatoarele necesită senzori locali compatibili; aplicația nu implementează overclock sau control de ventilatoare. Protecția Windows se gestionează separat, printr-o acțiune explicită cu original și recitire; setările protejate de Tamper Protection se deschid în Securitate Windows.
