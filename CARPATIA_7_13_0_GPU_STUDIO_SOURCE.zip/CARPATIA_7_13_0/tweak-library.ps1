﻿param([ValidateSet('Apply','Restore','Status','Check')][string]$Action='Status',[string]$Id='',[Parameter(Mandatory=$true)][string]$DataDir)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$catalog=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tweak-library.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root=Join-Path $DataDir 'tweak-library-backups'
New-Item -ItemType Directory -Path $root -Force | Out-Null
function Save-Journal($file,$record){
 $temp=$file+'.new'
 $record | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $temp -Encoding UTF8
 if(Test-Path -LiteralPath $file){[IO.File]::Replace($temp,$file,$file+'.previous')}else{[IO.File]::Move($temp,$file)}
}
. (Join-Path $PSScriptRoot 'registry-values.ps1')
. (Join-Path $PSScriptRoot 'resource-conflicts.ps1')
function Read-Journal($file){
 $j=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
 if($j.version -ne 1 -or [string]$j.id -notmatch '^library-[a-z0-9-]+$' -or $j.state -notin @('prepared','applied','failed','restored') -or -not @($j.values).Count){throw 'Backup invalid. Aplicarea este blocată.'}
 return $j
}
if($Action -eq 'Status'){
 $states=@();$errors=@()
 foreach($f in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)){
  try{$j=Read-Journal $f.FullName;$states+=@{id=$j.id;state=$j.state;date=$j.date}}
  catch{$errors+=$f.Name+': '+$_.Exception.Message}
 }
 @{success=($errors.Count -eq 0);states=@($states);errors=@($errors)} | ConvertTo-Json -Depth 6 -Compress
 exit
}
if($Id -notmatch '^library-[a-z0-9-]+$'){throw 'ID invalid.'}
$rule=@($catalog | Where-Object {$_.id -ceq $Id})
if($rule.Count -ne 1){throw 'ID inexistent în catalog.'};$rule=$rule[0]
$file=Join-Path $root ($Id+'.json')
if($Action -eq 'Check'){
 if($rule.status -ne 'registry' -or -not @($rule.entries).Count){throw 'Setare Registry nepermisă.'}
 $current=@();$matching=$true
 foreach($e in $rule.entries){
  $v=Read-Value $e;$current+=$v
  $expected=@{path=$e.path;name=$e.name;exists=($e.exists -ne $false);kind=$e.kind;value=$e.value}
  if(-not (Same-Value $v $expected)){$matching=$false}
 }
 @{success=$true;matching=$matching;current=@($current);message='Citire reală, fără modificări.'} | ConvertTo-Json -Depth 24 -Compress;exit
}
if($Action -eq 'Apply'){
 if(-not [string]::IsNullOrWhiteSpace([string]$rule.applyBlocked)){throw ([string]$rule.applyBlocked)}
 if($rule.status -ne 'registry' -or -not @($rule.entries).Count){throw 'Această setare nu este activată în motor.'}
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=New-Object Security.Principal.WindowsPrincipal($identity)
 if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Pornește CARPATIA ca administrator.'}
 if([Environment]::OSVersion.Version.Build -lt 10240){throw 'Necesită Windows 10/11.'}
 foreach($f in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)){
  $other=Read-Journal $f.FullName
  if($other.state -eq 'restored'){continue}
  if($other.id -ceq $Id){throw 'Există deja un backup activ pentru această setare. Restaurează înainte de reaplicare.'}
  foreach($e in $rule.entries){foreach($v in $other.values){if($e.path -ieq $v.path -and $e.name -ieq $v.name){throw ('Conflict cu backupul activ '+$other.id+'. Restaurează înainte de aplicare.')}}}
 }
 $nativeRoot=Join-Path $DataDir 'tweak-native-backups'
 if(Test-Path -LiteralPath $nativeRoot){foreach($f in @(Get-ChildItem -LiteralPath $nativeRoot -Filter '*.json' -File)){
  $n=Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
  if($n.version -ne 1){throw 'Jurnal nativ invalid.'}
  if($n.state -notin @('prepared','failed','applied')){continue}
  $o=$n.operation
  if(Test-NetworkRegistryConflict $rule $o){throw 'Restaurează mai întâi setarea nativă de rețea.'}
  foreach($e in $rule.entries){
   if($o.type -eq 'service'){foreach($svc in $o.services){if($e.path -ieq ('HKLM\SYSTEM\CurrentControlSet\Services\'+$svc.name)){throw 'Conflict cu backupul nativ al serviciului.'}}}
   if($o.type -eq 'hibernation' -and $e.path -ieq 'HKLM\SYSTEM\CurrentControlSet\Control\Power'){throw 'Conflict cu backupul hibernării.'}
  }
 }}
if(Test-Path -LiteralPath $file){
 $history=Join-Path $DataDir 'backup-history';New-Item -ItemType Directory -Path $history -Force | Out-Null
 Copy-Item -LiteralPath $file -Destination (Join-Path $history ($Id+'-'+[guid]::NewGuid().ToString()+'.json')) -ErrorAction Stop
}
 $values=@();foreach($e in $rule.entries){$original=Read-Value $e;Assert-RegistryCapture $original;$values+=$original}
 $already=$true
 foreach($e in $rule.entries){$expected=@{path=$e.path;name=$e.name;exists=($e.exists -ne $false);kind=$e.kind;value=$e.value};if(-not (Same-Value (Read-Value $e) $expected)){$already=$false}}
 if($already){@{success=$true;already=$true;verified=$true;message='Valorile cerute există deja. Nicio scriere și niciun backup nou.'} | ConvertTo-Json -Compress;exit}
 $journal=@{version=1;id=$Id;state='prepared';date=(Get-Date).ToString('o');values=@($values)}
 Save-Journal $file $journal
 try{
  foreach($e in $rule.entries){
   $expected=@{path=$e.path;name=$e.name;exists=($e.exists -ne $false);kind=$e.kind;value=$e.value}
   Set-Value $expected
   if(-not (Same-Value (Read-Value $e) $expected)){throw 'Verificarea valorii scrise a eșuat.'}
  }
  $journal.state='applied';Save-Journal $file $journal
  @{success=$true;verified=$true;id=$Id;message='Valorile Registry au fost scrise și recitite. Aceasta nu confirmă un câștig de performanță.'} | ConvertTo-Json -Compress
 }catch{
  $problem=$_.Exception.Message;$journal.state='failed';Save-Journal $file $journal
  @{success=$false;id=$Id;message=$problem;backupAvailable=$true} | ConvertTo-Json -Compress
 }
 exit
}
$restorePrincipal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if(-not $restorePrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Restaurarea necesită Administrator. Backupul nu a fost modificat.'}
if(-not (Test-Path -LiteralPath $file)){throw 'Backupul original lipsește. Nu se folosesc valori implicite inventate.'}
$j=Read-Journal $file
if($j.id -cne $Id){throw 'ID-ul backupului nu corespunde.'}
if($j.state -eq 'restored'){throw 'Acest backup a fost deja restaurat.'}
# Only original targets from this exact trusted rule may be restored.
if(@($j.values).Count -ne @($rule.entries).Count){throw 'Backupul nu corespunde definiției setării.'}
$seen=@{}
foreach($v in $j.values){
 $key=([string]$v.path+'|'+[string]$v.name).ToLowerInvariant()
 if($seen.ContainsKey($key) -or $v.exists -isnot [bool] -or -not @($rule.entries | Where-Object {$_.path -ieq $v.path -and $_.name -ieq $v.name}).Count){throw 'Țintă duplicată, absentă sau nepermisă în backup.'}
 if($v.exists -and ($v.kind -notin @('String','ExpandString','DWord','QWord','Binary','MultiString') -or $null -eq $v.value)){throw 'Original Registry incomplet.'}
 Assert-RegistryValue $v
 $seen[$key]=$true
}
foreach($v in $j.values){
 $e=@($rule.entries | Where-Object {$_.path -ieq $v.path -and $_.name -ieq $v.name})[0]
 $current=Read-Value $v;$desired=@{path=$e.path;name=$e.name;exists=($e.exists -ne $false);kind=$e.kind;value=$e.value}
 if(-not (Same-Value $current $v) -and -not (Same-Value $current $desired)){throw ('Modificare externă detectată: '+$v.path+' / '+$v.name+'. Restaurarea automată a fost oprită; originalul este păstrat.')}
}
$errors=@();$rows=@($j.values);[array]::Reverse($rows)
foreach($v in $rows){try{Set-Value $v;if(-not (Same-Value (Read-Value $v) $v)){throw 'Verificarea restaurării a eșuat.'}}catch{$errors+=$_.Exception.Message}}
if($errors.Count -eq 0){$j.state='restored';Save-Journal $file $j}
@{success=($errors.Count -eq 0);id=$Id;errors=@($errors);message='Restaurarea a fost verificată prin recitire; vezi eventualele erori.'} | ConvertTo-Json -Depth 6 -Compress
