@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  node tools\test-recovery-windows.js --help
  echo.
  echo Read VALIDARE_WINDOWS.md before running this test in a disposable VM.
  pause
  exit /b 2
)
node tools\test-recovery-windows.js %*
exit /b %errorlevel%
