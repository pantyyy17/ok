# Eliminarea modificarilor de aspect Windows

Regulile visual/desktop si regulile care modifica prezenta elementelor Windows sunt retrase din profilurile Smart/MAX si din catalogul aplicabil. Motorul PowerShell refuza aplicarea lor, inclusiv prin apel direct. Definitiile sunt pastrate numai pentru compatibilitate si restaurare; backupurile existente nu sunt sterse.

Aceasta arhiva contine surse, nu un installer Windows recompilat. Nu modifica automat PC-ul. Pentru revenirea modificarilor deja aplicate foloseste Backup & Restore cu backupul original. Restaurarea ULTRA revine asupra intregului profil salvat, inclusiv modificarilor care nu sunt vizuale. Nu sterge backupul daca restaurarea raporteaza eroare.

Redesignul dupa capturile TweakShift nu este inclus in acest patch. Functionalitatile sale interne nu se pot determina din captura dashboardului.
