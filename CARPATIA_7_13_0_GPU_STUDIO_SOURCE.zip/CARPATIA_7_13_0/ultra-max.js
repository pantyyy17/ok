"use strict";
// Standalone, deterministic selection of *supported* settings from the local HKCU catalog.
// Windows boot, kernel, security, driver, and service experiments are never in this allowlist.
const WINDOWS_11_ONLY = new Set(['widgets','taskbar_left','taskbar_endtask','ctt_end_task','snap_flyout']);
function maxPlan(snapshot,catalog){
 const build=Number(snapshot?.hardware?.osBuild)||0;
 if(build<10240)return {suggestions:[],selectableCount:0,mediumCount:0,excludedCount:catalog.length,reason:'Windows 10/11 nu a fost detectat. Nu aplica setari.'};
 if(!snapshot?.registry || !Array.isArray(snapshot.registry.matchingIds)){
  return {suggestions:[],selectableCount:0,mediumCount:0,excludedCount:catalog.length,reason:'Citirea Registry a esuat; MAX este blocat pentru siguranta.'};
 }
 const active=new Set(snapshot.registry.matchingIds);
 const targets=new Map();
 const suggestions=[];
 for(const t of catalog){
  if(t.restoreOnly)continue;
  const entries=Array.isArray(t.entries)?t.entries:[];
  let decision='max';let reason='Toate setarile compatibile din catalog, cu backup inainte de aplicare.';
  if(WINDOWS_11_ONLY.has(t.id)&&build<22000){decision='incompatible';reason='Optiune asociata Windows 11; omisa pe Windows 10.';}
  else if(!entries.length){decision='incompatible';reason='Regula fara valori de aplicat.';}
  else if(active.has(t.id)){decision='already';reason='Valoarea este deja aplicata; nu o rescriem.';}
  else{
   let collision=false;
   for(const e of entries){
    const key=String(e.path).toLowerCase()+'|'+String(e.name).toLowerCase();
    if(targets.has(key)){collision=true;break;}
   }
   if(collision){decision='duplicate';reason='Aceeasi valoare Registry este gestionata de alta regula; evitam scrierea dubla.';}
   else for(const e of entries)targets.set(String(e.path).toLowerCase()+'|'+String(e.name).toLowerCase(),t.id);
  }
  const risk=t.risk==='medium'?'medium':'low';
  suggestions.push({id:t.id,title:t.title,risk,category:t.category,decision,
   reason,benefit:t.desc||'Efectul real trebuie masurat pe PC.',focus:t.category,
   checked:decision==='max'});
 }
 return {
  suggestions,
  selectableCount:suggestions.filter(x=>x.decision==='max').length,
  mediumCount:suggestions.filter(x=>x.decision==='max'&&x.risk==='medium').length,
  excludedCount:suggestions.filter(x=>x.decision==='incompatible'||x.decision==='duplicate').length,
  reason:'Este un profil complet de configurare Windows, fara modificari de aspect Windows si fara FPS garantat.'
 };
}
module.exports={maxPlan,WINDOWS_11_ONLY};
