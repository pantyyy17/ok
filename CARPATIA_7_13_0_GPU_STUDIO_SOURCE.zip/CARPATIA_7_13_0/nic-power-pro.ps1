﻿param([ValidateSet('Status','Apply','Restore')][string]$Action='Status',[string]$Adapter='')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups';$file=Join-Path $dir 'nic-power-pro.json'
function Is-Admin {$id=[Security.Principal.WindowsIdentity]::GetCurrent();$principal=[Security.Principal.WindowsPrincipal]$id;return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Power-Object([string]$name){
 $items=@(Get-NetAdapterPowerManagement -Name ([WildcardPattern]::Escape($name)) -IncludeHidden -ErrorAction Stop)
 if($items.Count -ne 1 -or $items[0].Name -ne $name){throw 'Proprietatile de alimentare nu corespund adaptorului ales.'}
 return $items[0]
}
function Adapter-Values([string]$name,[bool]$requireUp=$true,[string]$guid=''){
 if($guid){
  $originalGuid=[guid]::Empty
  if(-not [guid]::TryParse($guid,[ref]$originalGuid)){throw 'Identitate adaptor invalida in backup.'}
  $nic=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop | Where-Object {([guid]$_.InterfaceGuid) -eq $originalGuid})
 }else{$nic=@(Get-NetAdapter -ErrorAction Stop | Where-Object {$_.Name -eq $name})}
 if(@($nic).Count -ne 1){throw 'Alege un singur adaptor.'}
 $nic=@($nic)[0]
 if($requireUp -and $nic.Status -ne 'Up'){throw 'Alege un adaptor activ.'}
 $pm=Power-Object $nic.Name
 return @{name=[string]$nic.Name;guid=[string]$nic.InterfaceGuid;selectiveSuspend=[string]$pm.SelectiveSuspend;deviceSleepOnDisconnect=[string]$pm.DeviceSleepOnDisconnect}
}
if($Action -eq 'Status'){
 $rows=@(Get-NetAdapter -ErrorAction Stop | Where-Object {$_.Status -eq 'Up' -and (-not $Adapter -or $_.Name -eq $Adapter)} | ForEach-Object {
  $adapterRow=$_;try{Adapter-Values $adapterRow.Name}catch{@{name=[string]$adapterRow.Name;guid=[string]$adapterRow.InterfaceGuid;error=$_.Exception.Message}}
 })
 $backup=$null;if(Test-Path -LiteralPath $file){$b=Get-Content -Raw -LiteralPath $file|ConvertFrom-Json;$backup=@{adapter=$b.name;guid=$b.guid}}
 @{success=$true;admin=(Is-Admin);adapters=$rows;backup=$backup}|ConvertTo-Json -Depth 5 -Compress;exit 0
}
if(!(Is-Admin)){throw 'Necesită administrator.'}
if($Action -eq 'Apply'){
 if(Test-Path -LiteralPath $file){throw 'Backup NIC Power PRO existent. Restaureaza-l intai.'}
 $s=Adapter-Values $Adapter
 $supported=@('selectiveSuspend','deviceSleepOnDisconnect')|Where-Object {$s[$_] -in @('Enabled','Disabled')}
 if(!$supported.Count){throw 'Driverul nu ofera proprietatile necesare.'}
 $change=@($supported|Where-Object {$s[$_] -eq 'Enabled'})
 if(!$change.Count){@{success=$true;changed=$false;message='Setarile suportate sunt deja dezactivate.'}|ConvertTo-Json -Compress;exit 0}
 New-Item -ItemType Directory -Path $dir -Force|Out-Null
 $s|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $file -Encoding UTF8
 try{
  $args=@{InputObject=(Power-Object $s.name);NoRestart=$true;ErrorAction='Stop'}
  if($change -contains 'selectiveSuspend'){$args.SelectiveSuspend='Disabled'}
  if($change -contains 'deviceSleepOnDisconnect'){$args.DeviceSleepOnDisconnect='Disabled'}
  Set-NetAdapterPowerManagement @args|Out-Null
  $check=Adapter-Values $s.name
  foreach($field in $change){if($check[$field] -ne 'Disabled'){throw "Verificare esuata pentru $field"}}
 }catch{
  $why=$_.Exception.Message
  throw "Configurarea a esuat: $why. Backupul a ramas disponibil; foloseste RESTAUREAZA NIC POWER."
 }
 @{success=$true;changed=$true;message='Selective Suspend si/sau Device Sleep au fost dezactivate unde erau disponibile. Nu este identic cu fiecare checkbox din Device Manager.';adapter=$s.name;backup=$true}|ConvertTo-Json -Compress;exit 0
}
if(!(Test-Path -LiteralPath $file)){throw 'Backup NIC Power PRO inexistent.'}
$b=Get-Content -Raw -LiteralPath $file|ConvertFrom-Json
$now=Adapter-Values '' $false ([string]$b.guid)
$supported=@('selectiveSuspend','deviceSleepOnDisconnect')|Where-Object {$b.$_ -in @('Enabled','Disabled')}
if(@($supported).Count -eq 0){throw 'Backup NIC Power incomplet. Nu se modifică adaptorul.'}
foreach($field in $supported){if($now[$field] -notin @('Disabled',[string]$b.$field)){throw ('Proprietate NIC schimbată din exterior: '+$field+'. Backup păstrat.')}}
$args=@{InputObject=(Power-Object $now.name);NoRestart=$true;ErrorAction='Stop'}
if($b.selectiveSuspend -in @('Enabled','Disabled')){$args.SelectiveSuspend=[string]$b.selectiveSuspend}
if($b.deviceSleepOnDisconnect -in @('Enabled','Disabled')){$args.DeviceSleepOnDisconnect=[string]$b.deviceSleepOnDisconnect}
Set-NetAdapterPowerManagement @args|Out-Null
$check=Adapter-Values $now.name $false
foreach($field in @('selectiveSuspend','deviceSleepOnDisconnect')){if($b.$field -in @('Enabled','Disabled') -and $check[$field] -ne $b.$field){throw "Restaurarea $field nu a fost confirmata. Backup pastrat."}}
Move-Item -LiteralPath $file -Destination (Join-Path $dir ('nic-power-restored-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')) -Force
@{success=$true;message='Proprietatile de economisire suportate au fost restaurate si verificate.'}|ConvertTo-Json -Compress
