# Read the saved AC index, including hidden settings, without parsing localized text.
function Read-PowerACIndex([guid]$Scheme,[guid]$Subgroup,[guid]$Setting){
 if(-not ('Carpatia.PowerReadApi' -as [type])){
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace Carpatia {
 public static class PowerReadApi {
  [DllImport("powrprof.dll", ExactSpelling = true)]
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
  public static extern uint PowerReadACValueIndex(
   IntPtr root, ref Guid scheme, ref Guid subgroup, ref Guid setting, out uint value);
 }
}
'@ -ErrorAction Stop
 }
 [uint32]$value=0
 [uint32]$code=[Carpatia.PowerReadApi]::PowerReadACValueIndex([IntPtr]::Zero,[ref]$Scheme,[ref]$Subgroup,[ref]$Setting,[ref]$value)
 if($code -ne 0){
  $detail=(New-Object System.ComponentModel.Win32Exception([int]$code)).Message
  throw ('Citire alimentare AC esuata: Windows '+$code+' ('+$detail+'). Setare '+$Setting+', plan '+$Scheme+'. Originalul nu poate fi confirmat; nu se aplica aceasta setare.')
 }
 return [long]$value
}
