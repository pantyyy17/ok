'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
// Local diagnostics only. Never record license codes or raw command arguments.
function createOperationLog({directory,run,now=Date.now,maxBytes=2*1024*1024}){
 function append(record){
  try{
   const dir=directory();fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,'operations.jsonl');
   if(fs.existsSync(file)&&fs.statSync(file).size>=maxBytes){
    const old=file+'.previous';if(fs.existsSync(old))fs.unlinkSync(old);fs.renameSync(file,old);
   }
   fs.appendFileSync(file,JSON.stringify({...record,time:new Date(now()).toISOString()})+'\n','utf8');
  }catch(error){console.error('CARPATIA diagnostic log unavailable:',error.message)}
 }
 return async function(args,timeout){
  const id=crypto.randomUUID(),start=now(),i=args.indexOf('-File'),a=args.indexOf('-Action');
  const script=i>=0?path.win32.basename(args[i+1]):'unknown',action=a>=0?args[a+1]:'Inspect';
  append({id,phase:'start',script,action});
  try{
   const result=await run(args,timeout);
   append({id,phase:'finish',script,action,durationMs:now()-start,success:result?.success!==false,
    ...(result?.success===false?{error:JSON.stringify({message:result.message,errors:result.errors}).slice(0,12000)}:{})});
   return result;
  }catch(error){
   append({id,phase:'error',script,action,durationMs:now()-start,error:String(error.message||error).slice(0,12000)});
   throw Error(`${script} / ${action}: ${error.message||error} [Diagnostic ${id}]`,{cause:error});
  }
 };
}
module.exports={createOperationLog};
