'use strict';
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaSecurity=Object.freeze(factory());
})(typeof window==='object'?window:globalThis,function(){
 function mount({api,document:doc=globalThis.document,requireNative=()=>false,task=(_,fn)=>fn(),confirmDialog=async()=>false,showToast=()=>{}}){
  const $=id=>doc.getElementById(id),panel=$('securitySettings');
  let info=null,generation=0,working=false,loading=false,destroyed=false;
  const write=(id,value)=>{$(id).textContent=String(value??'—')};
  const available=state=>state?.success===true&&state.available===true;
  const canDisable=state=>available(state)&&state.realTimeEnabled===true&&state.tamperProtected===false&&state.passive===false&&state.backup===false;
  const errorMessage=error=>String(error?.message||error||'Operația nu a fost confirmată.').replace(/^Error invoking remote method '[^']+':\s*Error:\s*/,'');
  function message(value,tone='neutral'){write('securityMessage',value);$('securityMessage').dataset.tone=tone;$('securityMessage').setAttribute('role',tone==='error'?'alert':'status')}
  function reason(state){
   if(!api)return 'Starea și controalele Microsoft Defender sunt disponibile în aplicația Windows.';
   if(!available(state))return state?.reason||'Verifică starea actuală înainte de a modifica protecția.';
   if(state.backup===true)return 'Există un original CARPATIA pentru această setare. Îl poți restaura mai jos; starea protecției este verificată separat.';
   if(state.passive===true)return 'Microsoft Defender este într-un mod pasiv sau administrat de alt antivirus. Verifică furnizorul activ în Securitate Windows.';
   if(state.realTimeEnabled===false)return 'Protecția în timp real este oprită. Deschide Securitate Windows pentru activare; CARPATIA nu inventează un original dacă nu există backup.';
   if(state.tamperProtected===true)return 'Tamper Protection protejează aceste setări. Folosește Securitate Windows; CARPATIA nu ocolește această protecție.';
   if(state.tamperProtected!==false||state.passive!==false||state.realTimeEnabled!==true||state.backup!==false)return 'Starea necesară modificării nu este confirmată complet. Folosește Securitate Windows.';
   return 'Protecția în timp real este activă. Oprirea ei reduce protecția împotriva amenințărilor și nu garantează performanță mai mare.';
  }
  function controls(){
   const locked=working||loading;
   panel.setAttribute('aria-busy',locked?'true':'false');
   $('securityRefresh').disabled=locked||typeof api?.securityStatus!=='function';
   $('securityDisable').disabled=locked||!canDisable(info)||typeof api?.tweakLibraryApply!=='function';
   $('securityRestore').disabled=locked||info?.backup!==true||typeof api?.tweakLibraryRestore!=='function';
   $('securityOpen').disabled=working||typeof api?.openSettings!=='function';
  }
  function render(){
   const known=available(info),realtime=known?info.realTimeEnabled:null,tamper=known?info.tamperProtected:null;
   const badge=realtime===true?'PROTECȚIE ACTIVĂ':realtime===false?'PROTECȚIE OPRITĂ':'STARE NEVERIFICATĂ';
   write('securityBadge',badge);$('securityBadge').dataset.tone=realtime===true?'success':realtime===false?'warning':'neutral';
   write('securityRealtime',realtime===true?'Activă':realtime===false?'Oprită':'Necunoscută');
   write('securityTamper',tamper===true?'Activă':tamper===false?'Oprită':'Necunoscută');
   write('securityMode',known?(info.passive===true?'Pasiv / alt furnizor':info.passive===false?'Microsoft Defender':'Necunoscut'):'Necunoscut');
   write('securityOriginal',info?.backup===true?'Original disponibil':info?.backup===false?'Niciun original CARPATIA':'Neverificat');
   message(reason(info),!known&&info?.reason?'error':realtime===false?'warning':'neutral');controls();
  }
  async function load({internal=false}={}){
   if(destroyed||working&&!internal)return info;
   const request=++generation;loading=true;controls();message('Verific starea reală a Microsoft Defender…');
   try{
    const next=typeof api?.securityStatus==='function'?await api.securityStatus():{success:false,available:false,reason:reason(null)};
    if(!destroyed&&request===generation){info=next;render()}
    return next;
   }catch(error){
    const next={success:false,available:false,backup:info?.backup,reason:'Starea protecției nu a putut fi verificată. '+errorMessage(error)};
    if(!destroyed&&request===generation){info=next;render()}
    return next;
   }finally{if(!destroyed&&request===generation){loading=false;controls()}}
  }
  async function change(restore=false){
   if(destroyed||working||loading||!api||!requireNative(restore))return;
   if(restore?info?.backup!==true:!canDisable(info))return;
   working=true;++generation;controls();
   try{
    return await task(restore?'Restaurare protecție Windows':'Microsoft Defender',async()=>{
     const confirmed=await confirmDialog(restore?'Restaurezi setarea originală Defender?':'Oprești protecția în timp real?',restore?'Se restaurează preferința salvată de CARPATIA. Starea reală a protecției va fi recitită după operație.':'Microsoft Defender nu va mai verifica în timp real amenințările în modul obișnuit.',restore?'Originalul rămâne păstrat dacă restaurarea nu poate fi confirmată.':'Această opțiune este separată de profilurile CPU/GPU/Internet și nu este aplicată automat.',restore?'Windows poate gestiona protecția și prin politici sau alt antivirus.':'Protecția calculatorului va fi redusă. Windows poate reactiva protecția automat. Oprirea nu garantează câștiguri de performanță.',restore?'RESTAUREAZĂ ORIGINALUL':'OPREȘTE PROTECȚIA');
     if(!confirmed)return;
     const fresh=await load({internal:true});
     if(destroyed)return;
     if(restore?fresh?.backup!==true:!canDisable(fresh)){message('Starea protecției s-a schimbat. Verifică detaliile și confirmă din nou.','error');return}
     let failure;
     try{
      const result=restore?await api.tweakLibraryRestore('library-cpu-022'):await api.tweakLibraryApply('library-cpu-022',true,'');
      if(result?.success!==true)throw Error(result?.message||'Windows nu a confirmat operația.');
     }catch(error){failure=error}
     await load({internal:true});
     if(destroyed)return;
     if(failure){message(errorMessage(failure),'error');showToast(errorMessage(failure));return}
     if(!restore&&info?.realTimeEnabled!==false){message('Windows nu confirmă oprirea protecției. Consultă starea actuală și Securitate Windows.','error');return}
     message(reason(info),info?.realTimeEnabled===false?'warning':'neutral');showToast('Operația s-a încheiat. Starea Microsoft Defender a fost recitită.');
    });
   }catch(error){if(!destroyed){message(errorMessage(error),'error');showToast(errorMessage(error))}}
   finally{if(!destroyed){working=false;loading=false;controls()}}
  }
  async function open(){
   if(destroyed||working||!api||!requireNative(true))return;
   try{await api.openSettings('security')}catch(error){if(!destroyed){message(errorMessage(error),'error');showToast(errorMessage(error))}}
  }
  $('securityRefresh').onclick=()=>load();$('securityDisable').onclick=()=>change(false);$('securityRestore').onclick=()=>change(true);$('securityOpen').onclick=open;
  function destroy(){destroyed=true;++generation;for(const id of ['securityRefresh','securityDisable','securityRestore','securityOpen'])$(id).onclick=null}
  render();return {load,destroy,getState:()=>info?{...info}:null};
 }
 return {mount};
});
