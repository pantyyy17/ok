﻿param(
 [ValidateSet('Scan','Remove')][string]$Action='Scan',
 [string]$Ids=''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
# Rule of least privilege: enumerate/remove AppX packages for the CURRENT user only.
# Never enumerate provisioned OS packages for deletion; no -AllUsers, wildcards, or core services.
$catalogPath = Join-Path $PSScriptRoot 'debloat-catalog.json'
if (-not (Test-Path -LiteralPath $catalogPath)) { throw 'Lipsește catalogul Debloat. Reinstalează versiunea completă CARPATIA.' }
try {
 $decoded = ConvertFrom-Json -InputObject (Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8) -ErrorAction Stop
 $catalog = @()
 foreach ($candidate in $decoded) {
  if ($null -eq $candidate -or $candidate -is [System.Array] -or
      $candidate.id -isnot [string] -or $candidate.name -isnot [string]) { throw 'Catalog Debloat invalid sau imbricat.' }
  $catalog += $candidate
 }
} catch { throw ('Catalogul Debloat nu poate fi citit: ' + $_.Exception.Message) }
if ($catalog.Count -lt 30 -or @($catalog | Select-Object -ExpandProperty id -Unique).Count -ne $catalog.Count) {
 throw 'Catalogul Debloat nu este complet ori conține ID-uri duplicate.'
}
$installed = @(Get-AppxPackage -ErrorAction Stop)
# Keep a physical array, even when there is a single returned item.
$installed = @($installed | Where-Object { $_ -and $_.Name -and $_.PackageFullName })

if ($Action -eq 'Scan') {
 $apps = New-Object System.Collections.Generic.List[object]
 foreach ($item in $catalog) {
  $matches = @($installed | Where-Object { $_.Name -ieq [string]$item.name -and $_.NonRemovable -ne $true })
  if ($matches.Count -gt 0) {
   [void]$apps.Add(@{ id=[string]$item.id; label=[string]$item.label; recommended=[bool]$item.recommended; count=$matches.Count; name=[string]$item.name })
  }
 }
 # Read-only inventory of traditional desktop uninstall registrations, for diagnosis only.
 $classicCount = 0
 try {
  $uninstallRoots = @(
   'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
   'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
   'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
  )
  $classic = @(Get-ItemProperty -Path $uninstallRoots -ErrorAction SilentlyContinue |
   Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.DisplayName) } |
   Select-Object -ExpandProperty DisplayName -Unique)
  $classicCount = $classic.Count
 } catch { $classicCount = -1 }
 # Other installed removable AppX packages are displayed read-only, not offered for blind removal.
 $matchedNames = @($catalog | ForEach-Object { [string]$_.name })
 $others = @($installed | Where-Object { $_.NonRemovable -ne $true -and $matchedNames -notcontains [string]$_.Name -and $_.Name -notmatch '^(Microsoft\.Windows\.|Microsoft\.VCLibs|Microsoft\.NET\.|Microsoft\.UI\.|Microsoft\.Services\.|Microsoft\.DesktopAppInstaller|Microsoft\.StorePurchaseApp|Microsoft\.WindowsStore|Windows\.|MicrosoftWindows\.)' } | Sort-Object -Property Name -Unique | Select-Object -First 60 | ForEach-Object { [string]$_.Name })
 $result = @{
  success=$true
  apps=@($apps.ToArray())
  installedAppxCount=$installed.Count
  otherAppxNames=@($others)
  catalogSize=$catalog.Count
  classicAppsCount=$classicCount
  scanScope='Get-AppxPackage (utilizatorul curent)'
  note='Lista de eliminare cuprinde doar aplicații AppX opționale din catalogul verificat. Programele desktop și aplicațiile Windows esențiale nu sunt eliminate aici.'
 }
 $result | ConvertTo-Json -Compress -Depth 6
 exit
}

$selected = @($Ids.Split(',') | Where-Object { $_ -ne '' })
if ($selected.Count -eq 0 -or $selected.Count -gt $catalog.Count -or
 @($selected | Select-Object -Unique).Count -ne $selected.Count) {
 throw 'Selecție Debloat invalidă.'
}
foreach ($id in $selected) {
 if (@($catalog | Where-Object { $_.id -ceq $id }).Count -ne 1) {
  throw 'Aplicație Debloat nepermisă.'
 }
}
$logdir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Debloat'
New-Item -ItemType Directory -Path $logdir -Force | Out-Null
$report=@{timestamp=(Get-Date).ToString('o');user=$env:USERNAME;results=@();note='Reinstalarea poate necesita Microsoft Store; datele locale ale aplicațiilor pot fi pierdute.'}
foreach ($id in $selected) {
 $item=$catalog | Where-Object { $_.id -ceq $id } | Select-Object -First 1
 # Exact package names and only the current user's removable packages.
 $packages=@($installed | Where-Object { $_.Name -ieq [string]$item.name -and $_.NonRemovable -ne $true })
 if ($packages.Count -eq 0) { $report.results+=@{id=$id;status='not_installed'};continue }
 foreach ($pkg in $packages) {
  try {
   Remove-AppxPackage -Package $pkg.PackageFullName -ErrorAction Stop
   $stillThere=@(Get-AppxPackage -Name $pkg.Name -ErrorAction Stop | Where-Object { $_.PackageFullName -eq $pkg.PackageFullName })
   if ($stillThere.Count -gt 0) { throw 'Windows raportează pachetul în continuare instalat după dezinstalare.' }
   $report.results+=@{id=$id;status='removed';package=$pkg.PackageFullName}
  } catch {
   $report.results+=@{id=$id;status='failed';error=$_.Exception.Message}
  }
 }
}
$filename='debloat-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.json'
$logfile=Join-Path $logdir $filename
$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $logfile -Encoding UTF8
$errors=@($report.results | Where-Object { $_.status -eq 'failed' })
@{success=($errors.Count -eq 0);results=@($report.results);log=$logfile;note=$report.note} | ConvertTo-Json -Compress -Depth 6
