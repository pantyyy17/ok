# CARPATIA 7.9.0 — audit și surse corectate

1 noiembrie 2026. Această livrare corectează arhiva `CARPATIA_7_9_0_RECOVERY_RO_SOURCE.zip`. Versiunea comercială nu a fost schimbată și nu a fost produs un installer. Arhiva originală este păstrată separat.

## Rezultatul verificării

| Verificare executată | Rezultat |
| --- | --- |
| `npm test`, Node.js 24.19.0, PowerShell activat | **252 teste trecute, 0 eșuate, 0 omise**; baza originală avea 204 teste |
| Motoare PowerShell cu operațiile Windows simulate | **59 aserțiuni** în cele două teste de integrare incluse în totalul de mai sus |
| Analiză sintactică PowerShell 7.5.4 | **30 scripturi**, fără erori de parsare |
| Chromium 154, DOM real, backend Electron simulat | **11 scenarii trecute**, fără erori JS/CSP/resurse |
| Instalare reproducibilă | `npm ci --ignore-scripts` reușit; 283 pachete; Electron 45.0.0 / electron-builder 26.18.0 rezolvate; builder pornește |
| Serviciu HTTP de licențiere | Pornire locală cu chei temporare de test în afara surselor; 404 pentru rută necunoscută, 401 pentru webhook nesemnat; fără emailuri sau licențe emise |
| Verificare distribuire | **Blocată corect**: lipsește `license-public.pem`, cheia publică originală a editorului |
| `npm audit`, inclusiv dependențele de dezvoltare | **15 moderate, 0 ridicate, 0 critice**; lanțul de build bazat pe `minimatch` |

Logurile sunt în `validation/`. Testele cu simulări verifică logica și recuperarea; nu confirmă că un driver, serviciu sau API Windows se comportă identic pe hardware real. Chromium verifică interfața reală, însă bridge-ul Electron și datele Windows sunt simulate. Binarul Electron nu a fost descărcat/executat prin instalarea cu `--ignore-scripts`.

## Probleme reparate

### Restaurare, copii manuale și concurență

- Restaurarea recitește starea Windows după confirmare și refuză suprascrierea unei schimbări externe detectate. Compararea obiectelor ignoră ordinea cheilor JSON, care poate varia între procese PowerShell.
- Selecțiile invalide sau ambigue nu mai pot deveni implicit „restaurează tot”. Interfața transmite explicit selecția goală pentru restaurarea totală.
- Jurnalele copiilor manuale își validează identitatea, țintele, indicii, originalele și duplicatele înainte de reluare. Un ID corupt nu poate redirecționa salvarea jurnalului în afara directorului tranzacției.
- Schimbarea manifestului după previzualizare invalidează confirmarea, chiar dacă fișierele capturilor sunt identice.
- Anularea începută se reia în aceeași direcție. O restaurare deja completă nu poate fi reaplicată prin „reluare”. Necesitatea restartului nu se pierde când o scriere este regăsită deja efectuată după întrerupere.
- Planurile de confirmare expirate sunt eliminate și numărul planurilor păstrate în memorie este limitat.
- Conflictele la restaurarea individuală includ și resursele native, nu doar Registry și servicii.
- Aplicarea parțială a unui profil Dashboard păstrează setările individuale preexistente reutilizate; rollback-ul nu mai restaurează originalele care aparțineau utilizatorului înainte de profil.
- Erorile notificărilor de progres nu mai întrerup recuperarea. Restaurarea Dashboard cere confirmare persistentă în jurnal.

### Motoare Windows

- Validare strictă pentru Registry înainte de scriere: tipuri, intervale DWORD, valori QWORD reprezentabile fără pierderi în JavaScript, octeți și liste de texte. Duplicate care ascundeau originale lipsă sunt respinse.
- Startup tratează numele Registry fără diferență între majuscule/minuscule și poate finaliza restaurarea deja scrisă înainte de o întrerupere.
- ULTRA, Power, GPU, Services, DNS, TCP și NIC verifică schimbările externe înainte de restaurare și păstrează originalele la refuz.
- TCP verifică revenirile înainte de ștergerea backupului; originalele DWORD unsigned pot fi restaurate fără overflow.
- DNS identifică adaptorul original prin GUID chiar dacă indexul s-a schimbat. Un Registry inaccesibil nu mai este confundat cu modul DNS automat. Backupurile DNS și Power sunt scrise atomic.
- Service/BCD/MTU pot recupera loturi parțial aplicate atunci când componentele încă au valori originale sau solicitate; o a treia valoare externă este refuzată.
- MTU folosește explicit `PersistentStore`, separat de `ActiveStore`.
- Restaurarea unui serviciu salvat „disabled, dar running” permite temporar pornirea și restabilește modul disabled chiar dacă pornirea eșuează.
- Curățarea TEMP recitește metadatele fișierelor și directoarelor înainte de ștergere; fișierele înlocuite/recent modificate sunt omise.
- Runnerul PowerShell refuză argumente cu NUL și răspunsuri JSON primitive; erorile fluxurilor de ieșire opresc arborele procesului înainte de eliberarea operației.

### Catalog și interfață

- Condițiile contradictorii Desktop/Laptop/Intel/AMD ale setărilor AC comune nu mai fac profilurile CPU imposibil de aplicat.
- DNS Google este disponibil și pentru Wi-Fi. Inventarul incomplet, Microsoft Basic Display Adapter și producătorii necunoscuți nu mai provoacă incompatibilități demonstrate false; GeForce/Radeon sunt recunoscute.
- Small Memory Dump scrie `CrashDumpEnabled=3`, nu valoarea pentru dump complet.
- HAGS verifică versiunea minimă Windows și pentru dezactivare.
- Prima navigare către restaurarea Internet păstrează categoria selectată. Răspunsurile asincrone vechi nu mai suprascriu starea mai nouă a catalogului sau Dashboardului.
- Interfața distinge reluarea anulării de reluarea restaurării, păstrează confirmarea/anularea și originalele accesibile fără o licență activă.
- Citirea senzorilor are limite de noduri/adâncime, separă hardware-ul CPU/GPU și refuză procente imposibile.
- Stilurile inline incompatibile cu CSP au fost eliminate; selectarea restaurării folosește stilul comun al interfeței.

Catalogul păstrează **236 intrări**: 146 Registry, 49 native, 15 de întreținere, 5 neimplementate și 21 excluse. Dintre cele 210 intrări cu motoare, următoarele **cinci au aplicarea blocată** deoarece ținteau rigid adaptorul display `0000`, care poate aparține altei plăci pe sisteme hibride:

- `library-gpu-001`, `library-gpu-002`, `library-gpu-011`, `library-gpu-047`, `library-gpu-055`.

Blocajul este verificat în UI, autorizarea JavaScript și scriptul PowerShell. Nu s-a inventat o mapare de driver și nu s-au redirecționat backupurile. Restaurarea originalelor existente rămâne disponibilă. Aceste opțiuni necesită implementare și validare separată cu identificarea reală a adaptorului.

### Licențiere, Shopify și build

- ID-urile Shopify de 64 biți se parsează fără pierdere de precizie; comenzile vecine nu mai pot fi confundate sau deduplicate incorect.
- Verificarea HMAC și semnăturilor Ed25519 respinge codificări necanonice, chei nepotrivite și fișiere de licență corupte/excesive.
- Directoarele de semnare sunt verificate și prin calea reală, inclusiv symlink/junction și strămoși existenți. Cheile private rămân în afara proiectului.
- Cheile neconcordante și istoricul de emitere corupt sunt raportate. Cheia publică originală nu a fost înlocuită; licențierea producției rămâne activă.
- Instrucțiunile SQL folosite pentru emitere sunt pregătite o singură dată în serviciu.
- `package-lock.json` fixează graful de dependențe; scripturile BAT cer Node 24+ și folosesc `npm ci`.
- Uneltele de test Windows verifică argumentele și păstrează rapoartele înainte/după restart.

## Ce rămâne de validat înainte de distribuire

1. Windows 10 și Windows 11, PowerShell 5.1, drepturi Administrator, cu checkpoint într-o VM: aplicare → recitire → restaurare → restart → reluare. Prioritare: DNS/NIC/MTU, servicii, BCD, stocare, GPU și copiile manuale. Procedurile existente și scripturile `TEST_*_WINDOWS.bat` rămân în proiect.
2. Hardware real, configurații desktop/laptop și mai multe GPU. Testele de aici nu măsoară FPS, latență, consum sau temperaturi. Nu există dovezi pentru un câștig universal de performanță sau o aplicație „fără greșeli”.
3. Adăugarea cheii publice originale și verificarea `npm run release:check`; apoi build și testarea installerului pe Windows. Nu este livrat un EXE verificat.
4. Urmărirea remedierii upstream pentru cele 15 alerte moderate din uneltele de build. npm propune o retrogradare majoră la electron-builder 20; nu a fost aplicată. Nu s-au forțat dependențe incompatibile și nu s-au dezactivat verificări de integritate/TLS.

## Reproducere

```text
npm ci
npm test
powershell -NoLogo -NoProfile -File tools/check-powershell.ps1
node tools/test-browser-smoke.js --output-dir <director-rezultate>
```

Ultima comandă necesită Chromium și un port local; folosește un backend simulat, fără modificări Windows. Pe Linux, testele PowerShell se activează prin `CARPATIA_PWSH=/cale/catre/pwsh` și directoare XDG scriibile când profilul este read-only. Runtime-ul folosit aici a fost descărcat din release-ul oficial PowerShell și verificat cu lista oficială SHA-256.

`validation/source-manifest.json` inventariază fișierele de cod și amprentele lor. Patch-ul din livrare permite compararea cu arhiva originală. Rapoartele vechi sunt păstrate ca istoric și nu descriu validările acestei livrări.
