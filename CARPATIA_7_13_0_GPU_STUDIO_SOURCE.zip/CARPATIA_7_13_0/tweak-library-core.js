'use strict';
const catalog=require('./tweak-library.json');
const ro=require('./catalog-ro.json');
const byId=new Map(catalog.map(x=>[x.id,x]));
const executable=new Set(['registry','native','maintenance']);
function publicCatalog(){return catalog.filter(row=>executable.has(row.status)).map(({entries,...row})=>({...row,...ro[row.id],targets:entries.map(e=>({...e}))}))}
function authorize(id,action,acknowledged){
 if(typeof id!=='string'||!byId.has(id))throw Error('ID de tweak nepermis.');
 if(!['Apply','Restore','Acknowledge'].includes(action))throw Error('Acțiune nepermisă.');
 const item=byId.get(id);
 if(action==='Apply'){
  if(item.applyBlocked)throw Error(item.applyBlocked);
  if(!executable.has(item.status))throw Error(item.reason||'Setare neimplementată.');
  if(acknowledged!==true)throw Error('Confirmă individual setarea și compatibilitatea înainte de aplicare.');
 }
 if(action==='Restore'&&item.status==='maintenance')throw Error('Această operație de întreținere nu are anulare automată.');
 if(action==='Acknowledge'&&item.status!=='maintenance')throw Error('Doar operațiile de întreținere întrerupte pot fi confirmate.');
 return item.id;
}
function getRule(id){if(!byId.has(id))throw Error('ID necunoscut');return {...byId.get(id),...ro[id]}}
function validateAdapter(value){
 if(value===undefined||value===null||value==='')return '';
 if(typeof value!=='string'||!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(value))throw Error('Adaptor invalid.');
 return value;
}
function engineFor(id){return getRule(id).status==='registry'?'tweak-library.ps1':'tweak-native.ps1'}
function isActiveState(state){return ['prepared','failed','applied'].includes(state)}
module.exports={publicCatalog,authorize,getRule,validateAdapter,engineFor,isActiveState};
