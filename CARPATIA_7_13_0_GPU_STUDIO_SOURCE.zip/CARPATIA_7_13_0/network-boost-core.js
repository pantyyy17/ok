'use strict';
// Strict, auditable plan builder. No network mutations in this module.
const PROVIDERS=new Set(['cloudflare','google','quad9','keep']);
const ADVANCED=['nicPower','tcp','interrupt','eee'];
const SCRIPT_STEPS=new Set(['dns','nicPower','tcp','interrupt','eee','flush']);
function normalizeAdapterGuid(value){
 if(typeof value!=='string')return null;
 const match=/^(?:\{([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\}|([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}))$/i.exec(value);
 return match?(match[1]||match[2]).toLowerCase():null;
}
function planNetwork(request,inventory){
 if(!request||typeof request!=='object'||Array.isArray(request))throw Error('Profilul de rețea este invalid.');
 const {adapter,provider,options}=request;
 if(typeof adapter!=='string'||!adapter.trim()||adapter.length>150||/[\r\n]/.test(adapter))throw Error('Alege adaptorul de rețea.');
 if(!PROVIDERS.has(provider))throw Error('Furnizor DNS necunoscut.');
 if(!options||typeof options!=='object'||Array.isArray(options)||ADVANCED.some(k=>typeof options[k]!=='boolean'))throw Error('Opțiuni de rețea invalide.');
 if(!inventory||!Array.isArray(inventory.adapters))throw Error('Inventarul plăcilor de rețea lipsește.');
 const adapterRow=inventory.adapters.find(a=>a.name===adapter);
 if(!adapterRow||!Array.isArray(adapterRow.ipv4)||adapterRow.ipv4.length===0)throw Error('Adaptorul ales nu are IPv4 valid sau nu mai este activ.');
 const actions=[];
 if(provider!=='keep')actions.push('dns');
 for(const [name,enabled] of Object.entries({nicPower:options.nicPower,tcp:options.tcp,interrupt:options.interrupt,eee:options.eee}))if(enabled)actions.push(name);
 actions.push('flush');
 const adapterGuid=normalizeAdapterGuid(adapterRow.guid);
 return {adapter,...(adapterGuid?{adapterGuid}:{}),provider,actions,advanced:actions.some(x=>ADVANCED.includes(x)),labels:actions.map(x=>({dns:'Schimbă DNS',nicPower:'Oprește economisirea energiei adaptorului',tcp:'TCPNoDelay + TcpAckFrequency (doar TCP)',interrupt:'Interrupt Moderation OFF',eee:'Energy Efficient Ethernet OFF',flush:'Curăță cache DNS'})[x])};
}
function validJournalSteps(steps){return Array.isArray(steps)&&steps.length<=6&&steps.every(x=>typeof x==='string'&&SCRIPT_STEPS.has(x))&&new Set(steps).size===steps.length;}
module.exports={planNetwork,validJournalSteps,normalizeAdapterGuid,ADVANCED,PROVIDERS};
