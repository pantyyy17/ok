@echo off
setlocal
cd /d "%~dp0"
title CARPATIA V7 PRO - verificare Windows (fara tweaks)
echo CARPATIA V7 PRO - DIAGNOSTIC FARA OPTIMIZARI
where node.exe >nul 2>&1
if errorlevel 1 (
  echo [EROARE] Node.js 24 sau mai nou lipseste.
  pause
  exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (echo [EROARE] Este necesar Node.js 24 sau mai nou. & pause & exit /b 1)
echo [1/5] Verific sintaxa JavaScript...
for %%F in (main.js preload.js ui.js licensing.js oneclick-engine.js) do (
  node --check "%%F"
  if errorlevel 1 goto :error
)
echo [2/5] Verific catalogul si suitele JS...
call npm test
if errorlevel 1 goto :error
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0tools\test-native-windows.ps1"
if errorlevel 1 goto :error
echo [3/5] Verific motorul PowerShell (doar Status, fara aplicare)...
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0engine.ps1" -Action Status
if errorlevel 1 goto :error
echo [4/5] Detectez componentele (citire)...
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0inspect.ps1"
if errorlevel 1 goto :error
echo [5/5] Verific statusul drepturilor (citire)...
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0permissions.ps1"
if errorlevel 1 goto :error
echo.
echo [OK] Verificarile de mai sus au trecut. Aplicarea/restaurarea NU au fost testate de acest script.
pause
exit /b 0
:error
echo.
echo [EROARE] Diagnostic intrerupt. Fotografiaza mesajul din aceasta fereastra.
pause
exit /b 1
