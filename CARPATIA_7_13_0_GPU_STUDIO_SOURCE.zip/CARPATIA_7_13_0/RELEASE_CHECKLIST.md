# CARPATIA V7 PRO — verificare obligatorie înainte de lansarea comercială

## Licențiere și distribuție
- [ ] Generează propriile chei Ed25519 pe un PC securizat, în afara proiectului; salvează separat copia de siguranță a cheii private.
- [ ] Configurează doar `license-public.pem` pentru installer.
- [ ] Generează cod valid, cod expirat și încearcă un cod alterat pe buildul **packaged**, nu doar în dezvoltare.
- [ ] Confirmă că sursele de editor (`tools/`, `LICENTA_MANAGER.bat`, fișiere private) **nu sunt în installer**.
- [ ] Testează instalarea, dezinstalarea, upgrade-ul și rularea după restart ca utilizator normal.
- [ ] Decide licențiere offline (fără limită de dispozitive) vs server de activări online. În acest build online NU e implementat.

## Windows 10/11 (teste native)
- [ ] Pornire UI în 100%, 125%, 150% scaling, navigare, fără erori în DevTools.
- [ ] Backup Registry cu UN tweak low risk, verificarea schimbării și restaurare inclusiv după restart.
- [ ] Power Plan — aplicare și restaurare, inclusiv cazul de backup existent.
- [ ] DNS Cloudflare/Quad9 — test conectivitate, restaurare exactă a configurației anterioare.
- [ ] TCP/NIC/Interrupt/Energy Efficient Ethernet — doar pe adaptoare compatibile, test separat, apoi restaurare.
- [ ] Debloat — scanarea AppX, eliminare doar după selecție, comunicarea efectelor și riscului de pierdere a datelor locale.
- [ ] TEMP — exclude fișierele recente și legăturile simbolice, verifică numărul de fișiere șterse.
- [ ] Startup — modificări HKCU Run și restaurare.
- [ ] GPU Windows preference — alegere `.exe`, aplicare și restaurare, fără overclock.
- [ ] Fără crash/freeze la eroare PowerShell, UAC anulat, internet indisponibil, backup lipsă/corupt.
- [ ] Test CPU/RAM utilizate la idle și în timpul scanării, pe Windows 10/11.
- [ ] Benchmarks din joc înainte/după, cu FPS mediu, 1% low și frametime; nu prezenta rezultate inventate.
- [ ] Review securitate, licențe materiale grafice și verificarea drepturilor de utilizare comercială.

**Status 23 octombrie 2026:** codul pur Node testat, dar Windows nativ și installer `.exe` încă nevalidate. Release Candidate, nu versiune certificată pentru vânzare.
