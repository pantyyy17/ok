'use strict';
// Event-driven: no timers, frame loop, particles, canvas or background polling.
(function(root){
 function createMotionController({document,Observer}){
  const circles=Array.from(document.querySelectorAll('.reactor'));
  const visible=new Set(Observer?[]:circles);
  let destroyed=false;
  const sync=()=>{
   if(destroyed)return;
   for(const circle of circles){
    const panel=circle.closest('.view');
    const paused=document.hidden||!visible.has(circle)||(panel&&!panel.classList.contains('active'));
    circle.classList.toggle('motion-paused',Boolean(paused));
   }
  };
  const observer=Observer?new Observer(entries=>{
   for(const entry of entries)entry.isIntersecting?visible.add(entry.target):visible.delete(entry.target);
   sync();
  },{threshold:.08}):null;
  circles.forEach(circle=>observer?.observe(circle));
  document.addEventListener('visibilitychange',sync);sync();
  return {sync,destroy(){destroyed=true;observer?.disconnect();document.removeEventListener('visibilitychange',sync);visible.clear();circles.forEach(c=>c.classList.add('motion-paused'))}};
 }
 if(typeof module==='object'&&module.exports)module.exports={createMotionController};
 else root.CarpatiaMotion=Object.freeze({createMotionController});
})(typeof window==='object'?window:globalThis);
