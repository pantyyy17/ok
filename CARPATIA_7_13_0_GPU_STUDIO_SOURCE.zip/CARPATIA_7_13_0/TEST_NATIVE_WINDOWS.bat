@echo off
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\test-native-windows.ps1"
if errorlevel 1 (echo TEST FAILED) else (echo TEST PASSED)
pause
