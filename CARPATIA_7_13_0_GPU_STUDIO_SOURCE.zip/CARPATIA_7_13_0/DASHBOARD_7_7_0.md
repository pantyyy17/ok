# CARPATIA 7.7.0 — Dashboard CPU / GPU / Internet

Cele trei butoane folosesc aceleași motoare tipizate și backupuri ca pagina Tweaks. Fiecare nivel este cumulativ; o singură confirmare afișează toți pașii înainte de aplicare.

| Nivel | CPU | GPU | Internet |
|---|---|---|---|
| Low | Win32PrioritySeparation: 38 | Windows Game Mode activ | DNS Google 8.8.8.8 / 8.8.4.4 pe adaptorul ales |
| Medium | Low + MMCSS Games: Priority 6, Scheduling High, SFIO High | Low + Game DVR/captură în fundal oprite | Low + RSS global activ |
| High | Medium + planul High Performance existent | Medium + preferințele GameDVR pentru fullscreen | Medium + TCP Fast Open activ |
| Ultra | High + PowerThrottlingOff | High + solicitare HAGS | High + TCP Initial RTO 2000 ms |

## Utilizare

Alege nivelul din selectorul de sub cerc. Pentru Internet selectează explicit adaptorul; DNS Google este afișat în interfață înainte de confirmare. Apasă cercul pentru analiză. Motorul verifică Windows, administratorul, GPU-ul pentru profilul GPU, citirea stărilor originale și backupurile existente. Planul High Performance trebuie să existe; aplicația nu creează un plan ascuns dacă lipsește. Verificările se repetă la confirmare.

Profilul activ este afișat sub cerc. Pentru un alt nivel folosește mai întâi Restaurare, apoi selectează și aplică noul nivel. CPU, GPU și Internet pot avea profiluri active simultan deoarece țintele lor nu se suprapun. Profilurile nu se amestecă automat cu tweak-uri individuale sau sesiunile vechi; backupurile conflictuale trebuie restaurate.

Restaurarea este disponibilă sub fiecare cerc și în Backup & Restore, inclusiv fără licență activă. Debloat rămâne accesibil din meniul lateral și nu este executat automat de profiluri.

## Jurnale și erori

- Jurnal de sesiune separat pentru fiecare componentă, în userData/dashboard-profiles.
- Jurnalul sesiunii este salvat înainte de fiecare pas. Motorul fiecărui tweak salvează originalul înainte de scriere.
- La prima eroare se oprește aplicarea; pașii începuți, inclusiv cel eșuat, sunt restaurați în ordine inversă.
- Eșecurile de restaurare rămân în jurnal și pot fi reluate după redeschiderea aplicației.
- Lipsa unui backup necesar nu este raportată drept restaurare reușită.
- Un pas nativ care era deja în starea dorită este înregistrat ca nemodificat și nu primește backup fictiv.
- Un token de confirmare este utilizabil o singură dată și expiră după 3 minute.
- Oprirea neconfirmată a proceselor Windows păstrează blocarea introdusă în 7.6.1; nu se pornește un alt profil peste o operație cu rezultat necunoscut.

## Efecte și limite

Low/Medium/High/Ultra descriu seturile de modificări, nu un câștig garantat. CPU High/Ultra pot crește consumul și temperatura. GPU Medium oprește capturarea Game DVR; High poate îmbunătăți sau înrăutăți anumite jocuri. GPU Ultra verifică build Windows >=19041 și existența unui GPU, dar NU validează automat suportul HAGS al driverului: scrierea unei valori Registry nu confirmă că driverul o utilizează. HAGS necesită restart.

DNS nu garantează ping mai mic; Fast Open și RTO privesc TCP, nu accelerează automat jocurile UDP. Setările RSS și TCP sunt globale, chiar dacă DNS se schimbă pe adaptorul ales. Rețelele private/VPN pot necesita DNS-ul lor; citește avertismentul din confirmare.

Profilurile nu includ dezinstalări, ștergerea cache-urilor, modificări de aspect Windows, BCD, dezactivarea Defender/Firewall sau scrierea în slotul GPU 0000 presupus din unele comenzi de referință.

## Verificare

113 teste Node trecute în mediul de dezvoltare Linux, inclusiv 12 teste ale planificării/recuperării și 5 ale interfeței Dashboard. Acoperă anulare, token expirat/reutilizat, backup apărut după analiză, rollback după eșec, reluare după restart al aplicației, backup lipsă, pași nemodificați și profiluri independente. Scripturile PowerShell modificate trec analiza gramaticală; acestea nu au fost executate pe Windows aici.

Testarea efectivă pe Windows 10/11, validarea driverelor, testele după restart și benchmark-urile rămân necesare. Installerul comercial rămâne condiționat de cheia publică originală și verificarea release. Pachetul livrat este cod sursă pentru testare, nu un installer Windows validat.
