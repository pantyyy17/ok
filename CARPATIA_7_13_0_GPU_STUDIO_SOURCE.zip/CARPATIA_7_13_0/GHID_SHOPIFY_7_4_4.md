# CARPATIA 7.11.0 — cumpărare și licență permanentă

Stare: implementare locală testată; magazinul, serverul, emailul și installerul NU sunt conectate/publicate. Niciun mesaj real nu a fost trimis și nicio cheie de producție nu a fost creată aici.

## Cum funcționează

Shopify confirmă comanda plătită → serverul verifică semnătura webhookului și varianta exactă de produs → emite un cod semnat Ed25519 per unitate cumpărată → salvează codul și emailul complet în aceeași tranzacție SQLite → trimite email prin Resend → clientul lipește codul în aplicație. O singură pereche de chei a editorului semnează toate codurile; nu se creează o nouă pereche pentru fiecare client. Verificarea ulterioară funcționează offline, fără expirare sau abonament.

Prețul nu este codificat în licență: aceeași variantă de produs poate costa 15 lei în campanie și 99 lei în afara campaniei. Plata și reducerile sunt gestionate de Shopify. Se procesează numai `orders/paid`, `financial_status=paid`, produsul configurat. Nu configura abonament recurent.

## Varianta simplă, fără server

Folosește `LICENTA_MANAGER.bat`, creează/păstrează cheile într-un folder privat extern și apasă COPIAZĂ CHEIA PUBLICĂ ÎN PROIECT. După verificarea manuală a plății, emite o licență PERMANENTĂ și livrează codul clientului. Această variantă nu livrează automat emailuri. Nu genera un nou set de chei dacă ai deja clienți: reutilizează perechea existentă.

## Prima configurare pe calculatorul editorului

Nu trimite cheia privată în chat, email sau acest mediu partajat. Pe PC-ul tău Windows, instalează Node.js 24+ și pornește `LICENTA_MANAGER.bat`. Verifică folderul privat afișat în manager: trebuie să fie separat de sursele CARPATIA, de exemplu `D:\CARPATIA_PRIVATE`. Pentru un folder ales explicit poți folosi:

```bat
node tools/license-manager.js --private-dir "D:\CARPATIA_PRIVATE"
```

1. La prima lansare, apasă **CREEAZĂ CHEILE O SINGURĂ DATĂ**. Dacă există deja clienți/licențe, restaurează perechea originală în folderul privat.
2. Fă un backup criptat al folderului privat într-un loc separat, controlat de tine. Păstrează cheia originală și după mutarea magazinului.
3. Apasă **COPIAZĂ CHEIA PUBLICĂ ÎN PROIECT**. Managerul afișează amprenta SHA-256 și confirmă că fișierul `license-public.pem` corespunde. O cheie diferită sau invalidă nu este suprascrisă.
4. **EXPORTĂ .PEM PUBLIC** exportă numai cheia publică pentru configurarea serverului. Cheia privată rămâne în folderul privat. Numai `license-public.pem` intră în installer.
5. Rulează `BUILD_INSTALLER.bat` pe Windows, apoi testează un cod emis cu aceeași pereche în installer. Starea cheii publice din manager confirmă doar potrivirea cheilor; buildul și testarea Windows rămân pași separați.

Alternativ, CLI-ul oferă `status`, `configure` și `export-public`, toate cu `--private-dir`. `status` raportează neconcordanțele fără a afișa cheia privată:

```bat
node tools/license-cli.js status --private-dir "D:\CARPATIA_PRIVATE"
node tools/license-cli.js configure --private-dir "D:\CARPATIA_PRIVATE"
node tools/license-cli.js export-public --private-dir "D:\CARPATIA_PRIVATE" --out "D:\carpatia-public.pem"
```

## Automatizare

1. Pe PC-ul editorului configurează perechea Ed25519 prin manager. Păstrează backup securizat al cheii private. Numai `license-public.pem` intră în installer. Compilarea rămâne blocată cât timp aceasta lipsește.
2. Pe Windows, cu Node.js 24+, rulează `BUILD_INSTALLER.bat`, apoi testează installerul. Publică DOAR installerul, niciodată acest ZIP cu uneltele vânzătorului. Configurează un URL HTTPS real pentru descărcarea lui.
3. Creează produs digital Shopify, fără transport, cu email obligatoriu la checkout. Identifică ID-ul numeric al VARIANTEI, nu al produsului. Setează prețul campaniei în Shopify. Nu a fost modificat niciun preț live.
4. Pe un server privat Node.js 24+ cu disc persistent, copiază sursele. Transferă în siguranță cheia privată originală creată pe PC-ul tău către un director privat extern proiectului, accesibil numai contului serviciului. Nu o genera în acest mediu partajat și nu o trimite prin chat/email. Pune și baza de date într-un director privat extern. Nu găzdui întregul folder ca fișiere publice.
5. Creează/configurează expeditorul verificat la Resend și cheia API. Completează variabilele din `seller/env.example` într-un fișier privat extern, de exemplu `/srv/carpatia-private/seller.env`. Nu trimite secrete în chat. `LICENSE_PUBLIC_KEY_FILE` trebuie să indice cheia publică exactă a installerului.
6. Pornește o SINGURĂ instanță: `node --env-file=/srv/carpatia-private/seller.env seller/server.js`. Serviciul ascultă pe 127.0.0.1:8787. Folosește un reverse proxy HTTPS cu limită de corp de 1 MiB și limitare de trafic. Configurează serviciul pentru restart automat.
7. În Shopify configurează webhook JSON pentru comenzi plătite (`orders/paid`) către `https://domeniul-serverului/webhooks/shopify/orders-paid`. Folosește secretul aferent metodei concrete de înregistrare a webhookului; nu confunda secretul de semnare cu tokenul Admin API. Verifică semnătura cu o livrare de test. Handlerul implementează webhookul clasic, nu noul format Shopify Events.
8. În mediu separat de test, folosește chei/date de test și `SHOPIFY_ALLOW_TEST=1`. Validează checkout, produs greșit, comandă neplătită, două bucăți, retrimitere webhook, email indisponibil, restart și activare în installer. Apoi setează `SHOPIFY_ALLOW_TEST=0` în producție.

## Operare

Baza `licenses.sqlite` conține coduri și emailuri ale clienților; nu o publica. Backupul trebuie să fie consistent SQLite, inclusiv WAL (folosește SQLite backup sau oprește serviciul înainte de copiere). Monitorizează comenzile Shopify și compară cu licențele: webhooks pot lipsi, deci reconcilierea rămâne manuală în această versiune.

Outbox are stările pending/sent/review. Reîncercările folosesc același ID și același cod. După 23h de la prima încercare, livrarea ambiguă se oprește în review; verifică istoricul Resend și livrează manual aceeași cheie dacă nu a ajuns. Nu emite alta. Statusul sent înseamnă acceptat de furnizor, nu confirmat în inbox; verifică bounce/spam în Resend.

În această versiune expeditorul, subiectul și URL-ul de descărcare sunt salvate împreună cu emailul la emitere. Schimbările ulterioare ale configurării se aplică numai comenzilor noi, iar reîncercările păstrează mesajul original. La actualizarea unei baze de date vechi, livrările deja încercate și neconfirmate intră în `review`, deoarece vechea versiune nu salva întregul conținut livrat.

Pentru verificarea locală a numărului de licențe și a stărilor emailurilor, fără afișarea adreselor sau a codurilor:

```sh
node seller/status.js /srv/carpatia-data
```

Verifică regulat că `review` este 0 și că `pending` se golește. Comenzile cu răspuns 422, de exemplu fără email sau cu cantitate invalidă, nu emit niciun cod: corectează datele și reconciliază comanda manual. O comandă neplătită, anulată sau de test cu `SHOPIFY_ALLOW_TEST=0` nu emite licențe. ID-urile Shopify mari sunt păstrate exact din JSON; nu copia ID-uri prin foi de calcul care le rotunjesc.

## După primele trei luni: site propriu

Păstrează perechea Ed25519, cheia publică din installer și baza de date. Clienții Shopify continuă să folosească aceleași coduri; mutarea magazinului nu cere reactivare sau un installer cu altă cheie. Baza de date reține amprenta editorului și refuză pornirea cu o altă cheie privată, chiar dacă ambele căi de chei din configurare au fost schimbate. Pentru o bază veche fără amprentă, serviciul verifică semnătura unui cod deja emis înainte de asociere.

`seller/fulfillment-core.js` conține emiterea independentă de magazin, tranzacția SQLite, deduplicarea și outbox-ul. Adaptorul Shopify îl folosește deja. Un viitor adaptor pentru site creează serviciul cu aceeași bază de date, `privateKey`, `publicKey` publică din installer, `emailFrom` și `downloadUrl`. Trebuie să verifice semnătura notificării furnizorului de plăți și plata finalizată, produsul și cantitatea, apoi să apeleze `fulfillVerifiedPurchase({source,purchaseId,email,items:[{id,quantity}]})`. Folosește o valoare `source` stabilă și distinctă de domeniul Shopify și referințele originale, nemodificate, ale plății/articolelor. Acest helper este exclusiv pe serverul privat; nu îl expune direct în browser și nu considera o pagină de succes sau un parametru `paid` drept dovadă a plății. Nu există încă un endpoint sau o integrare cu un furnizor de plăți pentru site-ul propriu.

Testarea locală folosește chei temporare și emailuri simulate. Acoperă activarea codului cumpărat în `createLicenseStore`, două bucăți, ID-uri mari, plăți invalide, retrimiteri, restart, email indisponibil, rollback la eșecul salvării și păstrarea exactă a mesajului la reîncercare. Nu probează checkout-ul live, livrarea reală sau installerul Windows.

Nu există revocare offline la refund, blocare la un PC, recuperare automată după pierderea bazei sau sincronizare automată cu comenzile ratate. Nu promite aceste funcții clienților. Licența este permanentă pentru produsul CARPATIA V7 PRO; suportul și drepturile asupra viitoarelor versiuni majore trebuie definite separat.

## Preț verificat la 24 octombrie 2026

Shopify România: 5 lei/lună primele 3 luni după 3 zile gratuite; Basic 139 lei/lună la plata lunară sau 99 lei/lună la plata anuală. Tarif standard de card afișat: 1,9% + 1,25 lei. La o vânzare de 15 lei rezultă aproximativ 13,47 lei după acest comision, înainte de taxe, abonament, email, hosting, reclame și refunduri. Nu este profit net. La acest tarif ar fi nevoie de aproximativ 11 vânzări/lună doar pentru 139 lei de abonament. Taxele și comisioanele efective depind de cont/card/plan.

99 → 15 lei înseamnă aproximativ 84,85% reducere. Nu afișa un preț de referință inventat; dacă 99 lei nu a fost un preț real, preferă „Preț de lansare: 15 lei”, până clarifici istoricul și regulile aplicabile campaniei.

Surse oficiale:
- https://www.shopify.com/ro/pricing
- https://shopify.dev/docs/apps/build/webhooks/verify-deliveries
- https://shopify.dev/docs/api/webhooks/latest
- https://resend.com/docs/api-reference/emails/send-email
- https://resend.com/docs/dashboard/emails/idempotency-keys
