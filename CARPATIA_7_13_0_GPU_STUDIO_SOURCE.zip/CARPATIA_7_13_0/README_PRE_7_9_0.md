# 7.8.3 — FIȘE TWEAK SIMPLIFICATE

Comenzile sursă, descrierile de referință, ID-urile și valorile Registry nu mai sunt afișate în fișe sau confirmările de aplicare. Riscurile, condițiile de compatibilitate și avertismentele rămân vizibile. Motorul Windows nu este modificat.

# 7.8.2 — MENIU BACKUP SIMPLIFICAT

Interfața de recuperare are o singură acțiune principală, restaurare totală sau pe categorie, setări individuale și istoric pliabile. Motorul Windows nu a fost modificat în această versiune. Limitele candidatului 7.8.1 rămân valabile.

# 7.8.1 — CANDIDAT PENTRU TESTARE WINDOWS

Citește întâi `RAPORT_7_8_1.md`. Nu este un release final validat; nu include EXE/installer. 183 teste Node au trecut; operațiile Windows și restartul nu au fost testate aici. Restaurarea directă a instantaneelor manuale rămâne neimplementată.

# CARPATIA 7.8.0 — Dashboard Resource Fix

Vezi FIX_7_8_0.md. 172 teste Node; executia reala Windows necesita verificare.

# CARPATIA 7.7.9 — Storage & BCD Fix

Vezi FIX_7_7_9.md pentru modificari, limite si verificare Windows.

# Actualizare 7.7.8 — Network & Recovery Engine Fix
Vezi FIX_7_7_8.md pentru Services, conflicte, RAM si testare.

# Actualizare 7.7.6
Vezi FIX_7_7_6.md pentru corectarea citirii parametrilor CPU si diagnosticul fara modificari.

# Actualizare 7.7.5
Vezi FIX_7_7_5.md pentru catalogul Internet si profilurile extinse.

# Actualizare 7.7.4
Vezi FIX_7_7_4.md pentru restaurare, loguri si testul Registry real izolat.

# CARPATIA V7 PRO — Ruby Redline 7.7.2

Surse experimentale pentru Windows 10/11. Interfața CARPATIA și bannerul original BMW / Peleș sunt păstrate. Nu este un installer comercial testat.

## Pornire pentru test

1. Extrage întregul ZIP într-un folder nou. Păstrează instalarea și backupurile existente.
2. Instalează Node.js 24 sau ulterior și rulează `npm install` în folderul proiectului.
3. Rulează `npm test`, apoi `TEST_CARPATIA_WINDOWS.bat` pentru diagnostic fără aplicarea tweak-urilor.
4. Pentru interfață folosește `TEST_UI_CARPATIA.bat`. Modul de dezvoltare există numai în surse, nu în aplicația distribuită. Modificările de sistem cer administrator.
5. În Tweaks alege categoria, citește efectul și aplică individual. Pentru DNS/MTU/IPv6 alege adaptorul. Nu există aplicare automată în masă.

## Dashboard nou

Cele trei cercuri sunt CPU, GPU și Internet. Fiecare are Low / Medium / High / Ultra și Restaurare. Alegi nivelul, apeși cercul, citești pașii și confirmi. Internet cere alegerea adaptorului. Pentru schimbarea unui profil activ îl restaurezi mai întâi. Debloat rămâne în meniul lateral.

Vezi DASHBOARD_7_7_0.md pentru pașii fiecărui nivel și limitele verificării.

Optimizările interfeței și măsurătorile sunt documentate în OPTIMIZARI_7_7_1.md.

## Documente

- Starea exactă a implementării și testării: CATALOG_7_6_0.md.
- Licențiere permanentă și cheia editorului: LICENTIERE.md.
- Integrarea separată Shopify/email: GHID_SHOPIFY_7_4_4.md.
- Istoric: docs/history/.

`npm run dist` verifică cheia publică Ed25519 înainte de build. Folosește cheia publică pereche a cheii private originale a editorului; nu genera o altă pereche pentru a ocoli o nepotrivire. Cheia privată și instrumentele seller nu se distribuie clienților.

Această livrare nu conține cheia publică de producție. Testarea Windows, compilarea installerului și verificarea activării cu cheia originală rămân necesare înainte de distribuire.
