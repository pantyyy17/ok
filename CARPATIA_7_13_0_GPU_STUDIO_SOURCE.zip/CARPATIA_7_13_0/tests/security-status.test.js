'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
const probe=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-Command','exit 0'],{encoding:'utf8',timeout:30000});
test('Defender status is read-only and preserves missing, protected, passive and failed inventory states',{skip:probe.error?.code==='ENOENT'?'PowerShell unavailable':false},()=>{
 assert.ifError(probe.error);assert.equal(probe.status,0,probe.stderr);
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'security-status.ps1')],{encoding:'utf8',timeout:30000});
 assert.ifError(result.error);assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));assert.equal(report.success,true);assert.equal(report.assertions,6);
});
