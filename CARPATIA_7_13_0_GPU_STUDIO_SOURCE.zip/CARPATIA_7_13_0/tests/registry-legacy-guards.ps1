$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$script:assertions=0
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$failed=$false;try{& $operation}catch{$failed=$true};Assert $failed $label}
function Import-Functions($file,$names){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root $file),[ref]$tokens,[ref]$errors)
 if(@($errors).Count){throw ('Parse errors in '+$file)}
 foreach($name in $names){
  $definition=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
  if($null -eq $definition){throw ('Missing function '+$name)}
  $parameters=(@($definition.Parameters | ForEach-Object {$_.Extent.Text}) -join ',')
  $body=$definition.Body.Extent.Text
  Set-Item -Path ('Function:script:'+$name) -Value ([scriptblock]::Create(('param('+ $parameters +')'+$body.Substring(1,$body.Length-2))))
 }
}
. (Join-Path $root 'registry-values.ps1')
$base=@{path='HKCU\Software\CarpatiaTest';name='Setting';exists=$true;kind='DWord';value=1}
foreach($value in @(-2147483648,0,2147483647,[long]4294967295)){
 $row=$base.Clone();$row.value=$value;Assert-RegistryValue $row;$script:assertions++
}
foreach($value in @([long]-2147483649,[long]4294967296,1.5,'1',$true)){
 $row=$base.Clone();$row.value=$value;Reject {Assert-RegistryValue $row} 'invalid DWORD cannot be silently converted'
}
$row=$base.Clone();$row.kind='Binary';$row.value=@(0,255);Assert-RegistryValue $row;$script:assertions++
foreach($value in @(@(0,256),@(1.5),@('2'))){$row.value=$value;Reject {Assert-RegistryValue $row} 'invalid binary element is rejected'}
$row=$base.Clone();$row.kind='MultiString';$row.value=@('one','two');Assert-RegistryValue $row;$script:assertions++
$row.value=@('one',7);Reject {Assert-RegistryValue $row} 'non-string multistring element is rejected'
$row=$base.Clone();$row.path='HKCC\Software\Test';Reject {Assert-RegistryValue $row} 'unsupported hive is rejected before writable open'
$row=$base.Clone();$row.exists='false';Reject {Assert-RegistryValue $row} 'string false cannot become true'
$row=$base.Clone();$row.kind='Dword';Reject {Assert-RegistryValue $row} 'inconsistent Registry kind casing is rejected'

Import-Functions 'tcp-latency.ps1' @('Validate-TcpState','Same-TcpValue','Assert-TcpRestored','Put-Previous')
$fields=@('TcpAckFrequency','TCPNoDelay')
$state=[pscustomobject]@{TcpAckFrequency=[pscustomobject]@{exists=$true;kind='DWord';value=[long]4294967295};TCPNoDelay=[pscustomobject]@{exists=$false;kind=$null;value=$null}}
Validate-TcpState $state;$script:assertions++
Assert (Same-TcpValue @{exists=$true;kind='DWord';value=-1} $state.TcpAckFrequency) 'DWORD sign representation does not cause false restore failure'
$script:writes=@()
function New-ItemProperty {param($LiteralPath,$Name,$Value,$PropertyType,[switch]$Force,$ErrorAction) $script:writes+=@{name=$Name;value=$Value}}
function Remove-ItemProperty {param($LiteralPath,$Name,$ErrorAction) $script:writes+=@{name=$Name;deleted=$true}}
Put-Previous 'trusted-interface' $state
Assert ($script:writes[0].value -eq -1) 'full unsigned DWORD original restores without overflow'
$state.TCPNoDelay=[pscustomobject]@{exists='false';kind=$null;value=$null}
$script:writes=@();Reject {Put-Previous 'trusted-interface' $state} 'corrupt second TCP original fails before first write'
Assert ($script:writes.Count -eq 0) 'TCP prevalidation caused zero partial writes'
function Get-RegState($key){return @{TcpAckFrequency=@{exists=$true;kind='DWord';value=5};TCPNoDelay=@{exists=$false}}}
$state.TCPNoDelay=[pscustomobject]@{exists=$false;kind=$null;value=$null}
Reject {Assert-TcpRestored 'trusted-interface' $state} 'rollback must reread originals before deleting backup'

Import-Functions 'dns.ps1' @('Same-DnsIPv4State','Read-DnsIPv4State')
Assert (Same-DnsIPv4State @{automatic=$true;servers=@('10.0.0.2')} $true @('10.0.0.1')) 'DHCP lease DNS changes do not prevent original automatic mode verification'
Assert (-not (Same-DnsIPv4State @{automatic=$false;servers=@('10.0.0.2')} $false @('10.0.0.1'))) 'different manual DNS is detected'
Assert (-not (Same-DnsIPv4State @{automatic=$true;servers=@('1.1.1.1')} $false @('1.1.1.1'))) 'same resolver addresses cannot hide automatic/manual mode changes'
function Get-DnsClientServerAddress {param($InterfaceIndex,$AddressFamily,$ErrorAction) return @{ServerAddresses=@('1.1.1.1')}}
function Get-Item {param($LiteralPath,$ErrorAction) throw 'Access denied'}
Reject {Read-DnsIPv4State @{ifIndex=4;InterfaceGuid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}} 'unreadable Registry is not classified as automatic DNS'

Import-Functions 'gpu-lab.ps1' @('Desired-Preference')
Assert ((Desired-Preference 'AutoHDREnable=1;GpuPreference=1;') -ceq 'AutoHDREnable=1;GpuPreference=2;') 'GPU desired state preserves independent preference tokens'
Assert ((Desired-Preference 'gpupreference=1;') -ceq 'GpuPreference=2;') 'GPU preference matching respects Registry case insensitivity'

# Run the real GPU restore branch with Registry/filesystem writes intercepted.
$tokens=$null;$errors=$null
$gpuAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'gpu-lab.ps1'),[ref]$tokens,[ref]$errors)
$restore=$gpuAst.Find({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Clauses[0].Item1.Extent.Text -eq "$('$Action') -eq 'Restore'"},$true)
Assert ($null -ne $restore) 'real GPU Restore branch located'
$restoreBlock=[scriptblock]::Create($restore.Extent.Text)
$Action='Restore';$target='C:\Games\sample.exe';$registryKey='HKCU:\Mock';$backupRoot='MockBackups'
$backup=@{present=$true;raw='GpuPreference=1;'}
$prior=@{present=$true;raw='AutoHDREnable=1;GpuPreference=2;'}
$script:writes=@()
Reject {& $restoreBlock} 'GPU restore rejects externally added HDR tokens'
Assert ($script:writes.Count -eq 0) 'external GPU drift causes zero Registry writes'
function Test-Path {param($LiteralPath) return $true}
function Get-BackupPath($target){return 'MockBackups/saved.json'}
function New-ItemProperty {param($LiteralPath,$Path,$Name,$Value,$PropertyType,[switch]$Force,$ErrorAction) $script:writes+=@{name=$Name;value=$Value};$script:gpuCurrent=@{present=$true;raw=$Value}}
function Get-Preference($target){return $script:gpuCurrent}
function Remove-Item {param($LiteralPath,[switch]$Force,$ErrorAction) $script:archived=$true}
function Emit($value){$script:lastReport=$value}
$prior=@{present=$true;raw='GpuPreference=2;'};$script:archived=$false
& $restoreBlock
Assert ($script:writes.Count -eq 1 -and $script:writes[0].value -ceq 'GpuPreference=1;') 'known GPU applied value restores the original'
Assert ($script:lastReport.success -and $script:archived) 'GPU backup clears only after readback succeeds'

# Exercise the real Startup restore loop. A case-variant selection and an exact
# already-written original must recover after a crash without another write.
$startup=Get-Content -LiteralPath (Join-Path $root 'startup.ps1') -Raw
$restoreOffset=$startup.IndexOf('$restored=@();$errors=@();$remaining=@()')
Assert ($restoreOffset -ge 0) 'real Startup restore loop located'
$startupRestore=[scriptblock]::Create($startup.Substring($restoreOffset))
$mockKey=[pscustomobject]@{}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValueNames -Value {return @('program')}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValueKind -Value {param($name) return 'String'}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValue -Value {param($name,$default,$flags) return 'C:\Program Files\Sample\app.exe'}
function Get-Item {param($LiteralPath) return $mockKey}
function Output($value){$script:lastReport=$value}
function Save($items){$script:remaining=$items}
$Action='Restore';$Name='pROgram';$run='HKCU:\Mock';$file='startup.json'
$backup=@([pscustomobject]@{name='Program';kind='String';value='C:\Program Files\Sample\app.exe'})
$script:writes=@()
& $startupRestore
Assert ($script:lastReport.success -and @($script:lastReport.restored).Count -eq 1) 'Startup recovery accepts case-insensitive selected name and exact existing original'
Assert ($script:writes.Count -eq 0) 'Startup recovery does not rewrite an already restored value'

@{success=$true;assertions=$script:assertions} | ConvertTo-Json -Compress
