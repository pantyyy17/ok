$ErrorActionPreference='Stop'
$script:assertions=0
function Assert($value,$label){if(-not $value){throw $label};$script:assertions++}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot '../security-status.ps1'),[ref]$tokens,[ref]$errors)
if(@($errors).Count){throw 'Security status parse failure'}
$definition=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Get-CarpatiaSecurityStatus'},$true)
if($null -eq $definition){throw 'Missing real status function'}
Invoke-Expression $definition.Extent.Text
$script:present=$true;$script:denied=$false
function Get-Command {param($Name,$ErrorAction) if($script:present){return [pscustomobject]@{Name=$Name}};return $null}
$script:status=[pscustomobject]@{RealTimeProtectionEnabled=$true;IsTamperProtected=$false;AMRunningMode='Normal'}
$script:preference=[pscustomobject]@{DisableRealtimeMonitoring=$false}
function Get-MpComputerStatus {param($ErrorAction) if($script:denied){throw 'Access denied'};return $script:status}
function Get-MpPreference {param($ErrorAction) return $script:preference}
$value=Get-CarpatiaSecurityStatus
Assert ($value.success -and $value.available -and $value.realTimeEnabled -and -not $value.tamperProtected -and $value.passive -ceq $false) 'Read-only normal Defender status is preserved'
$script:status.IsTamperProtected=$true
Assert (Get-CarpatiaSecurityStatus).tamperProtected 'Tamper Protection remains explicit'
$script:status=[pscustomobject]@{AMRunningMode='Unknown'}
$value=Get-CarpatiaSecurityStatus
Assert ($null -eq $value.realTimeEnabled -and $null -eq $value.tamperProtected -and $null -eq $value.passive) 'Missing flags never become false by coercion'
$script:status=[pscustomobject]@{RealTimeProtectionEnabled='false';IsTamperProtected=0;AMRunningMode='Passive Mode'}
$value=Get-CarpatiaSecurityStatus
Assert ($null -eq $value.realTimeEnabled -and $null -eq $value.tamperProtected -and $value.passive) 'Invalid boolean forms stay unknown and passive mode is detected'
$script:denied=$true
$value=Get-CarpatiaSecurityStatus
Assert (-not $value.success -and -not $value.available -and $value.reason -match 'Access denied') 'Read errors remain unavailable rather than protected or disabled claims'
$script:denied=$false;$script:present=$false
$value=Get-CarpatiaSecurityStatus
Assert ($value.success -and -not $value.available -and $null -eq $value.realTimeEnabled) 'Missing Defender commandlets are an explicit unavailable state'
@{success=$true;assertions=$script:assertions;scope='Real read-only function; Defender inventory mocked, no security settings changed.'} | ConvertTo-Json -Compress
