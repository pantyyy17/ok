'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const catalog=require('../tweak-library.json');
const {publicCatalog,authorize}=require('../tweak-library-core');
test('effective catalog preserves all 241 unique reference entries across 13 categories',()=>{
 assert.equal(catalog.length,241);assert.equal(new Set(catalog.map(x=>x.referenceId)).size,241);assert.equal(new Set(catalog.map(x=>x.category)).size,13);
 assert.equal(catalog.filter(x=>x.status==='registry').length,147);
});
test('every nonimplemented option is rejected by the trusted boundary',()=>{
 for(const row of catalog.filter(x=>!['registry','native','maintenance'].includes(x.status)))assert.throws(()=>authorize(row.id,'Apply',true));
});
test('individual confirmation cannot be omitted or replaced with truthy strings',()=>{
 const id=catalog.find(x=>x.status==='registry').id;
 for(const ack of [undefined,false,1,'true',{},[]])assert.throws(()=>authorize(id,'Apply',ack));
 assert.equal(authorize(id,'Apply',true),id);
 assert.throws(()=>authorize(id,'Run',true));assert.throws(()=>authorize(id+';echo test','Apply',true));
});
test('appearance and no-op examples remain in the audit catalog but cannot execute',()=>{
 for(const referenceId of ['win-018','win-019','util-dark-theme','ram-008','adv-009','adv-022']){
  const row=catalog.find(x=>x.referenceId===referenceId);assert.ok(row);assert.notEqual(row.status,'registry');assert.throws(()=>authorize(row.id,'Apply',true));
 }
});
test('registry adapters use typed values including deletion, never source scripts',()=>{
 for(const row of catalog.filter(x=>x.status==='registry')){
  assert.ok(row.entries.length);
  for(const e of row.entries){assert.match(e.path,/^HK(?:CU|LM|U)\\/);assert.ok(['String','DWord','Binary','MultiString'].includes(e.kind));if(e.kind==='DWord'&&e.exists!==false)assert.ok(Number.isInteger(e.value)&&e.value>=0&&e.value<=4294967295)}
 }
 assert.ok(publicCatalog().every(x=>!Object.hasOwn(x,'entries')&&Array.isArray(x.targets)));
});
test('restore stays addressable independently of apply acknowledgements',()=>{
 for(const row of catalog){if(row.status==='maintenance')assert.throws(()=>authorize(row.id,'Restore'));else assert.equal(authorize(row.id,'Restore'),row.id)}
 assert.throws(()=>authorize('unknown','Restore'));
});

test('catalog renderer is loaded before main UI and all referenced controls exist',()=>{
 const fs=require('node:fs'),path=require('node:path');
 const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
 const html=read('index.html'),js=read('tweak-library-ui.js');
 assert.ok(html.indexOf('src="tweak-library-ui.js"')>=0);
 assert.ok(html.indexOf('src="tweak-library-ui.js"')<html.indexOf('src="ui.js"'));
 for(const m of js.matchAll(/\$\('([\w-]+)'\)/g))assert.ok(html.includes('id="'+m[1]+'"'),m[1]);
 assert.ok(js.includes("requireNative(action!=='Apply')"));
});
test('page renders the full catalog and search/category filters without native operations',async()=>{
 const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
 class Element{
  constructor(){this.children=[];this.value='';this.listeners={};this.textContent=''}
  setAttribute(name,value){this[name]=value}
  append(...items){this.children.push(...items)}
  replaceChildren(...items){this.children=items}
  get firstChild(){return this.children[0]}
  addEventListener(name,fn){this.listeners[name]=fn}
 }
 const ids=Object.fromEntries(['tweakRows','tweakSearch','tweakCategory','tweakStatus','tweakSummary','loadTweaks','tweakCategoryTabs','tweakCategoryTitle','tweakCategoryHelp','tweakAdapterWrap','tweakAdapter','tweakOperationStatus'].map(x=>[x,new Element()]));
 const window={CARPATIA_TWEAK_PREVIEW:publicCatalog()};
 const context={window,document:{createElement:()=>new Element(),getElementById:id=>ids[id]}};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../tweak-library-ui.js'),'utf8'),context);
 const page=window.CarpatiaTweaks.mount({api:null,requireNative:()=>false,task:async(_,fn)=>fn(),showToast:()=>{},confirmDialog:()=>{throw Error('No native confirmations in preview')}});
 await page.load();assert.equal(ids.tweakRows.children.length,215);
 const firstCard=ids.tweakRows.children[0];assert.ok(!firstCard.children.some(x=>x.listeners.toggle));
 const visible=n=>[n.textContent,...n.children.map(visible)].join(' ');
 const cardText=visible(firstCard);assert.ok(cardText.includes('Risc estimat:'));assert.ok(!cardText.includes(publicCatalog()[0].sourceCommand));assert.ok(!cardText.includes(publicCatalog()[0].referenceId));

 assert.equal(ids.tweakCategoryTabs.children.length,14);
 ids.tweakCategoryTabs.children[2].onclick();assert.equal(ids.tweakCategory.value,'GPU');assert.equal(ids.tweakRows.children.length,publicCatalog().filter(x=>x.category===ids.tweakCategory.value).length);
 assert.equal(ids.tweakCategoryTitle.textContent,'GPU');
 ids.tweakCategoryTabs.children[0].onclick();assert.equal(ids.tweakRows.children[0],firstCard);
 ids.tweakSearch.value='util-dark-theme';ids.tweakSearch.listeners.input();assert.equal(ids.tweakRows.children[0].textContent,'Nicio setare nu corespunde filtrelor.');
 ids.tweakSearch.value='';ids.tweakCategory.value='CPU';ids.tweakCategory.listeners.change();assert.equal(ids.tweakRows.children.length,publicCatalog().filter(x=>x.category===ids.tweakCategory.value).length);
 ids.tweakCategory.value='';ids.tweakStatus.value='reversible';ids.tweakStatus.listeners.change();assert.equal(ids.tweakRows.children.length,publicCatalog().filter(x=>['registry','native'].includes(x.status)).length);
});
