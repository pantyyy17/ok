'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
async function render(item){
 const source=fs.readFileSync(path.join(__dirname,'../ui.js'),'utf8');const start=source.indexOf(' async function drawServices('),end=source.indexOf('\n async function changeService',start);
 const nodes={},calls=[];function el(tag,cls,text){return {tag,cls,text,children:[],append(...x){this.children.push(...x)},replaceChildren(...x){this.children=x}}}
 const context={api:{services:async()=>({success:true,elevated:true,items:[item]})},el,$:id=>nodes[id]||(nodes[id]=el('div')),changeService:(...a)=>calls.push(a),navigate:view=>calls.push(['navigate',view]),showResourceOwner:owner=>calls.push(['recovery',owner.id])};
 vm.runInNewContext(source.slice(start,end)+'\nthis.draw=drawServices;',context);await context.draw('servicesList');return {row:nodes.servicesList.children[0],calls};
}
test('Disabled state renders label without mutation button',async()=>{const x=await render({name:'WSearch',action:'disabled',label:'DEJA DEZACTIVAT'});assert.ok(!x.row.children.some(x=>x.tag==='button'));assert.equal(x.row.children.at(-1).text,'DEJA DEZACTIVAT')});
test('validated own backup renders Restore instead of Disable',async()=>{const x=await render({id:'search',name:'WSearch',action:'restore',label:'RESTAUREAZĂ'});const b=x.row.children.find(x=>x.tag==='button');b.onclick();assert.deepEqual(x.calls,[['Restore','search']])});
test('foreign owner routes to Recovery without directly restoring a different module',async()=>{const x=await render({name:'WSearch',action:'owner',label:'RESTAURARE ÎN TWEAKS',owners:[{id:'library-cpu-010',route:'tweaks'}]});x.row.children.find(x=>x.tag==='button').onclick();assert.deepEqual(x.calls,[['recovery','library-cpu-010']])});
test('unknown state never exposes Apply or Restore',async()=>{const x=await render({name:'WSearch',action:'blocked',label:'DIAGNOSTIC NECESAR',reason:'invalid backup'});assert.ok(!x.row.children.some(x=>x.tag==='button'))});
