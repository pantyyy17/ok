'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {PREFIX,PRODUCT,MAX_LENGTH,normalizeLicenseCode,inspectLicense,createIssuerCode,createLicenseStore}=require('../licensing');
// Ephemeral fixtures only: publisher signing material is never written to disk.
const pair=crypto.generateKeyPairSync('ed25519');
const publicKey=pair.publicKey.export({type:'spki',format:'pem'});
function payload(overrides={}){return {product:PRODUCT,licenseId:'purchase_0001',customer:'Client cumpărător',issuedAt:new Date(Date.now()-86400000).toISOString(),expiresAt:null,...overrides}}
function issue(overrides={}){return createIssuerCode(payload(overrides),pair.privateKey)}
function rawIssue(data){const body=PREFIX+'.'+Buffer.from(JSON.stringify(data)).toString('base64url');return body+'.'+crypto.sign(null,Buffer.from(body),pair.privateKey).toString('base64url')}
function fixture(t,key=publicKey){const directory=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-activation-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));return {directory,filename:path.join(directory,'carpatia-license.txt'),store:createLicenseStore({directory,publicKey:key})}}

test('purchased code accepts pasted line wraps, persists canonical code and reopens offline',t=>{
 const {directory,filename,store}=fixture(t),code=issue();
 const pasted='\uFEFF \r\n'+code.match(/.{1,47}/g).join(' \r\n\t\u00a0')+'\n';
 assert.equal(normalizeLicenseCode(pasted),code);
 assert.equal(inspectLicense(pasted,publicKey).licenseId,'purchase_0001');
 const activated=store.activate(pasted);
 assert.deepEqual(activated,{active:true,configured:true,reason:'active',developer:false,licenseId:'purchase_0001',customer:'Client cumpărător',expiresAt:null});
 assert.equal(fs.readFileSync(filename,'utf8'),code+'\n');
 assert.deepEqual(createLicenseStore({directory,publicKey}).status(),activated);
 if(process.platform!=='win32')assert.equal(fs.statSync(filename).mode&0o777,0o600);
});

test('normalization is bounded before whitespace removal and rejects non-whitespace additions',()=>{
 const code=issue();
 assert.throws(()=>normalizeLicenseCode(' '.repeat(MAX_LENGTH)+code),/lung/);
 assert.throws(()=>normalizeLicenseCode({toString:()=>code}),/invalid/);
 assert.equal(normalizeLicenseCode(' '.repeat(MAX_LENGTH)),'');
 for(const candidate of ['"'+code+'"','Licență: '+code,code+'\u200b',code.toLowerCase(),code.replace(/-/g,'–')])assert.throws(()=>inspectLicense(candidate,publicKey),/Format|Semnătura/);
});

test('missing and malformed publisher configuration remain distinguishable from a missing license',t=>{
 const {directory}=fixture(t);
 for(const key of [null,undefined,'',' \r\n']){
  const store=createLicenseStore({directory,publicKey:key});
  assert.equal(store.status().reason,'missing_publisher_key');assert.equal(store.status().configured,false);assert.equal(store.licensed(),false);assert.match(store.status().error,/publică/);
  assert.throws(()=>store.activate(issue()),error=>error.reason==='missing_publisher_key');
 }
 const otherAlgorithm=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'}).publicKey;
 for(const key of ['not a public key',otherAlgorithm,pair.privateKey]){
  const store=createLicenseStore({directory,publicKey:key});
  assert.equal(store.status().reason,'invalid_publisher_key');assert.equal(store.status().configured,false);assert.equal(store.licensed(),false);assert.match(store.status().error,/publică.*invalidă/);
  assert.throws(()=>store.activate(issue()),error=>error.reason==='invalid_publisher_key');
 }
 const store=createLicenseStore({directory,publicKey});
 assert.equal(store.status().configured,true);assert.equal(store.status().reason,'missing_license');assert.equal(store.status().active,false);assert.match(store.status().error,/Introdu/);
});

test('publisher configuration is parsed once while each saved code is reverified',t=>{
 const parse=crypto.createPublicKey;let parses=0;
 t.mock.method(crypto,'createPublicKey',(...args)=>{parses++;return parse(...args)});
 const {filename,store}=fixture(t);
 assert.equal(parses,1);
 store.status();store.activate(issue());store.status();store.licensed();
 assert.equal(parses,1);
 fs.writeFileSync(filename,'forged');
 assert.equal(store.status().reason,'invalid_license');assert.equal(store.licensed(),false);assert.equal(parses,1);
 const invalid=createLicenseStore({directory:path.dirname(filename),publicKey:'invalid'});
 assert.equal(parses,2);invalid.status();invalid.licensed();
 assert.throws(()=>invalid.activate(issue()),/publică/);assert.equal(parses,2);
});

test('failed forged or mismatched activation preserves an existing purchased license',t=>{
 const {directory,filename,store}=fixture(t),code=issue();
 store.activate(code);
 const parts=code.split('.');
 parts[1]=Buffer.from(JSON.stringify(payload({customer:'Forged customer'}))).toString('base64url');
 assert.throws(()=>store.activate(parts.join('.')),/Semnătura/);
 assert.throws(()=>store.activate(' '.repeat(MAX_LENGTH)+code),/lung/);
 assert.equal(fs.readFileSync(filename,'utf8'),code+'\n');assert.equal(store.status().active,true);
 const otherKey=crypto.generateKeyPairSync('ed25519').publicKey;
 const differentPublisher=createLicenseStore({directory,publicKey:otherKey});
 assert.equal(differentPublisher.status().configured,true);assert.equal(differentPublisher.status().reason,'invalid_license');assert.match(differentPublisher.status().error,/Semnătura/);assert.equal(differentPublisher.licensed(),false);
});

test('a previously activated license expires on the next authorization check',t=>{
 const {store}=fixture(t),now=Date.now(),expiresAt=new Date(now+60000).toISOString();
 store.activate(issue({expiresAt}));assert.equal(store.status().active,true);
 t.mock.method(Date,'now',()=>now+60001);
 const expired=store.status();
 assert.equal(expired.active,false);assert.equal(expired.configured,true);assert.equal(expired.reason,'expired_license');assert.match(expired.error,/expirat/);assert.equal(store.licensed(),false);
});

test('signed expired or wrong-product codes cannot replace a valid license',t=>{
 const {filename,store}=fixture(t),code=issue();store.activate(code);
 const expired=rawIssue(payload({issuedAt:new Date(Date.now()-3*86400000).toISOString(),expiresAt:new Date(Date.now()-86400000).toISOString()}));
 assert.throws(()=>store.activate(expired),error=>error.reason==='expired_license');
 assert.throws(()=>store.activate(rawIssue(payload({product:'OTHER_PRODUCT'}))),/CARPATIA/);
 assert.equal(fs.readFileSync(filename,'utf8'),code+'\n');
 fs.writeFileSync(filename,expired);
 assert.equal(store.status().reason,'expired_license');assert.equal(store.status().active,false);
});

test('invalid, oversized and non-file saved license contents stay inactive',t=>{
 const {filename,store}=fixture(t);
 fs.writeFileSync(filename,'invalid saved file');
 assert.equal(store.status().reason,'invalid_license');assert.equal(store.status().configured,true);assert.equal(store.status().active,false);
 fs.writeFileSync(filename,'X'.repeat(MAX_LENGTH+3));
 assert.equal(store.status().reason,'invalid_license_file');assert.equal(store.licensed(),false);
 fs.unlinkSync(filename);fs.mkdirSync(filename);
 assert.equal(store.status().reason,'invalid_license_file');assert.equal(store.licensed(),false);
});

test('explicit developer mode remains separately identified without masking distribution setup',t=>{
 const {directory}=fixture(t,null),store=createLicenseStore({directory,publicKey:null,developer:true});
 assert.deepEqual(store.status(),{active:true,configured:false,reason:'developer',developer:true,licenseId:'DEV',customer:'MOD DEZVOLTARE',expiresAt:null});
 assert.equal(createLicenseStore({directory,publicKey:null,developer:false}).licensed(),false);
});

test('publisher configuration refuses private PEM strings and buffers instead of deriving a public key',t=>{
 const crypto=require('node:crypto'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const pair=crypto.generateKeyPairSync('ed25519'),privatePem=pair.privateKey.export({type:'pkcs8',format:'pem'}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-public-only-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 for(const publicKey of [privatePem,Buffer.from(privatePem)]){const store=require('../licensing').createLicenseStore({directory:dir,publicKey});assert.equal(store.status().configured,false);assert.equal(store.status().reason,'invalid_publisher_key');}
});
