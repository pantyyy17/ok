$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../tweak-native-ops.ps1')
$script:count=0;$script:writes=0;$script:tamper=$true;$script:realTime=$true;$script:mode='Normal';$script:readback=$false
function Assert($value,$label){if(-not $value){throw $label};$script:count++}
function Reject($fn,$label){$failed=$false;try{& $fn}catch{$failed=$true};Assert $failed $label}
function Get-Command {param($Name,$ErrorAction) return @{Name=$Name}}
function Get-MpComputerStatus {param($ErrorAction) return @{IsTamperProtected=$script:tamper;RealTimeProtectionEnabled=$script:realTime;AMRunningMode=$script:mode}}
function Set-MpPreference {param($DisableRealtimeMonitoring,$ErrorAction) $script:writes++;$script:realTime=$script:readback}
$o=@{type='defender';property='DisableRealtimeMonitoring';value=$true}
Assert (-not (Get-NativeApplicability $o).applicable) 'Tamper Protection blocks the official write before any change'
Reject {Write-Native $o $true} 'Direct engine writes cannot bypass Tamper Protection'
Assert ($script:writes -eq 0) 'Protected state causes zero writes'
$script:tamper=$null
Reject {Write-Native $o $true} 'Unknown protected state blocks writes'
$script:tamper=$false;$script:mode='Passive'
Assert (-not (Get-NativeApplicability $o).applicable) 'Passive antivirus is not modified'
$script:mode='Normal';$script:readback=$true
Reject {Write-Native $o $true} 'Successful preference call without actual realtime change cannot claim success'
$script:readback=$false
Write-Native $o $true
Assert (-not $script:realTime) 'Allowed official preference verifies actual realtime state'
@{success=$true;assertions=$script:count;scope='Real engine guards; all Defender APIs mocked; no protection changed.'} | ConvertTo-Json -Compress
