'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {createIssuerCode,inspectLicense,PRODUCT}=require('../licensing');
const {privateKey,publicKey}=crypto.generateKeyPairSync('ed25519');
const priv=privateKey.export({type:'pkcs8',format:'pem'}),pub=publicKey.export({type:'spki',format:'pem'});
test('permanent license remains valid after 30 years',t=>{
 const now=Date.now(),code=createIssuerCode({product:PRODUCT,licenseId:'forever_01',customer:'Test',issuedAt:new Date(now).toISOString(),expiresAt:null},priv);
 t.mock.method(Date,'now',()=>now+30*365.25*86400000);assert.equal(inspectLicense(code,pub).expiresAt,null);
});
test('temporary license expires exactly at its deadline',t=>{
 const now=Date.now(),code=createIssuerCode({product:PRODUCT,licenseId:'temporary_01',customer:'Test',issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+1000).toISOString()},priv);
 t.mock.method(Date,'now',()=>now+1000);assert.throws(()=>inspectLicense(code,pub),/expirat/);
});
