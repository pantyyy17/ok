'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
const probe=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-Command','exit 0'],{encoding:'utf8',timeout:30000});
test('native profile applicability distinguishes absent capabilities from access and inventory errors',{skip:probe.error?.code==='ENOENT'?'PowerShell unavailable':false},()=>{
 assert.ifError(probe.error);assert.equal(probe.status,0,probe.stderr);
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'native-profile-applicability.ps1')],{encoding:'utf8',timeout:30000});
 assert.ifError(result.error);assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));assert.equal(report.success,true);assert.equal(report.assertions,9);
});
