'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {generateKeyPairSync}=require('node:crypto');
const {PRODUCT,createIssuerCode,inspectLicense,createLicenseStore}=require('../licensing');
const pair=generateKeyPairSync('ed25519');
const privateKey=pair.privateKey.export({format:'pem',type:'pkcs8'}),publicKey=pair.publicKey.export({format:'pem',type:'spki'});
const sample={product:PRODUCT,licenseId:'client_00012',customer:'Client test',issuedAt:new Date(Date.now()-3600000).toISOString(),expiresAt:new Date(Date.now()+86400000).toISOString()};
test('licență autentică Ed25519 este verificată fără cheie privată în client',()=>{
 const code=createIssuerCode(sample,privateKey);const decoded=inspectLicense(code,publicKey);
 assert.equal(decoded.licenseId,sample.licenseId);assert.equal(code.split('.').length,3);
});
test('un cod modificat după semnare nu este acceptat',()=>{
 const code=createIssuerCode(sample,privateKey),parts=code.split('.');
 parts[1]=Buffer.from(JSON.stringify({...sample,customer:'alt client'})).toString('base64url');
 assert.throws(()=>inspectLicense(parts.join('.'),publicKey),/Semnătura/);
});
test('semnătura unei alte chei nu deblochează licența',()=>{
 const another=generateKeyPairSync('ed25519');const code=createIssuerCode(sample,privateKey);
 assert.throws(()=>inspectLicense(code,another.publicKey),/Semnătura/);
});
test('licența expirată este refuzată chiar dacă are semnătură validă',()=>{
 const before={...sample,issuedAt:new Date(Date.now()-3*86400000).toISOString(),expiresAt:new Date(Date.now()-86400000).toISOString()};
 // Issuer normally does not create expired codes; for this test sign raw data to simulate a past issued license.
 const {sign}=require('node:crypto');const data=Buffer.from(JSON.stringify(before)).toString('base64url');
 const body='CARPATIA-V1.'+data;
 const code=body+'.'+sign(null,Buffer.from(body),privateKey).toString('base64url');
 assert.throws(()=>inspectLicense(code,publicKey),/expirat/);
});
test('fără cheie publică sau fără cod nu se deblochează aplicația comercială',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-license-'));
 try{const store=createLicenseStore({directory:dir,publicKey,developer:false});assert.equal(store.licensed(),false);assert.match(store.status().error,/Introdu/);
 const noKey=createLicenseStore({directory:dir,publicKey:null,developer:false});assert.equal(noKey.licensed(),false);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('activare persistată și revalidată la fiecare citire, fără a stoca cheia privată',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-license-'));
 try{const code=createIssuerCode(sample,privateKey);const store=createLicenseStore({directory:dir,publicKey,developer:false});
 assert.equal(store.activate(code).active,true);assert.equal(createLicenseStore({directory:dir,publicKey,developer:false}).status().licenseId,sample.licenseId);
 fs.writeFileSync(path.join(dir,'carpatia-license.txt'),'bad code');assert.equal(store.status().active,false);
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('modul dezvoltare este distinct de distribuția comercială',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-license-'));
 try{assert.equal(createLicenseStore({directory:dir,publicKey:null,developer:true}).status().developer,true);
 assert.equal(createLicenseStore({directory:dir,publicKey:null,developer:false}).licensed(),false)}finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('buildul comercial cere cheia publică, nu conține tools, include verificatorul',()=>{
 const p=JSON.parse(fs.readFileSync(path.join(__dirname,'..','package.json'),'utf8'));
 assert(p.build.files.includes('licensing.js'));assert(p.build.files.includes('license-public.pem'));assert(!p.build.files.some(x=>x.includes('private')||x.startsWith('tools/')));
 assert.match(fs.readFileSync(path.join(__dirname,'..','main.js'),'utf8'),/requireActiveLicense\(\)/);
 assert.match(fs.readFileSync(path.join(__dirname,'..','BUILD_INSTALLER.bat'),'utf8'),/check-release\.js/);
});
