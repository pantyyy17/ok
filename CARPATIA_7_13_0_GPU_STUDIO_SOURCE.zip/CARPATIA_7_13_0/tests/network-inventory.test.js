'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
const run=(extra=[])=>spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'network-inventory.ps1'),...extra],{encoding:'utf8',timeout:30000});
const probe=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-Command','exit 0'],{encoding:'utf8',timeout:30000});
const options={skip:probe.error?.code==='ENOENT'?'PowerShell unavailable; set CARPATIA_PWSH for native mock tests':false};
test('real network inventory script confirms success for recovery and excludes inactive/link-local addresses',options,()=>{
 assert.ifError(probe.error);assert.equal(probe.status,0,probe.stderr);
 const r=run();assert.ifError(r.error);assert.equal(r.status,0,r.stderr);
 const data=JSON.parse(r.stdout.trim().replace(/^\uFEFF/,''));
 assert.equal(data.success,true);
 assert.deepEqual(data.adapters,[{name:'Ethernet test',guid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',status:'Up',linkSpeed:'1 Gbps',ipv4:['192.0.2.10'],dns:['192.0.2.53']}]);
});
test('network inventory errors cannot be reported as successful recovery reads',options,()=>{
 const r=run(['-Fail']);assert.ifError(r.error);assert.equal(r.status,1);assert.match(r.stderr,/Simulated adapter inventory failure/);assert.equal(r.stdout.trim(),'');
});
