'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {mount}=require('../security-ui');
const markup=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const active={success:true,available:true,realTimeEnabled:true,tamperProtected:false,passive:false,backup:false};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
function harness({state=active,confirm=true,preview=false,api:overrides={}}={}){
 const nodes={};for(const match of markup.matchAll(/\bid="(security[\w-]+)"/g))nodes[match[1]]={textContent:'',disabled:false,dataset:{},setAttribute(name,value){this[name]=value}};
 let current={...state};const calls=[],permissions=[],messages=[],confirmations=[];
 const api=preview?null:{securityStatus:async()=>{calls.push(['status']);return {...current}},openSettings:async route=>calls.push(['settings',route]),tweakLibraryApply:async(...args)=>{calls.push(['apply',...args]);current={...current,realTimeEnabled:false,backup:true};return {success:true}},tweakLibraryRestore:async id=>{calls.push(['restore',id]);current={...current,realTimeEnabled:true,backup:false};return {success:true}},...overrides};
 const page=mount({api,document:{getElementById:id=>nodes[id]},requireNative:restore=>{permissions.push(restore);return true},task:async(_,fn)=>fn(),confirmDialog:async(...args)=>{confirmations.push(args);return confirm},showToast:text=>messages.push(text)});
 return {page,nodes,calls,permissions,messages,confirmations,setState:value=>{current=value}};
}
test('status read never changes protection and enables only the confirmed independent action',async()=>{
 const h=harness();assert.equal(h.calls.length,0);assert.equal(h.nodes.securityDisable.disabled,true);await h.page.load();
 assert.deepEqual(h.calls,[['status']]);assert.equal(h.nodes.securityDisable.disabled,false);assert.equal(h.nodes.securityRestore.disabled,true);assert.equal(h.nodes.securityBadge.textContent,'PROTECȚIE ACTIVĂ');h.page.destroy();
});
test('tamper, passive, unknown flags, absent original state and unavailable inventory cannot enable disable',async()=>{
 for(const state of [{...active,tamperProtected:true},{...active,tamperProtected:null},{...active,passive:true},{...active,passive:null},{...active,realTimeEnabled:null},{...active,backup:undefined},{...active,available:false},{...active,success:false}]){
  const h=harness({state});await h.page.load();assert.equal(h.nodes.securityDisable.disabled,true);await h.nodes.securityDisable.onclick();assert.equal(h.calls.filter(c=>c[0]==='apply').length,0);h.page.destroy();
 }
});
test('canceled explicit confirmation never calls a write',async()=>{
 const h=harness({confirm:false});await h.page.load();await h.nodes.securityDisable.onclick();assert.equal(h.confirmations.length,1);assert.match(h.confirmations[0][3],/Protecția calculatorului va fi redusă/);assert.equal(h.calls.filter(c=>c[0]==='apply').length,0);assert.equal(h.nodes.securityDisable.disabled,false);h.page.destroy();
});
test('state changing after confirmation blocks the write and explains the required recheck',async()=>{
 let reads=0;const h=harness({api:{securityStatus:async()=>++reads===1?active:{...active,tamperProtected:true}}});await h.page.load();await h.nodes.securityDisable.onclick();
 assert.equal(h.calls.filter(c=>c[0]==='apply').length,0);assert.match(h.nodes.securityMessage.textContent,/Starea protecției s-a schimbat/);assert.equal(h.nodes.securityDisable.disabled,true);h.page.destroy();
});
test('confirmed disable uses only the typed allowlisted rule then displays the real verified state',async()=>{
 const pending=deferred();let reads=0;
 const h=harness({api:{tweakLibraryApply:async(...args)=>{h.calls.push(['apply',...args]);return pending.promise},securityStatus:async()=>++reads<3?active:{...active,realTimeEnabled:false,backup:true}}});
 await h.page.load();const changing=h.nodes.securityDisable.onclick();await new Promise(setImmediate);assert.equal(h.nodes.securityDisable.disabled,true);assert.equal(h.nodes.securityBadge.textContent,'PROTECȚIE ACTIVĂ');pending.resolve({success:true});await changing;
 assert.deepEqual(h.calls.find(c=>c[0]==='apply'),['apply','library-cpu-022',true,'']);assert.equal(h.nodes.securityBadge.textContent,'PROTECȚIE OPRITĂ');assert.equal(h.nodes.securityRestore.disabled,false);assert.deepEqual(h.permissions,[false]);h.page.destroy();
});
test('success without real protection readback never claims Defender was disabled',async()=>{
 const h=harness({api:{tweakLibraryApply:async()=>({success:true})}});await h.page.load();await h.nodes.securityDisable.onclick();assert.equal(h.nodes.securityBadge.textContent,'PROTECȚIE ACTIVĂ');assert.match(h.nodes.securityMessage.textContent,/nu confirmă oprirea/);assert.equal(h.messages.length,0);h.page.destroy();
});
test('restoration uses the original and remains a license-independent recovery operation',async()=>{
 const h=harness({state:{...active,realTimeEnabled:false,backup:true}});await h.page.load();assert.equal(h.nodes.securityDisable.disabled,true);await h.nodes.securityRestore.onclick();
 assert.deepEqual(h.calls.find(c=>c[0]==='restore'),['restore','library-cpu-022']);assert.deepEqual(h.permissions,[true]);assert.equal(h.nodes.securityBadge.textContent,'PROTECȚIE ACTIVĂ');assert.equal(h.nodes.securityRestore.disabled,true);h.page.destroy();
});
test('failed restoration preserves visible original and displays the actual error',async()=>{
 const h=harness({state:{...active,realTimeEnabled:false,backup:true},api:{tweakLibraryRestore:async()=>{throw Error('Windows access denied; backup preserved')}}});await h.page.load();await h.nodes.securityRestore.onclick();assert.equal(h.nodes.securityRestore.disabled,false);assert.match(h.nodes.securityMessage.textContent,/access denied/);assert.equal(h.nodes.securityOriginal.textContent,'Original disponibil');h.page.destroy();
});
test('official settings open through a fixed route without mutation, including protected configurations',async()=>{
 const h=harness({state:{...active,tamperProtected:true}});await h.page.load();await h.nodes.securityOpen.onclick();assert.deepEqual(h.calls.at(-1),['settings','security']);assert.deepEqual(h.permissions,[true]);assert.equal(h.nodes.securityDisable.disabled,true);h.page.destroy();
});
test('late read cannot replace a newer state and destroyed module ignores pending responses',async()=>{
 const old=deferred();let count=0;const h=harness({api:{securityStatus:()=>++count===1?old.promise:Promise.resolve({...active,tamperProtected:true})}});
 const a=h.page.load(),b=h.page.load();await b;old.resolve(active);await a;assert.equal(h.page.getState().tamperProtected,true);assert.equal(h.nodes.securityDisable.disabled,true);
 const late=deferred(),x=harness({api:{securityStatus:()=>late.promise}}),read=x.page.load();x.page.destroy();late.resolve(active);await read;assert.equal(x.page.getState(),null);assert.equal(x.nodes.securityDisable.onclick,null);h.page.destroy();
});
test('preview and status errors stay explicit and recover after retry',async()=>{
 const preview=harness({preview:true});await preview.page.load();assert.equal(preview.nodes.securityDisable.disabled,true);assert.equal(preview.nodes.securityOpen.disabled,true);assert.match(preview.nodes.securityMessage.textContent,/aplicația Windows/);preview.page.destroy();
 let failed=true;const h=harness({api:{securityStatus:async()=>{if(failed)throw Error('Denied');return active}}});await h.page.load();assert.equal(h.nodes.securityDisable.disabled,true);assert.match(h.nodes.securityMessage.textContent,/Denied/);failed=false;await h.nodes.securityRefresh.onclick();assert.equal(h.nodes.securityDisable.disabled,false);h.page.destroy();
});
