'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {createWindowsRunner}=require('../windows-process');
function harness(){
 const calls=[],timers=new Map();let serial=0;
 const spawnProcess=(file,args,options)=>{
  const child=new EventEmitter();child.pid=600+calls.length;
  for(const stream of ['stdout','stderr']){child[stream]=new EventEmitter();child[stream].setEncoding=()=>{}}
  child.kill=()=>{child.killed=true};calls.push({file,args,options,child});return child;
 };
 const run=createWindowsRunner({platform:'win32',systemRoot:'C:\\Windows',spawnProcess,schedule:(f,ms)=>{const id=++serial;timers.set(id,{f,ms});return id},cancel:id=>timers.delete(id)});
 return {run,calls,timers,fire(){const [id,{f}]=timers.entries().next().value;timers.delete(id);f()}};
}
test('PowerShell runner parses fragmented UTF-8 JSON with BOM and uses fixed executable without shell',async()=>{
 const h=harness(),p=h.run(['-File','C:\\App Folder\\status.ps1']);const c=h.calls[0];
 c.child.stdout.emit('data','\uFEFF{"success":');c.child.stdout.emit('data','true}');c.child.emit('close',0);
 assert.deepEqual(await p,{success:true});assert.equal(h.timers.size,0);assert.equal(c.options.shell,false);
 assert.equal(c.file,'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe');assert.equal(c.args.at(-1),'C:\\App Folder\\status.ps1');
});
test('nonzero exit rejects even when stdout looks successful; diagnostics stay bounded',async()=>{
 const h=harness(),p=h.run([]),c=h.calls[0].child;c.stdout.emit('data','{"success":true}');c.stderr.emit('data','x'.repeat(12000));c.emit('close',1);
 await assert.rejects(p,e=>e.message.length===1500);assert.equal(h.timers.size,0);
});
test('invalid JSON cannot become a successful operation',async()=>{
 const h=harness(),p=h.run([]);h.calls[0].child.stdout.emit('data','not json');h.calls[0].child.emit('close',0);await assert.rejects(p,/date nevalide/);
});
test('spawn failure rejects and releases timers without trying to kill nonexistent process',async()=>{
 const h=harness(),p=h.run([]);h.calls[0].child.emit('error',Error('ENOENT'));await assert.rejects(p,/ENOENT/);assert.equal(h.calls.length,1);assert.equal(h.timers.size,0);
});
test('timeout waits for entire tree termination before releasing caller; late success is ignored',async()=>{
 const h=harness(),p=h.run([],90);let settled=false;p.then(()=>settled=true,()=>settled=true);
 h.fire();assert.equal(h.calls.length,2);assert.deepEqual(h.calls[1].args,['/PID','600','/T','/F']);
 h.calls[0].child.stdout.emit('data','{"success":true}');h.calls[0].child.emit('close',0);await Promise.resolve();assert.equal(settled,false);
 h.calls[1].child.emit('close',0);await assert.rejects(p,/nu a răspuns/);assert.equal(h.timers.size,0);
 const next=h.run([]);h.calls[2].child.stdout.emit('data','{}');h.calls[2].child.emit('close',0);await next;
});
test('output limit terminates once, ignoring later output and close events',async()=>{
 const h=harness(),p=h.run([]),c=h.calls[0].child;c.stdout.emit('data','x'.repeat(750001));c.stdout.emit('data','again');c.emit('close',0);assert.equal(h.calls.length,2);
 h.calls[1].child.emit('close',0);await assert.rejects(p,/prea mare/);
});
test('failed tree termination blocks further launches in this app session',async()=>{
 const h=harness(),p=h.run([]);h.fire();h.calls[1].child.emit('close',1);await assert.rejects(p,/nu este confirmată/);await assert.rejects(h.run([]),/Repornește Windows/);assert.equal(h.calls.length,2);
});
test('taskkill launch error also blocks subsequent operations',async()=>{
 const h=harness(),p=h.run([]);h.fire();h.calls[1].child.emit('error',Error('denied'));await assert.rejects(p,/nu este confirmată/);await assert.rejects(h.run([]),/Repornește Windows/);
});
test('hung taskkill has a bounded wait and never reports successful cancellation',async()=>{
 const h=harness(),p=h.run([]);h.fire();assert.equal([...h.timers.values()][0].ms,10000);h.fire();await assert.rejects(p,/nu este confirmată/);assert.ok(h.calls[1].child.killed);await assert.rejects(h.run([]));assert.equal(h.timers.size,0);
});
test('invalid arguments and non-Windows environments never spawn',async()=>{
 const h=harness();await assert.rejects(h.run([{}]));await assert.rejects(h.run([],0));assert.equal(h.calls.length,0);
 await assert.rejects(createWindowsRunner({platform:'linux',spawnProcess:()=>{throw Error('must not spawn')}})([]),/Windows 10/);
});

test('JSON primitives and arrays are not valid native operation responses',async()=>{
 for(const response of ['null','true','1','"ok"','[]']){
  const h=harness(),p=h.run([]);h.calls[0].child.stdout.emit('data',response);h.calls[0].child.emit('close',0);await assert.rejects(p,/date nevalide/);
 }
});
test('NUL arguments are rejected before process creation',async()=>{
 const h=harness();await assert.rejects(h.run(['unsafe\0value']),/Parametri/);assert.equal(h.calls.length,0);
});
test('stream read failures terminate the process tree before releasing the caller',async()=>{
 for(const stream of ['stdout','stderr']){
  const h=harness(),p=h.run([]);let settled=false;p.catch(()=>settled=true);
  h.calls[0].child[stream].emit('error',Error('broken stream'));await Promise.resolve();assert.equal(settled,false);assert.equal(h.calls.length,2);
  h.calls[1].child.emit('close',0);await assert.rejects(p,/Citirea/);assert.equal(h.timers.size,0);
 }
});
