'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const path=require('node:path');
test('PowerShell Registry and legacy engine guards execute without Windows mutations',t=>{
 const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'registry-legacy-guards.ps1')],{encoding:'utf8',timeout:30000});
 if(result.error?.code==='ENOENT'){t.skip('PowerShell unavailable; set CARPATIA_PWSH to execute engine guards.');return;}
 assert.ifError(result.error);
 assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));
 assert.equal(report.success,true);
 assert.ok(report.assertions>=38,'meaningful guard assertions executed');
});
