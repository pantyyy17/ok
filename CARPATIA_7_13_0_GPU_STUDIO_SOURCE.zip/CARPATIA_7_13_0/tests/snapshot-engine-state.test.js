'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
const env={...process.env};
const probe=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-Command','exit 0'],{env,encoding:'utf8',timeout:30000});
test('snapshot native writes resume and undo partial service/MTU changes while rejecting external drift',{
 skip:probe.error?.code==='ENOENT'?'PowerShell unavailable; set CARPATIA_PWSH to run native mocked regressions':false
},()=>{
 assert.ifError(probe.error);
 assert.equal(probe.status,0,probe.stderr);
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'snapshot-engine-state.ps1')],{env,encoding:'utf8',timeout:30000});
 assert.ifError(result.error);
 assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));
 assert.equal(report.success,true);
 assert.equal(report.assertions,19);
});
