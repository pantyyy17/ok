$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../tweak-native-ops.ps1')
$script:assertions=0
function Assert($value,$label){if(-not $value){throw $label};$script:assertions++}
function Reject($fn,$label){$rejected=$false;try{& $fn | Out-Null}catch{$rejected=$true};Assert $rejected $label}
$script:plans='Power Scheme GUID: 381b4222-f694-41f0-9685-ff5bb260df2e (Balanced)'
function Invoke-Tool($Name,$Arguments){if($script:plans -eq 'DENIED'){throw 'Access denied'};return $script:plans}
$power=@{type='power-active';value='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'}
Assert (-not (Get-NativeApplicability $power).applicable) 'Modern Standby without High Performance is explicitly not applicable'
$script:plans+=' Power Scheme GUID: 8C5E7FDA-E8BF-4A96-9A85-A6E23A8C635C (High Performance)'
Assert (Get-NativeApplicability $power).applicable 'Available High Performance scheme is accepted without changing it'
$script:plans='unrecognized response'
Reject {Get-NativeApplicability $power} 'Malformed power inventory cannot be treated as unsupported'
$script:plans='DENIED'
Reject {Get-NativeApplicability $power} 'Power permission failure remains fatal'
$script:settingPresent=$true
function Test-Path {param($LiteralPath,$PathType,$ErrorAction)
 if($LiteralPath -notlike 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\*'){throw 'Unexpected Registry target'}
 return $script:settingPresent
}
$setting=@{type='power-value';subgroup='54533251-82be-4824-96c1-47b60b740d00';setting='36687f9e-e3a5-4dbf-b1dc-15eb381c6863'}
Assert (Get-NativeApplicability $setting).applicable 'Known AC setting remains available'
$script:settingPresent=$false
Assert (-not (Get-NativeApplicability $setting).applicable) 'Absent AC setting is explicitly omitted'
$script:serviceMode='installed'
function Get-Service {param($Name,$ErrorAction)
 if($script:serviceMode -eq 'missing'){
  $errorRecord=New-Object System.Management.Automation.ErrorRecord ([Exception]::new('Missing service')),'NoServiceFoundForGivenName,Microsoft.PowerShell.Commands.GetServiceCommand',([System.Management.Automation.ErrorCategory]::ObjectNotFound),$Name
  throw $errorRecord
 }
 if($script:serviceMode -eq 'denied'){throw 'Access denied'}
 return [pscustomobject]@{Name=$Name;Status='Running'}
}
$service=@{type='service';services=@(@{name='WMPNetworkSvc'})}
Assert (Get-NativeApplicability $service).applicable 'Existing auxiliary service can be previewed'
$script:serviceMode='missing'
Assert (-not (Get-NativeApplicability $service).applicable) 'Missing optional service is omitted without creating it'
$script:serviceMode='denied'
Reject {Get-NativeApplicability $service} 'Service access failure remains fatal'
@{success=$true;assertions=$script:assertions;scope='Real applicability function; mocked read-only Windows inventory; no writes.'} | ConvertTo-Json -Compress
