'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {initialize,issuerStatus,configurePublicKey,exportPublicKey,publisherStatus,issueLicense,mustBeExternal}=require('../tools/issuer-core');
const {inspectLicense}=require('../licensing');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
function temporary(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-editor-'));t.after(()=>fs.rmSync(dir,{force:true,recursive:true}));return dir}
test('cheile private nu pot fi create în proiect sau la rădăcina discului',()=>{assert.throws(()=>mustBeExternal(root),/AFARA/);assert.throws(()=>mustBeExternal(path.join(root,'private')),/AFARA/);assert.throws(()=>mustBeExternal(path.parse(root).root),/rădăcina/)});
test('creează pereche Ed25519 și NU permite rescrierea cheii private',t=>{const dir=temporary(t);assert.equal(issuerStatus(dir).ready,false);initialize(dir);assert.equal(issuerStatus(dir).ready,true);assert.throws(()=>initialize(dir),/există/);const pem=fs.readFileSync(path.join(dir,'carpatia-private.pem'),'utf8');assert.match(pem,/BEGIN PRIVATE KEY/);assert.equal(crypto.createPrivateKey(pem).asymmetricKeyType,'ed25519')});
test('emite cod autentic, semnat și permanent; păstrează doar metadate în istoric',t=>{const dir=temporary(t);initialize(dir);const res=issueLicense(dir,{customer:'Client A',days:null});const pub=fs.readFileSync(path.join(dir,'carpatia-public.pem'),'utf8');const verified=inspectLicense(res.code,pub);assert.equal(verified.customer,'Client A');assert.equal(verified.expiresAt,null);assert(fs.existsSync(path.join(dir,res.id+'.txt')));const history=fs.readFileSync(path.join(dir,'issued-licenses.json'),'utf8');assert(!history.includes(res.code));assert(!history.includes('PRIVATE KEY'));assert.equal(issuerStatus(dir).issuedCount,1)});
test('respinge nume sau durate invalide și emite coduri distincte',t=>{const dir=temporary(t);initialize(dir);assert.throws(()=>issueLicense(dir,{customer:'X'}),/Numele/);assert.throws(()=>issueLicense(dir,{customer:'Client A',days:-1}),/Durată/);assert.throws(()=>issueLicense(dir,{customer:'Client A\nB'}),/Numele/);const a=issueLicense(dir,{customer:'Client A',days:365}),b=issueLicense(dir,{customer:'Client A',days:365});assert.notEqual(a.id,b.id);assert.equal(issuerStatus(dir).issuedCount,2)});
test('arată folderul separat și amprenta publică fără să expună cheia privată',t=>{
 const dir=temporary(t);initialize(dir);const status=issuerStatus(dir);
 assert.equal(status.privateDir,fs.realpathSync(dir));assert.equal(status.publicFile,path.join(fs.realpathSync(dir),'carpatia-public.pem'));
 assert.match(status.fingerprint,/^(?:[a-f0-9]{2}:){31}[a-f0-9]{2}$/);assert.match(status.publicKey,/BEGIN PUBLIC KEY/);
 assert(!JSON.stringify(status).includes('BEGIN PRIVATE KEY'));assert.equal(issuerStatus(dir).fingerprint,status.fingerprint);
});
test('exportul public este repetabil și nu suprascrie altă cheie sau un secret',t=>{
 const dir=temporary(t),other=temporary(t);initialize(dir);initialize(other);
 const output=path.join(dir,'public-only-export.pem');const result=exportPublicKey(dir,output);
 assert.equal(result.fingerprint,issuerStatus(dir).fingerprint);assert.equal(exportPublicKey(dir,output).filename,output);
 assert.match(fs.readFileSync(output,'utf8'),/^-----BEGIN PUBLIC KEY-----/);
 assert.throws(()=>exportPublicKey(other,output),/ALTĂ cheie/);assert.equal(publisherStatus(issuerStatus(dir).publicKey,output).state,'matching');
 const privateFile=path.join(dir,'carpatia-private.pem'),original=fs.readFileSync(privateFile,'utf8');
 assert.throws(()=>exportPublicKey(dir,privateFile),/ALTĂ cheie/);assert.equal(fs.readFileSync(privateFile,'utf8'),original);
});
test('verificarea buildului distinge cheia lipsă, invalidă și a altui editor',t=>{
 const dir=temporary(t),other=temporary(t);initialize(dir);initialize(other);const pub=issuerStatus(dir).publicKey,output=path.join(dir,'installer-public.pem');
 assert.equal(publisherStatus(pub,output).state,'missing');fs.writeFileSync(output,'invalid');assert.equal(publisherStatus(pub,output).state,'invalid');
 fs.writeFileSync(output,issuerStatus(other).publicKey);assert.equal(publisherStatus(pub,output).state,'mismatch');
 fs.writeFileSync(output,pub);assert.equal(publisherStatus(pub,output).configured,true);
});
test('un PEM privat nu poate fi folosit drept fișier public al editorului sau installerului',t=>{
 const dir=temporary(t);initialize(dir);const publicFile=path.join(dir,'carpatia-public.pem'),pub=fs.readFileSync(publicFile,'utf8'),secret=fs.readFileSync(path.join(dir,'carpatia-private.pem'),'utf8');
 const installerFile=path.join(dir,'bad-installer-public.pem');fs.writeFileSync(installerFile,secret);
 assert.equal(publisherStatus(pub,installerFile).state,'invalid');
 fs.writeFileSync(publicFile,secret);const status=issuerStatus(dir);assert.equal(status.ready,false);assert.equal(status.publicKey,null);assert.match(status.error,/NUMAI cheia PUBLICĂ/);
 assert.throws(()=>issueLicense(dir,{customer:'Client test'}),/NUMAI cheia PUBLICĂ/);
});
test('CLI exportă fișierul public și verifică starea buildului',t=>{
 const dir=temporary(t);initialize(dir);const output=path.join(dir,'cli-public.pem');
 const exported=spawnSync(process.execPath,[path.join(root,'tools/license-cli.js'),'export-public','--private-dir',dir,'--out',output],{encoding:'utf8'});
 assert.equal(exported.status,0,exported.stderr);assert.equal(fs.readFileSync(output,'utf8'),issuerStatus(dir).publicKey);
 const status=spawnSync(process.execPath,[path.join(root,'tools/license-cli.js'),'status','--private-dir',dir],{encoding:'utf8'});
 assert.equal(status.status,issuerStatus(dir).buildReady?0:1,status.stderr);assert(!status.stdout.includes('BEGIN PRIVATE KEY'));
});
test('managerul este sursă de editor și nu intră în installerul clientului',()=>{const manifest=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));assert(!manifest.build.files.some(name=>name.includes('tools')||name.includes('LICENTA_MANAGER')));const appCode=fs.readFileSync(path.join(root,'main.js'),'utf8');assert.match(appCode,/requireActiveLicense/);assert(!appCode.includes('carpatia-private.pem'))});
