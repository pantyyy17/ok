$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'tweak-native-ops.ps1')
$script:assertions=0
$script:writes=0
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}

# Exercise the actual snapshot Write branch with only native IO intercepted.
# AST extraction avoids executing the Windows identity/admin and request setup.
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'snapshot-engine.ps1'),[ref]$tokens,[ref]$errors)
Assert (@($errors).Count -eq 0) 'snapshot engine parses'
$definition=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Validate-Native'},$true)
Assert ($null -ne $definition) 'native target validation located'
$parameters=(@($definition.Parameters | ForEach-Object {$_.Extent.Text}) -join ',')
$body=$definition.Body.Extent.Text
Set-Item -Path Function:script:Validate-Native -Value ([scriptblock]::Create(('param('+ $parameters +')'+$body.Substring(1,$body.Length-2))))
$writeIf=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Clauses[0].Item1.Extent.Text -eq "$('$r').kind -eq 'registry'"},$true))[-1]
Assert ($null -ne $writeIf) 'real snapshot Write branch located'
$nativeBody=$writeIf.ElseClause.Extent.Text
$nativeWrite=[scriptblock]::Create($nativeBody.Substring(1,$nativeBody.Length-2))
function Write-Native($o,$v){$script:writes++;$script:current=$v}
function Capture-Native($o){return ,$script:current}
function Emit($value){throw 'Unexpected already-complete state'}

function Test-Partial($operation,$before,$target,$partial,$external,$label){
 $o=$operation
 foreach($undo in @($false,$true)){
  $direction=if($undo){'undo'}else{'restore'}
  $r=if($undo){@{target=$before;expected=$target}}else{@{target=$target;expected=$before}}
  $script:current=$partial;$script:writes=0
  & $nativeWrite
  Assert ($script:writes -eq 1) ($label+' partial '+$direction+' invokes the write')
  Assert ((Canonical-Native $script:current) -ceq (Canonical-Native $r.target)) ($label+' partial '+$direction+' verifies its destination')
  $script:current=$external;$script:writes=0;$failed=$false
  try{& $nativeWrite}catch{$failed=$true}
  Assert $failed ($label+' external change rejects '+$direction)
  Assert ($script:writes -eq 0) ($label+' external change causes zero writes during '+$direction)
 }
}

$service=@{type='service';services=@(@{name='WSearch';start=4;running=$false})}
$before=@(@{name='WSearch';start=2;running=$true;delayedExists=$true;delayed=1})
$target=@(@{name='WSearch';start=4;running=$false;delayedExists=$true;delayed=0})
$partial=@(@{name='WSearch';start=4;running=$true;delayedExists=$true;delayed=0})
$external=@(@{name='WSearch';start=3;running=$true;delayedExists=$true;delayed=0})
Test-Partial $service $before $target $partial $external 'service'
$mtu=@{type='mtu';adapterGuid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}
Test-Partial $mtu @{active=1400;persistent=1400} @{active=1500;persistent=1500} @{active=1400;persistent=1500} @{active=1300;persistent=1500} 'MTU'
@{success=$true;assertions=$script:assertions} | ConvertTo-Json -Compress
