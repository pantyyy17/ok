'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {compatibility} = require('../compatibility');
const catalog = require('../tweak-library-core');
const {descriptor} = require('../dashboard-profiles');

test('generic AC processor settings are available on desktop and Intel/AMD laptops', () => {
 for (const hardware of [
  {cpu:'Intel Core i7',formFactor:'Desktop',ramGB:32,osBuild:22631},
  {cpu:'Intel Core i7',formFactor:'Laptop',ramGB:16,osBuild:22631},
  {cpu:'AMD Ryzen 7',formFactor:'Laptop',ramGB:16,osBuild:22631}
 ]) {
  for (const step of descriptor('cpu', 'ultra').steps) {
   assert.notEqual(compatibility(catalog.getRule(step.id), hardware).state, 'incompatible', step.id);
  }
 }
});

test('Google DNS is applicable to a chosen Wi-Fi adapter', () => {
 assert.equal(compatibility(catalog.getRule('library-net-003'), {networkKinds:['WiFi']}).state, 'compatible');
});

test('incomplete inventories do not hide settings as hardware mismatches', () => {
 for (const cpu of ['Unknown', 'unavailable', 'Generic Processor', '']) {
  assert.equal(compatibility({conditions:'cpu:AMD'}, {cpu}).state, 'unknown');
 }
 for (const gpu of [['Microsoft Basic Display Adapter'], ['Intel Iris', 'Unknown'], [null]]) {
  assert.equal(compatibility({conditions:'gpu:NVIDIA'}, {gpu}).state, 'unknown');
 }
 assert.equal(compatibility({conditions:'gpu:NVIDIA'}, {gpu:['Intel Iris', 'GeForce RTX 4070']}).state, 'compatible');
 assert.equal(compatibility({conditions:'formFactor:Laptop'}, {formFactor:'Unknown'}).state, 'unknown');
 assert.equal(compatibility({conditions:'network:WiFi'}, {networkKinds:['Ethernet', 'Unknown']}).state, 'unknown');
 assert.equal(compatibility({conditions:'storage:SSD'}, {storage:[null]}).state, 'unknown');
 assert.equal(compatibility({conditions:'storage:SSD'}, {storage:'SSD'}).state, 'unknown');
 assert.equal(compatibility({conditions:'ram:>8GB'}, {ramGB:0}).state, 'unknown');
});

test('identified hardware mismatch still blocks incompatible application', () => {
 assert.equal(compatibility({conditions:'cpu:AMD'}, {cpu:'Intel Core i7'}).state, 'incompatible');
 assert.equal(compatibility({conditions:'gpu:NVIDIA'}, {gpu:['Intel Iris', 'AMD Radeon']} ).state, 'incompatible');
 assert.equal(compatibility({conditions:'network:WiFi'}, {networkKinds:['Ethernet']}).state, 'incompatible');
 assert.equal(compatibility({conditions:'storage:SSD'}, {storage:[{media:'HDD',bus:'SATA'}]}).state, 'incompatible');
 assert.equal(compatibility({id:'library-gpu-063'}, {osBuild:18363}).state, 'incompatible');
});

test('Small Memory Dump config writes Windows minidump mode rather than full dump mode', () => {
 const rule = catalog.getRule('library-adv-016');
 assert.equal(rule.entries.find(entry => entry.name === 'CrashDumpEnabled').value, 3);
 assert.match(rule.sourceCommand, /\/d 3 \/f/);
});

test('fixed display driver targets cannot apply to the wrong GPU and existing originals remain restorable', () => {
 const rules = require('../tweak-library.json');
 const blocked = rules.filter(rule => rule.applyBlocked);
 assert.deepEqual(blocked.map(rule => rule.id).sort(), ['library-gpu-001','library-gpu-002','library-gpu-011','library-gpu-047','library-gpu-055']);
 for (const rule of blocked) {
  assert.throws(() => catalog.authorize(rule.id, 'Apply', true), error => error.message === rule.applyBlocked);
  assert.equal(catalog.authorize(rule.id, 'Restore'), rule.id);
  const result = compatibility(rule, {gpu:['NVIDIA GeForce RTX 4070', 'AMD Radeon'],osBuild:22631});
  assert.equal(result.state, 'incompatible');
  assert.equal(result.reason, rule.applyBlocked);
  assert.ok(catalog.publicCatalog().some(row => row.id === rule.id && row.applyBlocked));
 }
 assert.equal(catalog.publicCatalog().length, 215);
});
