'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),read=name=>fs.readFileSync(path.join(root,name),'utf8');
test('performance and individual tweaks have one lightning navigation destination',()=>{
 const html=read('index.html'),nav=html.match(/<nav id="sidebarNav"[\s\S]*?<\/nav>/)[0];
 const controls=[...nav.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)].filter(match=>/data-view="(?:performance|tweaks)"/.test(match[1]));
 assert.equal(controls.length,1);assert.match(controls[0][1],/data-view="tweaks"/);assert.match(controls[0][2],/nav-icon">ϟ/);assert.match(controls[0][2],/Performanță &amp; Tweaks/);
 assert.doesNotMatch(html,/id="view-performance"|data-jump="performance"/);
 const section=html.match(/<section class="view" id="view-tweaks">[\s\S]*?<\/section>/)[0];
 for(const id of ['tweakRows','loadServices','servicesList','openCpuCatalog'])assert.match(section,new RegExp('id="'+id+'"'));
 for(const role of ['Încărcare aplicații · SysMain','Căutare Windows · WSearch','Diagnostic Windows · DiagTrack'])assert(section.includes(role),role);
});
test('command search finds Windows services under the unified performance destination',()=>{
 const calls=[];
 class Element{
  constructor(text=''){this.textContent=text;this.children=[];this.value='';this.dataset={};this.handlers={};const states=new Set(['hidden']);this.classList={add:x=>states.add(x),remove:x=>states.delete(x),contains:x=>states.has(x),toggle:(x,on)=>on?states.add(x):states.delete(x)}}
  append(...items){this.children.push(...items)}replaceChildren(...items){this.children=items}focus(){}addEventListener(type,fn){this.handlers[type]=fn}
 }
 const button=new Element();button.dataset.view='tweaks';button.querySelector=selector=>new Element(selector==='strong'?'Performanță & Tweaks':'Setări și servicii Windows');button.click=()=>{calls.push('tweaks');button.classList.add('active');button.handlers.click?.()};
 const ids=Object.fromEntries(['commandBackdrop','commandSearch','commandResults','commandOpen','commandClose','modalBackdrop','workspaceLocation'].map(id=>[id,new Element()]));
 const document={activeElement:new Element(),getElementById:id=>ids[id],querySelectorAll:()=>[button],createElement:()=>new Element(),addEventListener(){}};
 vm.runInNewContext(read('interface-shell.js'),{document,Event:class{}});
 ids.commandOpen.onclick();ids.commandSearch.value='SysMain';ids.commandSearch.oninput();
 const result=ids.commandResults.children[0];assert.equal(result.children[0].textContent,'Performanță & Tweaks');result.onclick();
 assert.deepEqual(calls,['tweaks']);assert.equal(ids.workspaceLocation.textContent,'Performanță & Tweaks');
});
