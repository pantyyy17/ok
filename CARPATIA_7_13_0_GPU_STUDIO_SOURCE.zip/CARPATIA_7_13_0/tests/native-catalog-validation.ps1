$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
. (Join-Path $project 'registry-values.ps1')
. (Join-Path $project 'tweak-native-ops.ps1')
$script:assertions=0
function Assert($value,$label){if(-not $value){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true};Assert $failed $label}

# Run the actual ULTRA branches against temporary files and an in-memory Registry.
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('CarpatiaCatalog-'+[guid]::NewGuid().ToString('N'))
$oldLocalData=$env:LOCALAPPDATA
$global:CarpatiaMockValues=@{};$global:CarpatiaMockWrites=0;$global:CarpatiaMockReads=0
try{
 New-Item -ItemType Directory -Path $testRoot | Out-Null
 foreach($name in @('engine.ps1','tweaks.json','registry-values.ps1')){Copy-Item -LiteralPath (Join-Path $project $name) -Destination $testRoot}
 @'
function Read-Value($entry){
 $global:CarpatiaMockReads++
 $key=([string]$entry.path+'|'+[string]$entry.name).ToLowerInvariant()
 if($global:CarpatiaMockValues.ContainsKey($key)){return $global:CarpatiaMockValues[$key]}
 return @{path=$entry.path;name=$entry.name;exists=$true;kind='None';value=@(1)}
}
function Set-Value($row){
 Assert-RegistryValue $row
 $global:CarpatiaMockWrites++
 $global:CarpatiaMockValues[([string]$row.path+'|'+[string]$row.name).ToLowerInvariant()]=$row
}
'@ | Add-Content -LiteralPath (Join-Path $testRoot 'registry-values.ps1') -Encoding UTF8
 $env:LOCALAPPDATA=$testRoot
 $engine=Join-Path $testRoot 'engine.ps1'
 $backup=Join-Path $testRoot 'TweakRomania/Backups/ultra-latest.json'
 Reject {& $engine -Action Apply -Ids game_dvr} 'ULTRA rejects an unsupported original Registry kind'
 Assert ($global:CarpatiaMockWrites -eq 0 -and -not (Test-Path -LiteralPath $backup)) 'unsupported originals cause no writes or unusable journal'
 $catalog=Get-Content -LiteralPath (Join-Path $project 'tweaks.json') -Raw | ConvertFrom-Json
 $rule=@($catalog | Where-Object {$_.id -ceq 'game_dvr'})[0]
 $rows=@();foreach($entry in $rule.entries){$rows+=@{id=$rule.id;path=$entry.path;name=$entry.name;existed=$false;type=$null;value=$null}}
 $journal=@{version=2;ids=@($rule.id);values=@($rows[0])}
 function Save-TestJournal { $journal | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $backup -Encoding UTF8 }
 Save-TestJournal
 $bytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($backup));$global:CarpatiaMockReads=0
 Reject {& $engine -Action Restore} 'truncated ULTRA originals cannot be reported as restored'
 Assert ($global:CarpatiaMockWrites -eq 0 -and $global:CarpatiaMockReads -eq 0) 'truncated journal rejected before Registry IO'
 Assert ([Convert]::ToBase64String([IO.File]::ReadAllBytes($backup)) -ceq $bytes) 'truncated original journal is retained byte for byte'
 $journal.values=@($rows[0],$rows[0]);Save-TestJournal
 Reject {& $engine -Action Restore} 'duplicate originals cannot hide a missing ULTRA target'
 Assert ($global:CarpatiaMockWrites -eq 0) 'duplicate originals cause no Registry writes'
 $journal.values=$rows;$journal.ids=@($rule.id,$rule.id);Save-TestJournal
 Reject {& $engine -Action Restore} 'duplicate selected IDs cannot weaken restore completeness'
 $journal.ids=@($rule.id);$journal.values=$rows;Save-TestJournal
 foreach($entry in $rule.entries){
  $path=$entry.path.Replace('HKCU:\','HKCU\')
  $global:CarpatiaMockValues[($path+'|'+$entry.name).ToLowerInvariant()]=@{path=$path;name=$entry.name;exists=$true;kind=$entry.type;value=$entry.value}
 }
 $report=(& $engine -Action Restore) | ConvertFrom-Json
 Assert ($report.success -and $report.restored -eq $rows.Count) 'complete ULTRA original set restores through the real branch'
 Assert ($global:CarpatiaMockWrites -eq $rows.Count -and -not (Test-Path -LiteralPath $backup)) 'complete restore archives only after all readbacks'
 foreach($unsafe in @([long]9007199254740992,[long]-9007199254740992)){
  $global:CarpatiaMockWrites=0
  for($i=0;$i -lt @($rule.entries).Count;$i++){
   $entry=$rule.entries[$i];$path=$entry.path.Replace('HKCU:\','HKCU\')
   $global:CarpatiaMockValues[($path+'|'+$entry.name).ToLowerInvariant()]=@{path=$path;name=$entry.name;exists=$true;kind='QWord';value=if($i -eq 0){[long]7}else{$unsafe}}
  }
  Reject {& $engine -Action Apply -Ids game_dvr} 'unsafe signed QWORD original rejects real ULTRA Apply'
  Assert ($global:CarpatiaMockWrites -eq 0 -and -not (Test-Path -LiteralPath $backup)) 'unsafe later QWORD creates neither Registry writes nor journal'
 }
 foreach($safe in @([long]9007199254740991,[long]-9007199254740991)){
  $global:CarpatiaMockWrites=0
  foreach($entry in $rule.entries){
   $path=$entry.path.Replace('HKCU:\','HKCU\')
   $global:CarpatiaMockValues[($path+'|'+$entry.name).ToLowerInvariant()]=@{path=$path;name=$entry.name;exists=$true;kind='QWord';value=$safe}
  }
  $report=(& $engine -Action Apply -Ids game_dvr) | ConvertFrom-Json
  Assert ($report.success -and $global:CarpatiaMockWrites -eq $rows.Count) 'safe signed QWORD boundary permits real ULTRA Apply'
  $saved=Get-Content -LiteralPath $backup -Raw | ConvertFrom-Json
  Assert ($saved.values[0].value -eq $safe -and $saved.values[0].value -is [long]) 'safe QWORD boundary is journaled exactly'
  $report=(& $engine -Action Restore) | ConvertFrom-Json
  $path=$rule.entries[0].path.Replace('HKCU:\','HKCU\');$key=($path+'|'+$rule.entries[0].name).ToLowerInvariant()
  Assert ($report.success -and $global:CarpatiaMockValues[$key].kind -ceq 'QWord' -and $global:CarpatiaMockValues[$key].value -eq $safe) 'safe signed QWORD original restores with its exact kind and value'
 }
}finally{
 $env:LOCALAPPDATA=$oldLocalData
 if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}
 Remove-Variable -Scope Global -Name CarpatiaMockValues,CarpatiaMockWrites,CarpatiaMockReads -ErrorAction SilentlyContinue
}

# Exercise original validation from the real Registry-library capture block.
$library=Get-Content -LiteralPath (Join-Path $project 'tweak-library.ps1') -Raw
$start=$library.IndexOf('$values=@();foreach');$end=$library.IndexOf('$already=$true',$start)
Assert ($start -ge 0 -and $end -gt $start) 'real library capture block located'
$capture=[scriptblock]::Create($library.Substring($start,$end-$start))
$rule=@{entries=@(@{path='HKCU\Software\Mock';name='first'},@{path='HKCU\Software\Mock';name='second'})}
function Read-Value($entry){return @{path=$entry.path;name=$entry.name;exists=$true;kind=if($entry.name -eq 'first'){'String'}else{'None'};value='original'}}
Reject {& $capture} 'library rejects an unsupported later original before creating a journal'
foreach($value in @([long]9007199254740992,[long]-9007199254740992)){
 $script:libraryOriginal=$value
 function Read-Value($entry){return @{path=$entry.path;name=$entry.name;exists=$true;kind='QWord';value=if($entry.name -eq 'first'){[long]7}else{$script:libraryOriginal}}}
 Reject {& $capture} 'library rejects unsafe signed QWORD before journal or writes'
}
foreach($value in @([long]9007199254740991,[long]-9007199254740991)){
 $script:libraryOriginal=$value
 & $capture
 Assert ($true) 'library accepts safe signed QWORD original boundary'
}
foreach($value in @([long]9007199254740992,[long]-9007199254740992,[long]::MaxValue,[long]::MinValue)){
 Assert-RegistryValue @{path='HKCU\Software\Mock';name='Historical';exists=$true;kind='QWord';value=$value}
 Assert ($true) 'historical QWORD restore still accepts the full Int64 range'
}

# Native original validation must happen before Desired-Native can conceal it.
$native=Get-Content -LiteralPath (Join-Path $project 'tweak-native.ps1') -Raw
$start=$native.LastIndexOf('$before=Capture-Native $o');$end=$native.IndexOf('if((Canonical-Native $before)',$start)
Assert ($start -ge 0 -and $end -gt $start) 'real native Apply capture block located'
$capture=[scriptblock]::Create($native.Substring($start,$end-$start))
$script:mockBefore='false';$script:desiredCalls=0
function Capture-Native($operation){return $script:mockBefore}
function Desired-Native($operation,$original){$script:desiredCalls++;return $operation.value}
$o=@{type='defender';property='DisableRealtimeMonitoring';value=$true}
Reject {& $capture} 'native Apply rejects string boolean original before it is replaced'
Assert ($script:desiredCalls -eq 0) 'invalid native original never reaches desired-state conversion'
$script:mockBefore=$false
& $capture
Assert ($script:desiredCalls -eq 1) 'valid native original and desired boolean remain accepted'
$o.value='false'
Reject {& $capture} 'invalid desired native value is rejected before journaling or writes'
@{success=$true;assertions=$script:assertions} | ConvertTo-Json -Compress
