const test=require('node:test');
const assert=require('node:assert/strict');
const catalog=require('../tweaks.json');
const {plan}=require('../smart-engine');
test('all appearance rules are recovery-only and absent from every automatic profile',()=>{
 const snapshot={hardware:{osBuild:22631,ramGB:8,gpu:['Intel UHD']},registry:{success:true,backup:false,matchingIds:[]}};
 const result=plan(snapshot,catalog);
 const retired=catalog.filter(t=>t.restoreOnly);
 assert.ok(retired.length>=20);
 assert.ok(catalog.filter(t=>['visual','desktop'].includes(t.category)).every(t=>t.restoreOnly));
 for(const t of retired){
  assert.ok(!result.suggestions.some(x=>x.id===t.id),t.id);
  assert.ok(!result.maxSuggestions.some(x=>x.id===t.id),t.id);
 }
 assert.ok(result.suggestions.some(t=>t.id==='game_mode'));
});
