'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createManualSnapshot}=require('../backup-core'),catalog=require('../tweak-library-core');
function fixture(t,overrides={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-capture-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const rule=catalog.getRule('library-cpu-035');
 const opts={dataDir:()=>dir,backupDir:()=>path.join(dir,'legacy'),catalog:()=>[rule],ruleFor:id=>catalog.getRule(id),identity:async()=>'a'.repeat(64),context:async()=>({success:true,adapters:[]}),read:async()=>({success:true,current:rule.entries.map(e=>({...e,exists:true,kind:'DWord',value:0}))}),save:(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(value))},...overrides};
 return {dir,capture:createManualSnapshot(opts)};
}
test('manual capture creates a hash-verified restorable snapshot and complete report',async t=>{const f=fixture(t),r=await f.capture();assert.equal(r.success,true);assert.equal(r.captured,1);assert.equal(r.restorable,true);const m=JSON.parse(fs.readFileSync(path.join(f.dir,'recovery-snapshots',r.id,'manifest.json')));assert.equal(m.complete,true);assert.equal(m.files.length,1)});
test('identity failure leaves a durable failed report with no restore action',async t=>{const f=fixture(t,{identity:async()=>{throw Error('Identity denied')}}),r=await f.capture();assert.equal(r.state,'failed');assert.equal(r.restorable,false);assert.match(r.results[0].message,/Identity denied/);assert.equal(JSON.parse(fs.readFileSync(path.join(f.dir,'recovery-reports',r.id+'.json'))).state,'failed')});
test('failure copying originals keeps valid captures restorable and reports partial state',async t=>{const f=fixture(t,{copy:()=>{throw Error('Copy denied')}});fs.mkdirSync(path.join(f.dir,'legacy'));const r=await f.capture();assert.equal(r.state,'partial');assert.equal(r.restorable,true);assert.equal(r.failed,1);assert.match(r.results.at(-1).message,/Copy denied/)});
test('progress subscriber errors do not interrupt backup creation',async t=>{const f=fixture(t,{notify:()=>{throw Error('UI gone')}});assert.equal((await f.capture()).success,true)});

test('contradictory alias reads preserve a usable partial snapshot instead of false complete success',async t=>{
 const rules=['library-cpu-035','library-ram-006'].map(id=>catalog.getRule(id));
 const f=fixture(t,{catalog:()=>rules,read:async id=>({success:true,current:catalog.getRule(id).entries.map(e=>({...e,exists:true,kind:'DWord',value:id===rules[0].id?0:1}))})});
 const report=await f.capture();assert.equal(report.state,'partial');assert.equal(report.success,false);assert.equal(report.captured,1);assert.equal(report.failed,1);
 const snapshot=require('../snapshot-core').createSnapshotService({dataDir:()=>f.dir}).loadSnapshot(report.id);assert.equal(snapshot.manifest.complete,false);assert.equal(snapshot.rows.length,1);
});
test('repeated adapter inventory identities create one capture and one checksum entry',async t=>{
 const rule=catalog.getRule('library-net-003'),guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',reads=[];
 const f=fixture(t,{catalog:()=>[rule],context:async()=>({success:true,adapters:[{guid,name:'Ethernet'},{guid:'{'+guid.toUpperCase()+'}',name:'Duplicate'}]}),read:async(id,adapterGuid)=>{reads.push(adapterGuid);return {success:true,operation:{...rule.operation,adapterGuid},current:{automatic:true,servers:[]}}}});
 const report=await f.capture(),m=JSON.parse(fs.readFileSync(path.join(f.dir,'recovery-snapshots',report.id,'manifest.json')));
 assert.equal(report.success,true);assert.deepEqual(reads,[guid]);assert.equal(m.files.length,1);
});
test('invalid adapter inventories remain partial while independent Registry captures are retained',async t=>{
 for(const context of [{success:true,adapters:{}},{success:true,adapters:[{guid:'not-a-guid'}]},{adapters:[]}]){
  const f=fixture(t,{context:async()=>context}),report=await f.capture();assert.equal(report.state,'partial');assert.equal(report.captured,1);assert.equal(report.failed,1);
 }
});
test('an invalid host fingerprint cannot create a successful snapshot with unusable provenance',async t=>{
 const f=fixture(t,{identity:async()=>'wrong-host'}),report=await f.capture();assert.equal(report.state,'failed');assert.equal(report.captured,0);assert.equal(report.restorable,false);
 assert.equal(fs.existsSync(path.join(f.dir,'recovery-snapshots',report.id,'manifest.json')),false);
});
