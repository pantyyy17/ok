'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const {createFulfillmentService}=require('../seller/fulfillment-core');
const {readDeliveryStatus}=require('../seller/status');
const {createShopifyService}=require('../seller/shopify-core');
const {createLicenseStore,createIssuerCode,PRODUCT}=require('../licensing');
const pair=crypto.generateKeyPairSync('ed25519');
const privateKey=pair.privateKey.export({type:'pkcs8',format:'pem'}),publicKey=pair.publicKey.export({type:'spki',format:'pem'});
const purchase={source:'ownsite',purchaseId:'checkout_123',email:'buyer@example.com',items:[{id:'carpatia',quantity:2}]};
function temporary(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-fulfillment-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir}
function fixture(t,extra={}){
 const dir=temporary(t),config={database:path.join(dir,'licenses.sqlite'),privateKey,publicKey,emailFrom:'CARPATIA <licenses@example.com>',downloadUrl:'https://example.com/installer.exe',...extra};
 let service=createFulfillmentService(config);t.after(()=>service.close());
 return {dir,config,get service(){return service},restart(changes={}){service.close();service=createFulfillmentService({...config,...changes})}};
}
test('verified own-site adapter reuses purchased license format and restart deduplication',async t=>{
 const f=fixture(t);assert.deepEqual(f.service.fulfillVerifiedPurchase(purchase),{issued:2});f.restart();
 assert.deepEqual(f.service.fulfillVerifiedPurchase(purchase),{issued:0});
 const mails=[];await f.service.deliver(async mail=>{mails.push(mail);return {id:mail.id}});
 assert.equal(mails.length,2);assert.notEqual(mails[0].text,mails[1].text);
 for(let i=0;i<mails.length;i++){
  const mail=mails[i],code=mail.text.split('\n').find(x=>x.startsWith('CARPATIA-V1.'));
  const store=createLicenseStore({directory:path.join(f.dir,'client-'+i),publicKey});
  assert.equal(store.activate(code).expiresAt,null);
  assert.equal(store.status().customer,purchase.email);
  assert.match(mail.text,/https:\/\/example.com\/installer.exe/);
 }
 assert.deepEqual(readDeliveryStatus(f.dir),{licenses:2,outbox:{pending:0,sent:2,review:0},pendingDue:0});
});
test('retry preserves exact recipient, sender, instructions and code after configuration changes',async t=>{
 const f=fixture(t),now=Date.now();f.service.fulfillVerifiedPurchase({...purchase,items:[{id:'carpatia',quantity:1}]});
 let first;await f.service.deliver(async mail=>{first=mail;throw Error('provider timeout')},now);
 f.restart({downloadUrl:'https://example.com/new.exe',emailFrom:'New sender <new@example.com>'});
 let second;await f.service.deliver(async mail=>{second=mail;return {id:'confirmed'}},now+60001);
 assert.deepEqual(second,first);
 assert.equal(second.from,'CARPATIA <licenses@example.com>');assert.match(second.text,/installer.exe/);
});
test('all purchase validation completes before any code or email is persisted',t=>{
 const f=fixture(t);
 for(const overrides of [{source:'../unsafe'},{purchaseId:''},{email:'missing'},{email:'buyer\x00@example.com'},{email:'buyer\x01@example.com'}, {items:[]},{items:[{id:'a',quantity:0}]},{items:[{id:'a',quantity:1},{id:'a',quantity:1}]}])assert.throws(()=>f.service.fulfillVerifiedPurchase({...purchase,...overrides}),{code:'INVALID_PURCHASE'});
 assert.equal(readDeliveryStatus(f.dir).licenses,0);
});
test('invalid delivery settings fail before opening a ledger',t=>{
 const directory=temporary(t),database=path.join(directory,'licenses.sqlite');
 for(const emailFrom of ['Display\x00 <licenses@example.com>','Display\x01 <licenses@example.com>','not-an-email'])assert.throws(()=>createFulfillmentService({database,privateKey,emailFrom}),/EMAIL_FROM/);
 for(const downloadUrl of ['http://example.com/app.exe','https://user:password@example.com/app.exe'])assert.throws(()=>createFulfillmentService({database,privateKey,downloadUrl}),/HTTPS/);
 assert.equal(fs.existsSync(database),false);
});
test('outbox persistence failure rolls the license transaction back',t=>{
 const f=fixture(t),db=new DatabaseSync(f.config.database);
 try{
  db.exec("CREATE TRIGGER fail_mail BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT,'simulated mail persistence failure'); END");
  assert.throws(()=>f.service.fulfillVerifiedPurchase(purchase),/simulated mail persistence failure/);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM licenses').get().count,0);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM outbox').get().count,0);
 }finally{db.close()}
});
test('upgrading existing outbox preserves codes and flags previously attempted legacy messages',async t=>{
 const dir=temporary(t),database=path.join(dir,'licenses.sqlite'),db=new DatabaseSync(database);
 db.exec("CREATE TABLE licenses(unit TEXT PRIMARY KEY, code TEXT NOT NULL); CREATE TABLE outbox(id TEXT PRIMARY KEY, recipient TEXT NOT NULL, body TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, first_attempt INTEGER, provider_id TEXT)");
 db.prepare('INSERT INTO licenses VALUES (?,?)').run('existing',createIssuerCode({product:PRODUCT,licenseId:'legacy_123',customer:'Existing buyer',issuedAt:new Date().toISOString(),expiresAt:null},privateKey));
 db.prepare('INSERT INTO outbox(id,recipient,body,attempts) VALUES (?,?,?,?)').run('unattempted','buyer@example.com','stored-code',0);
 db.prepare('INSERT INTO outbox(id,recipient,body,attempts) VALUES (?,?,?,?)').run('ambiguous','buyer@example.com','old-code',1);db.close();
 const service=createFulfillmentService({database,privateKey,emailFrom:'licenses@example.com',downloadUrl:'https://example.com/installer.exe'});t.after(()=>service.close());
 const mails=[];await service.deliver(async mail=>{mails.push(mail);return {id:mail.id}});
 assert.equal(mails.length,1);assert.equal(mails[0].id,'unattempted');assert.match(mails[0].text,/stored-code/);assert.match(mails[0].text,/installer.exe/);
 const status=readDeliveryStatus(dir);assert.equal(status.licenses,1);assert.equal(status.outbox.review,1);assert.equal(status.outbox.sent,1);
});
test('publisher is pinned to the database across restarts and public files cannot contain private PEM',t=>{
 const dir=temporary(t),database=path.join(dir,'licenses.sqlite'),config={database,privateKey,publicKey};
 let service=createFulfillmentService(config);service.fulfillVerifiedPurchase(purchase);service.close();
 const other=crypto.generateKeyPairSync('ed25519');
 assert.throws(()=>createFulfillmentService({...config,publicKey:privateKey}),/NUMAI cheia PUBLICĂ/);
 assert.throws(()=>createFulfillmentService({...config,privateKey:other.privateKey,publicKey:other.publicKey}),/ALTEI chei/);
 service=createFulfillmentService(config);assert.equal(service.fulfillVerifiedPurchase(purchase).issued,0);service.close();
});
test('storefront adapters share one publisher key without overlapping purchase identities',async t=>{
 const f=fixture(t);f.service.fulfillVerifiedPurchase({...purchase,items:[{id:'carpatia',quantity:1}]});
 const shop=createShopifyService({...f.config,secret:'test',shop:'store.myshopify.com',variantId:'123'});t.after(()=>shop.close());
 const raw=Buffer.from(JSON.stringify({id:123,email:'shopify@example.com',test:false,financial_status:'paid',line_items:[{id:123,variant_id:123,quantity:1}]}));
 const result=shop.accept(raw,{'x-shopify-hmac-sha256':crypto.createHmac('sha256','test').update(raw).digest('base64'),'x-shopify-shop-domain':'store.myshopify.com','x-shopify-topic':'orders/paid'});
 assert.equal(result.issued,1);
 const mails=[];await shop.deliver(async mail=>{mails.push(mail);return {id:mail.id}});assert.equal(mails.length,2);
 for(const [i,mail] of mails.entries())assert.equal(createLicenseStore({directory:path.join(f.dir,'client-'+i),publicKey}).activate(mail.text.split('\n').find(x=>x.startsWith('CARPATIA-V1.'))).active,true);
});
