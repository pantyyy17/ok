param([switch]$Fail)
$ErrorActionPreference='Stop'
function Get-NetAdapter {
 if($Fail){throw 'Simulated adapter inventory failure'}
 @([pscustomobject]@{Name='Ethernet test';InterfaceGuid='{AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE}';Status='Up';LinkSpeed='1 Gbps';ifIndex=42},[pscustomobject]@{Name='Disconnected';Status='Down';LinkSpeed='0 bps';ifIndex=43})
}
function Get-DnsClientServerAddress {param($InterfaceIndex,$AddressFamily,$ErrorAction) [pscustomobject]@{ServerAddresses=@('192.0.2.53')}}
function Get-NetIPAddress {param($InterfaceIndex,$AddressFamily,$ErrorAction) @([pscustomobject]@{IPAddress='192.0.2.10'},[pscustomobject]@{IPAddress='169.254.1.1'})}
& (Join-Path (Split-Path -Parent $PSScriptRoot) 'network.ps1')
if($LASTEXITCODE){exit $LASTEXITCODE}
