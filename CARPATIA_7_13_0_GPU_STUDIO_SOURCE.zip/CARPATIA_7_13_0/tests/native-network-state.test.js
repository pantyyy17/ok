'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const path=require('node:path');
const {planNetwork,normalizeAdapterGuid}=require('../network-boost-core');
test('native TCP and NIC recovery respects hardware identity and exact adapter aliases',t=>{
 const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'native-network-state.ps1')],{encoding:'utf8',timeout:30000});
 if(result.error?.code==='ENOENT'){t.skip('PowerShell unavailable; set CARPATIA_PWSH to execute native mocks.');return;}
 assert.ifError(result.error);
 assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));
 assert.equal(report.success,true);
 assert.ok(report.assertions>=24);
});
test('network plan retains canonical physical identity from native inventory',()=>{
 const guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
 const request={adapter:'Ethernet',provider:'keep',options:{nicPower:false,tcp:false,interrupt:false,eee:false}};
 const plan=planNetwork(request,{adapters:[{name:'Ethernet',guid:'{'+guid.toUpperCase()+'}',ipv4:['192.0.2.1']}]});
 assert.equal(plan.adapterGuid,guid);
 for(const invalid of ['',null,7,'not-a-guid','{'+guid,guid+'}'])assert.equal(normalizeAdapterGuid(invalid),null);
 assert.equal(planNetwork(request,{adapters:[{name:'Ethernet',ipv4:['192.0.2.1']}]}).adapterGuid,undefined);
});
