'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {PREFIX,PRODUCT,inspectLicense,createIssuerCode,createLicenseStore}=require('../licensing');
const keyPair=crypto.generateKeyPairSync('ed25519');
const privateKey=keyPair.privateKey.export({type:'pkcs8',format:'pem'});
const publicKey=keyPair.publicKey.export({type:'spki',format:'pem'});
const wrongKey=crypto.generateKeyPairSync('ed25519').publicKey.export({type:'spki',format:'pem'});
function payload(overrides={}) {return {product:PRODUCT,licenseId:'client_0001',customer:'Client Test',issuedAt:new Date(Date.now()-86400000).toISOString(),expiresAt:null,...overrides};}
const issue=(opts={})=>createIssuerCode(payload(opts),privateKey);
test('licență Ed25519 validă și metadate corecte',()=>{
 const data=inspectLicense(issue(),publicKey);
 assert.equal(data.product,PRODUCT);assert.equal(data.licenseId,'client_0001');
});
test('codul nu funcționează fără cheia publică și cu altă cheie',()=>{
 const code=issue();
 assert.throws(()=>inspectLicense(code,null),/publică/);
 assert.throws(()=>inspectLicense(code,wrongKey),/Semnătura/);
});
test('alterarea datelor sau semnăturii este respinsă',()=>{
 const code=issue();const [prefix,body,sig]=code.split('.');
 const forged=Buffer.from(JSON.stringify({...payload(),customer:'Alt client'})).toString('base64url');
 assert.throws(()=>inspectLicense(`${prefix}.${forged}.${sig}`,publicKey),/Semnătura/);
 const badSignature=(sig[0]==='A'?'B':'A')+sig.slice(1);
 assert.throws(()=>inspectLicense(`${prefix}.${body}.${badSignature}`,publicKey),/Semnătura/);
});
test('licența expirată este respinsă chiar dacă are semnătură validă',()=>{
 const expired={...payload(),issuedAt:new Date(Date.now()-10*86400000).toISOString(),expiresAt:new Date(Date.now()-2*86400000).toISOString()};
 const body=Buffer.from(JSON.stringify(expired)).toString('base64url');
 const sig=crypto.sign(null,Buffer.from(`${PREFIX}.${body}`),privateKey).toString('base64url');
 assert.throws(()=>inspectLicense(`${PREFIX}.${body}.${sig}`,publicKey),/expirat/);
});
test('alt produs nu poate activa CARPATIA',()=>{
 assert.throws(()=>createIssuerCode(payload({product:'ALT_PRODUS'}),privateKey),/CARPATIA/);
});
test('codul prea lung sau invalid este respins',()=>{
 assert.throws(()=>inspectLicense('X'.repeat(9000),publicKey),/lung/);
 assert.throws(()=>inspectLicense('CARPATIA-V1.invalid',publicKey),/Format/);
});
test('stocarea locală refuză codul invalid, apoi salvează doar licența validă',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-license-test-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const store=createLicenseStore({directory:dir,publicKey});
 assert.equal(store.status().active,false);
 assert.throws(()=>store.activate('cod-fals'),/Format/);
 assert.equal(fs.existsSync(path.join(dir,'carpatia-license.txt')),false);
 const code=issue();
 assert.equal(store.activate(code).active,true);
 assert.equal(store.status().active,true);
 assert.equal(fs.readFileSync(path.join(dir,'carpatia-license.txt'),'utf8').trim(),code);
 assert.equal(createLicenseStore({directory:dir,publicKey}).status().active,true);
});
test('fișierul licenței modificat nu mai deblochează aplicația',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-license-tamper-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const store=createLicenseStore({directory:dir,publicKey});
 store.activate(issue());
 fs.writeFileSync(path.join(dir,'carpatia-license.txt'),'cheie-falsă');
 assert.equal(store.status().active,false);
});
test('distribuția nu conține niciodată cheia privată a editorului',()=>{
 const root=path.join(__dirname,'..');
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
 assert(!manifest.build.files.some(name=>/private|license-cli|tools\//i.test(name)));
 assert.equal(fs.existsSync(path.join(root,'carpatia-private.pem')),false);
});
