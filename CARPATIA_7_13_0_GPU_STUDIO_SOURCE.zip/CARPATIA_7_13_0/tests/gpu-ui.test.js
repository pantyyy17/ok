'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {mount,metric}=require('../gpu-ui');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const flush=()=>new Promise(setImmediate);
function harness(overrides={},options={}){
 const nodes={},listeners={},windowListeners={},scheduled=new Map(),calls=[],gates=[],toasts=[];let nextTimer=0,observerCallback,disconnected=false;
 const doc={visibilityState:'visible',getElementById:id=>nodes[id],createElement:tag=>new Element('',tag),addEventListener:(n,f)=>listeners[n]=f,removeEventListener:n=>delete listeners[n]};
 class Element{
  constructor(id,tag='div',classes=''){this.id=id;this.tagName=tag.toUpperCase();this.children=[];this.textContent='';this.dataset={};this.disabled=false;const set=new Set(classes.split(/\s+/));this.classList={contains:x=>set.has(x),add:x=>set.add(x),remove:x=>set.delete(x)}}
  setAttribute(name,value){this[name]=String(value)}
  append(...items){this.children.push(...items)}
  replaceChildren(...items){this.children=items}
 }
 for(const match of html.matchAll(/<([\w-]+)\b([^>]*\bid="([\w-]+)"[^>]*)>/g))nodes[match[3]]=new Element(match[3],match[1],match[2].match(/class="([^"]*)"/)?.[1]||'');
 nodes['view-gpu'].classList.add('active');
 let status={success:true,selected:false,backup:false,highPerformance:false};
 class Observer{constructor(fn){observerCallback=fn}observe(){}disconnect(){disconnected=true}}
 const win={MutationObserver:Observer,addEventListener:(n,f)=>windowListeners[n]=f,removeEventListener:n=>delete windowListeners[n]};
 const api=options.preview?null:{
  gpuList:async()=>({success:true,gpus:[{name:'GPU <test>',driver:'1.2.3'}],hags:'Windows controlled'}),gpuStatus:async()=>({...status}),sensors:async()=>({available:false,reason:'No local sensor server'}),
  gpuPick:async()=>{calls.push('pick');status={...status,selected:true,name:'game.exe'};return {cancelled:false,name:'game.exe'}},
  gpuApply:async()=>{calls.push('apply');status={...status,highPerformance:true,backup:true};return {success:true,message:'Applied'}},gpuRestore:async()=>{calls.push('restore');status={...status,highPerformance:false,backup:false};return {success:true,message:'Restored'}},openSettings:async r=>calls.push(['settings',r]),...overrides
 };
 const page=mount({api,document:doc,window:win,requireNative:recovery=>{gates.push(recovery===true);return true},task:async(_,fn)=>fn(),confirmDialog:options.confirmDialog||(async()=>options.confirm!==false),showToast:m=>toasts.push(m),timers:{setTimeout:(fn,ms)=>{const id=++nextTimer;scheduled.set(id,{fn,ms});return id},clearTimeout:id=>scheduled.delete(id)}});
 return {page,nodes,doc,listeners,windowListeners,scheduled,calls,gates,toasts,setStatus:x=>status=x,observe:()=>observerCallback(),get disconnected(){return disconnected}};
}
test('GPU studio detects genuine inventory, keeps unsupported sensors absent and disables writes before a game is selected',async()=>{
 const h=harness();await h.page.load();assert.equal(h.nodes.gpuInventory.children[0].children[0].textContent,'GPU <test>');assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.equal(h.nodes.gpuUndo.disabled,true);assert.equal(h.nodes.gpuLoadValue.textContent,'—');assert.equal(h.nodes.gpuCoreClockValue.textContent,'—');assert.match(h.nodes.gpuPicked.textContent,/Niciun executabil/);assert.equal(h.scheduled.size,1);h.page.destroy();
});
test('choose, apply, authoritative readback and direct restore use the real bridge methods',async()=>{
 const h=harness();await h.page.load();await h.nodes.pickGpuExe.onclick();assert.equal(h.nodes.gpuPicked.textContent,'game.exe');assert.equal(h.nodes.gpuSetHigh.disabled,false);assert.equal(h.nodes.gpuUndo.disabled,true);
 await h.nodes.gpuSetHigh.onclick();assert.deepEqual(h.calls,['pick','apply']);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.equal(h.nodes.gpuUndo.disabled,false);assert.equal(h.nodes.gpuActionStatus.dataset.tone,'success');
 await h.nodes.gpuUndo.onclick();assert.deepEqual(h.calls,['pick','apply','restore']);assert.equal(h.nodes.gpuUndo.disabled,true);assert.equal(h.nodes.gpuSetHigh.disabled,false);assert.deepEqual(h.gates,[true,false,true]);h.page.destroy();
});
test('canceled game selection preserves the prior selection and feedback',async()=>{
 const h=harness({gpuPick:async()=>({cancelled:true})});h.setStatus({success:true,selected:true,name:'existing.exe',highPerformance:true,backup:true});await h.page.load();h.nodes.gpuActionStatus.textContent='Existing result';h.nodes.gpuActionStatus.dataset.tone='success';await h.nodes.pickGpuExe.onclick();assert.equal(h.nodes.gpuPicked.textContent,'existing.exe');assert.equal(h.nodes.gpuActionStatus.textContent,'Existing result');assert.equal(h.nodes.gpuActionStatus.dataset.tone,'success');assert.equal(h.nodes.gpuUndo.disabled,false);h.page.destroy();
});
test('canceled confirmation and already-configured preferences never apply or invent a backup',async()=>{
 const h=harness({}, {confirm:false});await h.page.load();await h.nodes.pickGpuExe.onclick();await h.nodes.gpuSetHigh.onclick();assert.deepEqual(h.calls,['pick']);assert.equal(h.nodes.gpuUndo.disabled,true);
 h.setStatus({success:true,selected:true,name:'already.exe',highPerformance:true,backup:false});await h.page.refreshStatus();await h.nodes.gpuSetHigh.onclick();assert.deepEqual(h.calls,['pick']);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.equal(h.nodes.gpuUndo.disabled,true);h.page.destroy();
});
test('success from Apply is insufficient without authoritative high-performance readback',async()=>{
 const h=harness({gpuApply:async()=>({success:true})});await h.page.load();await h.nodes.pickGpuExe.onclick();await h.nodes.gpuSetHigh.onclick();assert.equal(h.nodes.gpuActionStatus.dataset.tone,'error');assert.match(h.nodes.gpuActionStatus.textContent,/recitire/);assert.equal(h.toasts.length,1);h.page.destroy();
});
test('restore errors preserve the active original and remain actionable',async()=>{
 const h=harness({gpuRestore:async()=>({success:false,message:'External change; original retained'})});h.setStatus({success:true,selected:true,name:'game.exe',backup:true,highPerformance:true});await h.page.load();await h.nodes.gpuUndo.onclick();assert.equal(h.nodes.gpuUndo.disabled,false);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.equal(h.nodes.gpuActionStatus.dataset.tone,'error');assert.match(h.nodes.gpuActionStatus.textContent,/original retained/);h.page.destroy();
});
test('a failed native Apply rereads the newly retained original and exposes restoration immediately',async()=>{
 let h;h=harness({gpuApply:async()=>{h.setStatus({success:true,selected:true,name:'game.exe',backup:true,highPerformance:false});throw Error('Native write failed; backup retained')}});await h.page.load();await h.nodes.pickGpuExe.onclick();await h.nodes.gpuSetHigh.onclick();
 assert.equal(h.nodes.gpuUndo.disabled,false);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.match(h.nodes.gpuActionStatus.textContent,/backup retained/);h.page.destroy();
});
test('malformed selected status cannot authorize writes or claim restoration success',async()=>{
 const h=harness({gpuStatus:async()=>({success:true,selected:true,name:'game.exe'})});await h.page.load();assert.equal(h.page.getState().statusKnown,false);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.equal(h.nodes.gpuUndo.disabled,true);assert.equal(h.nodes.gpuActionStatus.dataset.tone,'error');h.page.destroy();
});
test('a confirmation resolved after teardown cannot start a native GPU write',async()=>{
 const confirmation=deferred(),h=harness({}, {confirmDialog:()=>confirmation.promise});await h.page.load();await h.nodes.pickGpuExe.onclick();const applying=h.nodes.gpuSetHigh.onclick();await flush();h.page.destroy();confirmation.resolve(true);await applying;assert.deepEqual(h.calls,['pick']);assert.equal(h.scheduled.size,0);
});
test('a late status from initial loading cannot overwrite a newly chosen game',async()=>{
 const old=deferred();let reads=0;const h=harness({gpuStatus:()=>++reads===1?old.promise:Promise.resolve({success:true,selected:true,name:'new.exe',highPerformance:false,backup:false})});const loading=h.page.load();await flush();await h.nodes.pickGpuExe.onclick();old.resolve({success:true,selected:false,backup:false});await loading;assert.equal(h.nodes.gpuPicked.textContent,'new.exe');assert.equal(h.nodes.gpuSetHigh.disabled,false);h.page.destroy();
});
test('telemetry uses actual GPU values, caps history, and rejects invalid readings',async()=>{
 let invalid=false;const h=harness({sensors:async()=>invalid?{available:true,gpuLoad:{value:101},gpuTemperature:{value:-1}}:{available:true,source:'Local test sensor',gpuLoad:{value:52.3},gpuTemperature:{value:63.7},gpuCoreClock:{value:1800},gpuMemoryClock:{value:7000},gpuPower:{value:95.2},gpuFan:{value:1200}}});await h.page.load();assert.equal(h.nodes.gpuLoadValue.textContent,'52 %');assert.equal(h.nodes.gpuTempValue.textContent,'64 °C');assert.equal(h.nodes.gpuCoreClockValue.textContent,'1800 MHz');assert.equal(h.nodes.gpuFanValue.textContent,'1200 RPM');assert.match(h.nodes.gpuTrendLoad.d,/^M/);
 for(let i=0;i<60;i++){const [id,t]=[...h.scheduled.entries()][0];h.scheduled.delete(id);await t.fn();await flush()}
 assert.equal(h.page.getState().samples,48);invalid=true;const [id,t]=[...h.scheduled.entries()][0];h.scheduled.delete(id);await t.fn();await flush();assert.equal(h.nodes.gpuLoadValue.textContent,'—');assert.equal(h.nodes.gpuTempValue.textContent,'—');h.page.destroy();
});
test('polling stops outside the active view and on hidden documents, and teardown prevents delayed updates',async()=>{
 let sensorCalls=0;const h=harness({sensors:async()=>{sensorCalls++;return {available:false}}});await h.page.load();assert.equal(sensorCalls,1);h.nodes['view-gpu'].classList.remove('active');h.observe();assert.equal(h.scheduled.size,0);h.nodes['view-gpu'].classList.add('active');h.observe();await flush();assert.equal(sensorCalls,2);h.doc.visibilityState='hidden';h.listeners.visibilitychange();assert.equal(h.scheduled.size,0);h.page.destroy();assert.equal(h.disconnected,true);assert.equal(h.scheduled.size,0);assert.equal(h.listeners.visibilitychange,undefined);
 const wait=deferred(),next=harness({gpuStatus:()=>wait.promise});const loading=next.page.load();next.page.destroy();wait.resolve({success:true,selected:true,name:'late.exe',backup:true});await loading;assert.notEqual(next.nodes.gpuPicked.textContent,'late.exe');
});
test('preview has no native polling and metrics reject numeric-looking strings',async()=>{
 const h=harness({}, {preview:true});await h.page.load();assert.equal(h.scheduled.size,0);assert.equal(h.nodes.gpuSetHigh.disabled,true);assert.match(h.nodes.gpuInventoryStatus.textContent,/Previzualizare/);assert.equal(metric({value:'50'},100),null);assert.equal(metric(null,100),null);assert.equal(metric({value:0},100),0);h.page.destroy();
});
