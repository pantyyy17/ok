'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const http=require('node:http');
const {spawn,spawnSync}=require('node:child_process');
const {once}=require('node:events');
const {setTimeout:delay}=require('node:timers/promises');
const {initialize,issuerStatus}=require('../tools/issuer-core');
const {inspectLicense}=require('../licensing');
const root=path.resolve(__dirname,'..');

async function launch(t,script,args=[],extraEnv={},directory){
 const dir=directory||fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-http-'));
 const child=spawn(process.execPath,[path.join(root,script),...args],{cwd:root,env:{...process.env,...extraEnv},stdio:['ignore','pipe','pipe']});
 let stdout='',stderr='',timer;
 t.after(async()=>{
  if(child.exitCode===null&&child.signalCode===null){
   const exited=once(child,'exit');child.kill('SIGTERM');
   const force=setTimeout(()=>child.kill('SIGKILL'),2000);
   try{await exited}finally{clearTimeout(force)}
  }
  fs.rmSync(dir,{recursive:true,force:true});
 });
 const ready=new Promise((resolve,reject)=>{
  timer=setTimeout(()=>reject(Error('Local service did not start: '+stderr)),5000);
  child.once('error',reject);
  child.once('exit',code=>reject(Error('Local service exited ('+code+'): '+stderr)));
  child.stderr.on('data',chunk=>{stderr+=chunk.toString()});
  child.stdout.on('data',chunk=>{
   stdout+=chunk.toString();
   if(stdout.includes('Adresă locală:')||stdout.includes('seller service ready'))resolve(stdout);
  });
 });
 try{return {dir,output:await ready}}finally{clearTimeout(timer)}
}

function request(url,{method='GET',headers={},chunks=[]}={}){
 return new Promise((resolve,reject)=>{
  const req=http.request(url,{method,headers},res=>{
   const body=[];res.on('data',chunk=>body.push(chunk));
   res.on('end',()=>resolve({status:res.statusCode,body:Buffer.concat(body).toString('utf8')}));
   res.on('error',reject);
  });
  req.on('error',reject);req.setTimeout(5000,()=>req.destroy(Error('Local HTTP request timed out')));
  (async()=>{
   for(let i=0;i<chunks.length;i++){
    if(req.destroyed)return;
    req.write(chunks[i]);
    // Give the server a separate read for each part of a split UTF-8 character.
    if(i+1<chunks.length)await delay(40);
   }
   req.end();
  })().catch(reject);
 });
}

test('manager preserves customers across split UTF-8 chunks and rejects invalid or oversized byte bodies',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-manager-http-'));initialize(dir);
 const {output}=await launch(t,'tools/license-manager.js',['--private-dir',dir],{},dir);
 const url=output.match(/http:\/\/127\.0\.0\.1:\d+\//)[0],origin=new URL(url).origin;
 const page=await request(url),token=page.body.match(/name="carpatia-token" content="([a-f0-9]+)"/)[1];
 const headers={Origin:origin,'X-Carpatia-Token':token,'Content-Type':'application/json'};
 const customer='Cumpărător român',body=Buffer.from(JSON.stringify({customer,days:null}));
 const split=body.indexOf(Buffer.from('ă'))+1;
 assert.ok(split>1);
 const issued=await request(url+'api/issue',{method:'POST',headers,chunks:[body.subarray(0,split),body.subarray(split)]});
 assert.equal(issued.status,200,issued.body);
 const result=JSON.parse(issued.body).result;
 assert.equal(result.customer,customer);
 assert.equal(inspectLicense(result.code,fs.readFileSync(path.join(dir,'carpatia-public.pem'),'utf8')).customer,customer);
 const invalid=Buffer.concat([Buffer.from('{"customer":"Client '),Buffer.from([0xc3]),Buffer.from('","days":null}')]);
 assert.equal((await request(url+'api/issue',{method:'POST',headers,chunks:[invalid]})).status,400);
 assert.equal((await request(url+'api/status',{method:'POST',headers,chunks:[Buffer.alloc(8193,0x20)]})).status,413);
 assert.equal(issuerStatus(dir).issuedCount,1);
 const status=await request(url+'api/status',{method:'POST',headers,chunks:[Buffer.from('{}')]});
 assert.equal(status.status,200);assert.equal(JSON.parse(status.body).result.ready,true);
});

test('seller returns an HTTP response for oversized uploads and remains available',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-seller-http-'));initialize(dir);
 const probe=http.createServer();probe.listen(0,'127.0.0.1');await once(probe,'listening');
 const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
 await launch(t,'seller/server.js',[],{
  PORT:String(port),SHOPIFY_WEBHOOK_SECRET:'test-secret',SHOPIFY_SHOP:'test.myshopify.com',SHOPIFY_VARIANT_ID:'123',
  LICENSE_PRIVATE_KEY_FILE:path.join(dir,'carpatia-private.pem'),LICENSE_PUBLIC_KEY_FILE:path.join(dir,'carpatia-public.pem'),
  LICENSE_DATA_DIR:path.join(dir,'data'),RESEND_API_KEY:'unused-test-value',EMAIL_FROM:'test@example.invalid',DOWNLOAD_URL:'https://example.invalid/installer'
 },dir);
 const url='http://127.0.0.1:'+port+'/webhooks/shopify/orders-paid';
 const tooLarge=await request(url,{method:'POST',chunks:[Buffer.alloc(1048577,0x20)]});
 assert.equal(tooLarge.status,413);
 assert.equal((await request(url,{method:'POST',chunks:[Buffer.from('{}')]})).status,401);
});

test('CLI reads and writes the canonical paths that passed the external directory check',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-cli-path-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 initialize(dir);
 const other=path.join(dir,'other'),child=path.join(other,'child'),link=path.join(dir,'link');
 fs.mkdirSync(child,{recursive:true});
 fs.symlinkSync(child,link,process.platform==='win32'?'junction':'dir');
 // Lexical normalization and operating-system traversal disagree after a symlink/.. pair.
 // All path validation and I/O must use the same normalized result.
 fs.writeFileSync(path.join(other,'carpatia-private.pem'),'not a signing key');
 const issued=spawnSync(process.execPath,[path.join(root,'tools/license-cli.js'),'issue',
  '--private',link+'/../carpatia-private.pem','--out',link+'/../client.txt','--customer','Client test','--id','cli_client_001'],{cwd:root,encoding:'utf8'});
 assert.equal(issued.status,0,issued.stderr);
 const code=fs.readFileSync(path.join(dir,'client.txt'),'utf8');
 assert.equal(inspectLicense(code,fs.readFileSync(path.join(dir,'carpatia-public.pem'),'utf8')).customer,'Client test');
 assert.equal(fs.existsSync(path.join(other,'client.txt')),false);
});
