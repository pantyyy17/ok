$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../tweak-native-ops.ps1')
$script:assertions=0
$script:writes=@()
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$threw=$false;try{& $operation}catch{$threw=$true};Assert $threw $label}
function Invoke-Tool($Name,$Arguments){$script:writes+=,$Name;return ''}
function New-ServiceState($name){return @{name=$name;start=2;running=$true;delayedExists=$true;delayed=1}}
$service=@{type='service';services=@(@{name='S1';start=4;running=$false},@{name='S2';start=4;running=$false})}
$before=@((New-ServiceState 'S1'),(New-ServiceState 'S2'))
$desired=Desired-Native $service $before
$current=Copy-Object $before;$current[0].start=4
Assert (Test-NativeRestoreState $service $current $before $desired) 'partial service configuration is restorable'
$current[0].running=$false
Assert (Test-NativeRestoreState $service $current $before $desired) 'one changed service and one untouched service is restorable'
$current[0].start=3
Assert (-not (Test-NativeRestoreState $service $current $before $desired)) 'external service start mode is rejected'
$current=Copy-Object $before;$current[0].name='other-service'
Assert (-not (Test-NativeRestoreState $service $current $before $desired)) 'foreign service is rejected'
$bcd=@{type='bcd';values=@(@{key='debug';object='{current}';value='no'},@{key='bootdebug';object='{current}';value='no'})}
$before=@(@{key='debug';object='{current}';exists=$false;value=$null},@{key='bootdebug';object='{current}';exists=$false;value=$null})
$desired=Desired-Native $bcd $before
$current=Copy-Object $before;$current[0]=Copy-Object $desired[0]
Assert (Test-NativeRestoreState $bcd $current $before $desired) 'partly applied BCD batch is restorable'
$current[0].value='yes'
Assert (-not (Test-NativeRestoreState $bcd $current $before $desired)) 'external BCD value is rejected'
$mtu=@{type='mtu'};$before=@{active=1400;persistent=1400};$desired=@{active=1500;persistent=1500}
Assert (Test-NativeRestoreState $mtu @{active=1400;persistent=1500} $before $desired) 'partial MTU writes are restorable'
Assert (-not (Test-NativeRestoreState $mtu @{active=1300;persistent=1500} $before $desired)) 'external MTU is rejected'
Reject {Write-Native @{type='power-active'} ('-'*36)} 'malformed power GUID rejected before writing'
Reject {Write-Native @{type='ipv6'} 'false'} 'string false cannot become true by coercion'
Reject {Write-Native @{type='power-value'} -1} 'negative power index is rejected'
Reject {Write-Native @{type='fsutil'} 4294967296} 'oversized NTFS value is rejected'
Reject {Write-Native @{type='dns'} @{automatic=$true;servers=@('8.8.8.8')}} 'contradictory automatic DNS rejected'
Reject {Write-Native @{type='dns'} @{automatic=$false;servers=@('::1')}} 'IPv6 address rejected by IPv4-only operation'
$badBcd=Desired-Native $bcd @();$badBcd[1].object='{bootmgr}'
Reject {Write-Native $bcd $badBcd} 'entire BCD batch is validated before first write'
$badService=@((New-ServiceState 'S1'),(New-ServiceState 'foreign'))
Reject {Write-Native $service $badService} 'entire service batch is validated before first write'
$hiber=@(@{name='HibernateEnabled';exists=$true;value=0},@{name='HiberFileType';exists=$true;value=2},@{name='HiberFileType';exists=$true;value=2})
Reject {Write-Native @{type='hibernation'} $hiber} 'malformed hibernation state rejected before powercfg'

# Capture must never turn a non-DWORD original into a restorable DWORD record.
# Every Windows service/Registry read below is mocked; the real capture function
# is exercised before the actual Apply path can create its journal or write.
$script:serviceValues=@{Start=2;DelayedAutoStart=1}
$script:serviceKinds=@{Start='DWord';DelayedAutoStart='DWord'}
$script:closedKeys=0
function Get-Service {param($Name,$ErrorAction) return [pscustomobject]@{Status='Running'}}
function Get-Item {
 param($LiteralPath,$ErrorAction)
 if($LiteralPath -cne 'HKLM:\SYSTEM\CurrentControlSet\Services\S1'){throw 'Unexpected service Registry target'}
 $key=[pscustomobject]@{}
 $key | Add-Member ScriptMethod GetValueNames {return @($script:serviceValues.Keys)}
 $key | Add-Member ScriptMethod GetValueKind {param($name) return $script:serviceKinds[$name]}
 $key | Add-Member ScriptMethod GetValue {param($name) return $script:serviceValues[$name]}
 $key | Add-Member ScriptMethod Dispose {$script:closedKeys++}
 return $key
}
$captureService=@{type='service';services=@(@{name='S1';start=4;running=$false})}
$captured=Capture-Native $captureService
Assert ($captured.Count -eq 1 -and $captured[0].start -eq 2 -and $captured[0].delayedExists -and $captured[0].delayed -eq 1 -and $captured[0].running) 'native service captures a restorable DWORD original'
Assert ($script:closedKeys -eq 1) 'native service closes the Registry handle after capture'
$script:serviceValues.Remove('DelayedAutoStart')
$captured=Capture-Native $captureService
Assert (-not $captured[0].delayedExists -and $captured[0].delayed -eq 0) 'absent delayed-start value remains absent in native original'
$script:serviceValues.DelayedAutoStart=1
foreach($kind in @('String','QWord','ExpandString')){
 $script:serviceKinds.DelayedAutoStart=$kind
 Reject {Capture-Native $captureService} ('native '+$kind+' delayed start is rejected before journaling or writes')
}
$script:serviceKinds.DelayedAutoStart='DWord';$script:serviceValues.DelayedAutoStart=2
Reject {Capture-Native $captureService} 'native unsupported delayed-start value cannot create an unusable backup'
$script:serviceValues.DelayedAutoStart=1;$script:serviceKinds.Start='String'
Reject {Capture-Native $captureService} 'native non-DWORD startup mode cannot lose its Registry kind'
$script:serviceKinds.Start='DWord';$script:serviceValues.Start=5
Reject {Capture-Native $captureService} 'native unsupported startup mode is rejected before journaling'
$script:serviceValues.Remove('Start')
Reject {Capture-Native $captureService} 'native missing startup mode is not invented'

# Profile reuse must see the persisted target, rather than assume that an ID
# already applied to one NIC/power scheme also belongs to the current target.
# Status executes its real read-only branch on isolated temporary journals.
$statusRoot=Join-Path ([IO.Path]::GetTempPath()) ('carpatia-native-status-'+[guid]::NewGuid().ToString('N'))
try{
 $journalRoot=Join-Path $statusRoot 'tweak-native-backups'
 New-Item -ItemType Directory -Path $journalRoot -Force | Out-Null
 $catalog=Get-Content -LiteralPath (Join-Path $PSScriptRoot '../tweak-library.json') -Raw | ConvertFrom-Json
 $dnsRule=@($catalog | Where-Object {$_.status -eq 'native' -and $_.operation.type -eq 'dns'})[0]
 $powerRule=@($catalog | Where-Object {$_.status -eq 'native' -and $_.operation.type -eq 'power-value'})[0]
 $dnsOperation=Copy-Object $dnsRule.operation;$dnsOperation | Add-Member NoteProperty adapterGuid 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
 $powerOperation=Copy-Object $powerRule.operation;$powerOperation | Add-Member NoteProperty scheme '11111111-2222-3333-4444-555555555555'
 $originals=@{}
 foreach($entry in @(@{rule=$dnsRule;operation=$dnsOperation},@{rule=$powerRule;operation=$powerOperation})){
  $file=Join-Path $journalRoot ($entry.rule.id+'.json')
  @{version=1;id=$entry.rule.id;state='applied';reversible=$true;operation=$entry.operation;targets=@('saved-target');before=0;desired=1} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $file -Encoding UTF8
  $originals[$file]=[Convert]::ToBase64String([IO.File]::ReadAllBytes($file))
 }
 $status=& (Join-Path $PSScriptRoot '../tweak-native.ps1') -Action Status -DataDir $statusRoot | ConvertFrom-Json
 Assert ($status.success -and @($status.states).Count -eq 2) 'native Status reads saved dynamic-target journals without Windows writes'
 $dnsState=@($status.states | Where-Object {$_.id -ceq $dnsRule.id})[0]
 $powerState=@($status.states | Where-Object {$_.id -ceq $powerRule.id})[0]
 Assert ($dnsState.operation.adapterGuid -ceq $dnsOperation.adapterGuid) 'native Status exposes the original DNS adapter identity'
 Assert ($powerState.operation.scheme -ceq $powerOperation.scheme -and $powerState.operation.subgroup -ceq $powerOperation.subgroup -and $powerState.operation.setting -ceq $powerOperation.setting) 'native Status exposes the original power scheme and setting identity'
 $unchanged=$true;foreach($file in $originals.Keys){if([Convert]::ToBase64String([IO.File]::ReadAllBytes($file)) -cne $originals[$file]){$unchanged=$false}}
 Assert $unchanged 'native target inventory preserves original journals byte for byte'
}finally{if(Test-Path -LiteralPath $statusRoot){Remove-Item -LiteralPath $statusRoot -Recurse -Force}}
Assert ($script:writes.Count -eq 0) 'all rejected states caused zero native tool writes'
# Simulate a disabled-but-running original without touching any Windows service.
$script:sequence=@();$script:startFails=$false
function Invoke-Tool($Name,$Arguments){$script:sequence+=,($Arguments -join ' ');return ''}
function New-ItemProperty {return $null}
function Get-Service {
 $svc=[pscustomobject]@{Status='Stopped'}
 $svc | Add-Member -MemberType ScriptMethod -Name WaitForStatus -Value {param($status,$timeout)}
 return $svc
}
function Start-Service {if($script:startFails){throw 'Mock start denied'};$script:sequence+=,'start'}
$o=@{type='service';services=@(@{name='S1';start=4;running=$true})}
$v=@(@{name='S1';start=4;running=$true;delayedExists=$true;delayed=1})
# The registry path is only passed to the mocked property writer.
Write-Native $o $v
Assert (($script:sequence -join '|') -eq 'config S1 start= disabled|config S1 start= demand|start|config S1 start= disabled') 'disabled-but-running service restored without permanently enabling it'
$script:sequence=@();$script:startFails=$true
Reject {Write-Native $o $v} 'failed service start remains a failure'
Assert ($script:sequence[-1] -eq 'config S1 start= disabled') 'saved disabled startup mode is retained after failed start'
@{success=$true;assertions=$script:assertions} | ConvertTo-Json -Compress
