'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createMotionController}=require('../ruby-motion');
function setup(){
 let active=true,callback,disconnected=false;const flags=new Set();
 const circle={classList:{toggle:(x,on)=>on?flags.add(x):flags.delete(x),add:x=>flags.add(x)},closest:()=>({classList:{contains:()=>active}})};
 const events=new Map(),document={hidden:false,querySelectorAll:()=>[circle],addEventListener:(n,f)=>events.set(n,f),removeEventListener:n=>events.delete(n)};
 class Observer{constructor(cb){callback=cb}observe(){}disconnect(){disconnected=true}}
 const controller=createMotionController({document,Observer});
 return {controller,document,events,flags,setActive:x=>active=x,visible:x=>callback([{target:circle,isIntersecting:x}]),get disconnected(){return disconnected}};
}
test('rings pause offscreen, on hidden pages, and outside dashboard',()=>{
 const x=setup();assert(x.flags.has('motion-paused'));x.visible(true);assert(!x.flags.has('motion-paused'));
 x.document.hidden=true;x.events.get('visibilitychange')();assert(x.flags.has('motion-paused'));
 x.document.hidden=false;x.setActive(false);x.controller.sync();assert(x.flags.has('motion-paused'));
 x.setActive(true);x.controller.sync();assert(!x.flags.has('motion-paused'));
});
test('motion cleanup disconnects observer and removes handler',()=>{const x=setup();x.controller.destroy();assert(x.disconnected);assert.equal(x.events.size,0);assert(x.flags.has('motion-paused'))});
