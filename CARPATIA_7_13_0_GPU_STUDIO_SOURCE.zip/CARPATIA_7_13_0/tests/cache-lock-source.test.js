const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const read = name => fs.readFileSync(path.join(__dirname,'..',name),'utf8');

test('cache cleanup distinguishes Windows file sharing locks from real errors', () => {
 const src = read('tweak-native-ops.ps1');
 assert.match(src,/function Test-CacheFileLock\(\$errorRecord\)/);
 assert.match(src,/-in @\(32,33\)/);
 assert.match(src,/if\(Test-CacheFileLock \$_\)\{\$skipped\+\+;\$locked\+\+;continue\}/);
 assert.match(src,/errors=@\(\$errors\);success=\(\$errors.Count -eq 0\)/);
 assert.doesNotMatch(src,/Stop-Process.*NVIDIA/i);
});

test('UI keeps separate counters for locked, recent and skipped files', () => {
 const src = read('tweak-library-ui.js');
 assert.match(src,/blocate de alt proces: \$\{r.locked\|\|0\}/);
 assert.match(src,/recent utilizate: \$\{r.recent\|\|0\}/);
});
