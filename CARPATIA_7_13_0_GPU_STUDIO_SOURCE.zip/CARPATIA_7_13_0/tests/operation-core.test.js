'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {restoreComponents}=require('../operation-core');
test('failed power inventory does not block registry recovery',async()=>{
 let restored=false;const r=await restoreComponents([['power','power'],['registry','registry']],async(file,action)=>{
  if(file==='power')throw Error('corrupt power backup');
  if(action==='Restore'){restored=true;return {success:true}}
  return {success:true,backup:!restored};
 });assert.equal(r.success,false);assert.equal(r.steps[1].success,true);
});
test('unknown status cannot be mistaken for no backup',async()=>{const r=await restoreComponents([['registry','x']],async()=>({success:false}));assert.equal(r.success,false)});
test('persistent backup after restore is failure',async()=>{const r=await restoreComponents([['registry','x']],async()=>({success:true,backup:true}));assert.equal(r.success,false)});
test('no backups is a successful no-op',async()=>{const r=await restoreComponents([['registry','x']],async()=>({success:true,backup:false}));assert.deepEqual(r,{success:true,steps:[]})});
