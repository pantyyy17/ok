'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {capabilitiesFor}=require('../network-capabilities');
const report=row=>({success:true,admin:true,adapters:[{name:'Ethernet',...row}]});
test('NIC supports DeviceSleep even when SelectiveSuspend is unsupported',()=>{
 const c=capabilitiesFor('Ethernet',{power:report({selectiveSuspend:'Unsupported',deviceSleepOnDisconnect:'Enabled'})});assert.equal(c.supported.nicPower,true);
});
test('NIC support includes already-disabled properties but excludes unknown values and read errors',()=>{
 for(const v of ['Enabled','Disabled'])assert.equal(capabilitiesFor('Ethernet',{power:report({selectiveSuspend:v})}).supported.nicPower,true);
 for(const row of [{selectiveSuspend:'Unsupported',deviceSleepOnDisconnect:'Unsupported'},{selectiveSuspend:'Enabled',error:'denied'}])assert.equal(capabilitiesFor('Ethernet',{power:report(row)}).supported.nicPower,false);
});
test('unreadable adapter or lack of administrator never enables an advanced option',()=>{
 for(const power of [null,{...report({selectiveSuspend:'Enabled'}),admin:false},{...report({selectiveSuspend:'Enabled'}),success:false},report({name:'Other',selectiveSuspend:'Enabled'})])assert.equal(capabilitiesFor('Ethernet',{power}).supported.nicPower,false);
});
test('unsupported NIC power does not disable independent TCP or EEE support',()=>{
 const c=capabilitiesFor('Ethernet',{tcp:report({supported:true}),power:report({selectiveSuspend:'Unsupported'}),advanced:report({interrupt:false,eee:true})});assert.deepEqual(c.supported,{tcp:true,nicPower:false,interrupt:false,eee:true});
});
function ui(getCaps,timers={}){
 const ids=Object.fromEntries(['adapterSelect','netNic','netTcp','netInterrupt','netEee','netStart','netCapabilitiesStatus','netCapabilitiesRefresh'].map(id=>[id,{value:'Ethernet',checked:true,addEventListener(){}}]));
 const window={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../network-options-ui.js'),'utf8'),{window,setTimeout,clearTimeout});
 return {ids,page:window.CarpatiaNetworkOptions.mount({...timers,api:{networkCapabilities:getCaps},document:{getElementById:id=>ids[id]}})};
}
test('unsupported selections are unchecked while supported selections stay available',async()=>{
 const x=ui(async()=>({adapter:'Ethernet',supported:{tcp:true,nicPower:false,interrupt:false,eee:false},reasons:{nicPower:'Driver unsupported'}}));await x.page.refresh();assert.equal(x.ids.netNic.checked,false);assert.equal(x.ids.netNic.disabled,true);assert.equal(x.ids.netTcp.checked,true);assert.equal(x.ids.netTcp.disabled,false);assert.equal(x.ids.netStart.disabled,false);
});
test('failed capability read leaves DNS usable but no advanced setting enabled',async()=>{
 const x=ui(async()=>{throw Error('failed')});await x.page.refresh();for(const id of ['netNic','netTcp','netInterrupt','netEee']){assert.equal(x.ids[id].disabled,true);assert.equal(x.ids[id].checked,false)}assert.equal(x.ids.netStart.disabled,false);assert.match(x.ids.netCapabilitiesStatus.textContent,/DNS/);
});
test('late result for previous adapter cannot re-enable unsupported options',async()=>{
 const pending=[];const x=ui(adapter=>new Promise(resolve=>pending.push({adapter,resolve})));const first=x.page.refresh();x.ids.adapterSelect.value='WiFi';const second=x.page.refresh();
 pending[1].resolve({adapter:'WiFi',supported:{tcp:false},reasons:{}});await second;pending[0].resolve({adapter:'Ethernet',supported:{tcp:true},reasons:{}});await first;assert.equal(x.ids.netTcp.disabled,true);
});
test('no adapter keeps execution disabled without a capability query',async()=>{
 let calls=0;const x=ui(async()=>{calls++});x.ids.adapterSelect.value='';await x.page.refresh();assert.equal(calls,0);assert.equal(x.ids.netStart.disabled,true);
});

test('stalled capability read times out and late success cannot enable unknown options',async()=>{
 let fire,resolve;const x=ui(()=>new Promise(r=>resolve=r),{schedule:f=>{fire=f;return 1},cancel:()=>{}});
 const pending=x.page.refresh();fire();await pending;assert.equal(x.ids.netStart.disabled,false);assert.equal(x.ids.netTcp.disabled,true);assert.match(x.ids.netCapabilitiesStatus.textContent,/15 secunde/);
 resolve({adapter:'Ethernet',supported:{tcp:true}});await Promise.resolve();assert.equal(x.ids.netTcp.disabled,true);
});
