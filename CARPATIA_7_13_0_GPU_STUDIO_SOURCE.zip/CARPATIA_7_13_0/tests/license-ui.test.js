'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {mount}=require('../license-ui');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const missing={active:false,configured:true,reason:'missing_license'};
const active={active:true,configured:true,reason:'active',customer:'Client test',licenseId:'client_123456',expiresAt:null};
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const flush=()=>new Promise(setImmediate);
function harness(overrides={},options={}){
 const nodes={},listeners={},windowListeners={},scheduled=new Map(),states=[],toasts=[];let timerId=0,time=Date.parse('2026-11-02T12:00:00Z'),recovered=0;
 const doc={visibilityState:'visible',getElementById:id=>nodes[id],querySelector:s=>s==='.shell'?nodes.shell:null,addEventListener:(name,fn)=>{listeners[name]=fn},removeEventListener:name=>{delete listeners[name]}};
 class Element{
  constructor(id,tag='div',classes=''){this.id=id;this.tagName=tag.toUpperCase();this.dataset={};this.textContent='';this.value='';this.disabled=false;this.isConnected=true;this.parentElement=null;const set=new Set(classes.split(/\s+/));this.classList={contains:x=>set.has(x),add:x=>set.add(x),remove:x=>set.delete(x),toggle(x,force){if(force===undefined)force=!set.has(x);force?set.add(x):set.delete(x);return force}}}
  setAttribute(name,value){this[name]=String(value)}
  addEventListener(name,fn){this['on'+name]=fn}
  focus(){if(!this.disabled)doc.activeElement=this}
  closest(selector){for(let node=this;node;node=node.parentElement)if(selector[0]==='.'?node.classList.contains(selector.slice(1)):node.id===selector.slice(1))return node;return null}
  contains(target){for(let node=target;node;node=node.parentElement)if(node===this)return true;return false}
  querySelectorAll(){return ['licenseCode','licenseClose','licenseActivate','licenseImport','licenseReplace','licenseRefresh','licenseRecovery'].map(id=>nodes[id])}
 }
 for(const match of html.matchAll(/<([\w-]+)\b([^>]*\bid="([\w-]+)"[^>]*)>/g)){const classes=match[2].match(/class="([^"]*)"/)?.[1]||'';nodes[match[3]]=new Element(match[3],match[1],classes)}
 nodes.shell=new Element('shell','div','shell');doc.body=new Element('body','body');doc.activeElement=doc.body;
 nodes.licenseGate.parentElement=doc.body;nodes.licenseDialog.parentElement=nodes.licenseGate;nodes.licenseButton.parentElement=nodes.shell;
 for(const [id,node] of Object.entries(nodes))if(id.startsWith('license')&&!['licenseGate','licenseDialog','licenseButton'].includes(id))node.parentElement=nodes.licenseDialog;
 for(const id of ['licenseCode','licenseCodeLabel','licenseInputHint'])nodes[id].parentElement=nodes.licenseEntry;
 const win={addEventListener:(name,fn)=>{windowListeners[name]=fn},removeEventListener:name=>{delete windowListeners[name]}};
 const api=options.preview?null:{licenseStatus:async()=>missing,licenseActivate:async()=>active,licenseImport:async()=>({cancelled:true}),...overrides};
 const page=mount({api,document:doc,window:win,now:()=>time,timers:{setTimeout(fn,delay){const id=++timerId;scheduled.set(id,{fn(){scheduled.delete(id);return fn()},delay});return id},clearTimeout:id=>scheduled.delete(id)},onState:state=>states.push(state),showToast:message=>toasts.push(message),onRecovery:()=>{recovered++}});
 const key=(key,extra={})=>{const event={key,prevented:false,stopped:false,preventDefault(){this.prevented=true},stopImmediatePropagation(){this.stopped=true},...extra};listeners.keydown?.(event);return event};
 return {page,nodes,doc,listeners,windowListeners,scheduled,states,toasts,key,advance:ms=>{time+=ms},recovered:()=>recovered};
}
test('first launch requests the saved status, focuses code, and keeps restoration available',async()=>{
 let activations=0;const h=harness({licenseActivate:async()=>{activations++;return active}});await h.page.init();
 assert.equal(h.nodes.licenseGate.classList.contains('hidden'),false);assert.equal(h.nodes.shell.inert,true);assert.equal(h.doc.activeElement,h.nodes.licenseCode);assert.equal(h.doc.body.dataset.licensed,'no');
 await h.nodes.licenseActivate.onclick();assert.equal(activations,0);assert.match(h.nodes.licenseMessage.textContent,/Lipește/);assert.equal(h.nodes.licenseCode['aria-invalid'],'true');
 h.nodes.licenseRecovery.onclick();assert.equal(h.recovered(),1);assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(h.nodes.shell.inert,false);
 h.advance(1200);await h.page.refresh();assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);h.page.destroy();
});
test('activation waits for backend success, saves only returned details, then offers explicit entry',async()=>{
 const activation=deferred(),calls=[],h=harness({licenseActivate:code=>{calls.push(code);return activation.promise}});await h.page.init();h.nodes.licenseCode.value='  CARPATIA-V1.wrapped\ncode.signature  ';
 const pending=h.nodes.licenseActivate.onclick();assert.equal(h.nodes.licenseActivate.disabled,true);assert.equal(h.nodes.licenseImport.disabled,true);assert.equal(h.doc.body.dataset.licensed,'no');
 await h.nodes.licenseActivate.onclick();assert.equal(calls.length,1);activation.resolve(active);await pending;
 assert.deepEqual(calls,['CARPATIA-V1.wrapped\ncode.signature']);assert.equal(h.doc.body.dataset.licensed,'yes');assert.equal(h.nodes.licenseGate.classList.contains('hidden'),false);assert.equal(h.nodes.licenseCode.value,'');assert.equal(h.nodes.licenseCustomer.textContent,active.customer);assert.equal(h.nodes.licenseId.textContent,active.licenseId);assert.equal(h.toasts.length,1);assert.equal(h.doc.activeElement,h.nodes.licenseClose);
 h.nodes.licenseClose.onclick();assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(h.doc.activeElement,h.nodes.licenseButton);h.page.destroy();
});
test('saved activation enters directly and can reopen license details',async()=>{
 const h=harness({licenseStatus:async()=>({...active,customer:'<img src=x onerror=bad>'})});await h.page.init();assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(h.doc.body.dataset.licensed,'yes');
 h.nodes.licenseButton.onclick();assert.equal(h.nodes.licenseGate.classList.contains('hidden'),false);assert.equal(h.nodes.licenseCustomer.textContent,'<img src=x onerror=bad>');assert.equal(h.nodes.licenseDetails.classList.contains('hidden'),false);assert.equal(h.nodes.licenseEntry.classList.contains('hidden'),true);h.nodes.licenseReplace.onclick();assert.equal(h.nodes.licenseEntry.classList.contains('hidden'),false);assert.equal(h.nodes.licenseReplace['aria-expanded'],'true');assert.equal(h.doc.activeElement,h.nodes.licenseCode);h.nodes.licenseReplace.onclick();assert.equal(h.nodes.licenseEntry.classList.contains('hidden'),true);assert.equal(h.key('Escape').prevented,true);assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);h.page.destroy();
});
test('invalid replacement preserves the typed code and authoritative existing activation',async()=>{
 const h=harness({licenseStatus:async()=>active,licenseActivate:async()=>{throw Error('Semnătura licenței nu este validă.')}});await h.page.init();h.page.open();h.nodes.licenseReplace.onclick();h.nodes.licenseCode.value='invalid replacement';await h.nodes.licenseActivate.onclick();
 assert.equal(h.doc.body.dataset.licensed,'yes');assert.equal(h.nodes.licenseCode.value,'invalid replacement');assert.equal(h.nodes.licenseMessage.dataset.tone,'error');assert.match(h.nodes.licenseMessage.textContent,/Codul nu a putut/);assert.equal(h.toasts.length,0);assert.equal(h.nodes.licenseClose.disabled,false);assert.equal(h.doc.activeElement,h.nodes.licenseCode);h.page.destroy();
});
test('renewal saves new details; Escape returns to the app and reopens compact details',async()=>{
 let renewed=false;const replacement={...active,licenseId:'renewal_123456',expiresAt:'2027-02-02T12:00:00Z'},h=harness({licenseStatus:async()=>renewed?replacement:active,licenseActivate:async code=>{assert.equal(code,'renewed code');renewed=true;return replacement}});await h.page.init();h.page.open();h.nodes.licenseReplace.onclick();h.nodes.licenseCode.value='draft';assert.equal(h.key('Escape').prevented,true);assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(h.doc.activeElement,h.nodes.licenseButton);
 h.page.open();assert.equal(h.nodes.licenseEntry.classList.contains('hidden'),true);h.nodes.licenseReplace.onclick();assert.equal(h.nodes.licenseCode.value,'draft');h.nodes.licenseCode.value='renewed code';await h.nodes.licenseActivate.onclick();assert.equal(h.nodes.licenseId.textContent,replacement.licenseId);assert.match(h.nodes.licenseExpiry.textContent,/2027/);assert.equal(h.nodes.licenseEntry.classList.contains('hidden'),true);assert.equal(h.nodes.licenseCode.value,'');assert.equal(h.doc.activeElement,h.nodes.licenseClose);h.nodes.licenseClose.onclick();assert.equal(h.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(h.doc.activeElement,h.nodes.licenseButton);h.page.destroy();
});
test('an inactive backend response never produces a success toast or clears the code',async()=>{
 const h=harness({licenseActivate:async()=>({active:false,configured:true,reason:'expired_license'})});await h.page.init();h.nodes.licenseCode.value='expired';await h.nodes.licenseActivate.onclick();assert.equal(h.toasts.length,0);assert.equal(h.nodes.licenseCode.value,'expired');assert.equal(h.doc.body.dataset.licensed,'no');assert.match(h.nodes.licenseMessage.textContent,/expirat/);h.page.destroy();
});
test('import cancellation preserves feedback and code; a successful import uses returned status',async()=>{
 let imported=false;const h=harness({licenseImport:async()=>imported?active:{cancelled:true}});await h.page.init();await h.nodes.licenseActivate.onclick();const feedback=h.nodes.licenseMessage.textContent;h.nodes.licenseCode.value='draft';await h.nodes.licenseImport.onclick();
 assert.equal(h.nodes.licenseMessage.textContent,feedback);assert.equal(h.nodes.licenseMessage.dataset.tone,'error');assert.equal(h.nodes.licenseCode.value,'draft');assert.equal(h.toasts.length,0);
 imported=true;await h.nodes.licenseImport.onclick();assert.equal(h.doc.body.dataset.licensed,'yes');assert.equal(h.nodes.licenseCode.value,'');assert.equal(h.toasts.length,1);h.page.destroy();
});
test('late background status cannot overwrite a newer activation result',async()=>{
 const old=deferred();let reads=0;const h=harness({licenseStatus:()=>++reads===1?Promise.resolve(missing):old.promise});await h.page.init();h.advance(1200);const check=h.page.refresh();await flush();h.nodes.licenseCode.value='new';await h.nodes.licenseActivate.onclick();old.resolve(missing);await check;
 assert.equal(h.doc.body.dataset.licensed,'yes');assert.equal(h.nodes.licenseId.textContent,active.licenseId);h.page.destroy();
});
test('publisher setup errors explain the next step and leave recovery enabled',async()=>{
 const h=harness({licenseStatus:async()=>({active:false,configured:false,reason:'missing_publisher_key'})});await h.page.init();assert.equal(h.nodes.licenseActivate.disabled,true);assert.equal(h.nodes.licenseImport.disabled,true);assert.equal(h.nodes.licenseRecovery.disabled,false);assert.equal(h.nodes.licenseRefresh.disabled,false);assert.equal(h.doc.activeElement,h.nodes.licenseRefresh);assert.match(h.nodes.licenseMessage.textContent,/pachetul oficial/);assert.doesNotMatch(h.nodes.licenseMessage.textContent,/Ed25519|publică|PEM/);h.page.destroy();
});
test('expiry schedules one backend recheck, while focus/visibility reads are coalesced',async()=>{
 let reads=0;const focus=deferred(),h=harness({licenseStatus:async()=>{reads++;return reads===1?{...active,expiresAt:'2026-11-02T12:00:01Z'}:reads===2?focus.promise:{active:false,configured:true,reason:'expired_license'}}});await h.page.init();assert.equal(h.scheduled.size,1);assert.equal([...h.scheduled.values()][0].delay,1030);
 h.advance(1200);const check=h.page.refresh();h.windowListeners.focus();h.listeners.visibilitychange();await flush();assert.equal(reads,2);focus.resolve({...active,expiresAt:'2026-11-02T12:00:02Z'});await check;
 h.advance(1000);[...h.scheduled.values()][0].fn();await flush();assert.equal(reads,3);assert.equal(h.doc.body.dataset.licensed,'no');assert.equal(h.nodes.licenseGate.classList.contains('hidden'),false);assert.equal(h.scheduled.size,0);h.page.destroy();assert.equal(h.scheduled.size,0);
});
test('expiry during a cancelled file picker is verified after the picker closes',async()=>{
 const picker=deferred();let expired=false;const h=harness({licenseStatus:async()=>expired?{active:false,configured:true,reason:'expired_license'}:{...active,expiresAt:'2026-11-02T12:00:01Z'},licenseImport:()=>picker.promise});await h.page.init();h.page.open();const pending=h.nodes.licenseImport.onclick();h.advance(1100);expired=true;[...h.scheduled.values()][0].fn();picker.resolve({cancelled:true});await pending;await flush();assert.equal(h.doc.body.dataset.licensed,'no');h.page.destroy();
});
test('long expirations cap native timer delay without polling the backend',async()=>{
 let reads=0;const h=harness({licenseStatus:async()=>{reads++;return {...active,expiresAt:'2027-11-02T12:00:00Z'}}});await h.page.init();const timer=[...h.scheduled.values()][0];assert.equal(timer.delay,2147483647);h.advance(timer.delay);timer.fn();assert.equal(reads,1);assert.equal([...h.scheduled.values()].at(-1).delay,2147483647);h.page.destroy();
});
test('keyboard keeps focus inside activation, allows submit shortcut, and blocks command palette',async()=>{
 let activations=0;const h=harness({licenseActivate:async()=>{activations++;return active}});await h.page.init();h.nodes.licenseCode.focus();assert.equal(h.key('Tab',{shiftKey:true}).prevented,true);assert.equal(h.doc.activeElement,h.nodes.licenseRecovery);assert.equal(h.key('Tab').prevented,true);assert.equal(h.doc.activeElement,h.nodes.licenseCode);assert.equal(h.key('Escape').stopped,true);assert.equal(h.nodes.licenseGate.classList.contains('hidden'),false);assert.equal(h.key('k',{ctrlKey:true}).stopped,true);
 h.nodes.licenseCode.value='code';h.key('Enter',{ctrlKey:true});await flush();assert.equal(activations,1);h.page.destroy();
});
test('status errors can be retried, preview stays available, and cleanup removes listeners',async()=>{
 let fail=true;const h=harness({licenseStatus:()=>{if(fail)throw Error('Unavailable');return Promise.resolve(missing)}});await h.page.init();assert.match(h.nodes.licenseMessage.textContent,/nu a putut fi verificată/);fail=false;await h.nodes.licenseRefresh.onclick();assert.equal(h.page.getState().reason,'missing_license');h.page.destroy();assert.equal(Object.keys(h.listeners).length,0);assert.equal(Object.keys(h.windowListeners).length,0);
 const preview=harness({}, {preview:true});await preview.page.init();assert.equal(preview.nodes.licenseGate.classList.contains('hidden'),true);assert.equal(preview.nodes.licenseButton.classList.contains('hidden'),true);preview.page.destroy();
});
