$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$script:assertions=0
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$failed=$false;try{& $operation}catch{$failed=$true};Assert $failed $label}
function Import-Functions($file,$names){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root $file),[ref]$tokens,[ref]$errors)
 if(@($errors).Count){throw ('Parse errors in '+$file)}
 foreach($name in $names){
  $definition=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
  if($null -eq $definition){throw ('Missing function '+$name)}
  $parameters=(@($definition.Parameters | ForEach-Object {$_.Extent.Text}) -join ',')
  $body=$definition.Body.Extent.Text
  Set-Item -Path ('Function:script:'+$name) -Value ([scriptblock]::Create(('param('+ $parameters +')'+$body.Substring(1,$body.Length-2))))
 }
}
function Restore-Block($file,$needle){
 $source=[IO.File]::ReadAllText((Join-Path $root $file))
 $offset=$source.IndexOf($needle,[StringComparison]::Ordinal)
 if($offset -lt 0){throw ('Restore branch missing: '+$file)}
 return [scriptblock]::Create($source.Substring($offset))
}
$guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
$script:adapters=@([pscustomobject]@{Name='Renamed[1]';InterfaceGuid=$guid;Status='Disconnected';ifIndex=42},[pscustomobject]@{Name='Ethernet';InterfaceGuid='11111111-2222-3333-4444-555555555555';Status='Up';ifIndex=43})
function Get-NetAdapter {
 param($Name,[switch]$IncludeHidden,$ErrorAction)
 $script:includedHidden=[bool]$IncludeHidden
 if($PSBoundParameters.ContainsKey('Name')){return @($script:adapters | Where-Object {$_.Name -like $Name})}
 return $script:adapters
}
function Test-Path {param($LiteralPath) return $true}
function Get-Content {param($LiteralPath,[switch]$Raw) return ($script:mockBackup|ConvertTo-Json -Depth 10)}
function Move-Item {param($LiteralPath,$Destination,[switch]$Force,$ErrorAction) $script:archived=$true}
function New-ItemProperty {
 param($LiteralPath,$Name,$Value,$PropertyType,[switch]$Force,$ErrorAction)
 $script:writes+=,@{name=$Name;value=$Value}
 $script:tcpCurrent[$Name]=@{exists=$true;kind=$PropertyType;value=$Value}
}
function Remove-ItemProperty {
 param($LiteralPath,$Name,$ErrorAction)
 $script:writes+=,@{name=$Name;deleted=$true}
 $script:tcpCurrent[$Name]=@{exists=$false;kind=$null;value=$null}
}
function Get-RegState($key){return $script:tcpCurrent}
Import-Functions 'tcp-latency.ps1' @('Validate-TcpState','Same-TcpValue','Assert-TcpRestored','Put-Previous','Resolve-Adapter')
$tcpRestore=Restore-Block 'tcp-latency.ps1' 'if(!(Test-Path -LiteralPath $file)){throw ''Nu exista backup TCP de restaurat.''}'
$root='MockInterfaces';$file='tcp-latency.json';$dir='MockBackups';$fields=@('TcpAckFrequency','TCPNoDelay')
$script:mockBackup=@{name='Ethernet';guid=('{'+$guid.ToUpperInvariant()+'}');key=(Join-Path $root $guid.ToUpperInvariant());state=@{TcpAckFrequency=@{exists=$true;kind='DWord';value=2};TCPNoDelay=@{exists=$false;kind=$null;value=$null}}}
$script:tcpCurrent=@{TcpAckFrequency=@{exists=$true;kind='DWord';value=1};TCPNoDelay=@{exists=$false;kind=$null;value=$null}}
$script:writes=@();$script:archived=$false
$report=& $tcpRestore | ConvertFrom-Json
Assert ($report.success -and $script:archived) 'TCP recovery follows original GUID after rename, even when old name belongs to new hardware'
Assert ($script:includedHidden) 'TCP recovery includes hidden/disconnected original adapter'
Assert ($script:tcpCurrent.TcpAckFrequency.value -eq 2 -and -not $script:tcpCurrent.TCPNoDelay.exists) 'partial TCP application restores all original values'
$script:tcpCurrent.TcpAckFrequency.value=7;$script:writes=@();$script:archived=$false
Reject {& $tcpRestore} 'external TCP value rejects restoration'
Assert ($script:writes.Count -eq 0 -and -not $script:archived) 'external TCP drift leaves original backup and values untouched'
$script:mockBackup.guid='invalid';$script:writes=@()
Reject {& $tcpRestore} 'invalid TCP GUID rejects restoration'
Assert ($script:writes.Count -eq 0) 'invalid TCP identity causes zero writes'
$script:mockBackup.guid='00000000-0000-0000-0000-000000000001'
Reject {& $tcpRestore} 'missing original TCP hardware cannot use old alias replacement'
$script:adapters=@([pscustomobject]@{Name='Ethernet[1]';InterfaceGuid=$guid;Status='Up';ifIndex=42},[pscustomobject]@{Name='Ethernet1';InterfaceGuid='11111111-2222-3333-4444-555555555555';Status='Up';ifIndex=43})
$target=Resolve-Adapter 'Ethernet[1]'
Assert ($target.guid -eq $guid) 'TCP apply resolves literal bracket alias without wildcard retargeting'

# NIC Power uses the saved GUID for recovery and passes the exact CIM object to
# the setter. The mocks honor wildcard syntax to detect alias retargeting.
$root=Split-Path -Parent $PSScriptRoot
Import-Functions 'nic-power-pro.ps1' @('Power-Object','Adapter-Values')
$powerRestore=Restore-Block 'nic-power-pro.ps1' 'if(!(Test-Path -LiteralPath $file)){throw ''Backup NIC Power PRO inexistent.''}'
$script:powerRows=@([pscustomobject]@{Name='Ethernet[1]';SelectiveSuspend='Disabled';DeviceSleepOnDisconnect='Disabled'},[pscustomobject]@{Name='Ethernet1';SelectiveSuspend='Enabled';DeviceSleepOnDisconnect='Enabled'})
function Get-NetAdapterPowerManagement {
 param($Name,[switch]$IncludeHidden,$ErrorAction)
 return @($script:powerRows | Where-Object {$_.Name -like $Name})
}
function Set-NetAdapterPowerManagement {
 param($InputObject,$Name,$SelectiveSuspend,$DeviceSleepOnDisconnect,[switch]$NoRestart,$ErrorAction)
 if($null -eq $InputObject){throw 'Setter must receive exact power CIM object'}
 $script:writes+=,@{target=$InputObject.Name}
 if($script:noOp){return}
 if($PSBoundParameters.ContainsKey('SelectiveSuspend')){$InputObject.SelectiveSuspend=$SelectiveSuspend}
 if($PSBoundParameters.ContainsKey('DeviceSleepOnDisconnect')){$InputObject.DeviceSleepOnDisconnect=$DeviceSleepOnDisconnect}
}
$script:mockBackup=@{name='Old Ethernet';guid=('{'+$guid.ToUpperInvariant()+'}');selectiveSuspend='Enabled';deviceSleepOnDisconnect='Disabled'}
$dir='MockBackups';$file='nic-power-pro.json';$script:writes=@();$script:archived=$false;$script:noOp=$false
$report=& $powerRestore | ConvertFrom-Json
Assert ($report.success -and $script:archived) 'NIC Power recovery follows saved GUID across alias changes and GUID formatting'
Assert ($script:writes.Count -eq 1 -and $script:writes[0].target -eq 'Ethernet[1]') 'NIC Power setter receives only the selected literal alias CIM object'
Assert ($script:powerRows[0].SelectiveSuspend -eq 'Enabled' -and $script:powerRows[1].SelectiveSuspend -eq 'Enabled') 'NIC Power restores the original without touching wildcard alias neighbor'
$script:powerRows[0].DeviceSleepOnDisconnect='Enabled';$script:writes=@();$script:archived=$false
Reject {& $powerRestore} 'NIC Power rejects external changes to an originally disabled field'
Assert ($script:writes.Count -eq 0 -and -not $script:archived) 'NIC Power drift preserves backup with zero writes'
$script:powerRows[0].DeviceSleepOnDisconnect='Disabled';$script:powerRows[0].SelectiveSuspend='Disabled';$script:noOp=$true
Reject {& $powerRestore} 'NIC Power no-op restore is not a successful restoration'
Assert (-not $script:archived) 'NIC Power failed readback preserves backup'
$script:mockBackup.guid='11111111-2222-3333-4444-555555555554';$script:writes=@()
Reject {& $powerRestore} 'NIC Power missing original adapter rejects restoration'
Assert ($script:writes.Count -eq 0) 'NIC Power unavailable GUID cannot write to similarly named replacement'

Import-Functions 'nicexperimental.ps1' @('FindProp')
$advancedRestore=Restore-Block 'nicexperimental.ps1' 'if(!(Test-Path -LiteralPath $file)){throw ''Backup pentru NIC experimental lipsa.''}'
$script:advancedRows=@([pscustomobject]@{Name='Ethernet[1]';RegistryKeyword='*EEE';RegistryValue=@('0')},[pscustomobject]@{Name='Ethernet1';RegistryKeyword='*EEE';RegistryValue=@('0')})
function Get-NetAdapterAdvancedProperty {
 param($Name,$RegistryKeyword,[switch]$IncludeHidden,$ErrorAction)
 return @($script:advancedRows | Where-Object {$_.Name -like $Name -and $_.RegistryKeyword -like $RegistryKeyword})
}
function Set-NetAdapterAdvancedProperty {
 param($InputObject,$Name,$RegistryKeyword,$RegistryValue,[switch]$NoRestart,$ErrorAction)
 if($null -eq $InputObject){throw 'Setter must receive exact advanced CIM object'}
 $script:writes+=,@{target=$InputObject.Name}
 $InputObject.RegistryValue=@($RegistryValue)
}
$Id='nic_eee';$key='*EEE';$file='nic_eee.json'
$script:mockBackup=@{version=1;id=$Id;keyword=$key;old='1';name='Old Ethernet';guid=('{'+$guid.ToUpperInvariant()+'}')}
$script:writes=@();$script:archived=$false
$report=& $advancedRestore | ConvertFrom-Json
Assert ($report.success -and $script:archived) 'experimental NIC restore accepts GUID case/braces and renamed original adapter'
Assert ($script:writes.Count -eq 1 -and $script:writes[0].target -eq 'Ethernet[1]') 'experimental NIC setter targets exact property CIM object'
Assert ($script:advancedRows[0].RegistryValue[0] -eq '1' -and $script:advancedRows[1].RegistryValue[0] -eq '0') 'experimental restore preserves wildcard alias neighbor'
$script:advancedRows[0].RegistryValue=@('2');$script:writes=@();$script:archived=$false
Reject {& $advancedRestore} 'experimental NIC external property drift blocks restoration'
Assert ($script:writes.Count -eq 0 -and -not $script:archived) 'experimental drift preserves backup and performs zero writes'
$script:mockBackup.guid='invalid'
Reject {& $advancedRestore} 'experimental NIC malformed GUID is rejected before property lookup'
Assert ($script:writes.Count -eq 0 -and -not $script:archived) 'experimental invalid identity leaves backup and native state intact'
@{success=$true;assertions=$script:assertions}|ConvertTo-Json -Compress
