'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {snapshotRows,createSnapshotService,equal,hash}=require('../snapshot-core'),catalog=require('../tweak-library-core');
const capture=(id,value=0)=>{const r=catalog.getRule(id);return {id,success:true,current:r.entries.map(e=>({...e,exists:true,kind:'DWord',value}))}};
function fixture(t,{legacy=false}={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-snapshot-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const id=crypto.randomUUID(),root=path.join(dir,'recovery-snapshots',id);fs.mkdirSync(root,{recursive:true});
 const c=capture('library-cpu-035'),name=c.id+'.json',raw=JSON.stringify(c);fs.writeFileSync(path.join(root,name),raw);const identity='a'.repeat(64);
 if(!legacy)fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify({version:2,id,identity,complete:true,files:[{name,sha256:hash(raw)}]}));
 const row=snapshotRows([c])[0],states=new Map([[row.resource,{...row.target,value:1}]]),writes=[],failure={};let clock=1000,host=identity,clear=true;
 const save=(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(value))};
 const options={dataDir:()=>dir,identity:async()=>host,assertClear:async()=>{if(!clear)throw Error('Active originals')},save,now:()=>clock,
 probe:async r=>({success:true,current:structuredClone(states.get(r.resource))}),write:async r=>{writes.push(r);if(failure.write)return {success:false,message:'Access denied'};if(equal(states.get(r.resource),r.target))return {success:true,verified:true,skipped:true};if(!equal(states.get(r.resource),r.expected))return {success:false,message:'External change'};states.set(r.resource,structuredClone(r.target));return {success:true,verified:true}}};
 return {id,dir,root,row,states,writes,failure,service:createSnapshotService(options),reopen:()=>createSnapshotService(options),host:v=>host=v,clear:v=>clear=v,expire:()=>clock+=180001};
}
test('snapshot preview does not write; commit restores captured value and persistent undo restores before state',async t=>{const f=fixture(t),p=await f.service.prepare(f.id);assert.equal(f.writes.length,0);assert.equal(p.rows[0].changed,true);const r=await f.service.commit(p.token);assert.equal(r.success,true);assert.equal(f.states.get(f.row.resource).value,0);const reopened=f.reopen();assert.equal(reopened.transactions().length,1);const undo=await reopened.resume(r.id,true);assert.equal(undo.state,'undone');assert.equal(f.states.get(f.row.resource).value,1)});
test('failed OS write retains undo and resumes across process recreation',async t=>{const f=fixture(t),p=await f.service.prepare(f.id);f.failure.write=true;const r=await f.service.commit(p.token);assert.equal(r.success,false);assert.equal(f.service.blocking().length,1);assert.equal(f.states.get(f.row.resource).value,1);f.failure.write=false;const resumed=await f.reopen().resume(r.id);assert.equal(resumed.success,true);assert.equal(f.service.blocking().length,0)});
test('external changes after preview are not overwritten or called success',async t=>{const f=fixture(t),p=await f.service.prepare(f.id);f.states.get(f.row.resource).value=8;const r=await f.service.commit(p.token);assert.equal(r.failed,1);assert.equal(f.states.get(f.row.resource).value,8);assert.match(r.rows[0].message,/External/)});
test('changed file hashes and cross-machine copies are rejected without mutation',async t=>{const f=fixture(t);f.host('b'.repeat(64));await assert.rejects(f.service.prepare(f.id),/altui/);f.host('a'.repeat(64));const p=await f.service.prepare(f.id);fs.appendFileSync(path.join(f.root,'library-cpu-035.json'),' ');await assert.rejects(f.service.commit(p.token),/coruptă/);assert.equal(f.writes.length,0)});
test('snapshot refuses active automatic originals, including when introduced after preview',async t=>{const f=fixture(t);f.clear(false);await assert.rejects(f.service.prepare(f.id),/Active/);f.clear(true);const p=await f.service.prepare(f.id);f.clear(false);await assert.rejects(f.service.commit(p.token),/Active/);assert.equal(f.service.transactions().length,0)});
test('expired and reused confirmations never write twice',async t=>{const f=fixture(t),p=await f.service.prepare(f.id);f.expire();await assert.rejects(f.service.commit(p.token),/expirat/);assert.equal(f.writes.length,0);const p2=await f.service.prepare(f.id);await f.service.commit(p2.token);await assert.rejects(f.service.commit(p2.token),/expirat/)});
test('legacy copies remain addressable with an explicit legacy warning',async t=>{const f=fixture(t,{legacy:true}),p=await f.service.prepare(f.id);assert.equal(p.legacy,true);assert.equal((await f.service.commit(p.token)).success,true)});
test('path traversal and symlink snapshots are rejected',async t=>{const f=fixture(t);await assert.rejects(f.service.prepare('../escape'));const manifest=JSON.parse(fs.readFileSync(path.join(f.root,'manifest.json')));manifest.files[0].name='../escape.json';fs.writeFileSync(path.join(f.root,'manifest.json'),JSON.stringify(manifest));await assert.rejects(f.service.prepare(f.id),/invalid/);assert.equal(f.writes.length,0)});
test('duplicate catalog aliases produce one physical write target',()=>{const rows=snapshotRows([capture('library-cpu-035'),capture('library-ram-006')]);assert.equal(rows.length,1);assert.throws(()=>snapshotRows([capture('library-cpu-035',0),capture('library-ram-006',1)]),/contradictorii/)});
test('foreign targets, duplicate originals and tampered native operations are rejected',()=>{const c=capture('library-cpu-035');c.current[0].name='arbitrary';assert.throws(()=>snapshotRows([c]));const g=capture('library-cpu-012');g.current[1]=g.current[0];assert.throws(()=>snapshotRows([g]),/duplicată/);assert.throws(()=>snapshotRows([{id:'library-net-003',success:true,current:{automatic:true,servers:[]},operation:{type:'maintenance',name:'anything'}}]),/diferită/)});
test('native saved adapter identity and partial BCD overlap are deduplicated correctly',()=>{const r=catalog.getRule('library-net-003'),op={...r.operation,adapterGuid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'};assert.equal(snapshotRows([{id:r.id,success:true,current:{automatic:true,servers:[]},operation:op}])[0].operation.adapterGuid,op.adapterGuid);const b=catalog.getRule('library-adv-006');const c={id:b.id,success:true,operation:b.operation,current:b.operation.values.map(x=>({...x,exists:false,value:null}))};assert.equal(snapshotRows([c,{...c,id:'library-adv-013'}]).length,1)});
test('unknown native before data must be present and maintenance cannot be restored as a snapshot',()=>{assert.throws(()=>snapshotRows([{id:'library-net-003',success:true,operation:catalog.getRule('library-net-003').operation}]));assert.throws(()=>snapshotRows([{id:'library-net-011',success:true,current:0}]),/ireversibilă/)});

test('modern manifests require a checksum for every file',async t=>{const f=fixture(t),file=path.join(f.root,'manifest.json'),m=JSON.parse(fs.readFileSync(file));delete m.files[0].sha256;fs.writeFileSync(file,JSON.stringify(m));await assert.rejects(f.service.prepare(f.id),/Amprenta/);assert.equal(f.writes.length,0)});

test('manifest changes after preview invalidate confirmation even when capture bytes match',async t=>{
 const f=fixture(t),p=await f.service.prepare(f.id),file=path.join(f.root,'manifest.json'),m=JSON.parse(fs.readFileSync(file));m.complete=false;fs.writeFileSync(file,JSON.stringify(m));
 await assert.rejects(f.service.commit(p.token),/schimbat/);assert.equal(f.writes.length,0);
});
test('Registry snapshots reject out-of-range DWORD, invalid bytes and coerced string lists',()=>{
 for(const [kind,value] of [['DWord',4294967296],['DWord',-2147483649],['Binary',[-1]],['Binary',[256]],['Binary',[1.5]],['MultiString',[42]]]){
  const c=capture('library-cpu-035');Object.assign(c.current[0],{kind,value});assert.throws(()=>snapshotRows([c]),/Registry|DWord/);
 }
 for(const value of [-2147483648,4294967295]){const c=capture('library-cpu-035',value);assert.equal(snapshotRows([c]).length,1)}
});
test('corrupt transaction IDs and targets are rejected before any write or save outside transaction root',async t=>{
 const f=fixture(t),p=await f.service.prepare(f.id),r=await f.service.commit(p.token),file=path.join(f.dir,'snapshot-transactions',r.id+'.json');
 r.id='../escaped';fs.writeFileSync(file,JSON.stringify(r));
 await assert.rejects(f.reopen().resume(path.basename(file,'.json'),true),/Jurnal/);
 assert.equal(fs.existsSync(path.join(f.dir,'escaped.json')),false);
 r.id=path.basename(file,'.json');r.rows[0].before.name='Foreign';fs.writeFileSync(file,JSON.stringify(r));
 await assert.rejects(f.reopen().resume(r.id,true),/Registry/);assert.equal(f.writes.length,1);
});
test('an interrupted undo must resume undo and cannot switch back to restore',async t=>{
 const f=fixture(t),p=await f.service.prepare(f.id),r=await f.service.commit(p.token);f.failure.write=true;
 const undo=await f.service.resume(r.id,true);assert.equal(undo.direction,'undo');assert.equal(undo.state,'partial');const count=f.writes.length;
 await assert.rejects(f.reopen().resume(r.id,false),/Anularea/);assert.equal(f.writes.length,count);
 f.failure.write=false;assert.equal((await f.reopen().resume(r.id,true)).state,'undone');
});

test('restart requirement survives a resumed write already present after an interruption',async t=>{
 const f=fixture(t),p=await f.service.prepare(f.id);f.failure.write=true;
 const partial=await f.service.commit(p.token);assert.equal(partial.success,false);
 // Model Windows accepting a write just before the previous process could persist its success.
 f.states.set(f.row.resource,structuredClone(f.row.target));f.failure.write=false;
 const resumed=await f.reopen().resume(partial.id);assert.equal(resumed.success,true);assert.equal(resumed.skipped,1);assert.equal(resumed.restartRequired,!!f.row.restart);
 await assert.rejects(f.reopen().resume(partial.id),/deja completă/);
});

test('malformed transactions remain visible diagnostics instead of crashing the recovery inventory',async t=>{
 const f=fixture(t),dir=path.join(f.dir,'snapshot-transactions');fs.mkdirSync(dir);fs.writeFileSync(path.join(dir,'broken.json'),'{');
 const rows=f.service.transactions();assert.equal(rows.length,1);assert.equal(rows[0].state,'invalid');assert.equal(rows[0].recoverable,false);assert.equal(f.service.blocking().length,1);assert.equal(fs.readFileSync(path.join(dir,'broken.json'),'utf8'),'{');
});
test('a valid empty transaction cannot have changed Windows and does not trap future snapshots',async t=>{
 const f=fixture(t),dir=path.join(f.dir,'snapshot-transactions');fs.mkdirSync(dir);const id=crypto.randomUUID();
 fs.writeFileSync(path.join(dir,id+'.json'),JSON.stringify({id,snapshotId:f.id,identity:'a'.repeat(64),type:'snapshot-restore',state:'prepared',rows:[]}));
 assert.equal(f.service.transactions()[0].state,'empty');assert.equal(f.service.blocking().length,0);assert.ok((await f.service.prepare(f.id)).token);assert.equal(f.writes.length,0);
});

test('native captures validate the entire state before they can be advertised as restorable',()=>{
 const guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
 const invalid=[
  ['library-net-003',{automatic:true,servers:['8.8.8.8']},{adapterGuid:guid}],
  ['library-net-003',{automatic:false,servers:['::1']},{adapterGuid:guid}],
  ['library-net-003',{automatic:false,servers:[]},{adapterGuid:guid}],
  ['library-net-003',{automatic:true,servers:[],metadata:'not returned by Windows'},{adapterGuid:guid}],
  [require('../tweak-library.json').find(r=>r.operation?.type==='mtu').id,{active:1500,persistent:0},{adapterGuid:guid}],
  ['library-cpu-010',[{name:'AnotherService',start:2,running:true,delayedExists:false,delayed:0}],{}],
  ['library-adv-006',[{key:'ForeignKey',object:'{current}',exists:false,value:null}],{}]
 ];
 for(const [id,current,extra] of invalid){const rule=catalog.getRule(id);assert.throws(()=>snapshotRows([{id,success:true,current,operation:{...rule.operation,...extra}}]),/nativă|diferită/)}
});
test('equivalent braced adapter identities address one physical snapshot target',()=>{
 const rule=catalog.getRule('library-net-003'),guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
 const c={id:rule.id,success:true,current:{automatic:true,servers:[]},operation:{...rule.operation,adapterGuid:guid}};
 const other={...c,operation:{...c.operation,adapterGuid:'{'+guid.toUpperCase()+'}'}};
 assert.equal(snapshotRows([c,other]).length,1);
 assert.throws(()=>snapshotRows([c,{...other,current:{automatic:false,servers:['8.8.8.8']}}]),/contradictorii/);
});
test('malformed live originals fail during preview without persisting an undo transaction',async t=>{
 const f=fixture(t);f.states.set(f.row.resource,{...f.row.target,name:'Foreign'});
 await assert.rejects(f.service.prepare(f.id),/Registry/);assert.equal(f.service.transactions().length,0);assert.equal(f.writes.length,0);
});
test('persisted native undo originals and target identities are validated before any write',async t=>{
 const f=fixture(t),p=await f.service.prepare(f.id),r=await f.service.commit(p.token),file=path.join(f.dir,'snapshot-transactions',r.id+'.json');
 const rule=catalog.getRule('library-net-003'),current={automatic:true,servers:[]};
 const row=snapshotRows([{id:rule.id,success:true,current,operation:{...rule.operation,adapterGuid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}}])[0];
 for(const changed of [{before:null},{before:current,resource:'native:dns:other-adapter'}]){
  fs.writeFileSync(file,JSON.stringify({...r,rows:[{...row,before:current,...changed}]}));
  await assert.rejects(f.reopen().resume(r.id,true),/nativă/);assert.equal(f.writes.length,1);
 }
});
test('a manifest cannot list the same capture filename twice',async t=>{
 const f=fixture(t),file=path.join(f.root,'manifest.json'),m=JSON.parse(fs.readFileSync(file));m.files.push({...m.files[0]});fs.writeFileSync(file,JSON.stringify(m));
 await assert.rejects(f.service.prepare(f.id),/duplicat/);assert.equal(f.writes.length,0);
});
test('undo of an unchanged snapshot does not invent a restart requirement',async t=>{
 const f=fixture(t);f.states.set(f.row.resource,structuredClone(f.row.target));const p=await f.service.prepare(f.id),r=await f.service.commit(p.token);
 assert.equal(r.skipped,1);assert.equal(r.restartRequired,false);const undo=await f.reopen().resume(r.id,true);assert.equal(undo.success,true);assert.equal(undo.restartRequired,false);
});
