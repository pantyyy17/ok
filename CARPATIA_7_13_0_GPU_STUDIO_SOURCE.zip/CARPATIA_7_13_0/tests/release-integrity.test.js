'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
function included(name,files){return files.some(glob=>new RegExp('^'+glob.split('*').map(s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('.*')+'$').test(name))}
function checkGraph(files){
 const visited=new Set();
 function visit(name){
  if(visited.has(name))return;visited.add(name);
  assert(included(name,files),'Missing packaged dependency: '+name);
  const source=fs.readFileSync(path.join(root,name),'utf8');
  for(const match of source.matchAll(/require\(['"](\.[^'"]+)['"]\)/g)){
   const relative=path.posix.normalize(path.posix.join(path.posix.dirname(name),match[1]));
   visit(path.posix.extname(relative)?relative:relative+'.js');
  }
 }
 visit(manifest.main);visit('preload.js');
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 for(const match of html.matchAll(/(?:src|href)="([^"#]+\.(?:js|css))"/g))assert(included(match[1],files),match[1]);
 return visited;
}
test('installer includes transitive local JS dependencies and UI assets',()=>{assert(checkGraph(manifest.build.files).has('ultra-max.js'))});
test('regression: missing ultra-max is detected before creating installer',()=>{assert.throws(()=>checkGraph(manifest.build.files.filter(x=>x!=='ultra-max.js')),/ultra-max/)});
test('all source JavaScript parses',()=>{for(const dir of ['.','tools','seller'])for(const name of fs.readdirSync(path.join(root,dir)).filter(x=>x.endsWith('.js')))new vm.Script(fs.readFileSync(path.join(root,dir,name),'utf8'),{filename:dir+'/'+name})});
