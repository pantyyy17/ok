'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawnSync}=require('node:child_process');
const {prepareWorkspace,captureBaseline,verifyBaseline,originalRequests,verifyOriginals,assertRestart}=require('../tools/recovery-validation-core');
const project=path.resolve(__dirname,'..');
function temporary(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-validation-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir}
const restart={version:1,phase:'awaiting-restart',group:'cpu',identity:'machine-user-hash',bootUtc:'2026-11-02T10:00:00Z',baseline:[{id:'test',current:1}],changedIds:['test']};
test('same-boot resume and a different machine/user never count as an OS restart',()=>{
 assert.throws(()=>assertRestart(restart,{identity:restart.identity,bootUtc:restart.bootUtc}),/not restarted/);
 assert.throws(()=>assertRestart(restart,{identity:'other',bootUtc:'2026-11-02T12:00:00Z'}),/another Windows/);
 assert.throws(()=>assertRestart(restart,{identity:restart.identity,bootUtc:'invalid'}),/boot time/);
 assert.throws(()=>assertRestart(restart,{identity:restart.identity,bootUtc:'2026-11-02T09:00:00Z'}),/not restarted/);
});
test('resume requires a changed pending profile and the selected saved group',()=>{
 const current={identity:restart.identity,bootUtc:'2026-11-02T12:00:00Z'};
 assert.doesNotThrow(()=>assertRestart(restart,current,'cpu'));
 assert.throws(()=>assertRestart(restart,current,'gpu'),/group differs/);
 assert.throws(()=>assertRestart({...restart,changedIds:[]},current),/No changed/);
 assert.throws(()=>assertRestart({...restart,phase:'verified'},current),/No pending/);
});
test('fresh workspace refuses existing user files, project, root and linked directories',t=>{
 const dir=temporary(t);fs.writeFileSync(path.join(dir,'user-backup.json'),'keep');
 assert.throws(()=>prepareWorkspace(dir,project),/empty dedicated/);assert.equal(fs.readFileSync(path.join(dir,'user-backup.json'),'utf8'),'keep');
 assert.throws(()=>prepareWorkspace(project,project),/outside/);assert.throws(()=>prepareWorkspace(path.parse(dir).root,project),/drive root/);
 const link=path.join(temporary(t),'link');try{fs.symlinkSync(dir,link,'junction')}catch(error){if(['EPERM','EACCES'].includes(error.code))return;throw error}
 assert.throws(()=>prepareWorkspace(link,project),/real directory/);
});
test('resume accepts only a matching owned workspace and preserves its originals',t=>{
 const dir=temporary(t);prepareWorkspace(dir,project);fs.writeFileSync(path.join(dir,'original.json'),'saved');
 assert.equal(prepareWorkspace(dir,project,{resume:true}),fs.realpathSync(dir));assert.equal(fs.readFileSync(path.join(dir,'original.json'),'utf8'),'saved');
 assert.throws(()=>prepareWorkspace(dir,project),/empty dedicated/);
 const other=temporary(t);assert.throws(()=>prepareWorkspace(other,project,{resume:true}),/No owned/);
 const marker=path.join(dir,'carpatia-test-workspace.json'),value=JSON.parse(fs.readFileSync(marker));value.directory=other;fs.writeFileSync(marker,JSON.stringify(value));assert.throws(()=>prepareWorkspace(dir,project,{resume:true}),/marker/);
});
test('baseline capture requires successful readback including absent Registry values',async()=>{
 const plan={steps:[{id:'registry'}],adapterGuid:''},before=[{path:'HKCU\\Example',name:'Original',exists:false}];
 const baseline=await captureBaseline(plan,async()=>({success:true,current:before}));assert.deepEqual(baseline,[{id:'registry',current:before}]);
 await assert.rejects(captureBaseline(plan,async()=>({success:true})),/Missing readback/);
 await assert.rejects(captureBaseline(plan,async()=>({success:false,current:before})),/Cannot read/);
});
test('verified restore requires equal original values and types, not success or desired matching flags',async()=>{
 const baseline=[{id:'registry',current:[{path:'P',name:'N',exists:true,kind:'DWord',value:0}]}];
 assert.equal(await verifyBaseline(baseline,'',async()=>({success:true,current:[{value:0,kind:'DWord',exists:true,name:'N',path:'P'}],matching:false})),1);
 await assert.rejects(verifyBaseline(baseline,'',async()=>({success:true,matching:true,current:[{path:'P',name:'N',exists:true,kind:'String',value:'0'}]})),/not restored/);
 await assert.rejects(verifyBaseline(baseline,'',async()=>({success:true,matching:true})),/Missing restored/);
});
test('saved native targets are probed directly after the active power plan changes back',async t=>{
 const dir=temporary(t),id='library-cpu-021',operation={type:'power-value',scheme:'saved-high-performance-scheme'},folder=path.join(dir,'tweak-native-backups');fs.mkdirSync(folder);
 fs.writeFileSync(path.join(folder,id+'.json'),JSON.stringify({version:1,id,state:'restored',operation,before:75}));
 const catalog=[{id,status:'native'}],requests=originalRequests(dir,[id],catalog);assert.deepEqual(requests,[{id,kind:'native',operation,target:75}]);
 assert.equal(await verifyOriginals(dir,[id],catalog,async request=>{assert.equal(request.operation.scheme,operation.scheme);return {success:true,current:75}}),1);
 await assert.rejects(verifyOriginals(dir,[id],catalog,async()=>({success:true,current:100})),/differs after restore/);
});
test('original readback also preserves Registry absence and rejects ambiguous or unfinished journals',async t=>{
 const dir=temporary(t),id='library-cpu-005',folder=path.join(dir,'tweak-library-backups');fs.mkdirSync(folder);
 const catalog=[{id,status:'registry',entries:[{path:'HKCU\\Example',name:'N'}]}],original={path:'HKCU\\Example',name:'N',exists:false},file=path.join(folder,id+'.json');
 const journal={version:1,id,state:'restored',values:[original]};fs.writeFileSync(file,JSON.stringify(journal));
 assert.equal(await verifyOriginals(dir,[id],catalog,async()=>({success:true,current:original})),1);
 await assert.rejects(verifyOriginals(dir,[id],catalog,async()=>({success:true,current:{...original,exists:true,kind:'DWord',value:0}})),/differs after restore/);
 fs.writeFileSync(file,JSON.stringify({...journal,state:'applied'}));assert.throws(()=>originalRequests(dir,[id],catalog),/not marked restored/);
 fs.writeFileSync(file,JSON.stringify({...journal,values:[original,original]}));assert.throws(()=>originalRequests(dir,[id],catalog),/Incomplete original/);
});
test('runner help never starts native validation or creates a test directory',t=>{
 const dir=temporary(t),child=spawnSync(process.execPath,[path.join(project,'tools/test-recovery-windows.js'),'--help','--data-dir',dir],{encoding:'utf8'});
 assert.equal(child.status,0,child.stderr);assert.match(child.stdout,/Disposable Windows VM/);assert.deepEqual(fs.readdirSync(dir),[]);
});
test('runner refuses unconsented native execution without creating files',t=>{
 const dir=temporary(t),child=spawnSync(process.execPath,[path.join(project,'tools/test-recovery-windows.js'),'--data-dir',dir],{encoding:'utf8'});
 assert.equal(child.status,2,child.stderr);assert.match(child.stderr,/No native test was performed/);assert.deepEqual(fs.readdirSync(dir),[]);
 if(process.platform!=='win32'){const explicit=spawnSync(process.execPath,[path.join(project,'tools/test-recovery-windows.js'),'--vm-test','--data-dir',dir],{encoding:'utf8'});assert.equal(explicit.status,2);assert.deepEqual(fs.readdirSync(dir),[])}
});
