'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {descriptor,validateSession,createProfileService}=require('../dashboard-profiles');
const catalog=require('../tweak-library-core');
const guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
test('Internet DNS choice selects one trusted target and keep preserves existing DNS',()=>{
 for(const dns of ['google','cloudflare','quad9','keep']){
  const p=descriptor('internet','ultra',guid,{dns}),rows=p.steps.map(s=>catalog.getRule(s.id)).filter(r=>r.operation?.type==='dns');
  assert.equal(rows.length,dns==='keep'?0:1);
  if(rows.length)assert.deepEqual(rows[0].operation.value,{google:['8.8.8.8','8.8.4.4'],cloudflare:['1.1.1.1','1.0.0.1'],quad9:['9.9.9.9','149.112.112.112']}[dns]);
 }
 for(const options of [{dns:'evil'},{dns:'constructor'},{dns:['google']},{dns:new String('google')},{auxiliary:'true'},{extraIds:['library-cpu-022']}])assert.throws(()=>descriptor('internet','low',guid,options));
});
test('auxiliary services require explicit opt-in and preserve independent profile ownership',()=>{
 const all=new Set();
 for(const group of ['cpu','gpu','internet']){
  const normal=descriptor(group,'low',guid),extended=descriptor(group,'low',guid,{auxiliary:true});
  const added=extended.steps.filter(s=>!normal.steps.some(x=>x.id===s.id));assert.equal(added.length,1);
  const rule=catalog.getRule(added[0].id);assert.equal(rule.operation.type,'service');assert.match(extended.warning,/Search|partajarea|SSDP/i);
  for(const service of rule.operation.services){assert.equal(all.has(service.name),false);all.add(service.name)}
 }
});
test('extended CPU settings use supported AC engine and GPU capture targets never edit a display driver',()=>{
 const cpu=descriptor('cpu','ultra'),gpu=descriptor('gpu','medium');
 for(const id of ['library-cpu-energy-performance','library-cpu-core-parking']){
  assert(cpu.steps.some(s=>s.id===id));const r=catalog.getRule(id);assert.equal(r.operation.type,'power-value');assert(!r.sourceCommand.includes('/setdcvalueindex'));
 }
 const r=catalog.getRule('library-gpu-background-capture');assert(gpu.steps.some(s=>s.id===r.id));assert(r.entries.every(e=>e.path.startsWith('HKCU\\')&&e.value===0));
});
test('new profile selections persist across service reopen and all their originals restore',async()=>{
 const records=new Map(),states=new Map();
 const store={read:g=>records.get(g),write:(g,s)=>records.set(g,structuredClone(s))};
 const ops={snapshot:async()=>({success:true,osBuild:26200,ramGB:7.4,gpu:['AMD Radeon']}),status:async()=>({success:true,states:[...states.values()]}),check:async()=>({success:true}),apply:async id=>{states.set(id,{id,state:'applied'});return {success:true}},restore:async id=>{states.set(id,{id,state:'restored'});return {success:true}}};
 let service=createProfileService({store,ops});const p=await service.prepare({group:'internet',level:'medium',adapterGuid:guid,options:{dns:'quad9',auxiliary:true}});
 assert.equal((await service.commit(p.token)).success,true);assert.deepEqual(records.get('internet').options,{dns:'quad9',auxiliary:true});
 validateSession(records.get('internet'),'internet');service=createProfileService({store,ops});assert.equal((await service.restore('internet')).success,true);
 assert([...states.values()].every(s=>s.state==='restored'));
});
