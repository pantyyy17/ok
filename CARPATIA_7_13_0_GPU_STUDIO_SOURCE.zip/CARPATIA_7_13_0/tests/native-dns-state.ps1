$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$script:assertions=0
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$failed=$false;try{& $operation | Out-Null}catch{$failed=$true;$script:rejection=$_.Exception.Message};Assert $failed $label}

# Execute the real DNS script with Windows APIs intercepted. Only an isolated
# temporary backup directory is written; no DNS or Registry operation is real.
$originalLocalAppData=$env:LOCALAPPDATA
$testDir=Join-Path ([IO.Path]::GetTempPath()) ('carpatia-dns-test-'+[guid]::NewGuid().ToString('N'))
$env:LOCALAPPDATA=$testDir
$backup=Join-Path $testDir 'TweakRomania/Backups/dns-latest.json'
$global:CarpatiaDnsMock=@{}
$global:CarpatiaDnsMock.adapter=[pscustomobject]@{Name='Ethernet[1]';Status='Up';ifIndex=42;InterfaceGuid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}
$global:CarpatiaDnsMock.otherAdapter=[pscustomobject]@{Name='Ethernet1';Status='Up';ifIndex=43;InterfaceGuid='11111111-2222-3333-4444-555555555555'}
$global:CarpatiaDnsMock.ipv6=@('2001:db8::53')
$global:CarpatiaDnsMock.noOp=$false
$global:CarpatiaDnsMock.writes=@()
function Get-NetAdapter {
 param($Name,[switch]$IncludeHidden,$ErrorAction)
 $items=@($global:CarpatiaDnsMock.adapter,$global:CarpatiaDnsMock.otherAdapter)
 if($PSBoundParameters.ContainsKey('Name')){return @($items | Where-Object {$_.Name -like $Name})}
 return $items
}
function Get-DnsClientServerAddress {
 param($InterfaceIndex,$AddressFamily,$ErrorAction)
 if($InterfaceIndex -ne 42){throw 'An unselected adapter was queried'}
 if($AddressFamily -ne 'IPv4'){throw 'DNS reads must select IPv4'}
 return [pscustomobject]@{InterfaceIndex=42;AddressFamily=2;ServerAddresses=@($global:CarpatiaDnsMock.ipv4)}
}
function Get-Item {
 param($LiteralPath,$ErrorAction)
 if($LiteralPath -notlike 'HKLM:*'){throw 'Unexpected Registry read'}
 $key=[pscustomobject]@{}
 $key|Add-Member ScriptMethod GetValue {param($name,$default) return $global:CarpatiaDnsMock.manual}
 $key|Add-Member ScriptMethod Dispose {}
 return $key
}
function Set-DnsClientServerAddress {
 param($InterfaceIndex,$InputObject,$ServerAddresses,[switch]$ResetServerAddresses,$ErrorAction)
 $global:CarpatiaDnsMock.writes+=@{input=$InputObject;interface=$InterfaceIndex;reset=[bool]$ResetServerAddresses;servers=@($ServerAddresses)}
 if($global:CarpatiaDnsMock.noOp){return}
 if($PSBoundParameters.ContainsKey('InterfaceIndex')){$global:CarpatiaDnsMock.ipv6=@()}
 if($ResetServerAddresses){$global:CarpatiaDnsMock.manual='';$global:CarpatiaDnsMock.ipv4=@('192.0.2.54')}
 else{$global:CarpatiaDnsMock.manual=@($ServerAddresses) -join ',';$global:CarpatiaDnsMock.ipv4=@($ServerAddresses)}
}
try{
 # A DHCP lease may already supply the chosen pair. Address-only readback must
 # not turn a silently ignored request into a successful static DNS apply.
 $global:CarpatiaDnsMock.manual='';$global:CarpatiaDnsMock.ipv4=@('1.1.1.1','1.0.0.1');$global:CarpatiaDnsMock.noOp=$true
 Reject {& (Join-Path $root 'dns.ps1') -Action Set -Adapter 'Ethernet[1]' -Provider cloudflare} 'no-op static apply with matching DHCP addresses is rejected'
 Assert (Test-Path -LiteralPath $backup) ('failed static mode verification retains the backup: '+$script:rejection)
 Assert ($global:CarpatiaDnsMock.writes.Count -eq 1 -and $global:CarpatiaDnsMock.writes[0].input.AddressFamily -eq 2 -and $null -eq $global:CarpatiaDnsMock.writes[0].interface) 'static apply binds the IPv4 CIM object rather than the whole interface'
 Assert (($global:CarpatiaDnsMock.ipv6 -join ',') -ceq '2001:db8::53') 'apply preserves the independent static IPv6 resolver'
 Remove-Item -LiteralPath $backup -Force

 # Exact alias selection must not treat square brackets in a Windows adapter
 # name as wildcard syntax and select Ethernet1 instead of Ethernet[1].
 $global:CarpatiaDnsMock.noOp=$false;$global:CarpatiaDnsMock.writes=@();$global:CarpatiaDnsMock.manual='192.0.2.53';$global:CarpatiaDnsMock.ipv4=@('192.0.2.53')
 $applied=& (Join-Path $root 'dns.ps1') -Action Set -Adapter 'Ethernet[1]' -Provider google | ConvertFrom-Json
 Assert ($applied.success -and $applied.adapter -ceq 'Ethernet[1]') 'literal wildcard characters resolve to the selected adapter'
 Assert (($global:CarpatiaDnsMock.ipv4 -join ',') -ceq '8.8.8.8,8.8.4.4' -and $global:CarpatiaDnsMock.manual -ceq '8.8.8.8,8.8.4.4') 'successful apply verifies static mode and server list'
 # Renaming is supported because restoration resolves the persisted GUID.
 $global:CarpatiaDnsMock.adapter.Name='Renamed Ethernet'
 $restored=& (Join-Path $root 'dns.ps1') -Action Restore | ConvertFrom-Json
 Assert ($restored.success -and $global:CarpatiaDnsMock.manual -ceq '192.0.2.53') 'manual original restores by GUID after adapter rename'
 Assert (-not (Test-Path -LiteralPath $backup)) 'confirmed manual restore archives its backup'
 Assert (($global:CarpatiaDnsMock.ipv6 -join ',') -ceq '2001:db8::53') 'manual restore preserves IPv6 DNS'

 # Automatic IPv4 restoration also has to leave an independent IPv6 override.
 $global:CarpatiaDnsMock.manual='';$global:CarpatiaDnsMock.ipv4=@('192.0.2.54');$global:CarpatiaDnsMock.writes=@()
 & (Join-Path $root 'dns.ps1') -Action Set -Adapter 'Renamed Ethernet' -Provider quad9 | Out-Null
 $restored=& (Join-Path $root 'dns.ps1') -Action Restore | ConvertFrom-Json
 Assert ($restored.success -and $global:CarpatiaDnsMock.manual -ceq '') 'automatic original restores to DHCP mode'
 Assert ($global:CarpatiaDnsMock.writes.Count -eq 2 -and $global:CarpatiaDnsMock.writes[1].reset -and $global:CarpatiaDnsMock.writes[1].input.AddressFamily -eq 2 -and $null -eq $global:CarpatiaDnsMock.writes[1].interface) 'automatic restoration resets only its IPv4 CIM object'
 Assert (($global:CarpatiaDnsMock.ipv6 -join ',') -ceq '2001:db8::53') 'automatic IPv4 restore preserves static IPv6 DNS'
 Assert (-not (Test-Path -LiteralPath $backup)) 'confirmed automatic restore archives its backup'

 # A genuine outside change still causes zero restore writes and keeps recovery.
 $global:CarpatiaDnsMock.manual='192.0.2.53';$global:CarpatiaDnsMock.ipv4=@('192.0.2.53')
 & (Join-Path $root 'dns.ps1') -Action Set -Adapter 'Renamed Ethernet' -Provider google | Out-Null
 $global:CarpatiaDnsMock.manual='192.0.2.99';$global:CarpatiaDnsMock.ipv4=@('192.0.2.99');$global:CarpatiaDnsMock.writes=@()
 Reject {& (Join-Path $root 'dns.ps1') -Action Restore} 'external manual DNS changes are rejected'
 Assert ($global:CarpatiaDnsMock.writes.Count -eq 0 -and (Test-Path -LiteralPath $backup)) 'external drift causes no write and retains the backup'
}finally{
 $env:LOCALAPPDATA=$originalLocalAppData
 Remove-Variable -Name CarpatiaDnsMock -Scope Global -ErrorAction SilentlyContinue
 if(Test-Path -LiteralPath $testDir){Remove-Item -LiteralPath $testDir -Recurse -Force}
}
@{success=$true;assertions=$script:assertions}|ConvertTo-Json -Compress
