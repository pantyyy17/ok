'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
test('Registry and native engines retain only complete, restorable originals',t=>{
 const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
 const result=spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(__dirname,'native-catalog-validation.ps1')],{encoding:'utf8',timeout:30000});
 if(result.error?.code==='ENOENT'){t.skip('PowerShell unavailable; set CARPATIA_PWSH to execute mocked catalog guards');return;}
 assert.ifError(result.error);
 assert.equal(result.status,0,result.stderr||result.stdout);
 const report=JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''));
 assert.equal(report.success,true);
 assert.ok(report.assertions>=35);
});
