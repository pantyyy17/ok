'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function harness(confirm){
 class E{constructor(text=''){this.textContent=text;this.children=[];this.value='';this.dataset={};this.classList={add(){}}}append(...x){this.children.push(...x)}replaceChildren(...x){this.children=x}scrollIntoView(){}}
 const nodes={},calls=[],window={};
 const item={id:'library-cpu-035',title:'Kernel paging',category:'CPU',state:'applied',date:'2026-10-27',original:0,live:{current:1},restart:true};
 const api={recoveryInventory:async()=>({items:[item],errors:[],history:[]}),recoveryPrepare:async s=>{calls.push(['prepare',s]);return {token:'token',rows:[item]}},recoveryCommit:async token=>{calls.push(['commit',token]);return {success:true,succeeded:1,failed:0,skipped:0,restartRequired:true,results:[{title:item.title,status:'restored'}]}}};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../recovery-ui.js'),'utf8'),{window,document:{getElementById:id=>nodes[id]??=new E(),createElement:()=>new E()},Option:class extends E{constructor(t,v){super(t);this.value=v}}});
 const page=window.CarpatiaRecovery.mount({api,task:(_,fn)=>fn(),confirmDialog:async()=>confirm,requireNative:()=>true,showToast:()=>{}});return {page,nodes,calls};
}
test('recovery renders named item and confirmed individual restore, with report',async()=>{const h=harness(true);await h.page.load();const row=h.nodes.recoveryRows.children[0];await row.children.find(x=>x.textContent==='RESTAUREAZĂ').onclick();assert.equal(h.calls[0][1].id,'library-cpu-035');assert.deepEqual(h.calls[1],['commit','token']);assert.match(h.nodes.recoveryReport.textContent,/1 restaurate/)});
test('canceling restore never invokes commit',async()=>{const h=harness(false);await h.page.load();await h.nodes.recoveryRestore.onclick();assert.equal(h.calls.length,1)});
