'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const read=x=>fs.readFileSync(path.join(__dirname,'..',x),'utf8');
const {restoreComponents}=require('../operation-core');
test('Eroarea de restaurare parțială include exact valoarea defectă, fără a șterge alte backupuri',async()=>{
 const result=await restoreComponents([['registry','engine.ps1']],async(_file,action)=>action==='Status'?{success:true,backup:true}:{success:false,message:'Restaurare incompletă',errors:[{id:'reg-1',error:'Acces refuzat'}]});
 assert.equal(result.success,false);assert.match(result.steps[0].message,/reg-1: Acces refuzat/);
});
test('Recovery Center nu blochează restaurarea pe durata scanării și afișează raportul complet',()=>{
 assert.match(read('ui.js'),/\$\('restoreScan'\)\.onclick=\(\)=>\{if\(!requireNative\(true\)\)return;text/);
 assert.match(read('ui.js'),/restoreUltra'\)\.onclick=\(\)=>showResourceOwner/);
 assert.match(read('recovery-ui.js'),/r\.succeeded/);
 assert.match(read('dashboard-profiles-ui.js'),/skipAdapters/);
 assert.match(read('index.html'),/id=\"restoreResult\"/);
});
