'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {readLedger,resources,conflicts,serviceState,validateServiceBackup}=require('../resource-ledger');
const catalog=require('../tweak-library.json');
function harness(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-ledger-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));const dataDir=path.join(root,'data'),backupDir=path.join(root,'legacy');function write(folder,name,value){const f=path.join(folder==='legacy'?backupDir:path.join(dataDir,folder),name+'.json');fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,typeof value==='string'?value:JSON.stringify(value));return f}return {dataDir,backupDir,write,read:()=>readLedger({dataDir,backupDir})}}
const svc=(extra={})=>({id:'search',name:'WSearch',installed:true,state:'Running',startMode:'Auto',backup:false,...extra});
const backup=()=>({version:1,id:'search',name:'WSearch',before:{name:'WSearch',state:'Running',startMode:'Auto',delayedAutoStart:null}});
function registry(id){const rule=catalog.find(x=>x.id===id);return {version:1,id,state:'applied',values:rule.entries.map(e=>({...e,exists:true,kind:'DWord',value:1}))}}
function nativeService(){return {version:1,id:'library-cpu-010',state:'applied',operation:{type:'service'},before:[{name:'WSearch',start:2,running:true,delayedExists:false,delayed:0}]}}
test('Disabled without backup has no Apply or fabricated Restore',t=>{const h=harness(t),s=serviceState(svc({startMode:'Disabled',state:'Stopped'}),h.read());assert.equal(s.action,'disabled');assert.equal(s.label,'DEJA DEZACTIVAT');assert.equal(h.read().records.length,0)});
test('Enabled service becomes restorable from a validated persistent original',t=>{const h=harness(t);assert.equal(serviceState(svc(),h.read()).action,'apply');h.write('legacy','services-search',backup());const s=serviceState(svc({backup:true,startMode:'Disabled',state:'Stopped'}),h.read());assert.equal(s.action,'restore');assert.deepEqual(validateServiceBackup(backup(),'search').before,backup().before)});
test('independent active Registry backup does not block service',t=>{const h=harness(t);h.write('tweak-library-backups','library-cpu-035',registry('library-cpu-035'));assert.equal(serviceState(svc(),h.read()).action,'apply')});
test('same-service native owner directs recovery to Tweaks',t=>{const h=harness(t);h.write('tweak-native-backups','library-cpu-010',nativeService());const s=serviceState(svc({startMode:'Disabled',state:'Stopped'}),h.read());assert.equal(s.action,'owner');assert.equal(s.owners[0].id,'library-cpu-010');assert.equal(s.owners[0].route,'tweaks')});
test('restart reconstructs recovery ownership solely from disk',t=>{const h=harness(t);h.write('legacy','services-search',backup());const restarted=readLedger({dataDir:h.dataDir,backupDir:h.backupDir});assert.equal(serviceState(svc({backup:true}),restarted).action,'restore')});
test('missing backup reported by native inventory blocks recovery',t=>{const h=harness(t);assert.equal(serviceState(svc({backup:true}),h.read()).action,'blocked')});
test('corrupt and incompatible legacy backups remain byte-for-byte intact and block mutation',t=>{for(const content of ['{broken',JSON.stringify({...backup(),version:99})]){const h=harness(t),file=h.write('legacy','services-search',content);assert.equal(serviceState(svc({backup:true}),h.read()).action,'blocked');assert.equal(fs.readFileSync(file,'utf8'),content)}});
test('unknown running state or absent delayed original cannot be used',t=>{const h=harness(t);assert.equal(serviceState(svc({state:'Start Pending'}),h.read()).action,'blocked');const b=backup();delete b.before.delayedAutoStart;assert.throws(()=>validateServiceBackup(b,'search'))});
test('corrupt unrelated journal remains a conservative unknown-scope block',t=>{const h=harness(t);h.write('tweak-native-backups','unknown','{');assert.equal(serviceState(svc(),h.read()).action,'blocked')});
test('overlapping legacy and native backups are not auto-restored in guessed order',t=>{const h=harness(t);h.write('legacy','services-search',backup());h.write('tweak-native-backups','library-cpu-010',nativeService());assert.equal(serviceState(svc({backup:true}),h.read()).action,'blocked')});
test('RAM duplicate identifies CPU owner by exact Registry target',t=>{const h=harness(t);h.write('tweak-library-backups','library-cpu-035',registry('library-cpu-035'));const owners=conflicts(h.read(),resources(catalog.find(r=>r.id==='library-ram-006')));assert.equal(owners[0].id,'library-cpu-035')});
test('Network P2P duplicate identifies CPU owner',t=>{const h=harness(t);h.write('tweak-library-backups','library-cpu-017',registry('library-cpu-017'));assert.equal(conflicts(h.read(),resources(catalog.find(r=>r.id==='library-net-039')))[0].id,'library-cpu-017')});
test('incomplete Dashboard session detects missing original and never clears it',t=>{const h=harness(t);h.write('dashboard-profiles','cpu',{version:1,group:'cpu',level:'low',state:'applying',started:['library-cpu-005'],unchanged:[]});assert.match(h.read().errors[0],/Backup lipsa/)});
test('Dashboard ownership is retained after restarting',t=>{const h=harness(t);h.write('tweak-library-backups','library-cpu-005',registry('library-cpu-005'));h.write('dashboard-profiles','cpu',{version:1,group:'cpu',level:'low',state:'applied',started:['library-cpu-005'],unchanged:[]});assert.equal(h.read().records[0].route,'dashboard')});
test('SysMain WSearch DiagTrack never occur in Dashboard automatic profiles',()=>{const {descriptor}=require('../dashboard-profiles');for(const g of ['cpu','gpu','internet'])for(const step of descriptor(g,'ultra','aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee').steps){const r=catalog.find(x=>x.id===step.id);assert.ok(!resources(r).some(x=>['service:sysmain','service:wsearch','service:diagtrack'].includes(x)))}});
test('BCD independent keys do not inherit cpu-033 ownership after restart',t=>{const h=harness(t),r=catalog.find(x=>x.id==='library-cpu-033');h.write('tweak-native-backups',r.id,{version:1,id:r.id,state:'applied',operation:r.operation,before:r.operation.values.map(v=>({...v,exists:false,value:null}))});const ledger=h.read();assert.deepEqual(ledger.errors,[]);for(const id of ['library-adv-007','library-adv-008'])assert.equal(conflicts(ledger,resources(catalog.find(r=>r.id===id))).length,0);assert.equal(conflicts(ledger,resources(r)).length,1)});
test('BCD exact overlap accounts for object, key, case and multi-key operations',()=>{const r=values=>resources({operation:{type:'bcd',values}}),one={object:'{CURRENT}',key:'DEBUG'};const ledger={records:[{id:'owner',resources:r([one])}]};assert.equal(conflicts(ledger,r([{object:'{current}',key:'debug'}])).length,1);assert.equal(conflicts(ledger,r([{object:'{bootmgr}',key:'debug'}])).length,0);assert.equal(conflicts(ledger,r([{object:'{current}',key:'nx'},one])).length,1)});

test('duplicated originals cannot stand in for another Registry target',t=>{
 const h=harness(t),b=registry('library-cpu-012');assert.ok(b.values.length>1);b.values[1]={...b.values[0]};
 h.write('tweak-library-backups',b.id,b);const ledger=h.read();assert.equal(ledger.records.length,0);assert.match(ledger.errors[0],/duplicată/);
});
test('invalid typed Registry originals block mutation without rewriting backup',t=>{
 for(const [kind,value] of [['DWord',4294967296],['DWord',1.5],['QWord',Number.MAX_SAFE_INTEGER+1],['Binary',[256]],['Binary','bad'],['MultiString',[1]],['String',7]]){
  const h=harness(t),b=registry('library-cpu-035');Object.assign(b.values[0],{kind,value});
  const file=h.write('tweak-library-backups',b.id,b),raw=fs.readFileSync(file,'utf8');assert.ok(h.read().errors.length,kind+' '+JSON.stringify(value));assert.equal(fs.readFileSync(file,'utf8'),raw);
 }
});
test('Registry originals use Windows case-insensitive target names',t=>{
 const h=harness(t),b=registry('library-cpu-035');b.values[0].name=b.values[0].name.toUpperCase();h.write('tweak-library-backups',b.id,b);
 assert.deepEqual(h.read().errors,[]);assert.equal(h.read().records.length,1);
});
test('interrupted profile reuse keeps preexisting originals owned by their individual module',t=>{
 for(const session of [{state:'applying'},{state:'recovery',rollback:true},{state:'restoring',rollback:true}]){
  const h=harness(t);h.write('tweak-library-backups','library-cpu-005',registry('library-cpu-005'));
  h.write('dashboard-profiles','cpu',{version:1,group:'cpu',level:'low',started:['library-cpu-005'],unchanged:[],reused:['library-cpu-005'],...session});
  const ledger=h.read();assert.deepEqual(ledger.errors,[]);assert.equal(ledger.records[0].route,'tweaks');assert.equal(ledger.records[0].module,'Tweaks');
 }
});
test('malformed native originals stay diagnostic and intact before recovery can mutate Windows',t=>{
 const rule=catalog.find(r=>r.operation?.type==='dns');
 for(const before of [null,{},false,{automatic:false,servers:[]},{automatic:true,servers:['8.8.8.8']}]){
  const h=harness(t),file=h.write('tweak-native-backups',rule.id,{version:1,id:rule.id,state:'applied',operation:rule.operation,before}),raw=fs.readFileSync(file,'utf8');
  const ledger=h.read();assert.equal(ledger.records.length,0);assert.match(ledger.errors[0],/nativă/);assert.equal(fs.readFileSync(file,'utf8'),raw);
 }
});
