'use strict';
// Isolate failures so one corrupt backup cannot prevent another component's recovery.
async function restoreComponents(components,invoke){
 const steps=[];
 for(const [kind,file] of components){
  try{
   const before=await invoke(file,'Status');
   if(before?.success!==true||typeof before.backup!=='boolean')throw Error('Starea backupului nu a putut fi verificată.');
   if(!before.backup)continue;
   const result=await invoke(file,'Restore');
   if(result?.success!==true){
    const failures=Array.isArray(result?.errors)?result.errors.slice(0,12).map(x=>`${x.id||x.value||kind}: ${x.error||x.message||'eroare necunoscută'}`):[];
    throw Error(failures.length?`${failures.join('; ')}${result.errors.length>12?'; …':''}`:(result?.message||'Restaurare neconfirmată.'));
   }
   const after=await invoke(file,'Status');
   if(after?.success!==true||after.backup!==false)throw Error('Backupul rămâne activ sau verificarea a eșuat.');
   steps.push({kind,success:true,message:result.message||'Restaurare verificată.'});
  }catch(error){steps.push({kind,success:false,message:String(error.message||error)})}
 }
 return {success:steps.every(x=>x.success),steps};
}
module.exports={restoreComponents};
