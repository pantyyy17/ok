'use strict';
// Pure recovery validation. Renderer cannot supply PowerShell commands or registry paths.
const ORDER=Object.freeze(['eee','interrupt','tcp','nicPower','dns']);
function buildRecoverySteps(journalSteps, backups){
 const pending=new Set([...(journalSteps||[]),...(backups||[])]);
 return ORDER.filter(s=>pending.has(s));
}
function validateRecoverySteps(selected,snapshot){
 const allowed=new Set((snapshot?.steps||[]).map(x=>x.id));
 if(!Array.isArray(selected)||selected.length<1||selected.length>ORDER.length||
    new Set(selected).size!==selected.length||
    selected.some(x=>typeof x!=='string'||!allowed.has(x)))
   throw Error('Selecție de restaurare invalidă. Reîncarcă lista backupurilor.');
 const journal=snapshot?.journalSteps||[];
 if(journal.some(x=>!selected.includes(x)))
   throw Error('Recuperarea sesiunii necesită toți pașii rămași în jurnal.');
 return ORDER.filter(x=>selected.includes(x));
}
function markRestored(started,step){
 if(!Array.isArray(started)||!ORDER.includes(step)||!started.includes(step))
  throw Error('Pas de restaurare necunoscut.');
 return started.filter(x=>x!==step);
}
module.exports={ORDER,buildRecoverySteps,validateRecoverySteps,markRestored};
