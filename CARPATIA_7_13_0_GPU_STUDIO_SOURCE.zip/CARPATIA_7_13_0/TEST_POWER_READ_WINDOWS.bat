@echo off
setlocal
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0tools\test-power-read-windows.ps1"
if errorlevel 1 (echo Citire esuata - trimite POWER_READ_REPORT.txt) else (echo Citire confirmata. Nicio modificare Windows.)
pause
