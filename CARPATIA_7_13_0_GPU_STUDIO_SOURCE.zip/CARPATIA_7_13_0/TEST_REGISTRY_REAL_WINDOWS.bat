@echo off
setlocal
cd /d "%~dp0"
title CARPATIA - test Registry izolat
 echo Acest test scrie si restaureaza numai o cheie HKCU temporara de test.
 echo Nu aplica profiluri CPU/GPU/Internet si nu foloseste backupurile existente.
 echo Raportul REGISTRY_TEST_*.txt va fi salvat in acest folder.
 pause
 "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0tools\test-registry-roundtrip-windows.ps1"
 if errorlevel 1 (echo TEST ESUAT - pastreaza raportul.) else (echo TEST REGISTRY IZOLAT REUSIT.)
 pause
