﻿# Read-only hardware inventory; no elevation and no registry mutations.
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
function TryRead($block,$fallback){try { & $block }catch { $fallback }}
$os=TryRead { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } $null
$cpu=TryRead { @(Get-CimInstance Win32_Processor -ErrorAction Stop) } @()
$gpu=TryRead { @(Get-CimInstance Win32_VideoController -ErrorAction Stop) } @()
$disks=TryRead { @(Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.Size -gt 0 }) } @()
if(@($disks).Count -eq 0){
 $disks=TryRead { @(Get-CimInstance Win32_DiskDrive -ErrorAction Stop) } @()
}
$batteries=TryRead { @(Get-CimInstance Win32_Battery -ErrorAction Stop) } @()
$gpus=@($gpu | Where-Object { $_.Name } | ForEach-Object { [string]$_.Name } | Select-Object -Unique)
$storage=@($disks | ForEach-Object {
 $media='Necunoscut'
 if($_.PSObject.Properties.Name -contains 'MediaType' -and $_.MediaType){$media=[string]$_.MediaType}
 $model=[string]$_.FriendlyName
 if([string]::IsNullOrWhiteSpace($model)){$model=[string]$_.Model}
 @{model=$model; bus=[string]$_.BusType; media=$media; sizeGB=[math]::Round([double]$_.Size/1GB,1)}
})
$chassis=TryRead { @((Get-CimInstance Win32_SystemEnclosure -ErrorAction Stop).ChassisTypes) } @()
$formFactor=if(@($chassis | Where-Object {$_ -in @(8,9,10,14,30,31,32)}).Count){'Laptop'}elseif(@($chassis | Where-Object {$_ -in @(3,4,5,6,7,15,16,24)}).Count){'Desktop'}else{$null}
$networkKinds=TryRead { @(Get-NetAdapter -Physical -ErrorAction Stop | ForEach-Object {if([string]$_.PhysicalMediaType -match '802.11|Wireless'){'WiFi'}elseif([string]$_.PhysicalMediaType -match '802.3'){'Ethernet'}} | Select-Object -Unique) } @()
$processor=if(@($cpu).Count){[string]$cpu[0].Name}else{'Necunoscut'}
$ramGB=if($os -and $os.TotalVisibleMemorySize){[math]::Round([double]$os.TotalVisibleMemorySize/1MB,1)}else{[math]::Round([double](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,1)}
$build=0
if($os -and $os.BuildNumber){$build=[int]$os.BuildNumber}
$windowsName=if($build -ge 22000){'Windows 11'}elseif($build -ge 10240){'Windows 10'}else{'Windows / necunoscut'}
@{
 formFactor=$formFactor
 networkKinds=@($networkKinds)
 success=$true
 detectedAt=(Get-Date).ToString('o')
 osName=$windowsName
 osBuild=$build
 osVersion=if($os){[string]$os.Version}else{''}
 cpu=$processor
 threads=if(@($cpu).Count){[int](($cpu|Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)}else{0}
 gpu=@($gpus)
 ramGB=$ramGB
 storage=@($storage)
 hasBattery=(@($batteries).Count -gt 0)
 batteryStatus=if(@($batteries).Count){[string]$batteries[0].BatteryStatus}else{'Fără baterie detectată'}
} | ConvertTo-Json -Compress -Depth 6
