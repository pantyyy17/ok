'use strict';
window.CarpatiaNetworkOptions={mount({api,document,schedule=setTimeout,cancel=clearTimeout}){
 const $=id=>document.getElementById(id),controls={nicPower:'netNic',tcp:'netTcp',interrupt:'netInterrupt',eee:'netEee'};let generation=0;
 async function refresh(){
  const current=++generation,adapter=$('adapterSelect').value;
  for(const id of Object.values(controls))$(id).disabled=true;
  $('netStart').disabled=true;
  if(!api||!adapter){$('netCapabilitiesStatus').textContent='Alege un adaptor activ în aplicația Windows.';return}
  $('netCapabilitiesStatus').textContent='Verific opțiunile expuse de driver…';
  try{
   let timer;
   const deadline=new Promise((_,reject)=>{timer=schedule(()=>reject(Error('Verificarea driverului a depășit 15 secunde. Reîncarcă pagina pentru o nouă încercare.')),15000)});
   let caps;try{caps=await Promise.race([api.networkCapabilities(adapter),deadline])}finally{cancel(timer)}
   if(current!==generation)return;
   if(caps.adapter!==adapter)throw Error('Adaptorul răspunsului nu corespunde selecției.');
   const omitted=[];
   for(const [key,id] of Object.entries(controls)){
    const enabled=caps.supported?.[key]===true;$(id).disabled=!enabled;$(id).title=caps.reasons?.[key]||'';
    if(!enabled){$(id).checked=false;omitted.push(caps.reasons?.[key]||key+': indisponibil')}
   }
   $('netCapabilitiesStatus').textContent=omitted.length?omitted.join(' '):'Opțiunile avansate sunt disponibile pentru adaptorul selectat.';
  }catch(e){
   if(current!==generation)return;
   for(const id of Object.values(controls)){$(id).disabled=true;$(id).checked=false}
   $('netCapabilitiesStatus').textContent='Opțiunile avansate nu au putut fi verificate. DNS și curățarea cache-ului rămân disponibile. '+String(e.message||e);
  }finally{if(current===generation)$('netStart').disabled=false}
 }
 $('adapterSelect').addEventListener('change',refresh);
 $('netCapabilitiesRefresh').onclick=refresh;
 return {refresh};
}};
