@echo off
setlocal
cd /d "%~dp0"
title CARPATIA - TEST EDITOR
where node.exe >nul 2>&1
if errorlevel 1 (echo Instaleaza Node.js 24 sau mai nou. & pause & exit /b 1)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (echo Este necesar Node.js 24 sau mai nou. & pause & exit /b 1)
if not exist "node_modules\electron\cli.js" (
 call npm ci --no-audit --no-fund
 if errorlevel 1 (echo Instalarea dependentelor a esuat. & pause & exit /b 1)
)
echo TEST EDITOR: nu este licenta comerciala si nu se distribuie clientilor.
echo Programul porneste fara elevare automata. Modificarile necesita confirmarea ta.
set "CARPATIA_DEV_MODE=1"
call npm start
if errorlevel 1 pause
endlocal
