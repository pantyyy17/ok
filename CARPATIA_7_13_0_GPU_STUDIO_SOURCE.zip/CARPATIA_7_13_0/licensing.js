'use strict';
// Offline Ed25519 license verification. This file only needs the PUBLIC key.
// Private signing keys must NEVER be included in the application or its ZIP.
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const PREFIX='CARPATIA-V1';
const PRODUCT='CARPATIA_V7_PRO';
const MAX_LENGTH=8192;
const b64url=x=>Buffer.from(x).toString('base64url');
function licenseError(reason,message){const error=Error(message);error.reason=reason;return error}
function normalizeLicenseCode(code){
 // Email clients may wrap a purchased code or replace spaces with non-breaking spaces.
 // Bound the original input before removing whitespace; never alter signed characters.
 if(typeof code!=='string'||code.length>MAX_LENGTH)throw licenseError('invalid_license','Cod de licență prea lung sau invalid.');
 return code.replace(/\s/g,'');
}
function publisherKey(publicKey){
 if(publicKey===null||publicKey===undefined||(typeof publicKey==='string'&&!publicKey.trim()))throw licenseError('missing_publisher_key','Aplicația nu are cheia publică configurată de editor.');
 try{
  const pem=Buffer.isBuffer(publicKey)?publicKey.toString('utf8'):typeof publicKey==='string'?publicKey:'';
  if(/-----BEGIN [^-]*PRIVATE KEY-----/.test(pem))throw Error('Private keys cannot be distributed in the client.');
  const key=publicKey instanceof crypto.KeyObject?publicKey:crypto.createPublicKey(publicKey);
  if(key.type!=='public'||key.asymmetricKeyType!=='ed25519')throw Error('Ed25519 required');
  return key;
 }catch{throw licenseError('invalid_publisher_key','Cheia publică a editorului este invalidă. Verifică distribuția.')}
}
function assertLicensePayload(data){
 if(!data||typeof data!=='object'||Array.isArray(data)||data.product!==PRODUCT)throw Error('Codul nu este pentru CARPATIA V7 PRO.');
 for(const name of ['licenseId','customer','issuedAt'])if(typeof data[name]!=='string'||!data[name].trim()||data[name].length>180)throw Error('Datele licenței sunt invalide.');
 if(!/^[a-zA-Z0-9_-]{6,100}$/.test(data.licenseId))throw Error('Identificator licență invalid.');
 const issue=Date.parse(data.issuedAt);
 if(!Number.isFinite(issue)||issue>Date.now()+1000*3600*24)throw Error('Data emiterii este invalidă.');
 if(data.expiresAt!==null&&data.expiresAt!==undefined){
  if(typeof data.expiresAt!=='string')throw Error('Data expirării este invalidă.');
  const exp=Date.parse(data.expiresAt);
  if(!Number.isFinite(exp)||exp<=issue)throw Error('Data expirării este invalidă.');
  if(exp<=Date.now())throw licenseError('expired_license','Licența a expirat.');
 }
 return data;
}
function inspectLicense(code, publicKey){
 const value=normalizeLicenseCode(code);
 const pieces=value.split('.');
 if(pieces.length!==3||pieces[0]!==PREFIX||!/^[A-Za-z0-9_-]+$/.test(pieces[1])||!/^[A-Za-z0-9_-]+$/.test(pieces[2]))throw Error('Format de licență necunoscut.');
 const key=publisherKey(publicKey);
 const signed=Buffer.from(PREFIX+'.'+pieces[1],'utf8');
 let valid=false;
 try{
  const signature=Buffer.from(pieces[2],'base64url');
  valid=signature.length===64&&signature.toString('base64url')===pieces[2]&&crypto.verify(null,signed,key,signature);
 }catch{valid=false}
 if(!valid)throw Error('Semnătura licenței nu este validă.');
 let payload;
 try{payload=JSON.parse(Buffer.from(pieces[1],'base64url').toString('utf8'))}catch{throw Error('Conținutul licenței este invalid.')}
 return assertLicensePayload(payload);
}
function createIssuerCode(payload,privateKey){
 const data=assertLicensePayload(payload);
 const key=privateKey instanceof crypto.KeyObject?privateKey:crypto.createPrivateKey(privateKey);
 if(key.type!=='private'||key.asymmetricKeyType!=='ed25519')throw Error('Cheie de semnare incompatibilă: este necesară Ed25519.');
 const part=b64url(Buffer.from(JSON.stringify(data),'utf8'));
 const message=PREFIX+'.'+part;
 const signature=crypto.sign(null,Buffer.from(message,'utf8'),key);
 return `${message}.${signature.toString('base64url')}`;
}
function createLicenseStore({directory,publicKey,developer=false}){
 const filename=path.join(directory,'carpatia-license.txt');
 let key=null,configurationError=null;
 // The publisher key never changes during a store's lifetime. Parse it once while
 // still re-reading and verifying the saved license on every authorization check.
 try{key=publisherKey(publicKey)}catch(error){configurationError=error}
 const configured=key!==null;
 function activeStatus(data,development=false){return {active:true,configured,reason:development?'developer':'active',developer:development,licenseId:data.licenseId,customer:data.customer,expiresAt:data.expiresAt??null}}
 function readSaved(){
  try{
   const stat=fs.statSync(filename);
   if(!stat.isFile()||stat.size>MAX_LENGTH+2)throw licenseError('invalid_license_file','Fișier de licență prea lung sau invalid.');
   return fs.readFileSync(filename,'utf8').trim();
  }catch(e){if(e.code==='ENOENT')return '';if(!e.reason)e.reason='invalid_license_file';throw e}
 }
 function validate(code){if(configurationError)throw configurationError;return inspectLicense(code,key)}
 function status(){
  if(developer)return activeStatus({licenseId:'DEV',customer:'MOD DEZVOLTARE'},true);
  if(configurationError)return {active:false,configured:false,reason:configurationError.reason,error:configurationError.reason==='missing_publisher_key'?'Cheia publică a editorului lipsește. Verifică distribuția.':configurationError.message};
  try{
   const code=readSaved();
   if(!code)return {active:false,configured,reason:'missing_license',error:'Introdu licența cumpărată.'};
   return activeStatus(validate(code));
  }
  catch(e){return {active:false,configured,reason:e.reason||'invalid_license',error:e.message}}
 }
 function activate(code){
  const normalized=normalizeLicenseCode(code);
  const data=validate(normalized);
  fs.mkdirSync(directory,{recursive:true});
  // Atomic write; never persist an unverified code. Restrict Unix permissions when applicable.
  const tmp=filename+'.tmp-'+crypto.randomBytes(6).toString('hex');
  fs.writeFileSync(tmp,normalized+'\n',{encoding:'utf8',mode:0o600,flag:'wx'});
  try{fs.renameSync(tmp,filename)}catch(e){try{fs.unlinkSync(tmp)}catch{}throw e}
  return activeStatus(data);
 }
 return {status,activate,licensed:()=>status().active};
}
module.exports={PREFIX,PRODUCT,MAX_LENGTH,normalizeLicenseCode,publisherKey,inspectLicense,createIssuerCode,createLicenseStore};
