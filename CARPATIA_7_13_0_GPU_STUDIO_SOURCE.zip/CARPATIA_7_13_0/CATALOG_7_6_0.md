# CARPATIA 7.6.0 — implementare și limite

235 de intrări în 13 categorii, pe baza catalogului efectiv al referinței furnizate. Nu importăm motorul, autentificarea sau executabilul TweakShift. `sourceCommand` este text de comparație; nu se evaluează ca script.

| Stare | Număr | Comportament |
|---|---:|---|
| Registry | 146 | Scriere/eliminare tipizată, backup, recitire, restaurare |
| Native Windows | 48 | Adaptoare proprii pentru servicii, alimentare, rețea, BCD, stocare și protecție |
| Întreținere | 15 | Comenzi punctuale, rezultat în jurnal, fără anulare automată |
| Aspect exclus | 21 | Inactive conform cerinței de a nu schimba aspectul Windows |
| Nesuportate / fără implementare în referință | 5 | net-017, net-026, ram-008, adv-009, adv-022; nu se simulează succesul |

Total cu motor implementat: 209. Implementat nu înseamnă validat pe Windows sau recomandat pentru orice PC.

## Comportament

- Aplicare individuală și confirmare; nu există selecție automată a celor 209 opțiuni.
- Pentru operațiile reversibile, originalul se salvează înainte de prima scriere. Se păstrează absența valorii, tipul Registry și valoarea originală; nu se inventează valori implicite.
- Jurnale atomice, stări de eșec și blocarea suprapunerilor. Un backup activ trebuie restaurat înainte de reaplicarea aceleiași setări.
- Restaurarea rămâne accesibilă fără licență activă. Operațiile de întreținere nu afișează un buton de restaurare fictiv.
- O întreținere întreruptă necesită verificare manuală și confirmare înainte de repetare. Această confirmare nu o declară reușită.
- DNS/MTU/IPv6 folosesc un adaptor selectat explicit și identificat prin GUID. Nu se alege automat prima placă de rețea.
- Curățarea ignoră legăturile/reparse points și fișierele modificate în ultima oră; raportează fișierele eliminate și omise. Nu oprește Windows Update pentru a-i forța ștergerea cache-ului.
- Denumirile înșelătoare ale unor opțiuni au fost corectate. Condițiile și afirmațiile de performanță ale referinței sunt afișate ca atare, nu prezentate ca rezultate măsurate.
- Modificările de protecție și de pornire sunt marcate distinct. Backupul unei valori BCD nu garantează posibilitatea de a deschide aplicația dacă Windows nu mai pornește.

## Curățarea codului

Adaptoare comune tipizate în `tweak-native-ops.ps1`, controlul jurnalelor separat în `tweak-native.ps1`, rutare și autorizare într-un singur modul JS. Aceeași interfață gestionează aplicarea, recuperarea și mesajele. Nu se creează câte un script separat pentru fiecare tweak. Catalogul vechi se păstrează pentru compatibilitatea backupurilor, cu modificările de aspect retrase din aplicare.

## Verificări efectuate

- 96 teste Node: licențiere, IPC, recuperare, catalog, confirmare, anulare, adaptor explicit și afișarea recuperării după eșec.
- Verificare sintactică JavaScript și analiză gramaticală a celor trei scripturi PowerShell noi/modificate pentru catalog.
- Previzualizare HTML statică: cele 209 intrări implementate și 13 categorii sunt în document, inclusiv pe iPhone fără JavaScript.

## Ce nu a fost validat aici

Mediul de lucru este Linux: nu s-au executat modificările Windows, nu s-a compilat un installer Windows și nu s-au măsurat FPS, latență sau consum. Lipsesc probe pe Windows 10/11, drivere Intel/AMD/NVIDIA, politici Defender, limbi diferite și restaurare după restart. Unele comenzi pot fi refuzate de versiunea Windows sau de politica PC-ului; aplicația trebuie să raporteze refuzul, nu succesul.

Testul PowerShell `tools/test-native-windows.ps1` verifică parserul Windows și funcțiile pure; nu aplică tweak-uri. `TEST_CARPATIA_WINDOWS.bat` îl include. Testarea reală Apply → Restore se face ulterior, câte o setare, preferabil într-o mașină virtuală cu snapshot pentru opțiunile de boot/protecție și întreținere ireversibilă.

Cheia publică originală de producție nu este inclusă. Release check blochează distribuirea până la configurare; cheia privată rămâne la editor. Licențele permanente existente depind de păstrarea aceleiași perechi de chei.

Cele 26 de intrări excluse/nesuportate nu sunt afișate în pagina de utilizare. Rămân numai în catalogul intern de audit; nu au buton de aplicare și sunt respinse la autorizare.

## Revizia 7.6.1 — execuție Windows

Execuția PowerShell este extrasă din main.js în windows-process.js. Executabilele sunt adresate prin calea System32, fără shell și fără căutare în PATH. Rezultatele JSON, codurile de ieșire și limitele de output sunt tratate într-un singur loc.

La timeout sau depășirea limitei de output, se cere oprirea arborelui prin taskkill /T /F. Promisiunea rămâne în așteptare până la rezultatul opririi, astfel încât blocarea operațiilor concurente din aplicație să nu fie eliberată prematur. Dacă oprirea eșuează sau nu răspunde în 10 secunde, alte comenzi Windows sunt blocate în sesiunea aplicației și se cere repornirea Windows. Jurnalul operației rămâne disponibil; o oprire nu este echivalentă cu restaurarea.

10 teste suplimentare cu procese și temporizatoare simulate acoperă succes JSON, erori, timeout, output excesiv, terminare întârziată și terminare neconfirmată. Aceste simulări nu înlocuiesc testarea proceselor Windows reale.
