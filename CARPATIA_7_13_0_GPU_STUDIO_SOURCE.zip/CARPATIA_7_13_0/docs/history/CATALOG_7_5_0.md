# CARPATIA 7.5.0 — stadiu de implementare

Se păstrează interfața Ruby Redline. Prototipul mov CARPATIA 8 nu este folosit.

Catalogul efectiv din arhiva TweakShift 1.2.3 furnizată de utilizator: 235 de intrări în 13 categorii (200 de bază + 47 utilitare - 12 înlocuite). Denumirile și descrierile de referință sunt păstrate pentru trasabilitate; afirmațiile despre performanță nu sunt validate.

- 130 au adaptor Registry propriu: aplicare individuală, backup înainte de scriere, recitire și restaurare per setare. Nu execută șirurile de comenzi ale referinței.
- 67 necesită încă adaptoare specifice. Nu se execută.
- 21 modificări de aspect sunt excluse conform cerinței utilizatorului.
- 14 necesită revizuire pentru impact asupra protecției/stabilității; nu se execută.
- 3 sunt mesaje fără optimizarea pretinsă în comanda sursă; nu se execută.

Restaurarea nu cere licență activă. Nu se folosesc valori Windows implicite în locul backupului. Se blochează aplicarea peste backupuri ULTRA vechi și suprapunerea țintelor între setări cu backup activ.

TESTARE: testele Node și verificările statice nu validează execuția PowerShell pe Windows, compatibilitatea unui tweak, efectul driverului sau un câștig FPS. Această livrare este o sursă experimentală și o previzualizare a catalogului, nu un installer testat și nici toate cele 235 de funcții implementate. Nu folosi aplicare în masă; nu există o astfel de comandă în noua pagină.

Fișierele și licențierea TweakShift nu sunt incluse ca aplicație. Motorul, autentificarea și mecanismele sale de premium nu au fost importate. Modificările sunt în tweak-library*. Catalogul vechi este păstrat pentru restaurarea și profilurile CARPATIA existente.
