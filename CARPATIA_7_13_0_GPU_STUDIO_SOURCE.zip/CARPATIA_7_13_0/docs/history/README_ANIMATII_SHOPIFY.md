# CARPATIA 7.4.1 — Animatie + Shopify

## Modificări
- Trei butoane circulare Ruby Red: inele lente în repaus, accelerație la hover, animație de lucru legată de starea efectivă a operațiilor.
- Animațiile se opresc când fereastra este ascunsă și respectă preferința *Reduce motion*.
- Formularea despre funcții eliminate a fost scoasă din pagina Setări.
- Licențierea Ed25519 offline și motorul Windows sunt păstrate din 7.4.0.

## Ce NU reprezintă un test
- Animația nu indică FPS sau ping măsurat. Nu reprezintă un succes automat.
- Nu există tester Windows în acest mediu: aplicarea, restaurarea și installerul necesită validare pe Windows 10/11.
- Generarea cheii private se face numai pe calculatorul editorului; nu în această arhivă.

Pentru configurare offline folosește `LICENTA_MANAGER.bat` și `LICENTIERE.md` din proiect. Pentru magazin vezi ghidul Shopify din arhiva site-ului.
