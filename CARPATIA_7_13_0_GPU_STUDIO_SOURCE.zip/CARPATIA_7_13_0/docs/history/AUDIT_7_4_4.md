# Audit CARPATIA Ruby Redline 7.4.4

24 octombrie 2026. Bază: arhiva 7.4.3 QA FIX. Acesta este un audit și un patch de surse, NU certificare că au fost eliminate toate erorile și NU un installer testat pe Windows.

## Corecții implementate

- Licențiere: eliminată limita ascunsă de 20 de ani aplicată datei emiterii; licența permanentă nu mai expiră implicit. Expirarea temporară se aplică exact la termen.
- Pornirea din surse nu mai deblochează automat programul. Modul dezvoltare cere explicit CARPATIA_DEV_MODE=1 și este refuzat în buildul împachetat.
- Restaurările Startup/GPU și citirile necesare sunt accesibile fără licență. Aplicările rămân blocate. Centrul Restore are legături pentru acestea.
- O singură instanță Electron deține operațiile și backupurile; a doua nu deschide fereastră.
- Jurnalele de rețea se înlocuiesc prin fișier temporar + rename, reducând riscul JSON trunchiat. Nu reprezintă garanție împotriva pierderii alimentării sau coruperii discului.
- Cleanup verifică separatorul de la limita LOCALAPPDATA și refuză un TEMP sau strămoș care este junction/symlink. Nu este o implementare rezistentă la toate cursele de filesystem; verificarea Windows rămâne necesară.
- Fluxurile PowerShell folosesc UTF-8, iar decodarea Node păstrează caracterele multibyte între fragmente.
- Citirea senzorilor are termen total, tratează răspunsul întrerupt și limitează adâncimea arborelui.
- Eliminat cache de licență nefolosit. Actualizată versiunea din pachet și UI.

## Adăugiri comerciale

seller/shopify-core.js și seller/server.js: verificare HMAC pe corpul brut, magazin și variantă permise, comandă plătită, refuz test implicit, chei permanente Ed25519, deduplicare persistentă per comandă/linie/unitate, tranzacție SQLite pentru licență+outbox, email Resend cu timeout/reîncercări și oprire pentru revizuire înainte de expirarea ferestrei de idempotență. Serverul și uneltele de emitere sunt excluse din lista de fișiere a installerului.

## Verificări executate

- Cele 46 de teste inițiale treceau înaintea modificărilor.
- Acum 60/60 teste trecute pe Node 24.22.1/Linux, inclusiv 14 teste noi pentru permanență, IPC și Shopify. IPC este testat cu Electron simulat; emailul folosește un transport fals, fără destinatari reali.
- Verificare sintactică Node pentru toate fișierele JavaScript.
- `npm run release:check` BLOCAT corect: lipsește license-public.pem. Nu a fost creată o cheie de producție sau ascuns acest blocaj.

## Ce rămâne înainte de vânzare

1. Test pe Windows 10/11 și PowerShell 5.1: instalare/dezinstalare, UAC, cont standard/admin, activare și restart, registry/power/DNS/TCP/NIC/services/Startup/GPU, întreruperi și restaurare. În acest mediu nu există Windows/PowerShell; schimbările .ps1 au doar revizie statică.
2. Nu s-au instalat dependințele Electron/electron-builder și nu s-a executat auditul vulnerabilităților lor. Nu există lockfile verificat sau installer compilat/semnat. Validează versiunile și dependențele la build; nu declara release reproductibil încă.
3. Backupurile vechi/malformate și restaurarea GPU când executabilul a fost șters necesită evaluare suplimentară. UI cere încă alegerea unui executabil existent. Restaurarea automată nu poate acoperi orice stare Windows.
4. Persistența și tranzacțiile nu înlocuiesc reconcilierea Shopify, monitorizarea emailurilor, backupul cheilor și configurarea reală HTTPS. Serviciul presupune o singură instanță worker și stocare persistentă. Integrarea live nu a fost testată.
5. Licențele sunt copiable între calculatoare și nu pot fi revocate offline după refund. Nu există limită tehnică de un dispozitiv. Nu livra ZIP-ul sursă clienților.
6. Nu există dovezi de câștig FPS sau de superioritate față de Razer. Măsoară înainte/după pe configurații reale. Debloat și ștergerea TEMP nu au rollback integral.

Instrucțiuni comerciale și configurare: GHID_SHOPIFY_7_4_4.md. Documentele 7.4.3 și mai vechi rămân istoric, nu descriere a acestei verificări.
