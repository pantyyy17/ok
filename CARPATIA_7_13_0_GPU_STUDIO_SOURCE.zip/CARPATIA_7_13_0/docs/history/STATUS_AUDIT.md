# Audit 7.4.0 RC — 23 octombrie 2026

Am păstrat motorul de Windows existent, lista albă de tweak-uri și mecanismul Ed25519 offline.

### Nou / verificat
- License Manager local (`tools/license-manager.js`, `manager.html`, CSS și JS) pe `127.0.0.1`, token aleator și blocare cereri cross-origin.
- `tools/issuer-core.js`: generare chei, verificare corespondență chei, emitere licențe cu ID aleator, evidență metadata fără secret.
- Launcher `LICENTA_MANAGER.bat` pentru editor, **exclus** din installer.
- Verificarea automată a licențelor rămâne în Electron, nu în UI.
- `package.json` actualizat la 7.4.0; dashboard 7.4.0 fără modificarea designului Ruby Red ales.

### Ce NU a fost demonstrat
- Instalare `.exe` pe Windows 10/11, consum RAM real, compatibilitatea tuturor driverelor și comenzi PowerShell native.
- Server de activare online și limitarea unui cod la un număr de PC-uri.
- Lipsa absolută a bugurilor sau creșterea FPS.

**Nu distribui ZIP-ul sursă clienților**: sursa include fișiere de dezvoltare și panoul editorului. Distribuția comercială este installerul compilat după configurarea cheii publice și testele de compatibilitate.
