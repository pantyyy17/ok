# Activare online pentru CARPATIA — plan de implementare comercială

**Starea actuală:** versiunea 7.4.0 RC are licențe offline semnate și manager LOCAL pentru editor. **Nu există încă platformă publică online și nu există legare la un dispozitiv.**

## Ce construim după testarea aplicației Windows

1. **Portalul editorului** pe un domeniu propriu cu autentificare multifactor (de ex. `admin.carpatia.example`, nume ilustrativ, nu URL real). Vezi comenzile plătite, licențele active, dispozitivele asociate și ai buton de suspendare.
2. **Baza de date** pentru licențe, plăți confirmate, maximum 1 sau 2 activări, log minim cu data activării și expirării; acces strict separat între client și administrator.
3. **API HTTPS** cu verificarea semnăturii licenței și a stării în baza de date. Cererile de activare sunt rate-limited și jurnalizate fără a stoca codurile în clar când nu sunt necesare.
4. **Identificator de instalare pseudonim**, generat local, NU adresa MAC, seriale hardware sau date personale inutile. Clientul poate muta licența după reinstalare printr-un flux de resetare controlat.
5. **Token de activare semnat**, valabil 7–14 zile offline. Aplicația poate funcționa offline pe durata perioadei de grație. Revocarea se aplică la reconectare, nu instant când PC-ul este offline.
6. **Protecție a secretelor:** cheia privată principală rămâne pe PC-ul editorului / serviciu dedicat de semnare, nu în executabilul cumpărătorilor. Serverul online folosește propria cheie de semnare a tokenurilor cu rotație de chei și permisiuni stricte.
7. **Plată & GDPR:** webhook semnat de procesatorul de plăți, politică de confidențialitate, retenția minimă a datelor, drept la export/ștergere a datelor personale compatibil cu evidențele contabile.

## Regula de lansare

Nu activa blocarea online până nu testăm separat scenariile fără internet, cădere de server, schimbare PC, expirare de licență și suportul clienților. **Un control anti-copiere nu trebuie să transforme un produs cumpărat legal într-un program inutilizabil.**

## Ordinea recomandată

**Faza A:** finalizezi optimizările Windows și testerii inițiali, folosești License Manager local și licențe semnate offline. **Faza B:** activezi portal online cu limită de dispozitive și perioadă offline, după ce ai hosting, domeniu, bază de date și teste de securitate. **Faza C:** plăți și emitere automată a licențelor doar după validarea webhookurilor și politicii de rambursare.
