'use strict';
// Read-only local operator report. No signing key, customer address or code output.
const {DatabaseSync}=require('node:sqlite');
const path=require('node:path');
const {externalPath}=require('../tools/private-path');
function readDeliveryStatus(directory,now=Date.now()){
 const data=externalPath(directory,path.resolve(__dirname,'..'));
 const db=new DatabaseSync(path.join(data,'licenses.sqlite'),{readOnly:true});
 try{
  const outbox={pending:0,sent:0,review:0};
  for(const row of db.prepare('SELECT state,COUNT(*) AS count FROM outbox GROUP BY state').all())outbox[row.state]=row.count;
  return {licenses:db.prepare('SELECT COUNT(*) AS count FROM licenses').get().count,outbox,pendingDue:db.prepare("SELECT COUNT(*) AS count FROM outbox WHERE state='pending' AND next_at<=?").get(now).count};
 }finally{db.close()}
}
if(require.main===module){
 try{if(process.argv.length!==3)throw Error('Utilizare: node seller/status.js DIRECTOR_PRIVAT_DATE');console.log(JSON.stringify(readDeliveryStatus(process.argv[2]),null,2))}
 catch(error){console.error(error.message);process.exitCode=1}
}
module.exports={readDeliveryStatus};
