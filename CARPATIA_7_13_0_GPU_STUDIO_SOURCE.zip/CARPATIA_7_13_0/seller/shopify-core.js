'use strict';
// Seller only: never include this directory, database or private PEM in the installer.
const {createHmac,timingSafeEqual}=require('node:crypto');
const {createFulfillmentService}=require('./fulfillment-core');
function validId(value){return (typeof value==='string'&&/^[1-9][0-9]{0,30}$/.test(value))||(Number.isSafeInteger(value)&&value>0)}
function verifyHmac(raw,signature,secret){
 if(typeof signature!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(signature)||!secret||!Buffer.isBuffer(raw))return false;
 const actual=Buffer.from(signature,'base64'),expected=createHmac('sha256',secret).update(raw).digest();
 return actual.length===expected.length&&actual.toString('base64')===signature&&timingSafeEqual(actual,expected);
}
function createShopifyService({secret,shop,variantId,allowTest=false,...issuer}){
 if(typeof secret!=='string'||!secret.trim()||typeof shop!=='string'||!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)||!validId(variantId)||typeof allowTest!=='boolean')throw Error('Configurare Shopify incompletă.');
 const fulfillment=createFulfillmentService(issuer);
 function accept(raw,headers={}){
  if(!headers||typeof headers!=='object')return {status:401};
  if(!verifyHmac(raw,headers['x-shopify-hmac-sha256'],secret))return {status:401};
  if(headers['x-shopify-shop-domain']!==shop)return {status:403};
  if(headers['x-shopify-topic']!=='orders/paid')return {status:400};
  let order;try{
   // Node 24 exposes each original numeric JSON token, retaining 64-bit IDs.
   order=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw),(key,value,context)=>
    ['id','variant_id'].includes(key)&&typeof value==='number'&&/^[1-9][0-9]{0,30}$/.test(context.source)?context.source:value);
  }catch{return {status:400}}
  if(!order||typeof order!=='object'||Array.isArray(order)||!validId(order.id)||!Array.isArray(order.line_items)||(order.test!==undefined&&typeof order.test!=='boolean')||(order.cancelled_at!=null&&typeof order.cancelled_at!=='string'))return {status:400};
  if(order.financial_status!=='paid'||order.cancelled_at!=null||(order.test===true&&!allowTest))return {status:200,ignored:true};
  const lines=order.line_items.filter(x=>x&&typeof x==='object'&&validId(x.variant_id)&&String(x.variant_id)===String(variantId));
  if(!lines.length)return {status:200,ignored:true};
  // Validate everything before the shared issuer begins its transaction.
  if(lines.some(x=>!validId(x.id)))return {status:422};
  try{
   const result=fulfillment.fulfillVerifiedPurchase({source:shop,purchaseId:String(order.id),email:order.email||order.contact_email,items:lines.map(x=>({id:String(x.id),quantity:x.quantity}))});
   return {status:200,...result};
  }catch(error){
   if(error.code==='INVALID_PURCHASE')return {status:422};
   throw error;
  }
 }
 return {accept,deliver:fulfillment.deliver,close:fulfillment.close};
}
module.exports={createShopifyService,verifyHmac};
