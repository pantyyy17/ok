'use strict';
// Seller only. A payment adapter must verify payment BEFORE calling this service.
// Shopify and a future website share this ledger, signing key and license format.
const {DatabaseSync}=require('node:sqlite');
const {randomUUID,createPrivateKey,createPublicKey,createHash,KeyObject}=require('node:crypto');
const {createIssuerCode,inspectLicense,PRODUCT}=require('../licensing');
const validReference=value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:-]{0,179}$/.test(value);
const validEmail=value=>typeof value==='string'&&value.length<=180&&!/[\x00-\x1f\x7f]/.test(value)&&/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value);
function deliverySettings({emailFrom=null,downloadUrl=null}={}){
 if(emailFrom!==null){
  const mailbox=typeof emailFrom==='string'&&emailFrom.match(/^(?:[^<>]*<([^<>]+)>|([^<>]+))$/);
  if(!mailbox||emailFrom.length>254||/[\x00-\x1f\x7f]/.test(emailFrom)||!validEmail((mailbox[1]||mailbox[2]).trim()))throw Error('EMAIL_FROM invalid.');
 }
 if(downloadUrl!==null){
  let parsed;try{parsed=new URL(downloadUrl)}catch{throw Error('DOWNLOAD_URL trebuie să fie HTTPS.')}
  if(parsed.protocol!=='https:'||parsed.username||parsed.password)throw Error('DOWNLOAD_URL trebuie să fie HTTPS.');
  downloadUrl=parsed.href;
 }
 return {emailFrom,downloadUrl};
}
function createFulfillmentService({database,privateKey,publicKey=null,...delivery}){
 const {emailFrom,downloadUrl}=deliverySettings(delivery);
 const signingKey=privateKey instanceof KeyObject?privateKey:createPrivateKey(privateKey);
 if(signingKey.asymmetricKeyType!=='ed25519')throw Error('Cheie de semnare incompatibilă.');
 const derivedPublic=createPublicKey(signingKey),publicDer=derivedPublic.export({type:'spki',format:'der'});
 if(publicKey!==null){
  if(!(publicKey instanceof KeyObject)&&(typeof publicKey!=='string'||!/^\s*-----BEGIN PUBLIC KEY-----\s+[A-Za-z0-9+/=\s]+-----END PUBLIC KEY-----\s*$/.test(publicKey)))throw Error('Fișierul public trebuie să conțină NUMAI cheia PUBLICĂ în format PEM.');
  const expectedPublic=publicKey instanceof KeyObject?publicKey:createPublicKey(publicKey);
  if(expectedPublic.type!=='public'||expectedPublic.asymmetricKeyType!=='ed25519'||!publicDer.equals(expectedPublic.export({type:'spki',format:'der'})))throw Error('Cheia de semnare nu corespunde installerului.');
 }
 const publisherFingerprint=createHash('sha256').update(publicDer).digest('hex');
 const db=new DatabaseSync(database);
 db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS issuer_settings (name TEXT PRIMARY KEY, value TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS licenses (unit TEXT PRIMARY KEY, code TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS outbox (id TEXT PRIMARY KEY, recipient TEXT NOT NULL, body TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, first_attempt INTEGER, provider_id TEXT, sender TEXT, subject TEXT);`);
 // Migrate existing seller databases without replacing any purchased code.
 const columns=new Set(db.prepare('PRAGMA table_info(outbox)').all().map(x=>x.name));
 const legacyOutbox=!columns.has('sender')||!columns.has('subject');
 db.exec('BEGIN IMMEDIATE');
 try{
  const pinned=db.prepare("SELECT value FROM issuer_settings WHERE name='publisher_sha256'").get();
  if(pinned&&pinned.value!==publisherFingerprint)throw Error('Baza de date aparține ALTEI chei de editor. Restaurează cheia originală; nu genera alta.');
  if(!pinned){
   // Legacy ledgers predate the fingerprint. Verify an existing signed code
   // before pinning their publisher; never relabel older purchased licenses.
   const existing=db.prepare('SELECT code FROM licenses LIMIT 1').get();
   if(existing)try{inspectLicense(existing.code,derivedPublic)}catch{throw Error('Licențele existente nu corespund cheii de editor. Restaurează perechea originală.')}
   db.prepare("INSERT INTO issuer_settings(name,value) VALUES ('publisher_sha256',?)").run(publisherFingerprint);
  }
  if(legacyOutbox){
   if(!columns.has('sender'))db.exec('ALTER TABLE outbox ADD COLUMN sender TEXT');
   if(!columns.has('subject'))db.exec('ALTER TABLE outbox ADD COLUMN subject TEXT');
   // An old in-flight message may already be accepted by its provider. Its old
   // envelope was not recorded, so changing it under the same retry ID is unsafe.
   db.exec("UPDATE outbox SET state='review' WHERE state='pending' AND attempts>0");
   db.prepare("UPDATE outbox SET sender=?,subject=?,body=body||? WHERE state='pending' AND attempts=0").run(emailFrom,'Licența ta permanentă CARPATIA',downloadUrl?'\nDescarcă installerul: '+downloadUrl+'\n':'');
  }
  db.exec('COMMIT');
 }catch(error){db.exec('ROLLBACK');db.close();throw error}
 const findLicense=db.prepare('SELECT unit FROM licenses WHERE unit=?');
 const addLicense=db.prepare('INSERT INTO licenses(unit,code) VALUES (?,?)');
 const addMail=db.prepare('INSERT INTO outbox(id,recipient,body,sender,subject) VALUES (?,?,?,?,?)');
 function fulfillVerifiedPurchase({source,purchaseId,email,items}={}){
  // References form the durable deduplication key. Keep their values stable when
  // retrying a webhook or moving from Shopify to a verified own-site adapter.
  if(!validReference(source)||!validReference(purchaseId)||!validEmail(email)||!Array.isArray(items)||!items.length||items.length>100||items.some(x=>!x||!validReference(x.id)||!Number.isSafeInteger(x.quantity)||x.quantity<1||x.quantity>100)||new Set(items.map(x=>x.id)).size!==items.length||items.reduce((n,x)=>n+x.quantity,0)>100){const error=Error('Cumpărare verificată invalidă.');error.code='INVALID_PURCHASE';throw error}
  db.exec('BEGIN IMMEDIATE');
  try{
   let issued=0;
   for(const item of items){
    for(let unit=0;unit<item.quantity;unit++){
     const id=`${source}/${purchaseId}/${item.id}/${unit}`;
     if(findLicense.get(id))continue;
     const code=createIssuerCode({product:PRODUCT,licenseId:'crp_'+randomUUID().replaceAll('-',''),customer:email,issuedAt:new Date().toISOString(),expiresAt:null},signingKey);
     addLicense.run(id,code);
     const body=`Mulțumim pentru cumpărare!\n\nLicență CARPATIA V7 PRO permanentă, fără abonament.\nComanda: ${purchaseId}\n\n${code}\n\nDeschide CARPATIA → INTRODU LICENȚA și lipește întregul cod. Păstrează acest email pentru reinstalare.\n${downloadUrl?'\nDescarcă installerul: '+downloadUrl+'\n':''}`;
     // Persist the complete delivery content with the code in one transaction.
     // An environment change must not alter a provider-idempotent retry.
     addMail.run(id,email,body,emailFrom,'Licența ta permanentă CARPATIA');
     issued++;
    }
   }
   db.exec('COMMIT');return {issued};
  }catch(error){db.exec('ROLLBACK');throw error}
 }
 let delivering=false;
 async function deliver(sendMail,now=Date.now()){
  if(delivering)return;delivering=true;
  try{
   const rows=db.prepare("SELECT * FROM outbox WHERE state='pending' AND next_at<=? ORDER BY rowid LIMIT 20").all(now);
   for(const row of rows){
    // Provider deduplication lasts 24h. Stop ambiguous retries before that expires.
    if(row.first_attempt!==null&&now-row.first_attempt>=23*3600000){db.prepare("UPDATE outbox SET state='review' WHERE id=?").run(row.id);continue}
    db.prepare('UPDATE outbox SET first_attempt=COALESCE(first_attempt,?), attempts=attempts+1 WHERE id=?').run(now,row.id);
    try{
     const result=await sendMail({to:row.recipient,text:row.body,id:row.id,from:row.sender,subject:row.subject});
     if(typeof result?.id!=='string'||!result.id)throw Error('Email neconfirmat');
     db.prepare("UPDATE outbox SET state='sent',provider_id=? WHERE id=?").run(result.id,row.id);
    }catch{
     const delay=Math.min(3600000,60000*2**Math.min(row.attempts,6));
     db.prepare('UPDATE outbox SET next_at=? WHERE id=?').run(now+delay,row.id);
    }
   }
  }finally{delivering=false}
 }
 return {fulfillVerifiedPurchase,deliver,close:()=>db.close()};
}
module.exports={createFulfillmentService,deliverySettings,validEmail};
