# CARPATIA — verificarea reală a profilurilor pe Windows

Acest ghid este pentru o **mașină virtuală Windows 10/11 de unică folosință**, cu checkpoint salvat și acces la consola VM. Runnerul schimbă setări Windows reale și poate întrerupe rețeaua. Nu îl rula pe calculatorul principal. Testele Node/Chromium din mediul Linux nu reprezintă această validare nativă.

## Pregătire

Instalează Node.js 24+, extrage sursele, rulează `npm ci` și `npm test`, apoi deschide un terminal ca Administrator în folderul proiectului. Folosește un folder de date nou și gol pentru fiecare comandă inițială. Runnerul refuză un folder existent cu fișiere, rădăcina discului și folderul proiectului; nu îi da directorul de date al aplicației.

Testul nu creează licențe, nu citește chei private și nu necesită activarea clientului. El folosește direct aceleași servicii de profil și motoare Windows. Verificarea installerului și a activării din interfață rămâne un scenariu separat.

## CPU și GPU: aplicare, redeschidere, restaurare, reaplicare

```bat
node tools/test-recovery-windows.js --vm-test --group cpu --data-dir C:\CarpatiaTests\cpu-low-1
node tools/test-recovery-windows.js --vm-test --group gpu --data-dir C:\CarpatiaTests\gpu-low-1
```

Nivelul implicit este **LOW**. Fiecare comandă execută două cicluri de aplicare și restaurare prin instanțe noi ale serviciului, verifică revenirea la valorile originale și confirmă că profilul nu mai este activ. Pentru nivelurile următoare folosește explicit `--level medium`, `--level high` sau `--level ultra` și directoare noi. CPU Ultra omite opțiunea pentru nucleu în RAM dacă nu sunt confirmați peste 8 GB utilizabili și poate crește temperatura și consumul. GPU Ultra omite HAGS pe versiuni Windows anterioare buildului 19041; scrierea HAGS nu dovedește suportul hardware/driverului în VM.

## Internet

Din PowerShell, identifică explicit adaptorul VM (comandă numai de citire):

```powershell
Get-NetAdapter | Select-Object Name, InterfaceGuid, Status
```

În terminalul Administrator, înlocuiește GUID_ADAPTOR cu GUID-ul exact al adaptorului de test:

```bat
node tools/test-recovery-windows.js --vm-test --group internet --adapter GUID_ADAPTOR --data-dir C:\CarpatiaTests\internet-low-1
```

Păstrează consola VM disponibilă, deoarece DNS/setările de rețea sunt schimbate. Nu folosi o conexiune la distanță drept singur acces la VM.

## Restaurare după un restart Windows real

Fiecare test de restart alege explicit un singur grup. Exemplu pentru CPU:

```bat
node tools/test-recovery-windows.js --vm-test --group cpu --hold-for-restart --data-dir C:\CarpatiaTests\cpu-restart-1
```

Mesajul `PENDING` înseamnă că testul încă nu este încheiat. Repornește manual VM, deschide din nou terminalul ca Administrator și rulează:

```bat
node tools/test-recovery-windows.js --vm-test --resume --data-dir C:\CarpatiaTests\cpu-restart-1
```

Runnerul verifică identitatea instalării/utilizatorului și timpul real al pornirii Windows. Relansarea procesului în aceeași pornire Windows este refuzată și nu este raportată drept test de restart. Repetă separat pentru `gpu` și `internet`, cu directoare noi; pentru Internet, GUID-ul se dă la prima comandă și este păstrat pentru reluare. Nu există restart automat.

## Dovezi și interpretare

Directorul de test conține `windows-test-report.json`, `windows-test-evidence.json`, markerul directorului și jurnalele originale. După restaurare, runnerul recitește independent starea inițială și țintele din jurnale prin `snapshot-engine.ps1` cu acțiunea `Probe` (numai citire). Astfel sunt verificate și valorile planului de alimentare salvat, chiar dacă planul activ a fost schimbat între timp. Se compară valoarea, tipul și absența unei intrări Registry, nu doar un mesaj de succes.

- `PASS` și evenimentul `VERIFIED` cer recitirea originalelor și un profil final inactiv.
- `PENDING` cere restart și reluare; nu reprezintă succes final.
- `NOT APPLICABLE`, cod de ieșire 2: toate valorile erau deja configurate; nu a fost demonstrată o restaurare. Reia într-un checkpoint potrivit sau testează alt nivel explicit.
- `FAILED`, cod de ieșire 1: păstrează întregul director pentru diagnostic și recuperare. Nu șterge backupurile și nu porni o nouă aplicare peste el. Un test de restart incomplet poate fi reîncercat cu același `--resume`; după remedierea problemei, restaurarea și recitirea trebuie confirmate.

Aceste verificări confirmă aplicarea și restaurarea valorilor Windows din profilul ales. Nu confirmă FPS, stabilitate în toate jocurile, efecte firmware/driver sau suport HAGS. Backupul manual, installerul, activarea cu licență și performanța înainte/după necesită propriile scenarii.

Profilul pregătit poate conține `skipped`: opțiunile incompatibile sunt omise înainte de capturarea baseline-ului. Raportul verifică numai pașii disponibili și păstrează motivele omiterii. Nu pretinde că a testat aplicarea opțiunilor omise.
