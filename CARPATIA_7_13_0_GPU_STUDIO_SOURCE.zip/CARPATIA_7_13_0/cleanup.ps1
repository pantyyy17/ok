﻿param([ValidateSet('Scan','Clean')][string]$Action='Scan')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
# This optional operation deletes ONLY ordinary user TEMP files older than 7 days.
# It skips junctions, symlinked directories, system TEMP, folders and recent files.
$folder=[IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$local=[IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd('\')+'\'
if(-not $folder.StartsWith($local,[StringComparison]::OrdinalIgnoreCase)){throw 'TEMP nu se afla in profilul utilizatorului.'}
# Refuse a junction in TEMP or any ancestor before traversing.
$ancestor=Get-Item -LiteralPath $folder -Force
while($null -ne $ancestor){
 if(($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'TEMP traverseaza un junction/symlink.'}
 $ancestor=$ancestor.Parent
}
$cut=(Get-Date).AddDays(-7)
$queue=New-Object System.Collections.Stack
$queue.Push($folder)
$files=New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
$scanned=0
while($queue.Count -gt 0 -and $files.Count -lt 2500 -and $scanned -lt 25000){
 $current=[string]$queue.Pop()
 $entries=@(Get-ChildItem -LiteralPath $current -Force -ErrorAction SilentlyContinue)
 foreach($e in $entries){
  $scanned++
  if($scanned -gt 25000 -or $files.Count -ge 2500){break}
  if(($e.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){continue}
  if($e.PSIsContainer){$queue.Push($e.FullName);continue}
  if($e -is [IO.FileInfo] -and $e.LastWriteTime -lt $cut){$files.Add($e)}
 }
}
$bytes=[long]0
foreach($f in $files){$bytes += [long]$f.Length}
if($Action -eq 'Scan'){
 @{success=$true;count=$files.Count;bytes=$bytes;folder=$folder;limit=2500;note='TEMP utilizator: fisiere mai vechi de 7 zile, fara junction/symlink. Scanare limitata.'}|ConvertTo-Json -Compress;exit
}
$removed=0;$freed=[long]0;$failed=0;$skipped=0
foreach($f in $files){try{
 if(-not (Test-Path -LiteralPath $f.FullName -PathType Leaf)){$skipped++;continue}
 # Enumeration and deletion can be far apart. Refresh both file metadata and
 # ancestors rather than deleting a newly replaced/recent file from stale data.
 $fresh=Get-Item -LiteralPath $f.FullName -Force -ErrorAction Stop
 if($fresh -isnot [IO.FileInfo] -or ($fresh.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $fresh.LastWriteTime -ge $cut -or $fresh.LastWriteTimeUtc -ne $f.LastWriteTimeUtc -or $fresh.Length -ne $f.Length){$skipped++;continue}
 $ancestor=$fresh.Directory
 while($null -ne $ancestor){
  $ancestor.Refresh()
  if(($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Curățare oprită pentru un junction/symlink nou.'}
  $ancestor=$ancestor.Parent
 }
 Remove-Item -LiteralPath $fresh.FullName -Force -ErrorAction Stop;$removed++;$freed += [long]$fresh.Length
}catch{$failed++}}
@{success=($failed -eq 0);removed=$removed;freed=$freed;failed=$failed;skipped=$skipped;note='Curatarea TEMP nu este reversibila si nu garanteaza FPS suplimentar.'}|ConvertTo-Json -Compress
