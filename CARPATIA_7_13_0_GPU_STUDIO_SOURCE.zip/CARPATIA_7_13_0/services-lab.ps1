﻿# CARPATIA Services Lab v31 - dedicated allowlist. No arbitrary commands.
param(
 [ValidateSet('Status','Apply','Restore')][string]$Action='Status',
 [ValidateSet('sysmain','search','diagtrack')][string]$Id='sysmain'
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$PSDefaultParameterValues['Out-File:Encoding']='utf8'
$serviceNames=[ordered]@{sysmain='SysMain';search='WSearch';diagtrack='DiagTrack'}
$backupRoot=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
function BackupFile([string]$id){Join-Path $backupRoot ('services-'+$id+'.json')}
function IsElevated {
 $principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
 return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Current([string]$id){
 $name=$serviceNames[$id]
 $obj=Get-CimInstance Win32_Service -Filter "Name='$name'" -ErrorAction Stop
 if(-not $obj){return @{id=$id;name=$name;installed=$false;backup=(Test-Path -LiteralPath (BackupFile $id))}}
 $delayKey='HKLM:\SYSTEM\CurrentControlSet\Services\'+$name
 $key=Get-Item -LiteralPath $delayKey -ErrorAction Stop
 $delayed=$null
 if($key.GetValueNames() -contains 'DelayedAutoStart'){
  $value=$key.GetValue('DelayedAutoStart')
  if([string]$key.GetValueKind('DelayedAutoStart') -cne 'DWord' -or $value -notin @(0,1)){throw 'DelayedAutoStart are un tip sau o valoare neacceptată. Serviciul nu se modifică.'}
  $delayed=[int]$value
 }
 return @{id=$id;name=$name;installed=$true;state=[string]$obj.State;startMode=[string]$obj.StartMode;delayedAutoStart=$delayed;backup=(Test-Path -LiteralPath (BackupFile $id));disabled=([string]$obj.StartMode -eq 'Disabled')}
}
function Read-ServiceBackup([string]$id){
 $b=Get-Content -Raw -Encoding UTF8 -LiteralPath (BackupFile $id) | ConvertFrom-Json
 $v=$b.before
 if($b.version -ne 1 -or $b.id -cne $id -or $b.name -cne $serviceNames[$id] -or $v.name -cne $serviceNames[$id] -or $v.startMode -notin @('Auto','Manual','Disabled') -or $v.state -notin @('Running','Stopped') -or $v.PSObject.Properties.Name -notcontains 'delayedAutoStart' -or ($null -ne $v.delayedAutoStart -and $v.delayedAutoStart -notin @(0,1))){throw 'Backup Services incompatibil sau incomplet; originalul este pastrat.'}
 return $b
}
if($Action -eq 'Status'){
 $items=@();foreach($idKey in $serviceNames.Keys){try{$row=Current $idKey;if($row.backup){$null=Read-ServiceBackup $idKey};$items+=$row}catch{$items+=@{id=$idKey;name=$serviceNames[$idKey];installed=$false;error=$_.Exception.Message;backup=(Test-Path -LiteralPath (BackupFile $idKey))}}}
 @{success=$true;items=@($items);elevated=(IsElevated)}|ConvertTo-Json -Compress -Depth 6
 exit 0
}
if(-not (IsElevated)){throw 'Administrator necesar. Închide CARPATIA și pornește START_ADMIN_OPTIONAL.bat cu Run as administrator.'}
if(-not (Test-Path -LiteralPath $backupRoot)){New-Item -ItemType Directory -Path $backupRoot -Force -ErrorAction Stop|Out-Null}
$filename=BackupFile $Id
$svcName=$serviceNames[$Id]
if($Action -eq 'Apply'){
 if(Test-Path -LiteralPath $filename){throw 'Backupul este deja activ. Folosește Restaurare înainte de o nouă aplicare.'}
 $before=Current $Id
 if(-not $before.installed){throw ('Serviciul '+$svcName+' nu este instalat pe acest Windows.')}
 if($before.startMode -eq 'Disabled'){@{success=$true;already=$true;message='DEJA DEZACTIVAT. Fara modificari sau backup nou.'}|ConvertTo-Json -Compress;exit}
 if($before.startMode -notin @('Auto','Manual') -or $before.state -notin @('Running','Stopped')){throw 'Stare serviciu necunoscuta sau tranzitorie. Nicio modificare.'}
 # Save the exact previous start mode, running state and delayed auto-start before mutating anything.
 $backup=@{version=1;id=$Id;name=$svcName;created=(Get-Date).ToString('o');before=$before}
 $temp=Join-Path $backupRoot ('services-'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $backup|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $temp -Encoding UTF8 -ErrorAction Stop
  Move-Item -LiteralPath $temp -Destination $filename -ErrorAction Stop
 }catch{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue};throw}
 $errors=@()
 try{Set-Service -Name $svcName -StartupType Disabled -ErrorAction Stop}catch{$errors+=('Startup: '+$_.Exception.Message)}
 if($errors.Count -eq 0){
  try{$service=Get-Service -Name $svcName -ErrorAction Stop;if($service.Status -ne 'Stopped'){Stop-Service -Name $svcName -ErrorAction Stop;$service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}}
  catch{$errors+=('Stop: '+$_.Exception.Message)}
 }
 $after=Current $Id
 if($after.state -ne 'Stopped'){$errors+=('Oprire neconfirmata: '+$after.state)}
 if($after.startMode -ne 'Disabled'){$errors+=('Verificarea eșuată: startup='+$after.startMode)}
 @{success=($errors.Count -eq 0);id=$Id;before=$before;after=$after;errors=@($errors);message='Backup persistent creat. Dacă oprirea este incompletă, apasă Restaurare. Nu garantează FPS suplimentar.'}|ConvertTo-Json -Depth 7 -Compress
 exit 0
}
if(-not (Test-Path -LiteralPath $filename)){throw 'Nu există backup CARPATIA. Nu putem inventa modul inițial al serviciului.'}
$backup=Read-ServiceBackup $Id
if([int]$backup.version -ne 1 -or [string]$backup.id -cne $Id -or [string]$backup.name -cne $svcName){throw 'Backup incompatibil; nimic nu a fost modificat.'}
$before=$backup.before
if([string]$before.name -cne $svcName -or [string]$before.startMode -notin @('Auto','Manual','Disabled')){throw 'Backup cu valori nepermise.'}
$current=Current $Id
if(-not $current.installed -or $current.startMode -notin @($before.startMode,'Disabled') -or $current.state -notin @($before.state,'Stopped')){throw 'Serviciul a fost schimbat din exterior sau este într-o stare tranzitorie. Backupul este păstrat.'}
$modes=@{Auto='Automatic';Manual='Manual';Disabled='Disabled'}
$mode=$modes[[string]$before.startMode]
$errors=@()
try{Set-Service -Name $svcName -StartupType $mode -ErrorAction Stop}catch{$errors+=('Startup: '+$_.Exception.Message)}
# Preserve delayed auto-start for services originally configured as Automatic (Delayed Start).
$delayKey='HKLM:\SYSTEM\CurrentControlSet\Services\'+$svcName
if($errors.Count -eq 0){
 try{
  if($null -ne $before.delayedAutoStart){New-ItemProperty -LiteralPath $delayKey -Name DelayedAutoStart -PropertyType DWord -Value ([int]$before.delayedAutoStart) -Force -ErrorAction Stop|Out-Null}
  elseif(Get-ItemProperty -LiteralPath $delayKey -Name DelayedAutoStart -ErrorAction SilentlyContinue){Remove-ItemProperty -LiteralPath $delayKey -Name DelayedAutoStart -ErrorAction Stop}
 }catch{$errors+=('DelayedAutoStart: '+$_.Exception.Message)}
}
if($errors.Count -eq 0){
 try{
  $service=Get-Service -Name $svcName -ErrorAction Stop
  if([string]$before.state -eq 'Running' -and $service.Status -ne 'Running'){Start-Service -Name $svcName -ErrorAction Stop;$service.WaitForStatus('Running',[TimeSpan]::FromSeconds(30))}
  elseif([string]$before.state -eq 'Stopped' -and $service.Status -ne 'Stopped'){Stop-Service -Name $svcName -ErrorAction Stop;$service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}
 }catch{$errors+=('State: '+$_.Exception.Message)}
}
$after=Current $Id
if($errors.Count -eq 0 -and [string]$after.startMode -ne [string]$before.startMode){$errors+=('Verificarea startup nu coincide cu backupul: '+$after.startMode)}
if($errors.Count -eq 0 -and $after.delayedAutoStart -ne $before.delayedAutoStart){$errors+=('Verificarea DelayedAutoStart nu coincide cu backupul.')}
if($after.state -ne $before.state){$errors+=('Starea Running/Stopped nu coincide cu originalul: '+$after.state)}
if($errors.Count -eq 0){
 $archive=Join-Path $backupRoot ('services-restored-'+$Id+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.json')
 try{Move-Item -LiteralPath $filename -Destination $archive -ErrorAction Stop}catch{$errors+=('Arhivare backup: '+$_.Exception.Message)}
}
@{success=($errors.Count -eq 0);id=$Id;before=$before;after=$after;errors=@($errors);message='Setările inițiale au fost restaurate dacă nu există erori. Unele schimbări pot necesita restart.'}|ConvertTo-Json -Depth 7 -Compress
