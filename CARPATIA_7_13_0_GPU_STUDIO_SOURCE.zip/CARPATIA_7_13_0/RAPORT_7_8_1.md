# CARPATIA V7 PRO REDLINE 7.8.1 — candidat pentru validare Windows

27 octombrie 2026. Aceasta este o versiune sursă modificată, NU o versiune finală validată pe Windows. Nu include executabil sau installer.

## Baza verificată

Sursa: CARPATIA_7_8_0_DASHBOARD_RESOURCE_FIX_SOURCE.zip, SHA-256 `916eb310edd58f425aac1418b39bae7bd717b4367c3c5c505fdc6eea80680a12`.
Au fost inspectate cele patru capturi din 26 octombrie, orele 15:39:38, 15:39:51, 15:39:59 și 15:40:07, recuperate din fișierele conversației anterioare. Toate arată catalogul sau Dashboard-ul; niciuna dintre aceste patru nu arată pagina Backup & Restore. Pagina a fost analizată din cod.

## Cauze și corecții

- Filtrul gol: `showResourceOwner` și ramuri similare scriau ID-ul în `tweakSearch`, deși indexul de căutare nu conținea acel ID. Noile comenzi deschid recuperarea fără să scrie în căutare, categorie sau filtrul de stare.
- CPU: `library-cpu-035` era simultan pas de profil și tweak individual cu backup activ. Referința RAM din titlu nu înseamnă un ID diferit. Profilul reutilizează acum exact aceeași setare numai când jurnalul este `applied` și citirea Windows confirmă valoarea dorită. Păstrează originalul; nu execută din nou scrierea.
- GPU: captura și sursa folosesc `library-cpu-012` pentru Game DVR. `library-gpu-012` nu există în această sursă. ID-ul este păstrat pentru compatibilitate cu backupurile existente.
- Alte ID-uri care ating aceeași resursă rămân blocate, inclusiv valorile contradictorii. Nu sunt îmbinate automat două originale independente. Mesajul indică centrul de recuperare; previzualizarea și confirmarea preced restaurarea.
- Dashboard citește acum valorile efective prin Check, în loc să considere jurnalul `applied` dovada stării curente. Poate afișa activ, parțial, inactiv cu backup păstrat sau necunoscut.
- Selectoarele de nivel nu aplică nimic. Cercul analizează, iar confirmarea separată execută profilul. Animațiile și cele trei cercuri sunt păstrate.

## Implementare

- `recovery-core.js`: coordonare centrală, selecție individuală/categorie, token unic de confirmare cu expirare, invalidare dacă backupurile s-au schimbat, execuție secvențială, rapoarte persistente după fiecare rezultat.
- `recovery-ui.js`: centrul Ruby Redline, listă de backupuri cu nume/categorie/dată/stare, originale și valori curente înainte de restaurare, istoric și raport de erori/restart. Comenzile anterioare rămân disponibile într-o secțiune de compatibilitate.
- Sunt inventariate jurnalele catalogului, profilurile prin apartenența fiecărui pas, ULTRA vechi, Power, Internet vechi, servicii, Startup și preferințele GPU pe executabil. Nu se elimină funcționalitățile vechi.
- Restaurarea individuală din centru actualizează și jurnalul profilului. Restaurările reușite sunt verificate de adaptoarele Windows și prin recitirea jurnalului.
- Eveniment comun după mutații pentru reîncărcarea Dashboard, catalog, rețea și recuperare. Filtrele utilizatorului sunt păstrate.
- Registry: detectarea schimbărilor externe înainte de prima scriere, validarea originalelor și țintelor duplicate, verificarea privilegiilor, recitire după restaurare. Valorile deja corecte nu mai sunt rescrise.
- Native: detectarea abaterilor față de original și valoarea aplicată înainte de restaurare. O stare ambiguă rămâne blocată, cu backup păstrat.
- Backupurile ciclurilor precedente sunt arhivate la reaplicare. Raportul curent este salvat înainte de prima restaurare și după fiecare pas.
- Backup manual: captură read-only a stărilor reversibile din catalog, pentru fiecare adaptor unde este necesar, plus copii separate ale originalelor automate și backupurilor vechi. Operațiile fără stare reversibilă sunt omise explicit. Setările indisponibile sau necitibile produc raport parțial.
- Startup verifică tipul și valoarea recitită înainte de a elimina intrarea din backup.
- Recuperarea rămâne disponibilă fără licență activă. Nu s-au introdus dezactivări automate ale protecțiilor.

## Teste executate efectiv aici

Mediu: Linux, Node 24.22.1. `npm test`: **183 teste, 183 trecute, 0 eșuate**. Jurnalul este inclus în `test-results-7.8.1.txt`. Verificarea sintaxei Node a trecut pentru cele 24 de fișiere JavaScript principale și pentru noul runner Windows.

Scenarii verificate cu adaptoare simulate: CPU/GPU/Internet ULTRA aplicare → restaurare → reaplicare; recrearea serviciului cu jurnalele păstrate; reutilizarea unui tweak individual identic fără scriere; blocarea conflictelor și schimbărilor externe; eșec parțial și păstrarea originalelor; confirmări expirate sau reutilizate; invalidarea confirmării după modificarea jurnalului; restaurare individuală și pe categorie; anulare fără commit; raport UI și navigare fără modificarea căutării; diferența dintre jurnal aplicat și stare observată parțială.

Aceste teste NU demonstrează funcționarea Registry, Power, DNS, TCP sau serviciilor Windows. Testele UI folosesc DOM simulat, nu randare Electron.

## Validări neexecutate / blocaje

- Nu există Windows/PowerShell sau VM Windows în acest mediu. Nu s-a aplicat/restaurat efectiv nicio setare Windows și nu s-a testat restartul Windows. Compatibilitatea Windows 10/11 nu este certificată.
- Randarea vizuală nu a putut fi executată: Playwright este instalat, dar binarul Chromium lipsește. Nu există capturi fabricate ale interfeței noi.
- `node tools/check-release.js` a blocat build-ul: lipsește `license-public.pem`. Cheia utilizatorului nu a fost înlocuită și verificarea de release nu a fost ocolită. Nu există EXE/installer generate sau verificate.

## Limite funcționale rămase înainte de release

1. Instantaneele manuale sunt salvate real, dar NU au încă un flux de import/restaurare directă din instantaneu. Restaurarea din UI folosește originalele automate. Acest punct nu îndeplinește încă un sistem complet de revenire la orice backup manual.
2. Stările native mixte după eșec parțial și modificările externe sunt oprite conservator; necesită diagnostic, nu sunt suprascrise automat. Nu există încă un dialog de rezolvare pe fiecare valoare divergentă.
3. Backupurile legacy și cele din catalog sunt restaurate prin adaptoarele lor existente. Pentru combinații ambigue se poate cere restaurarea catalogului și repetarea operației legacy. Nu există o migrare completă a tuturor formatelor într-un singur format nou.
4. Backupurile istorice sunt consultabile; nu există încă restaurare arbitrară la o generație istorică. Istoricul poate crește; nu se șterge automat.
5. Originalele per utilizator trebuie restaurate sub același cont Windows. Rularea elevată cu un alt cont și migrarea backupurilor între calculatoare necesită validare suplimentară.
6. Schimbarea stării din afara aplicației necesită Actualizează/Analizează; nu există monitorizare continuă a Registry.

Prin urmare, pachetul este un candidat de implementare pentru testare, NU îndeplinirea integrală și validată a tuturor cerințelor de release.

## Validare Windows pregătită, dar neexecutată

Folosește o VM Windows de test cu checkpoint și acces la consolă, Administrator, Node 24+. NU calculatorul principal. `tools/test-recovery-windows.js` execută operații reale și poate întrerupe rețeaua sau cere restart.

1. `TEST_NATIVE_WINDOWS.bat`: parser PowerShell și transformări read-only existente.
2. `node tools/test-recovery-windows.js --vm-test --adapter GUID_ADAPTOR --data-dir C:\CarpatiaTest\Recovery`: două cicluri ULTRA pentru fiecare grup și un tweak individual. Directorul trebuie dedicat acestui test.
3. Pentru restart: adaugă `--group cpu --hold-for-restart`, repornește efectiv VM, apoi execută runnerul cu același `--data-dir` și `--resume`. Repetă pentru GPU și Internet. Runnerul nu pretinde că a efectuat restartul.
4. Verifică manual centrul de recuperare, restaurarea completă, filtrele, eșecurile de acces, backupurile incomplete și recuperarea după închiderea aplicației.
5. Numai după validare și configurarea cheii publice reale: `npm run dist` pe Windows. Nu distribui comercial candidatul ca versiune verificată.
