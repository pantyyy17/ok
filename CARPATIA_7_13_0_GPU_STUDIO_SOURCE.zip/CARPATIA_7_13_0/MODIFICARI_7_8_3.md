# 7.8.3 — Fișe curate

Eliminate din fișele vizibile: comenzile PowerShell/CMD, blocurile Registry, descrierile provenite din aplicația de referință, denumirile de referință și ID-urile interne.

Păstrate: titlul operației, categoria, riscul estimat, caracterul experimental, necesitatea restartului, condițiile de compatibilitate explicate, avertismentele despre protecții/pornire și operațiile fără anulare. Confirmarea arată informații utile, fără comenzi sau căi Registry. Erorile reale pot conține în continuare detalii tehnice necesare diagnosticului.

Filtrul separă setările cu restaurare de întreținerea fără anulare. Căutarea folosește numele și categoria vizibile. Stările salvate sunt afișate în română.

Definițiile tehnice, motorul de execuție și backupurile nu au fost eliminate. Nu sunt introduse promisiuni despre FPS sau latență. Titlurile catalogului rămân, în mare parte, în engleză; traducerea completă necesită verificarea individuală a efectelor.

Testare: npm test, 183 teste trecute (logică și UI simulat). Windows și randarea Electron nu au fost validate în acest mediu. Pachetul este sursă, nu EXE. Limitele de restaurare manuală descrise în RAPORT_7_8_1.md rămân valabile.
