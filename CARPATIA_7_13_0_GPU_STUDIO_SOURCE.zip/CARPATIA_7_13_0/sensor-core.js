'use strict';
// Optional local LibreHardwareMonitor read-only sensor feed. Never send commands to sensor server.
const http=require('node:http');
const ADDRESS='http://127.0.0.1:8085/data.json';
// Iterative traversal bounds both unnamed nesting and non-sensor nodes. Hardware
// scope comes from the nearest hardware ancestor, never the computer's hostname.
function walk(node,ancestors=[],out=[]){
 const pending=[{node,ancestors,depth:0,hardware:null}],seen=new WeakSet();let visited=0;
 while(pending.length&&visited<5000&&out.length<400){
  const current=pending.pop(),value=current.node;
  if(!value||typeof value!=='object'||current.depth>30||seen.has(value))continue;
  seen.add(value);visited++;
  const name=String(value.Text??value.text??'').slice(0,120);
  const route=[...current.ancestors,name].filter(Boolean);
  const image=String(value.ImageURL??value.imageURL??'');
  let hardware=current.hardware;
  // LHM icons identify devices even when their display names are customized.
  if(/(?:^|[\/])(?:cpu|processor)\.png(?:$|\?)/i.test(image))hardware='cpu';
  else if(/(?:^|[\/])(?:nvidia|ati|amd|gpu|intel_gpu)\.png(?:$|\?)/i.test(image))hardware='gpu';
  else if(current.depth>0){
   if(/\b(?:gpu|graphics|radeon|geforce|nvidia)\b/i.test(name))hardware='gpu';
   else if(/\b(?:cpu|processor|intel core|ryzen)\b/i.test(name))hardware='cpu';
  }
  const val=String(value.Value??value.value??''),num=Number.parseFloat(val.replace(',','.'));
  if(Number.isFinite(num))out.push({name,path:route.join(' / '),value:num,unit:val,hardware});
  const children=value.Children??value.children;
  if(Array.isArray(children))for(let i=Math.min(children.length,5000-visited-pending.length)-1;i>=0;i--)pending.push({node:children[i],ancestors:route,depth:current.depth+1,hardware});
 }
 return out;
}
function firstMatching(items,scope,kind){
 const rxKind=kind==='temperature'?/(°\s*c|\bcelsius\b)/i:/(%|percent)/i;
 const nameRx=kind==='temperature'?/(package|core|gpu|hot spot|temperature|tdie|tctl)/i:/(total|core|gpu|load)/i;
 const candidates=items.filter(s=>s.hardware===scope&&rxKind.test(s.unit)&&nameRx.test(s.name)&&!/(max|min|threshold)/i.test(s.name)&&s.value>=0&&(kind!=='load'||s.value<=100));
 const prioritized=candidates.sort((a,b)=>{
  const score=s=>/package|tdie|gpu core|gpu temperature|gpu load|cpu total/i.test(s.name)?0:1;
  return score(a)-score(b);
 });
 const s=prioritized[0];return s?{name:s.name,value:s.value,unit:kind==='temperature'?'°C':'%'}:null;
}
function gpuMetric(items,nameRx,unitRx,unit,max){const sensor=items.find(s=>s.hardware==='gpu'&&nameRx.test(s.name)&&unitRx.test(s.unit)&&s.value>=0&&s.value<=max);if(!sensor)return null;return {name:sensor.name,value:sensor.value*(unit==='MHz'&&/GHz/i.test(sensor.unit)?1000:1),unit}}
function parseSensorTree(tree){const items=walk(tree);return {cpuTemperature:firstMatching(items,'cpu','temperature'),gpuTemperature:firstMatching(items,'gpu','temperature'),gpuLoad:firstMatching(items,'gpu','load'),gpuCoreClock:gpuMetric(items,/(?:gpu\s*)?core(?:\s*clock)?$/i,/(?:M|G)Hz/i,'MHz',10000),gpuMemoryClock:gpuMetric(items,/(?:gpu\s*)?memory(?:\s*clock)?$/i,/(?:M|G)Hz/i,'MHz',30000),gpuPower:gpuMetric(items,/package|total|board|gpu power/i,/\bW$/i,'W',2000),gpuFan:gpuMetric(items,/fan/i,/RPM/i,'RPM',30000),sensorCount:items.length};}
function fetchLocalSensors(timeout=1700){return new Promise(resolve=>{
 let finished=false;let deadline;const done=data=>{if(finished)return;finished=true;clearTimeout(deadline);resolve(data)};
 const req=http.get(ADDRESS,{timeout,headers:{Accept:'application/json'}},res=>{
  if(res.statusCode!==200){res.resume();return done({available:false,reason:'Server local indisponibil: HTTP '+res.statusCode});}
  res.on('error',()=>done({available:false,reason:'Conexiunea senzorilor a fost întreruptă.'}));
  res.on('aborted',()=>done({available:false,reason:'Răspuns senzori incomplet.'}));
  let content='';res.setEncoding('utf8');res.on('data',part=>{content+=part;if(content.length>1000000){req.destroy();done({available:false,reason:'Răspunsul senzorilor este prea mare.'})}});
  res.on('end',()=>{try{const data=parseSensorTree(JSON.parse(content));done({available:true,source:'LibreHardwareMonitor local',...data})}catch{done({available:false,reason:'Date JSON senzori invalide.'})}});
 });
 deadline=setTimeout(()=>{req.destroy();done({available:false,reason:'Timpul de citire a senzorilor a expirat.'})},timeout);
 req.on('timeout',()=>req.destroy(new Error('timeout')));
 req.on('error',()=>done({available:false,reason:'Pornește LibreHardwareMonitor și activează serverul local 127.0.0.1:8085. Nu este necesar pentru restul CARPATIA.'}));
 });}
module.exports={ADDRESS,walk,parseSensorTree,fetchLocalSensors};
