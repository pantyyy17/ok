# CARPATIA 7.7.1 — optimizarea interfeței

- Catalogul static este încărcat o singură dată pe sesiunea interfeței. Jurnalele și stările Windows NU sunt păstrate în acest cache.
- Indexul text pentru căutare se construiește o singură dată. Rândurile existente se reutilizează la căutare și filtrare.
- Descrierile detaliate, valorile Registry și comenzile de referință se construiesc numai la prima deschidere a secțiunii Detalii a unui rând.
- Cache-ul de rânduri se invalidează când sunt reîncărcate jurnalele, inclusiv după aplicare/restaurare, ca butoanele să reflecte noua stare.
- Lista adaptoarelor nu se recitește după fiecare verificare de profil sau de backup. Butonul Actualizează o reîncarcă explicit. Dacă introduci o placă nouă sau schimbi conexiunea, apasă Actualizează înainte de selecție.
- Motoarele validează în continuare identificatorul adaptorului și citesc starea reală înainte de schimbare. Verificările de compatibilitate, licență și recuperare nu au fost eliminate.

## Măsurare reproductibilă, fără Windows

Repetă măsurarea cu `npm run measure:catalog`.

Într-un DOM simulat, la aceeași listă de 209 intrări, s-au numărat apelurile createElement:

| Operație | 7.7.0 | 7.7.1 |
|---|---:|---:|
| Prima afișare | 3188 | 2370 |
| Căutare «cpu», apoi ștergerea căutării | 3816 suplimentare | 0 suplimentare |

Aceasta măsoară construcția elementelor interfeței, nu consumul real RAM/CPU al Electron, timpii de pornire Windows sau FPS. Aceste valori necesită măsurare pe un PC Windows.

114 teste Node trec, inclusiv păstrarea identității rândurilor după filtrare, construirea o singură dată a detaliilor și actualizarea explicită a adaptoarelor.

Pentru încheierea release-ului sunt necesare încă: testarea Apply/Restore pe Windows 10/11, verificarea după restart, configurarea cheii publice originale și testarea installerului și activării permanente. Nu este o livrare comercială validată.
