# CARPATIA 7.9.0 — raport de livrare

28 octombrie 2026. Bază: proiectul 7.8.0 și corecțiile 7.8.1–7.8.3.

## Implementare

Copiile manuale pot fi restaurate din Istoric. Motorul validează țintele față de catalog și pregătește schimbările înainte de confirmare. Copiile noi includ manifest, amprente SHA-256 și identitatea calculatorului/contului. Copiile vechi fără manifest cer confirmarea provenienței; identitatea lor nu poate fi verificată retrospectiv. Amprentele detectează coruperea fișierelor, dar nu sunt semnături de autenticitate.

Restaurarea salvează starea de dinaintea operației într-un jurnal separat, înainte de scriere. Jurnalul permite reluare sau anulare după redeschidere. Scrierea compară starea curentă cu cea previzualizată și verifică rezultatul prin recitire. Refuzul Windows, lipsa privilegiilor și schimbările externe produc erori, nu succes simulat. Eșecurile parțiale păstrează recuperarea și blochează alte modificări până la rezolvare.

Originalele automate active trebuie restaurate înainte de încărcarea unei copii manuale, pentru a nu le suprascrie. Capturile manuale restaurabile acoperă operațiile reversibile din catalog; operațiile ireversibile sunt omise explicit, iar capturile indisponibile sunt raportate. Fișierele vechi de recuperare sunt copiate separat ca dovezi/originale, nu executate ca scripturi de restaurare a unei stări arbitrare. Punctele de restaurare Windows rămân separate.

Toate cele 210 intrări executabile au titluri și explicații în română în `catalog-ro.json`. Descrierile urmăresc efectul implementat, fără promisiuni de FPS. Comenzile brute și ID-urile rămân în surse și detaliile tehnice. Riscurile și avertismentele sunt păstrate.

Compatibilitatea folosește CPU, GPU, RAM, stocare, tipul calculatorului, adaptoare și versiunea Windows, unde datele sunt cunoscute. Incompatibilitățile demonstrate sunt ascunse implicit; „Arată toate” le afișează cu motiv și aplicarea dezactivată. Datele necunoscute nu sunt tratate drept incompatibilitate. Setările cu backup activ rămân vizibile. Backendul verifică și el compatibilitatea înainte de aplicare. Suportul efectiv al comenzilor și driverelor rămâne verificat de motorul Windows.

Restaurarea din Dashboard, catalog, GPU și servicii deschide centrul comun cu selecția relevantă. Rețeaua trimite către categoria Internet din catalogul comun. Controalele vechi rămân într-o zonă pliabilă pentru compatibilitate. Funcțiile distincte, precum preferințele GPU per aplicație și configurarea adaptorului, sunt păstrate.

Restaurarea nu introduce ID-uri în căutare; filtrele sunt independente de recuperare. Evenimentele de schimbare actualizează paginile. Selectarea HIGH/ULTRA rămâne separată de executare. Sesiunile fără modificări efective și jurnalele goale de rețea nu mai lasă profiluri fals active.

Țintele fizice duplicate din copiile manuale sunt deduplicate, inclusiv aliasurile CPU/RAM pentru aceeași valoare. Valorile contradictorii sunt respinse. Verificările de proprietate și conflict existente nu au fost eliminate.

## Testare efectuată și limite

Mediu Linux/Node.js. `npm test`: **204 teste trecute, 0 eșuate, 0 omise**. Rezultatul complet: `test-results-7.9.0.txt`. JavaScript verificat sintactic.

Testele verifică profiluri, conflicte, filtrare/căutare, rutare și sincronizare cu DOM simulat. Testele noi acoperă previzualizarea fără scrieri, restaurarea/anularea, persistența după recrearea serviciului, reluarea eșecurilor, schimbările externe, expirarea confirmării, integritatea fișierelor, identitatea calculatorului, originalele active și deduplicarea.

Testele folosesc adaptoare Windows simulate și fișiere temporare reale pentru persistență. **Operațiile Windows și restartul real nu au fost executate.** PowerShell, Registry, servicii, BCD și rețea necesită validare Windows. Randarea și animațiile Electron nu au fost verificate vizual aici.

`node tools/check-release.js` a refuzat distribuirea deoarece lipsește `license-public.pem`. Nu a fost generată o cheie înlocuitoare. Nu a fost produs sau verificat un EXE/installer.

## Validare necesară pe Windows 10 și Windows 11

Folosește o mașină virtuală cu checkpoint, Administrator și acces la consolă, cu directoare dedicate testelor.

CPU/GPU/Internet ULTRA → restaurare → reaplicare, plus tweak individual:

```powershell
node tools/test-recovery-windows.js --vm-test --data-dir C:\CarpatiaTests\Profiles --adapter GUID_ADAPTOR
```

Pentru restart, adaugă `--group cpu --hold-for-restart`, repornește Windows manual și rulează cu același director și `--resume`. Repetă separat pentru GPU și Internet. Scriptul nu repornește calculatorul automat.

Copie manuală: scriere, verificare și revenire la starea anterioară:

```powershell
node tools/test-snapshot-windows.js --vm-test --data-dir C:\CarpatiaTests\Snapshot
```

Pentru restart, adaugă `--hold-for-restart`, repornește manual și rulează cu același director și `--resume`. Dacă valoarea de test este deja aplicată, scriptul raportează scenariul neaplicabil, nu succes fictiv.

În interfața reală verifică suplimentar restaurare totală după mai multe tweakuri, căutare/categorie păstrate, profiluri parțiale, confirmare/anulare, „Arată toate”, lipsa Administrator, schimbări externe, copii incomplete, eșecuri parțiale, redeschidere și animații. Validează tipurile native pe hardware-ul/serviciile disponibile. Distribuția Windows necesită aceste validări și cheia originală.
