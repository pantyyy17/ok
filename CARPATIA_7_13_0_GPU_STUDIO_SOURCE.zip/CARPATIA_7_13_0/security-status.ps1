# Read-only Microsoft Defender status. No protection, service or policy is changed.
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
function Get-CarpatiaSecurityStatus {
 if(-not (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) -or -not (Get-Command Get-MpPreference -ErrorAction SilentlyContinue)){
  return @{success=$true;available=$false;realTimeEnabled=$null;tamperProtected=$null;passive=$null;reason='Microsoft Defender nu poate fi verificat pe această instalare. Deschide Securitate Windows pentru starea antivirusului.'}
 }
 try{
  $status=Get-MpComputerStatus -ErrorAction Stop
  $preference=Get-MpPreference -ErrorAction Stop
  if($null -eq $status -or $null -eq $preference){throw 'Windows nu a returnat o stare completă a protecției.'}
  $realtime=if($status.RealTimeProtectionEnabled -is [bool]){$status.RealTimeProtectionEnabled}else{$null}
  $tamper=if($status.IsTamperProtected -is [bool]){$status.IsTamperProtected}else{$null}
  $mode=[string]$status.AMRunningMode
  $passive=if($mode -ceq 'Normal'){$false}elseif($mode -match 'Passive|EDR Block'){$true}else{$null}
  $disabled=if($preference.DisableRealtimeMonitoring -is [bool]){$preference.DisableRealtimeMonitoring}else{$null}
  return @{success=$true;available=$true;realTimeEnabled=$realtime;tamperProtected=$tamper;passive=$passive;mode=$mode;preferenceDisabled=$disabled;reason='Stare citită din Windows. Setările protejate de sistem se gestionează în Securitate Windows.'}
 }catch{
  return @{success=$false;available=$false;realTimeEnabled=$null;tamperProtected=$null;passive=$null;reason=('Starea Microsoft Defender nu a putut fi verificată: '+$_.Exception.Message)}
 }
}
Get-CarpatiaSecurityStatus | ConvertTo-Json -Depth 5 -Compress
