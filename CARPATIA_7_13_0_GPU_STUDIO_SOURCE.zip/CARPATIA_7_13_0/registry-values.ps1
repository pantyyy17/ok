﻿# Shared typed Registry IO. No writes occur when this file is loaded.
# Validate every original before opening a writable key. Never coerce a corrupt
# backup into a different Registry value or truncate numeric/list elements.
function Assert-RegistryValue($row){
 if($null -eq $row -or $row.path -isnot [string] -or $row.name -isnot [string] -or $row.exists -isnot [bool]){throw 'Descriere Registry incompletă.'}
 if($row.path -notmatch '^(HKCU|HKU|HKLM)\\[^\x00]+$' -or $row.name.IndexOf([char]0) -ge 0){throw 'Țintă Registry invalidă.'}
 if(-not $row.exists){return}
 if($null -eq $row.value){throw 'Original Registry fără valoare.'}
 switch -CaseSensitive ([string]$row.kind){
  'DWord' {if(($row.value -isnot [int] -and $row.value -isnot [long] -and $row.value -isnot [uint32]) -or [long]$row.value -lt -2147483648 -or [long]$row.value -gt 4294967295){throw 'DWORD invalid.'}}
  'QWord' {if($row.value -isnot [int] -and $row.value -isnot [long]){throw 'QWORD invalid.'}}
  'String' {if($row.value -isnot [string]){throw 'Text Registry invalid.'}}
  'ExpandString' {if($row.value -isnot [string]){throw 'Text Registry invalid.'}}
  'Binary' {
   if($row.value -isnot [array]){throw 'Listă binară Registry invalidă.'}
   foreach($byte in $row.value){if(($byte -isnot [byte] -and $byte -isnot [int] -and $byte -isnot [long]) -or $byte -lt 0 -or $byte -gt 255){throw 'Octet Registry invalid.'}}
  }
  'MultiString' {
   if($row.value -isnot [array]){throw 'Listă text Registry invalidă.'}
   foreach($text in $row.value){if($text -isnot [string] -or $text.IndexOf([char]0) -ge 0){throw 'Element text Registry invalid.'}}
  }
  default {throw 'Tip Registry nesuportat pentru restaurare.'}
 }
}
# New journals are also consumed by JavaScript recovery, whose JSON numbers
# must be safe integers. Keep full Int64 support above for historical restores.
function Assert-RegistryCapture($row){
 Assert-RegistryValue $row
 if($row.exists -and $row.kind -ceq 'QWord' -and ([long]$row.value -lt -9007199254740991 -or [long]$row.value -gt 9007199254740991)){throw 'Original QWORD nereprezentabil fără pierderi în recuperare. Nu se modifică registrul.'}
}
function Open-Hive($path){
 if($path.StartsWith('HKCU\')){$h=[Microsoft.Win32.RegistryHive]::CurrentUser}
 elseif($path.StartsWith('HKU\')){$h=[Microsoft.Win32.RegistryHive]::Users}
 elseif($path.StartsWith('HKLM\')){$h=[Microsoft.Win32.RegistryHive]::LocalMachine}
 else{throw 'Registry hive nepermis.'}
 [Microsoft.Win32.RegistryKey]::OpenBaseKey($h,[Microsoft.Win32.RegistryView]::Registry64)
}
function Read-Value($entry){
 $h=Open-Hive $entry.path;$k=$null
 try{
  $k=$h.OpenSubKey(($entry.path.Substring($entry.path.IndexOf('\')+1)),$false)
  if($null -eq $k -or $k.GetValueNames() -notcontains [string]$entry.name){return @{path=$entry.path;name=$entry.name;exists=$false;kind=$null;value=$null}}
  $kind=[string]$k.GetValueKind([string]$entry.name)
  $value=$k.GetValue([string]$entry.name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
  return @{path=$entry.path;name=$entry.name;exists=$true;kind=$kind;value=$value}
 }finally{if($null -ne $k){$k.Dispose()};$h.Dispose()}
}
function Set-Value($row){
 Assert-RegistryValue $row
 $h=Open-Hive $row.path;$k=$null
 try{
  if(-not $row.exists){
   $k=$h.OpenSubKey(($row.path.Substring($row.path.IndexOf('\')+1)),$true)
   if($null -ne $k){$k.DeleteValue([string]$row.name,$false)}
   return
  }
  $kind=[Enum]::Parse([Microsoft.Win32.RegistryValueKind],[string]$row.kind)
  $v=$row.value
  switch([string]$row.kind){
   'DWord' {if([long]$v -gt [int]::MaxValue){$v=[BitConverter]::ToInt32([BitConverter]::GetBytes([uint32]$v),0)}else{$v=[int]$v}}
   'QWord' {$v=[long]$v}
   'Binary' {$v=[byte[]]$v}
   'MultiString' {$v=[string[]]$v}
   'String' {$v=[string]$v}
   'ExpandString' {$v=[string]$v}
   default {throw 'Tip Registry nesuportat pentru restaurare.'}
  }
  $k=$h.CreateSubKey(($row.path.Substring($row.path.IndexOf('\')+1)));$k.SetValue([string]$row.name,$v,$kind)
 }finally{if($null -ne $k){$k.Dispose()};$h.Dispose()}
}
function Same-Value($a,$b){
 if([bool]$a.exists -ne [bool]$b.exists){return $false}
 if(-not $a.exists){return $true}
 if([string]$a.kind -ne [string]$b.kind){return $false}
 if($a.kind -eq 'DWord'){return (([long]$a.value -band 4294967295) -eq ([long]$b.value -band 4294967295))}
 return (($a.value | ConvertTo-Json -Compress -Depth 6) -ceq ($b.value | ConvertTo-Json -Compress -Depth 6))
}
