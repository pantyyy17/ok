# Read-only checks: parser and pure transformations. No tweak is applied.
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$files=@(Get-ChildItem -LiteralPath $project -Filter '*.ps1' -File)
$files+=Get-Item -LiteralPath $PSCommandPath
foreach($file in $files){
 $tokens=$null;$errors=$null
 [System.Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors) | Out-Null
 if(@($errors).Count){throw ($file.Name+': '+(($errors | ForEach-Object {$_.Message}) -join '; '))}
}
. (Join-Path $project 'tweak-native-ops.ps1')
function Assert-Equal($actual,$expected,$label){if((Canonical-Native $actual) -cne (Canonical-Native $expected)){throw ('FAILED: '+$label)}}
Assert-Equal @{x=1;y=$false} ([pscustomobject]@{y=$false;x=[long]1}) 'JSON roundtrip equivalence'
if((Canonical-Native $false) -ceq (Canonical-Native 0)){throw 'Boolean/number collision'}
if((Canonical-Native @('a','b')) -ceq (Canonical-Native @('b','a'))){throw 'Array order lost'}
$before=@([pscustomobject]@{name='TestOnly';start=3;delayedExists=$false;delayed=0;running=$true})
$spec=[pscustomobject]@{type='service';services=@([pscustomobject]@{name='TestOnly';start=4;running=$false})}
$desired=Desired-Native $spec $before
Assert-Equal $before[0].start 3 'Original service snapshot not mutated'
Assert-Equal $desired[0].start 4 'Desired startup mode'
Assert-Equal $desired[0].running $false 'Desired running state'
$dns=Desired-Native ([pscustomobject]@{type='dns';value=@()}) $null
Assert-Equal $dns @{automatic=$true;servers=@()} 'DHCP DNS representation'
$bcd=Desired-Native ([pscustomobject]@{type='bcd';values=@([pscustomobject]@{key='disabledynamictick';object='{current}';value='yes'})}) $null
Assert-Equal @($bcd).Count 1 'Single-item BCD snapshot preserved'
Write-Output ('PASS: '+$files.Count+' PowerShell files parsed; pure adapter checks passed. No Windows settings changed.')
# Power settings must coexist while duplicate targets still collide.
$base=[pscustomobject]@{type='power-value';scheme='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';subgroup='54533251-82be-4824-96c1-47b60b740d00';setting='893dee8e-2bef-41e0-89c6-b55d0929964c'}
$other=Copy-Object $base;$other.setting='bc5038f7-23e0-4960-96da-33abaf5935ec'
$one=@(Native-Targets $base);$two=@(Native-Targets $other)
if($one[0] -ceq $two[0]){throw 'Different CPU power settings collide'}
Assert-Equal @(Native-Targets $base) @(Native-Targets (Copy-Object $base)) 'Identical power settings conflict'
if($one[0] -eq @(Native-Targets ([pscustomobject]@{type='power-active'}))[0]){throw 'Power activation collides with per-scheme values'}
Write-Output 'PASS: exact power targets permit independent settings, preserve duplicate detection.'
. (Join-Path $project 'resource-conflicts.ps1')
$networkRule=[pscustomobject]@{category='Network';entries=@([pscustomobject]@{path='HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization';name='DODownloadMode'})}
if(Test-NetworkRegistryConflict $networkRule ([pscustomobject]@{type='tcp-global';property='fastopen'})){throw 'Independent P2P policy falsely blocked by TCP'}
if(-not (Test-NetworkRegistryConflict $networkRule ([pscustomobject]@{type='maintenance';name='reset-network'}))){throw 'Reset-network overlap lost'}
if(Test-NativeTargetOverlap @('network|adapter|dns') @('network|adapter|mtu')){throw 'DNS and MTU exact targets collide'}
if(-not (Test-NativeTargetOverlap @('network|adapter') @('network|adapter|mtu'))){throw 'Legacy broad network lock lost'}
Write-Output 'PASS: independent network values and conservative legacy/reset conflicts.'
# 7.7.9: pure fsutil parser regressions; no system writes.
Assert-Equal (Convert-FsutilValue disable8dot3 'The registry state is: 2 (Per volume setting - the default).') 2 'fsutil colon'
Assert-Equal (Convert-FsutilValue mftzone 'mftzone = 1') 1 'fsutil equals'
Assert-Equal (Convert-FsutilValue DisableDeleteNotify "NTFS DisableDeleteNotify = 0 (Disabled)`nReFS DisableDeleteNotify = 1 (Enabled)") 0 'TRIM selects NTFS only'
foreach($raw in @('Access denied','state: 9',"state: 1`nother: 2")){
 $rejected=$false;try{Convert-FsutilValue disable8dot3 $raw | Out-Null}catch{$rejected=$true};if(-not $rejected){throw 'Ambiguous or invalid fsutil output accepted'}
}
Write-Output 'PASS: fsutil parsing regressions; unknown originals rejected.'

# Applicability check is read-only and never changes encryption.
function Get-BitLockerVolume { param($MountPoint)
 [pscustomobject]@{VolumeStatus='FullyDecrypted';ProtectionStatus='Off'} }
Assert-Equal (Get-NativeApplicability ([pscustomobject]@{type='bitlocker';drive='C:'})).applicable $false 'Unencrypted BitLocker volume is not applicable'
Remove-Item Function:\Get-BitLockerVolume
