'use strict';
const fs=require('node:fs');
const path=require('node:path');

// Resolve existing ancestors too: a not-yet-created directory under a junction
// must not place signing material inside the distributed project.
function canonicalPath(value){
 let current=path.resolve(value);
 const missing=[];
 for(;;){
  try{fs.lstatSync(current)}catch(error){
   if(error.code!=='ENOENT')throw error;
   const parent=path.dirname(current);
   if(parent===current)throw error;
   missing.unshift(path.basename(current));current=parent;continue;
  }
  return path.join(fs.realpathSync(current),...missing);
 }
}
function isInside(root,target){
 const relative=path.relative(root,target);
 return relative===''||(!path.isAbsolute(relative)&&relative!=='..'&&!relative.startsWith('..'+path.sep));
}
function externalPath(value,root){
 if(typeof value!=='string'||!value.trim())throw Error('Alege un director separat de proiect.');
 const full=path.resolve(value),actual=canonicalPath(full);
 if(isInside(path.resolve(root),full)||isInside(canonicalPath(root),actual))throw Error('Directorul cheilor private trebuie să fie în AFARA proiectului.');
 if(path.parse(actual).root===actual)throw Error('Nu folosi rădăcina discului drept director pentru cheia privată.');
 return actual;
}
module.exports={canonicalPath,externalPath};
