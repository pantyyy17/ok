# Safe self-test: touches ONLY a disposable directory under the current user's TEMP.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
. (Join-Path $PSScriptRoot '..\tweak-native-ops.ps1')

$root = Join-Path ([IO.Path]::GetTempPath()) ('CarpatiaCacheLockTest-' + ([guid]::NewGuid().ToString('N')))
$stream = $null
try {
 New-Item -ItemType Directory -Path $root -ErrorAction Stop | Out-Null
 $lockedPath = Join-Path $root 'locked-cache.bin'
 $stalePath = Join-Path $root 'stale-cache.bin'
 [IO.File]::WriteAllText($lockedPath, 'test file locked by another process')
 [IO.File]::WriteAllText($stalePath, 'test file eligible for cleanup')
 (Get-Item -LiteralPath $lockedPath).LastWriteTime = (Get-Date).AddHours(-3)
 (Get-Item -LiteralPath $stalePath).LastWriteTime = (Get-Date).AddHours(-3)
 $stream = [IO.File]::Open($lockedPath,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 $result = Remove-CacheFiles @($root)
 $result | ConvertTo-Json -Depth 5 | Write-Output
 if(-not $result.success){throw 'Test eșuat: operația a raportat erori reale.'}
 if($result.removed -ne 1){throw ('Test eșuat: fișiere șterse=' + $result.removed + ', așteptat 1.')}
 if($result.locked -ne 1){throw ('Test eșuat: fișiere blocate=' + $result.locked + ', așteptat 1.')}
 if(-not (Test-Path -LiteralPath $lockedPath)){throw 'Test eșuat: fișierul blocat nu trebuia șters.'}
 if(Test-Path -LiteralPath $stalePath){throw 'Test eșuat: fișierul eligibil nu a fost șters.'}
 Write-Host '[OK] CACHE LOCK: fișier blocat omis și fișier eligibil șters.'
 exit 0
}catch {
 Write-Error ('[FAIL] CACHE LOCK: ' + $_.Exception.Message)
 exit 1
}finally {
 if($null -ne $stream){$stream.Dispose()}
 if(Test-Path -LiteralPath $root){Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
}
