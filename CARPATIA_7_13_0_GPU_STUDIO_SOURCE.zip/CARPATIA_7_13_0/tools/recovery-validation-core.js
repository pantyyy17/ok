'use strict';
// Read-only verification helpers. No Windows commands or mutation engines run here.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const PURPOSE='CARPATIA disposable Windows recovery test';
function save(file,value){const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(value,null,2)+'\n');fs.renameSync(tmp,file)}
function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
 return value;
}
function assertSame(actual,expected,label){assert.deepEqual(canonical(actual),canonical(expected),label)}
function prepareWorkspace(directory,project,{resume=false}={}){
 directory=path.resolve(directory);project=fs.realpathSync(project);
 if(directory===path.parse(directory).root)throw Error('Use a dedicated test directory, never the drive root.');
 if(fs.existsSync(directory)){
  if(!fs.statSync(directory).isDirectory()||fs.lstatSync(directory).isSymbolicLink())throw Error('Test directory must be a real directory.');
  directory=fs.realpathSync(directory);
 }
 const relative=path.relative(project,directory),reverse=path.relative(directory,project);
 if(!relative||(!relative.startsWith('..'+path.sep)&&relative!=='..'&&!path.isAbsolute(relative))||!reverse||(!reverse.startsWith('..'+path.sep)&&reverse!=='..'&&!path.isAbsolute(reverse)))throw Error('Test directory must be outside the project and its ancestors.');
 const marker=path.join(directory,'carpatia-test-workspace.json');
 if(resume){
  if(!fs.existsSync(marker))throw Error('No owned test workspace. Do not use the application data directory.');
  const value=JSON.parse(fs.readFileSync(marker,'utf8'));
  if(value.version!==1||value.purpose!==PURPOSE||value.directory!==directory)throw Error('Test workspace marker does not match this directory.');
 }else{
  if(fs.existsSync(directory)&&fs.readdirSync(directory).length)throw Error('A fresh test requires an empty dedicated directory. Use --resume only for a saved restart test.');
  fs.mkdirSync(directory,{recursive:true});save(marker,{version:1,purpose:PURPOSE,directory,createdAt:new Date().toISOString()});
 }
 return directory;
}
async function captureBaseline(plan,check){
 const rows=[];
 for(const step of plan.steps){const result=await check(step.id,plan.adapterGuid);assert.equal(result.success,true,'Cannot read '+step.id);assert(Object.hasOwn(result,'current'),'Missing readback for '+step.id);rows.push({id:step.id,current:result.current,...(result.operation?{operation:result.operation}:{})})}
 return rows;
}
async function verifyBaseline(baseline,adapter,check){
 assert(Array.isArray(baseline)&&baseline.length,'No original baseline to verify.');
 for(const row of baseline){const result=await check(row.id,adapter);assert.equal(result.success,true,'Cannot read restored '+row.id);assert(Object.hasOwn(result,'current'),'Missing restored readback for '+row.id);assertSame(result.current,row.current,'Original state was not restored: '+row.id)}
 return baseline.length;
}
function originalRequests(directory,ids,catalog){
 const requests=[];
 for(const id of ids){
  const rule=catalog.find(row=>row.id===id);assert(rule&&['registry','native'].includes(rule.status),'Unknown test target '+id);
  const folder=rule.status==='registry'?'tweak-library-backups':'tweak-native-backups';
  const journal=JSON.parse(fs.readFileSync(path.join(directory,folder,id+'.json'),'utf8'));
  assert.equal(journal.version,1,'Invalid original for '+id);assert.equal(journal.id,id);assert.equal(journal.state,'restored','Original not marked restored: '+id);
  if(rule.status==='registry'){
   assert(Array.isArray(journal.values)&&journal.values.length===rule.entries.length,'Incomplete original '+id);
   for(let index=0;index<rule.entries.length;index++){
    const entry=rule.entries[index],rows=journal.values.filter(value=>typeof value.path==='string'&&typeof value.name==='string'&&value.path.toLowerCase()===entry.path.toLowerCase()&&value.name.toLowerCase()===entry.name.toLowerCase());
    assert.equal(rows.length,1,'Ambiguous original '+id);requests.push({id,kind:'registry',index,target:rows[0]});
   }
  }else{
   assert(journal.operation&&Object.hasOwn(journal,'before'),'Incomplete native original '+id);
   requests.push({id,kind:'native',operation:journal.operation,target:journal.before});
  }
 }
 return requests;
}
async function verifyOriginals(directory,ids,catalog,probe){
 const requests=originalRequests(directory,ids,catalog);
 for(const request of requests){const result=await probe(request);assert.equal(result.success,true,'Cannot probe original '+request.id);assert(Object.hasOwn(result,'current'),'Missing original readback '+request.id);assertSame(result.current,request.target,'Saved target differs after restore: '+request.id)}
 return requests.length;
}
function assertRestart(evidence,current,group){
 assert(evidence&&evidence.version===1&&evidence.phase==='awaiting-restart','No pending restart test in this directory.');
 assert(['cpu','gpu','internet'].includes(evidence.group),'Invalid restart group.');
 if(group)assert.equal(group,evidence.group,'Selected group differs from the saved restart test.');
 assert.equal(current.identity,evidence.identity,'This test belongs to another Windows installation or user.');
 assert(typeof evidence.bootUtc==='string'&&Number.isFinite(Date.parse(evidence.bootUtc))&&typeof current.bootUtc==='string'&&Number.isFinite(Date.parse(current.bootUtc)),'Cannot establish Windows boot time.');
 assert(Date.parse(current.bootUtc)>Date.parse(evidence.bootUtc),'Windows has not restarted since apply. Restart the VM manually, then use --resume.');
 assert(Array.isArray(evidence.baseline)&&evidence.baseline.length&&Array.isArray(evidence.changedIds)&&evidence.changedIds.length,'No changed settings and baseline saved for restart validation.');
}
module.exports={save,canonical,assertSame,prepareWorkspace,captureBaseline,verifyBaseline,originalRequests,verifyOriginals,assertRestart};
