'use strict';
const csrf=document.querySelector('meta[name="carpatia-token"]').content;
const $=id=>document.getElementById(id);
const feedback=message=>$('feedback').textContent=message;
let currentStatus=null;
for(const id of ['init','configure','issue'])$(id).disabled=true;
async function post(route,payload={}){
 const res=await fetch('/api/'+route,{method:'POST',headers:{'Content-Type':'application/json','X-Carpatia-Token':csrf},body:JSON.stringify(payload)});
 const parsed=await res.json();if(!res.ok||!parsed.ok)throw Error(parsed.error||'Cererea a eșuat.');return parsed.result;
}
async function refresh(){
 const r=await post('status');currentStatus=r;$('privateDirectory').textContent=r.privateDir;$('publisherFile').textContent=r.publisherFile;$('keyState').textContent=r.error?'EROARE: '+r.error:r.partial?'Chei incomplete — verifică folderul înainte de continuare.':r.ready?'Cheile Ed25519 există și corespund. Păstrează această pereche pentru toate vânzările.':'Nu au fost generate încă chei. Dacă ai emis deja licențe, restaurează perechea originală în acest folder.';
 $('init').disabled=r.ready||r.partial||!!r.error;
 $('configure').disabled=!r.ready||['mismatch','invalid'].includes(r.build.state);$('issue').disabled=!r.buildReady;
 $('buildState').textContent=r.build.message;$('publicDetails').classList.toggle('hidden',!r.publicKey);$('publicKey').value=r.publicKey||'';$('fingerprint').value=r.fingerprint||'';
 $('count').textContent='('+r.issuedCount+')';const history=$('history');history.replaceChildren();
 for(const entry of r.records){const row=document.createElement('div');row.className='history-row';const name=document.createElement('strong');name.textContent=entry.customer;const detail=document.createElement('small');detail.textContent=entry.id+' · '+(entry.expiresAt?'Expiră '+entry.expiresAt.slice(0,10):'Permanentă');row.append(name,detail);history.append(row)}
 if(!r.records.length)history.textContent='Nu există licențe emise.';
}
async function act(name,fn){try{feedback('Se procesează…');const message=await fn();feedback(message||name+' — reușit.')}catch(e){feedback('EROARE: '+e.message)}}
$('init').onclick=()=>act('Cheile editorului',async()=>{if(!confirm('Prima lansare: creezi perechea originală de chei pe acest PC, în '+currentStatus.privateDir+'? Dacă ai emis deja licențe, anulează și restaurează cheia originală. Fă apoi un backup criptat separat.'))return 'Crearea cheilor a fost anulată.';await post('init');await refresh();return 'Cheile au fost create. Fă un backup criptat al folderului privat, apoi copiază NUMAI cheia publică în proiect.'});
$('configure').onclick=()=>act('Cheia publică',async()=>{const r=await post('configure');await refresh();return r.message});
$('issue').onclick=()=>act('Licență nouă',async()=>{const duration=$('duration').value;const r=await post('issue',{customer:$('customer').value,days:duration==='permanent'?null:Number(duration)});$('generated').classList.remove('hidden');$('generatedTitle').textContent=r.id+' · '+(r.expiresAt?'Valabilă până la '+r.expiresAt.slice(0,10):'Permanentă');$('licenseOutput').value=r.code;await refresh()});
$('copy').onclick=()=>act('Cod copiat',async()=>{await navigator.clipboard.writeText($('licenseOutput').value)});
$('copyPublic').onclick=()=>act('Cheie publică copiată',async()=>{await navigator.clipboard.writeText($('publicKey').value)});
$('downloadPublic').onclick=()=>act('Cheie publică exportată',async()=>{const url=URL.createObjectURL(new Blob([$('publicKey').value],{type:'application/x-pem-file'}));const link=document.createElement('a');link.href=url;link.download='carpatia-public.pem';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});
refresh().catch(e=>feedback('Nu pot citi datele: '+e.message));
