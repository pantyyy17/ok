'use strict';
const fs=require('node:fs'),path=require('node:path');
const {publisherKey}=require('../licensing');
const file=path.join(__dirname,'..','license-public.pem');
if(!fs.existsSync(file)){
 console.error('[BUILD BLOCAT] Lipsește license-public.pem. Pentru prima lansare, creează cheile pe PC-ul tău cu LICENTA_MANAGER.bat și copiază numai cheia publică în proiect. Pentru o ediție existentă, păstrează cheia originală. Vezi LICENTIERE.md.');
 process.exit(1);
}
try{publisherKey(fs.readFileSync(file,'utf8'));console.log('[OK] Cheie publică Ed25519 pregătită pentru build; cheia privată rămâne separată.');}
catch(error){console.error('[BUILD BLOCAT] Cheia publică invalidă:',error.message);process.exit(1);}
