# Read-only integration check against the real Windows power API. No settings changed.
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
. (Join-Path $project 'tweak-native-ops.ps1')
$scheme=Get-ActivePower
$subgroup='54533251-82be-4824-96c1-47b60b740d00'
$settings=@(
 @{name='Minimum CPU AC';guid='893dee8e-2bef-41e0-89c6-b55d0929964c'},
 @{name='Maximum CPU AC';guid='bc5038f7-23e0-4960-96da-33abaf5935ec'},
 @{name='Boost Mode AC (hidden)';guid='be337238-0d82-4146-a960-4f3749d470c7'}
)
$rows=@();$failed=$false
foreach($setting in $settings){
 try{
  $value=Read-PowerACIndex -Scheme ([guid]$scheme) -Subgroup ([guid]$subgroup) -Setting ([guid]$setting.guid)
  $rows+=('PASS: '+$setting.name+' = '+$value+'; plan '+$scheme)
 }catch{$failed=$true;$rows+=('FAIL: '+$setting.name+'; '+$_.Exception.Message)}
}
$report=Join-Path $project 'POWER_READ_REPORT.txt'
$rows | Set-Content -LiteralPath $report -Encoding UTF8
$rows | Write-Output
Write-Output ('Raport: '+$report+'. Nicio setare Windows modificata.')
if($failed){exit 1}
