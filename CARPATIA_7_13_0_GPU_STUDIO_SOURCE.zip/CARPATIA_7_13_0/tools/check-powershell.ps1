# Syntax validation only: never executes the inspected scripts or changes Windows.
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$Root=(Resolve-Path -LiteralPath $Root).Path
$files=@(Get-ChildItem -LiteralPath $Root -Filter '*.ps1' -File)
foreach($folder in @('tools','tests')){
 $dir=Join-Path $Root $folder
 if(Test-Path -LiteralPath $dir){$files+=@(Get-ChildItem -LiteralPath $dir -Filter '*.ps1' -File)}
}
$failures=@()
foreach($file in $files){
 $tokens=$null;$errors=$null
 $null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 foreach($error in @($errors)){$failures+=@{file=$file.Name;line=$error.Extent.StartLineNumber;message=$error.Message}}
}
@{success=($failures.Count -eq 0);files=$files.Count;errors=@($failures);runtime=$PSVersionTable.PSVersion.ToString()}|ConvertTo-Json -Depth 8 -Compress
if($failures.Count){exit 1}
