'use strict';
// Explicit real-Windows test for a disposable VM with checkpoint and console access.
// Never imported or automatically executed by npm test. Never reboots Windows.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {parseArgs}=require('node:util');
const {createWindowsRunner}=require('../windows-process');
const {createProfileService,descriptor}=require('../dashboard-profiles');
const catalog=require('../tweak-library.json');
const {save,prepareWorkspace,captureBaseline,verifyBaseline,verifyOriginals,assertRestart}=require('./recovery-validation-core');
const {values}=parseArgs({options:{help:{type:'boolean'},'vm-test':{type:'boolean'},adapter:{type:'string'},'data-dir':{type:'string'},group:{type:'string'},level:{type:'string'},resume:{type:'boolean'},'hold-for-restart':{type:'boolean'}}});
if(values.help){console.log('Disposable Windows VM only. --vm-test --data-dir EMPTY_EXTERNAL_DIR [--group cpu|gpu|internet] [--level low|medium|high|ultra] [--adapter GUID]. For restart: select one --group, add --hold-for-restart, restart manually, then use the same --data-dir with --resume.');process.exit(0)}
if(process.platform!=='win32'||!values['vm-test']){console.error('NOT RUN: requires Windows VM and explicit --vm-test. No native test was performed.');process.exit(2)}
const project=path.resolve(__dirname,'..');
let directory,record=()=>{};
(async()=>{
 if(!values['data-dir']?.trim())throw Error('Supply an empty dedicated persistent --data-dir outside the project.');
 if(values.group&&!['cpu','gpu','internet'].includes(values.group))throw Error('Unknown --group; use cpu, gpu or internet.');
 const level=values.level||'low';if(!['low','medium','high','ultra'].includes(level))throw Error('Unknown --level.');
 if(values.resume&&values['hold-for-restart'])throw Error('--resume and --hold-for-restart are mutually exclusive.');
 if(values['hold-for-restart']&&!values.group)throw Error('--hold-for-restart requires one explicit --group. Test each group separately.');
 const adapter=values.adapter||'';
 if(!values.resume&&(!values.group||values.group==='internet')&&!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(adapter))throw Error('Supply the explicit --adapter GUID for Internet testing.');
 const run=createWindowsRunner();
 const ps=(file,...params)=>run(['-File',path.join(project,file),...params],180000);
 const admin=await ps('permissions.ps1');assert.equal(admin.admin,true,'Administrator required');
 directory=prepareWorkspace(values['data-dir'],project,{resume:!!values.resume});
 const report=path.join(directory,'windows-test-report.json');
 const log=values.resume?JSON.parse(fs.readFileSync(report,'utf8')):[];assert(Array.isArray(log),'Invalid existing report; preserve it for diagnosis.');
 record=(scenario,result)=>{log.push({date:new Date().toISOString(),scenario,result});save(report,log)};
 const evidenceFile=path.join(directory,'windows-test-evidence.json');
 const boot=await ps('tools/recovery-validation-probe.ps1'),identity=await ps('snapshot-engine.ps1','-Action','Identity');
 assert.equal(boot.success,true);assert.equal(identity.success,true);
 const machine={identity:identity.identity,bootUtc:boot.bootUtc};
 const op=(id,action,guid='')=>{const row=catalog.find(item=>item.id===id);assert(row,'Unknown test setting');return ps(row.status==='registry'?'tweak-library.ps1':'tweak-native.ps1','-Action',action,'-Id',id,'-DataDir',directory,...(row.status==='native'?['-AdapterGuid',guid]:[]))};
 const store={read:group=>{const file=path.join(directory,group+'.json');return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null},write:(group,value)=>save(path.join(directory,group+'.json'),value)};
 const ops={snapshot:()=>ps('inspect.ps1'),status:async()=>{const rows=await Promise.all(['tweak-library.ps1','tweak-native.ps1'].map(file=>ps(file,'-Action','Status','-DataDir',directory)));return {success:rows.every(row=>row.success),states:rows.flatMap(row=>row.states||[])}},check:(id,guid)=>op(id,'Check',guid),apply:(id,guid)=>op(id,'Apply',guid),restore:id=>op(id,'Restore')};
 const probe=async request=>{const file=path.join(directory,'probe-'+crypto.randomUUID()+'.json');save(file,request);try{return await ps('snapshot-engine.ps1','-Action','Probe','-RequestFile',file)}finally{fs.rmSync(file,{force:true})}};
 async function restoreAndVerify(evidence,{afterRestart=false}={}){
  const service=createProfileService({store,ops}),state=service.status().find(row=>row.group===evidence.group);
  assert(state&&state.recoverable!==false,'Saved profile is not recoverable.');
  const restored=await service.restore(evidence.group);record('restore '+evidence.group,restored);assert.equal(restored.success,true,'Profile restoration failed; preserve this test directory.');
  const checked=await verifyBaseline(evidence.baseline,evidence.adapter,ops.check);
  // Probe saved operations directly too: CPU changes a power plan, so its saved
  // power-value target can differ from the active plan used by Check after restore.
  const originals=await verifyOriginals(directory,evidence.changedIds,catalog,probe);
  assert.equal(createProfileService({store,ops}).status().find(row=>row.group===evidence.group).active,false);
  record(afterRestart?'VERIFIED restore after actual Windows restart':'VERIFIED restore after service reopen',{group:evidence.group,baselineSettings:checked,savedTargets:originals,bootBefore:evidence.bootUtc,bootAfter:machine.bootUtc});
 }
 if(values.resume){
  const evidence=JSON.parse(fs.readFileSync(evidenceFile,'utf8'));assertRestart(evidence,machine,values.group);
  await restoreAndVerify(evidence,{afterRestart:true});save(evidenceFile,{...evidence,phase:'verified-after-restart',verifiedAt:new Date().toISOString(),resumedBootUtc:machine.bootUtc});
  console.log('PASS: actual Windows restart confirmed; saved originals and baseline independently reread. Report: '+report);return;
 }
 let verified=0,notApplicable=0;
 for(const group of values.group?[values.group]:['cpu','gpu','internet']){
  for(let cycle=0;cycle<2;cycle++){
   const service=createProfileService({store,ops}),prepared=await service.prepare({group,level,adapterGuid:adapter});
   const plan=prepared.plan,baseline=await captureBaseline(plan,ops.check);
   let evidence={version:1,phase:'applying',group,level,adapter:plan.adapterGuid,cycle,...machine,baseline,skipped:plan.skipped||[],changedIds:[],applicationVersion:require('../package.json').version};save(evidenceFile,evidence);
   const applied=await service.commit(prepared.token);
   record(group+' '+level+' apply '+cycle,applied);assert.equal(applied.success,true,'Apply failed; preserve the directory for recovery.');
   const changedIds=applied.results.filter(row=>!row.already).map(row=>row.id);
   if(applied.already||!changedIds.length){notApplicable++;save(evidenceFile,{...evidence,phase:'not-applicable'});record('NOT APPLICABLE: '+group,{message:'All requested values already existed; no restoration or restart claim.'});if(values['hold-for-restart']){process.exitCode=2;console.error('NOT APPLICABLE: no changed profile to hold for restart.');return}continue}
   for(const step of plan.steps){const current=await ops.check(step.id,plan.adapterGuid);assert.equal(current.success,true);assert.equal(current.matching,true,'Applied value not independently confirmed: '+step.id)}
   evidence={...evidence,phase:values['hold-for-restart']?'awaiting-restart':'applied',changedIds};save(evidenceFile,evidence);
   if(values['hold-for-restart']){record('PENDING actual Windows restart',{group,bootUtc:machine.bootUtc});console.log('PENDING: restart the VM manually, then use the same --data-dir with --vm-test --resume. This is not a completed restart test.');return}
   await restoreAndVerify(evidence);verified++;save(evidenceFile,{...evidence,phase:'verified',verifiedAt:new Date().toISOString()});
  }
 }
 if(!verified){process.exitCode=2;console.error('NOT APPLICABLE: no profile changed; no native restore claim.');return}
 record('COMPLETED',{verifiedCycles:verified,notApplicable,restartTested:false});console.log('PASS: '+verified+' apply/restore cycles independently verified. OS restart was not tested in this run. Report: '+report);
})().catch(error=>{try{record('FAILED',{message:error.message})}catch{}console.error(error.message);process.exitCode=1});
