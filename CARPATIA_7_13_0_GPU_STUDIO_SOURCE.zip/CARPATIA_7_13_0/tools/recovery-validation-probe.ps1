# Read-only boot evidence for the explicitly invoked disposable-VM runner.
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$os=Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop | Select-Object -First 1
if($null -eq $os -or $os.LastBootUpTime -isnot [DateTime]){throw 'Windows boot time could not be read.'}
@{success=$true;bootUtc=$os.LastBootUpTime.ToUniversalTime().ToString('o')} | ConvertTo-Json -Compress
