﻿# Real Windows Registry integration test, isolated from production backups/settings.
# Writes only a fresh HKCU\Software\CarpatiaIntegrationTest_<GUID> key.
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$token=[guid]::NewGuid().ToString('N')
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('CarpatiaIntegration-'+$token)
$keyPath='HKCU:\Software\CarpatiaIntegrationTest_'+$token
$oldLocalData=$env:LOCALAPPDATA
$report=Join-Path $project ('REGISTRY_TEST_'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.txt')
$lines=New-Object 'System.Collections.Generic.List[string]'
try{
 New-Item -ItemType Directory -Path $testRoot | Out-Null
 foreach($name in @('engine.ps1','registry-values.ps1')){Copy-Item -LiteralPath (Join-Path $project $name) -Destination $testRoot}
 . (Join-Path $project 'registry-values.ps1')
 $catalog=Get-Content -LiteralPath (Join-Path $project 'tweaks.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 # Keep the exact 59-rule schema, replace targets with a test-only Registry subtree.
 foreach($rule in $catalog){foreach($entry in $rule.entries){$entry.path=$keyPath}}
 $rule=$catalog[0];$rule | Add-Member -NotePropertyName restoreOnly -NotePropertyValue $false -Force
 $cases=@(
  @{name='String';kind='String';value='original'},
  @{name='Expand';kind='ExpandString';value='%TEMP%\CarpatiaOriginal'},
  @{name='Dword';kind='DWord';value=4294967295},
  @{name='Qword';kind='QWord';value=1234567890123},
  @{name='Binary';kind='Binary';value=@(0,1,127,255)},
  @{name='Multi';kind='MultiString';value=@('first','second')},
  @{name='Missing';kind=$null;value=$null}
 )
 $sentinel=@{path=$keyPath.Replace('HKCU:\','HKCU\');name='Unrelated';kind='String';value='must survive';exists=$true}
 Set-Value $sentinel
 $entries=@();$originals=@()
 foreach($case in $cases){
  $row=@{path=$keyPath.Replace('HKCU:\','HKCU\');name=$case.name;kind=$case.kind;value=$case.value;exists=($case.name -ne 'Missing')}
  Set-Value $row
  $originals+=Read-Value $row
  $entries+=@{path=$keyPath;name=$case.name;type='String';value='temporary tweak'}
 }
 $rule.entries=$entries
 $catalog | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $testRoot 'tweaks.json') -Encoding UTF8
 $env:LOCALAPPDATA=$testRoot
 $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 function Engine($action){
  $output=& $ps -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $testRoot 'engine.ps1') -Action $action -Ids $rule.id 2>&1
  if($LASTEXITCODE -ne 0){throw ($output | Out-String)}
  $result=($output | Out-String) | ConvertFrom-Json
  if(-not $result.success){throw ($result | ConvertTo-Json -Depth 8)}
  return $result
 }
 $null=Engine 'Apply'
 foreach($row in $originals){$actual=Read-Value $row;if($actual.value -cne 'temporary tweak' -or $actual.kind -ne 'String'){throw ('Apply readback failed: '+$row.name)}}
 if(-not (Same-Value (Read-Value $sentinel) $sentinel)){throw 'Unrelated Registry value was modified'}
 $lines.Add('PASS: real Apply changed all 7 isolated values.')
 $backup=Join-Path $testRoot 'TweakRomania\Backups\ultra-latest.json'
 $before=[IO.File]::ReadAllBytes($backup)
 $null=Engine 'Restore'
 foreach($row in $originals){if(-not (Same-Value (Read-Value $row) $row)){throw ('Restore readback failed: '+$row.name)}}
 $lines.Add('PASS: Restore preserved raw types, arrays, unsigned DWORD and originally absent value.')
 if((Engine 'Status').backup){throw 'Backup still active after successful restore'}
 $archived=@(Get-ChildItem -LiteralPath (Split-Path $backup) -Filter 'ultra-restored-*.json')
 if($archived.Count -ne 1 -or [Convert]::ToBase64String([IO.File]::ReadAllBytes($archived[0].FullName)) -cne [Convert]::ToBase64String($before)){throw 'Original backup archive differs'}
 $lines.Add('PASS: original backup archived byte-for-byte; active backup cleared only after verification.')
 $lines.Add('This test does NOT validate CPU/GPU/network profiles, drivers or performance gains.')
}catch{
 $lines.Add('FAIL: '+$_.Exception.Message)
 throw
}finally{
 $env:LOCALAPPDATA=$oldLocalData
 if(Test-Path -LiteralPath $keyPath){Remove-Item -LiteralPath $keyPath -Recurse -Force}
 if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}
 $lines | Set-Content -LiteralPath $report -Encoding UTF8
 $lines | Write-Output
 Write-Output ('Report: '+$report)
}
