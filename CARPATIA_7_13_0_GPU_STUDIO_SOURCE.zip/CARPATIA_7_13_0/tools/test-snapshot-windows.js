'use strict';
// REAL WINDOWS test. Disposable VM only; never automatically runs during npm test.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {createWindowsRunner}=require('../windows-process'),{createSnapshotService,hash}=require('../snapshot-core');
const {parseArgs}=require('node:util');
const {values}=parseArgs({options:{'vm-test':{type:'boolean'},'data-dir':{type:'string'},resume:{type:'boolean'},'hold-for-restart':{type:'boolean'}}});
if(process.platform!=='win32'||!values['vm-test']){console.error('NOT RUN: Windows VM and --vm-test required.');process.exit(2)}
if(!values['data-dir']?.trim())throw Error('Dedicated --data-dir required.');
if(values.resume&&values['hold-for-restart'])throw Error('--resume and --hold-for-restart are mutually exclusive.');
const dir=path.resolve(values['data-dir']);fs.mkdirSync(dir,{recursive:true});
const run=createWindowsRunner(),project=path.resolve(__dirname,'..'),ps=(file,...params)=>run(['-File',path.join(project,file),...params],180000);
const save=(file,value)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file+'.tmp',JSON.stringify(value));fs.renameSync(file+'.tmp',file)};
const operation=async(row,action)=>{const file=path.join(dir,'request-'+crypto.randomUUID()+'.json');save(file,row);try{return await ps('snapshot-engine.ps1','-Action',action,'-RequestFile',file)}finally{fs.rmSync(file,{force:true})}};
const id='library-cpu-005',native=action=>ps('tweak-library.ps1','-Action',action,'-Id',id,'-DataDir',dir);
const identity=async()=>{const r=await ps('snapshot-engine.ps1','-Action','Identity');assert.equal(r.success,true);return r.identity};
const service=createSnapshotService({dataDir:()=>dir,probe:r=>operation(r,'Probe'),write:r=>operation(r,'Write'),identity,assertClear:async()=>{const s=await native('Status');assert.equal(s.success,true);assert.ok(!s.states.some(x=>['prepared','applied','failed'].includes(x.state)),'Restore active originals first');},save});
(async()=>{
 if(values.resume){const t=service.transactions().toSorted((a,b)=>String(a.date).localeCompare(String(b.date))).at(-1);if(!t)throw Error('No saved transaction.');const undo=await service.resume(t.id,true);assert.equal(undo.success,true);save(path.join(dir,'snapshot-windows-undo-after-restart.json'),{scenario:'undo after actual restart',...undo});return}
 const applied=await native('Apply');assert.equal(applied.success,true);if(applied.already){console.log('NOT APPLICABLE: selected value already set; no test claimed.');process.exitCode=2;return}
 const captured=await native('Check');assert.equal(captured.success,true);
 const snapshotId=crypto.randomUUID(),root=path.join(dir,'recovery-snapshots',snapshotId),name=id+'.json';save(path.join(root,name),{id,...captured});save(path.join(root,'manifest.json'),{id:snapshotId,version:2,identity:await identity(),complete:true,files:[{name,sha256:hash(fs.readFileSync(path.join(root,name),'utf8'))}]});
 const original=await native('Restore');assert.equal(original.success,true);
 const plan=await service.prepare(snapshotId),restored=await service.commit(plan.token);assert.equal(restored.success,true);assert.equal((await native('Check')).matching,true);save(path.join(dir,'snapshot-windows-result.json'),restored);
 if(values['hold-for-restart']){console.log('Restart Windows manually, then run with same --data-dir and --resume.');return}
 const undone=await service.resume(restored.id,true);assert.equal(undone.success,true);save(path.join(dir,'snapshot-windows-undo.json'),undone);console.log('PASS: actual snapshot write, readback and undo completed.');
})().catch(e=>{save(path.join(dir,'snapshot-windows-error.json'),{success:false,message:e.message});console.error(e);process.exitCode=1});
