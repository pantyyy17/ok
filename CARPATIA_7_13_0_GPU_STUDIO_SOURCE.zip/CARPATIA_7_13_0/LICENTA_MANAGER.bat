@echo off
setlocal
cd /d "%~dp0"
title CARPATIA LICENSE MANAGER - DOAR EDITORUL
where node.exe >nul 2>&1
if errorlevel 1 (echo [EROARE] Instaleaza Node.js 24 sau mai nou. & pause & exit /b 1)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (echo [EROARE] Este necesar Node.js 24 sau mai nou. & pause & exit /b 1)
echo.
echo IMPORTANT: NU folosi folderul programului pentru cheia PRIVATA.
echo Alege un folder sigur, de exemplu C:\CARPATIA_PRIVATE.
echo Recomandat: stocare criptata, cu backup intr-un loc separat.
echo.
set "PRIVATE_DIR=%USERPROFILE%\CARPATIA_PRIVATE"
set /p "PRIVATE_DIR=Folder chei private [implicit %USERPROFILE%\CARPATIA_PRIVATE]: "
if "%PRIVATE_DIR%"=="" set "PRIVATE_DIR=%USERPROFILE%\CARPATIA_PRIVATE"
node tools\license-manager.js --private-dir "%PRIVATE_DIR%"
if errorlevel 1 (echo [EROARE] Managerul nu a pornit. & pause & exit /b 1)
pause
endlocal
