@echo off
setlocal
cd /d "%~dp0"
title CARPATIA V7 PRO RUBY REDLINE
where node.exe >nul 2>&1
if errorlevel 1 (
 echo [EROARE] Node.js 24 sau mai nou nu este instalat sau nu este in PATH.
 echo Instaleaza Node.js 24 sau mai nou de la https://nodejs.org apoi ruleaza din nou.
 pause
 exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (echo [EROARE] Este necesar Node.js 24 sau mai nou. & pause & exit /b 1)
if not exist "node_modules\electron\cli.js" (
 echo [CARPATIA] Instalez dependentele aplicatiei. Doar la prima pornire...
 call npm ci --no-audit --no-fund
 if errorlevel 1 (
  echo [EROARE] npm ci a esuat. Verifica conexiunea si drepturile pentru acest folder.
  pause
  exit /b 1
 )
)
echo [CARPATIA] Cer administrator prin UAC. Acesta este dialogul oficial Windows.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LAUNCH_ADMIN.ps1"
if errorlevel 1 (
 echo [EROARE] CARPATIA nu a putut porni sau cererea UAC a fost anulata.
 pause
 exit /b 1
)
endlocal
