'use strict';
// Pure, deterministic recommendation engine. All changes are applied by the existing allowlisted engine.ps1.
const {maxPlan}=require('./ultra-max');
const APPROVED={
 // Gaming: impact can be measurable, but depends on OS and what is already running.
 game_mode:{condition:()=>true,kind:'recommended',reason:'Game Mode este functia oficiala Windows dedicata jocurilor.',benefit:'Poate reduce interferentele proceselor de fundal; FPS neconfirmat.'},
 game_dvr:{condition:()=>true,kind:'review',reason:'Captura Game DVR poate avea un cost in timpul jocului; opreste si inregistrarea din fundal.',benefit:'Posibil cost de capturare redus, dar pierzi inregistrarea Game Bar.'},
 gamebar_history:{condition:()=>true,kind:'review',reason:'Dezactiveaza capturarea retroactiva a gameplay-ului daca nu o utilizezi.',benefit:'Poate reduce activitatea de capturare; nu promite FPS.'},
 gamebar_tips:{condition:()=>true,kind:'recommended',reason:'Ascunde indicatiile de pornire Game Bar.',benefit:'Mai putine intreruperi vizuale; nu creste FPS.'},
 gamebar_controller:{condition:()=>true,kind:'recommended',reason:'Previne deschiderea Game Bar din butonul controllerului.',benefit:'Evita pornirea accidentala a overlay-ului.'},
 // Desktop: these are deliberately described as desktop/UI, never as direct gaming FPS fixes.
 transparency:{condition:()=>true,kind:'recommended',reason:'Reduce efectele de transparenta folosite de desktop.',benefit:'Poate reduce activitatea grafica pe desktop; nu FPS in joc.'},
 taskbar_anim:{condition:()=>true,kind:'recommended',reason:'Reduce animatiile barei de activitati.',benefit:'Desktop mai receptiv; nu FPS in joc.'},
 minanimate:{condition:()=>true,kind:'recommended',reason:'Elimina o parte din animatiile ferestrelor.',benefit:'Tranzitii vizuale mai rapide; nu FPS in joc.'},
 menu_delay:{condition:()=>true,kind:'recommended',reason:'Reduce intarzierea de deschidere a meniurilor.',benefit:'Meniuri Windows mai rapide; nu ping sau FPS.'},
 widgets:{condition:h=>h.osBuild>=22000,kind:'recommended',reason:'Ascunde Widgets din bara de activitati Windows 11.',benefit:'Interfata mai curata; fara FPS garantat.'},
 // Background and suggestions: reduces Windows recommendations, not game-engine load.
 consumer_feat:{condition:()=>true,kind:'recommended',reason:'Limiteaza instalarea automata a aplicatiilor consumer sugerate.',benefit:'Mai putine recomandari si instalari viitoare.'},
 softlanding:{condition:()=>true,kind:'recommended',reason:'Reduce sfaturile si pop-upurile introductive Windows.',benefit:'Mai putine notificari inutile.'},
 content_suggestions:{condition:()=>true,kind:'recommended',reason:'Reduce sugestiile de continut promovate in Windows.',benefit:'Mai putine sugestii in fundal; FPS neconfirmat.'},
 start_recom:{condition:()=>true,kind:'recommended',reason:'Ascunde recomandarile de documente recente din Start.',benefit:'Mai putin continut sugerat; nu FPS.'},
 act_history:{condition:()=>true,kind:'recommended',reason:'Reduce experientele personalizate Windows.',benefit:'Mai putine recomandari contextuale; nu FPS.'},
 search_highlights:{condition:()=>true,kind:'recommended',reason:'Dezactiveaza continutul Search Highlights.',benefit:'Cautare Windows mai simpla; nu FPS.'},
 explorer_sync_ads:{condition:()=>true,kind:'recommended',reason:'Opreste recomandarile promovate in File Explorer.',benefit:'Mai putin continut promotional; nu FPS.'},
 ctt_ads_id:{condition:()=>true,kind:'recommended',reason:'Dezactiveaza identificatorul publicitar pentru aplicatii.',benefit:'Control asupra confidentialitatii, nu FPS.'},
 // Riskier operations stay opt-in.
 bg_apps:{condition:()=>true,kind:'review',reason:'Restrictioneaza aplicatiile UWP in fundal si poate opri sincronizarea/notificarile.',benefit:'Pot scadea activitatile din fundal, dar anumite aplicatii pot fi afectate.'},
 visual_fx:{condition:h=>h.ramGB<=12||h.integrated,kind:'review',reason:'Elimina efecte Windows, cu impact vizibil asupra interfetei.',benefit:'Poate ajuta sisteme vechi sau cu grafica integrata; nu neaparat FPS.'},
 mouse_accel:{condition:()=>true,kind:'review',reason:'Dezactiveaza accelerarea Windows pentru cursor, dar unele jocuri folosesc Raw Input.',benefit:'Schimba senzatia mouse-ului in desktop; nu reduce automat input lag-ul.'}
};
const HIGH='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';
function plan(snapshot,catalog){
 const hw=snapshot.hardware||{};
 const gpu=Array.isArray(hw.gpu)?hw.gpu.filter(x=>typeof x==='string'):[];
 const ramGB=Number(hw.ramGB)||0;
 const osBuild=Number(hw.osBuild)||0;
 const integrated=gpu.length>0&&gpu.every(g=>/intel\s+(uhd|hd graphics|iris)|amd radeon\(tm\) graphics|radeon\s+graphics/i.test(g));
 const h={ramGB,osBuild,integrated,gpu};
 const registryValid=snapshot.registry?.success===true&&Array.isArray(snapshot.registry.matchingIds)&&typeof snapshot.registry.backup==='boolean';
 const matching=new Set(registryValid?snapshot.registry.matchingIds:[]);
 const catalogIds=new Set(catalog.filter(t=>!t.restoreOnly).map(t=>t.id));
 const suggestions=[];
 for(const [id,rule] of Object.entries(APPROVED)){
  if(osBuild<10240)continue; // Fail closed on unsupported / unidentified Windows builds.
  if(!catalogIds.has(id))continue;
  if(!rule.condition(h))continue;
  const entry=catalog.find(x=>x.id===id);
  const current=matching.has(id);
  const review=rule.kind==='review'||entry?.risk==='medium';
  suggestions.push({id,title:entry.title,risk:entry.risk||'low',category:entry.category,decision:current?'already':review?'review':'recommended',reason:current?'Valoarea dorită este deja prezentă în Registry.':rule.reason,benefit:rule.benefit,focus:id==='game_mode'||id.startsWith('gamebar_')||id==='game_dvr'?'gaming':id==='bg_apps'||id==='consumer_feat'?'fundal':'desktop',checked:!current&&!review});
 }
 const power=snapshot.power||null;
 const hasBattery=hw.hasBattery===true;
 const powerActive=typeof power?.active==='string'&&power.active.toLowerCase()===HIGH;
 const powerAdvice=power?.backup?'Există deja un backup de alimentare; nu vom crea unul nou.':hasBattery?'Laptop detectat: High Performance nu este propus automat (consum și temperaturi).':powerActive?'Planul High Performance este deja activ.':!power?.active?'Nu s-a putut citi planul de alimentare.':'Planul High Performance rămâne opțional; poate crește consumul și temperaturile.';
 const powerSuggested=!!power?.active&&!power?.backup&&!hasBattery&&!powerActive;
 const max=maxPlan(snapshot,catalog);
 const warnings=[];
 if(osBuild<10240)warnings.push('Versiunea Windows nu a fost confirmată ca Windows 10/11.');
 if(!ramGB)warnings.push('RAM nedetectată: recomandările de memorie sunt limitate.');
 if(gpu.length===0)warnings.push('GPU nedetectat: nu se fac recomandări specifice plăcii video.');
 if(!snapshot.registry)warnings.push('Starea Registry nu a putut fi citită: verifică manual setările deja active.');
 if(!snapshot.power)warnings.push('Planul de alimentare nu a putut fi verificat.');
 if(snapshot.registry?.backup)warnings.push('Există un backup ULTRA nerestaurat: aplicarea unui nou profil este blocată până la restaurare.');
 return {detectedAt:hw.detectedAt||new Date().toISOString(),hardware:{...hw,integrated},suggestions,maxSuggestions:max.suggestions,maxInfo:{selectableCount:max.selectableCount,mediumCount:max.mediumCount,excludedCount:max.excludedCount,reason:max.reason},
  recommendedCount:suggestions.filter(x=>x.checked).length,
  reviewCount:suggestions.filter(x=>x.decision==='review').length,
  alreadyCount:suggestions.filter(x=>x.decision==='already').length,
  profileBlocked:!registryValid||osBuild<10240||!!snapshot.registry?.backup, power:{suggested:powerSuggested,reason:powerAdvice,active:power?.active||null},warnings,
  limitations:'Recomandări pe bază de reguli și setări curente; nu este un benchmark și nu estimează FPS.'};
}
module.exports={plan};
