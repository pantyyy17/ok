'use strict';

// Only identified hardware can establish a mismatch. Generic fallback names
// (for example Microsoft Basic Display Adapter) are incomplete inventory.
const CPU_VENDORS = {Intel: /intel/i, AMD: /amd|ryzen|athlon|epyc|threadripper/i};
const GPU_VENDORS = {Intel: /intel/i, AMD: /amd|radeon/i, NVIDIA: /nvidia|geforce|quadro/i};
const unidentified = value => typeof value !== 'string' || !value.trim() ||
 /unknown|necunoscut|unspecified|unavailable|indisponibil|basic display|basic render/i.test(value);

function compatibility(rule, hardware = {}) {
 if (rule.applyBlocked) return {state: 'incompatible', reason: rule.applyBlocked, scope: 'Aplicare indisponibilă; restaurarea originalelor existente rămâne disponibilă.'};
 const checks = [];
 const known = (ok, reason) => checks.push({state: ok ? 'compatible' : 'incompatible', reason: ok ? '' : reason});
 const unknown = reason => checks.push({state: 'unknown', reason});
 const conditions = String(rule.conditions || 'always').replace(/storage:SSD,NVMe/g, 'storage:SSD|NVMe');
 for (const raw of conditions.split(',')) {
  const part = raw.trim();
  if (part === 'always' || part.startsWith('tier:') || part === 'Windows 10/11; TCP global') continue;
  if (part.startsWith('cpu:')) {
   const vendor = part.slice(4), cpu = hardware.cpu;
   if (!CPU_VENDORS[vendor] || unidentified(cpu)) unknown('Procesorul nu a putut fi identificat.');
   else if (CPU_VENDORS[vendor].test(cpu)) known(true, '');
   else if (Object.values(CPU_VENDORS).some(rx => rx.test(cpu)) || /qualcomm|snapdragon|arm|apple/i.test(cpu)) known(false, 'Necesită procesor ' + vendor + '.');
   else unknown('Producătorul procesorului nu a putut fi confirmat.');
  } else if (part.startsWith('gpu:')) {
   const vendor = part.slice(4), gpus = hardware.gpu;
   if (!GPU_VENDORS[vendor] || !Array.isArray(gpus) || !gpus.length) unknown('Placa video nu a putut fi identificată.');
   else if (gpus.some(name => !unidentified(name) && GPU_VENDORS[vendor].test(name))) known(true, '');
   else if (gpus.some(name => unidentified(name) || !Object.values(GPU_VENDORS).some(rx => rx.test(name)))) unknown('Unele plăci video nu au producător identificat.');
   else known(false, 'Necesită placă video ' + vendor + '.');
  } else if (part.startsWith('formFactor:')) {
   const wanted = part.slice(11);
   if (!['Laptop', 'Desktop'].includes(hardware.formFactor)) unknown('Tipul calculatorului nu a fost confirmat.');
   else known(hardware.formFactor === wanted, wanted === 'Laptop' ? 'Necesită laptop.' : 'Necesită desktop.');
  } else if (part.startsWith('ram:>')) {
   const minimum = Number(part.slice(5).replace('GB', ''));
   if (!Number.isFinite(minimum) || !Number.isFinite(hardware.ramGB) || hardware.ramGB <= 0) unknown('Memoria RAM nu a putut fi citită.');
   else known(hardware.ramGB > minimum, 'Necesită peste ' + minimum + ' GB RAM.');
  } else if (part.startsWith('network:')) {
   const wanted = part.slice(8), kinds = hardware.networkKinds;
   if (!Array.isArray(kinds) || !kinds.length) unknown('Tipul adaptoarelor nu a fost confirmat.');
   else if (kinds.includes(wanted)) known(true, '');
   else if (kinds.some(kind => !['WiFi', 'Ethernet'].includes(kind))) unknown('Unele adaptoare nu au tip identificat.');
   else known(false, 'Necesită ' + (wanted === 'WiFi' ? 'Wi-Fi' : 'conexiune Ethernet') + '.');
  } else if (part.startsWith('storage:')) {
   const wanted = part.slice(8).split('|'), disks = hardware.storage;
   if (!Array.isArray(disks) || !disks.length) unknown('Tipul stocării nu a putut fi citit.');
   else if (disks.some(disk => disk && wanted.some(kind => kind === 'NVMe' ? /nvme/i.test(disk.bus || '') : kind === String(disk.media).toUpperCase()))) known(true, '');
   else if (disks.some(disk => !disk || unidentified(disk.media) || !['HDD', 'SSD'].includes(String(disk.media).toUpperCase()))) unknown('Unele discuri nu au tip identificat.');
   else known(false, 'Necesită stocare ' + wanted.join(' sau ') + '.');
  } else unknown('Condiție de compatibilitate neidentificată.');
 }
 if (['library-cpu-013', 'library-gpu-063', 'library-gpu-066'].includes(rule.id) && Number.isInteger(hardware.osBuild) && hardware.osBuild > 0) known(hardware.osBuild >= 19041, 'HAGS necesită Windows 10 build 19041 sau mai nou.');
 if (Number.isInteger(hardware.osBuild) && hardware.osBuild > 0) known(hardware.osBuild >= 10240, 'Necesită Windows 10 sau 11.');
 const state = checks.some(check => check.state === 'incompatible') ? 'incompatible' : checks.some(check => check.state === 'unknown') ? 'unknown' : 'compatible';
 return {state, reason: checks.filter(check => check.state === state && check.reason).map(check => check.reason).join(' '), scope: 'Condiții hardware; suportul driverului este verificat la aplicare.'};
}

module.exports = {compatibility};
