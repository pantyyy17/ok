﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$cli=Join-Path $root 'node_modules\electron\cli.js'
if(-not (Test-Path -LiteralPath $cli)){throw 'Electron lipseste. Ruleaza mai intai npm install.'}
$node=(Get-Command node.exe -ErrorAction Stop).Source
# Only our local application is launched elevated. There is no UAC bypass.
Start-Process -FilePath $node -ArgumentList @(('"'+$cli+'"'),('"'+$root+'"')) -WorkingDirectory $root -Verb RunAs -ErrorAction Stop
Write-Host '[OK] Am solicitat lansarea CARPATIA prin dialogul UAC.'
