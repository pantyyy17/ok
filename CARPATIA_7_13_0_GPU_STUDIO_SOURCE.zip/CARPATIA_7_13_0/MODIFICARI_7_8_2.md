# 7.8.2 — Backup simplu

- O singură pagină, cu titlu și explicație scurtă.
- Acțiunea principală: Restaurează tot. Selectarea categoriei schimbă explicit ținta butonului.
- Lista setărilor individuale este închisă implicit și arată numai backupurile restaurabile.
- Backupurile încheiate apar în istoric, nu printre operațiile active.
- Istoricul și comenzile vechi sunt pliabile. Stările sunt afișate în română.
- Confirmarea arată numele setărilor, fără blocuri JSON. Datele tehnice sunt în detaliile istoricului.
- Raportul scurt rămâne vizibil; detaliile se deschid separat.
- Butonul Restaurare este dezactivat dacă nu există nimic de restaurat sau jurnalele sunt necitibile.
- Filtrarea pe categorie folosește inventarul deja încărcat, fără scanări Windows repetate.
- Răspunsurile întârziate nu mai suprascriu inventarul nou.
- Copia manuală este descrisă explicit: restaurarea directă din ea nu este disponibilă încă.

Motorul nativ, backupurile și validările de siguranță sunt păstrate. Aceasta este sursă pentru testare, nu EXE/installer Windows. Testele de logică și UI simulat sunt în test-results-7.8.2.txt; nu reprezintă testare Windows reală.
