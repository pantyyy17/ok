# Conservative cross-engine conflicts. Exempt only explicitly audited independent values.
function Test-NetworkRegistryConflict($rule,$operation){
 if($rule.category -ne 'Network'){return $false}
 if($operation.name -eq 'reset-network'){return $true}
 if($operation.type -notin @('dns','mtu','ipv6','tcp-global','rss','tunnel')){return $false}
 $independent=@(
  'HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings|AutoDetect',
  'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile|NetworkThrottlingIndex',
  'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization|DODownloadMode',
  'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient|EnableMulticast',
  'HKLM\SYSTEM\CurrentControlSet\Services\NetBT\Parameters|EnableLMHOSTS'
 )
 if(@($rule.entries).Count -eq 0){return $true}
 foreach($entry in $rule.entries){if(($entry.path+'|'+$entry.name) -notin $independent){return $true}}
 return $false
}
function Test-NativeTargetOverlap($left,$right){
 foreach($a in $left){foreach($b in $right){
  if($a -ieq $b){return $true}
  # Preserve broad network targets from old journals as conservative prefix locks.
  if($a -match '^network\|[^|]+$' -and $b.StartsWith($a+'|',[StringComparison]::OrdinalIgnoreCase)){return $true}
  if($b -match '^network\|[^|]+$' -and $a.StartsWith($b+'|',[StringComparison]::OrdinalIgnoreCase)){return $true}
 }}
 return $false
}
