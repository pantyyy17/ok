﻿param([ValidateSet('Status','Apply','Restore')][string]$Action='Status')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$file=Join-Path $dir 'power-plan.json'
function ActiveGuid {
 $output=(& powercfg.exe /getactivescheme | Out-String)
 if($LASTEXITCODE -ne 0){throw 'Nu pot citi planul de alimentare.'}
 $m=[regex]::Match($output,'[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}')
 if(!$m.Success){throw 'GUID-ul planului de alimentare nu a fost gasit.'}
 return $m.Value
}
if($Action -eq 'Status'){@{success=$true;active=(ActiveGuid);backup=(Test-Path $file)}|ConvertTo-Json -Compress;exit}
if($Action -eq 'Apply'){
 if(Test-Path $file){throw 'Exista un plan de alimentare salvat. Restaureaza-l inainte de o noua aplicare.'}
 $old=ActiveGuid
 # Standard Windows High Performance GUID. Some OEMs do not expose this scheme.
 $target='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
 $temporary=$file+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{
  @{previous=$old;created=(Get-Date).ToString('o')}|ConvertTo-Json | Set-Content -LiteralPath $temporary -Encoding UTF8
  Move-Item -LiteralPath $temporary -Destination $file -ErrorAction Stop
 }finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue}}
 & powercfg.exe /setactive $target | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Planul High Performance nu este disponibil pe acest PC. Backup pastrat pentru verificare/restaurare.'}
 if((ActiveGuid) -ne $target){throw 'Windows nu confirma activarea planului High Performance. Backup pastrat.'}
 @{success=$true;previous=$old;active=(ActiveGuid);message='Plan High Performance activat. Consum energetic si temperaturi potential mai mari.'}|ConvertTo-Json -Compress;exit
}
if(!(Test-Path $file)){throw 'Nu exista backup pentru planul de alimentare.'}
$data=Get-Content -Raw -LiteralPath $file|ConvertFrom-Json
if($data.previous -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'Backup invalid.'}
$current=ActiveGuid
if($current -ine [string]$data.previous -and $current -ine '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'){throw 'Planul a fost schimbat din exterior. Originalul este păstrat; restaurarea automată a fost oprită.'}
& powercfg.exe /setactive $data.previous | Out-Null
if($LASTEXITCODE -ne 0){throw 'Nu am putut restaura planul original.'}
if((ActiveGuid) -ne [string]$data.previous){throw 'Planul initial nu este activ dupa restaurare. Backup pastrat.'}
Remove-Item -LiteralPath $file -Force
@{success=$true;active=(ActiveGuid);message='Planul original a fost restaurat.'}|ConvertTo-Json -Compress
