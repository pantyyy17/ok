'use strict';
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaGpu=factory();
})(typeof window==='object'?window:globalThis,function(){
 const metricDefs=[['gpuLoad','gpuLoadValue','%',100],['gpuTemperature','gpuTempValue','°C',150],['gpuCoreClock','gpuCoreClockValue','MHz',100000],['gpuMemoryClock','gpuMemoryClockValue','MHz',100000],['gpuPower','gpuPowerValue','W',10000],['gpuFan','gpuFanValue','RPM',100000]];
 function metric(value,max){const n=value&&typeof value==='object'?value.value:value;return typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=max?n:null}
 function mount({api,document:doc=globalThis.document,window:win=globalThis.window,requireNative=()=>true,task=async(_,fn)=>fn(),confirmDialog=async()=>false,showToast=()=>{},timers={setTimeout:(fn,ms)=>setTimeout(fn,ms),clearTimeout:id=>clearTimeout(id)}}){
  const $=id=>doc.getElementById(id),page=$('view-gpu');
  let destroyed=false,busy=false,statusKnown=false,status={selected:false,backup:false},selectedName='',statusEpoch=0,inventoryEpoch=0,sensorEpoch=0,poll=null,sensorFlight=null,loadFlight=null;
  const samples=[],listeners=[];
  const listen=(target,name,fn)=>{target?.addEventListener(name,fn);listeners.push([target,name,fn])};
  const text=(id,value)=>{const node=$(id);if(node)node.textContent=String(value??'')};
  const visible=()=>!destroyed&&doc.visibilityState!=='hidden'&&page.classList.contains('active');
  function message(value,tone='neutral'){if(destroyed)return;text('gpuActionStatus',value);$('gpuActionStatus').dataset.tone=tone;$('gpuActionStatus').setAttribute('role',tone==='error'?'alert':'status')}
  function render(){
   if(destroyed)return;
   const selected=statusKnown&&status.selected===true;
   $('pickGpuExe').disabled=busy||!api;$('gpuRefresh').disabled=busy||!api;
   $('gpuSetHigh').disabled=busy||!selected||status.highPerformance===true||status.backup===true;
   $('gpuUndo').disabled=busy||!selected||status.backup!==true;
   page.setAttribute('aria-busy',String(busy));
   text('gpuPicked',selected?selectedName||status.name||String(status.exe||'').split(/[\\/]/).at(-1)||'Aplicație selectată':'Niciun executabil selectat.');
   text('gpuPreferenceBadge',!statusKnown?'STARE NECONFIRMATĂ':!selected?'ALEGE UN JOC':status.highPerformance?'PERFORMANȚĂ RIDICATĂ':'PREFERINȚĂ WINDOWS');
   text('gpuBackupState',!statusKnown?'Reverifică starea înainte de modificare.':status.backup?'Original salvat · restaurarea este disponibilă.':selected?'Nu există un backup CARPATIA activ pentru acest executabil.':'Alege fișierul .exe care pornește jocul.');
  }
  async function refreshStatus(){
   const request=++statusEpoch;
   try{
    const next=await api.gpuStatus();
    if(!next||next.success!==true||typeof next.selected!=='boolean'||next.selected&&(typeof next.backup!=='boolean'||typeof next.highPerformance!=='boolean'))throw Error(next?.message||'Starea preferinței GPU nu a fost confirmată.');
    if(!destroyed&&request===statusEpoch){status=next;statusKnown=true;if(next.name)selectedName=next.name;render()}
    return next;
   }catch(error){if(!destroyed&&request===statusEpoch){statusKnown=false;render()}throw error}
  }
  async function inventory(){
   const request=++inventoryEpoch;
   try{
    const info=await api.gpuList();
    if(!info||info.success!==true||!Array.isArray(info.gpus))throw Error(info?.message||'Inventarul GPU nu a fost confirmat.');
    if(destroyed||request!==inventoryEpoch)return;
    const target=$('gpuInventory');target.replaceChildren();
    for(const gpu of info.gpus){const card=doc.createElement('article');card.className='gpu-device';const name=doc.createElement('strong');name.textContent=gpu.name||'GPU neidentificat';const detail=doc.createElement('small');detail.textContent='Driver '+(gpu.driver||'indisponibil')+(gpu.videoProcessor?' · '+gpu.videoProcessor:'');card.append(name,detail);target.append(card)}
    if(!info.gpus.length){const empty=doc.createElement('p');empty.textContent='Windows nu a raportat o placă video. Apasă Actualizează pentru a reîncerca.';target.append(empty)}
    text('gpuHags',info.hags||'Controlat de Windows / driver');
    text('gpuInventoryStatus',info.warning?'Inventar parțial: '+info.warning:info.gpus.length+' adaptoare grafice detectate');
   }catch(error){if(!destroyed&&request===inventoryEpoch)text('gpuInventoryStatus','Inventar indisponibil: '+String(error.message||error));throw error}
  }
  function clearPoll(){if(poll!==null)timers.clearTimeout(poll);poll=null}
  function schedule(){clearPoll();if(api&&visible()&&!busy)poll=timers.setTimeout(()=>{poll=null;refreshSensors().finally(schedule)},5000)}
  function drawTrend(){
   for(const [key,id,maximum] of [['gpuLoad','gpuTrendLoad',100],['gpuTemperature','gpuTrendTemp',120]]){
    let connected=false;const commands=[];
    samples.forEach((sample,i)=>{const n=sample[key];if(n===null){connected=false;return}const x=samples.length>1?i*480/(samples.length-1):0,y=120-Math.min(maximum,n)*120/maximum;commands.push((connected?'L':'M')+x.toFixed(1)+' '+y.toFixed(1));connected=true});
    $(id).setAttribute('d',commands.join(' '));
   }
   text('gpuTrendStatus',samples.some(s=>s.gpuLoad!==null||s.gpuTemperature!==null)?samples.length+' citiri locale · maximum 48':'Graficul apare când sunt disponibili senzori GPU.');
  }
  async function refreshSensors(){
   if(!api||!visible()||busy)return;
   if(sensorFlight)return sensorFlight;
   const request=++sensorEpoch;
   const pending=Promise.resolve().then(()=>api.sensors()).then(info=>{
    if(destroyed||request!==sensorEpoch||!visible()||busy)return;
    const sample={};let available=0;
    for(const [key,id,unit,max] of metricDefs){const n=info?.available===true?metric(info[key],max):null;sample[key]=n;text(id,n===null?'—':Math.round(n)+' '+unit);if(n!==null)available++}
    if(available){samples.push(sample);if(samples.length>48)samples.shift();text('gpuSensorSource',info.source||'Senzori locali');text('gpuSensorStatus','Monitorizare activă · actualizare la 5 secunde')}
    else{samples.push(sample);if(samples.length>48)samples.shift();text('gpuSensorSource','FĂRĂ SENZORI GPU');text('gpuSensorStatus',info?.reason||'Pornește LibreHardwareMonitor cu serverul local pentru temperatură, frecvențe și consum. Preferințele pentru jocuri funcționează și fără senzori.')}
    drawTrend();
   },error=>{if(!destroyed&&request===sensorEpoch&&visible()){for(const [,id] of metricDefs)text(id,'—');text('gpuSensorStatus','Citirea senzorilor a eșuat: '+String(error.message||error))}}).finally(()=>{if(sensorFlight===pending)sensorFlight=null});
   sensorFlight=pending;return pending;
  }
  async function load(){
   if(!api||destroyed){if(!api){text('gpuInventoryStatus','Previzualizare: detectarea GPU și preferințele jocurilor necesită aplicația Windows.');text('gpuSensorStatus','Datele hardware reale apar în aplicația Windows.')}return}
   if(busy)return;if(loadFlight)return loadFlight;
   const pending=Promise.allSettled([inventory(),refreshStatus()]).then(async results=>{
    if(destroyed)return;
    const failed=results.filter(r=>r.status==='rejected');if(failed.length)message(failed.map(r=>String(r.reason.message||r.reason)).join(' · '),'error');
    await refreshSensors();schedule();
   }).finally(()=>{if(loadFlight===pending)loadFlight=null});loadFlight=pending;return pending;
  }
  async function action(label,fn){
   if(!api||destroyed||busy)return;
   busy=true;statusEpoch++;sensorEpoch++;clearPoll();render();
   try{return await task(label,async()=>{try{return await fn()}catch(error){if(!destroyed)try{await refreshStatus()}catch{}message(String(error.message||error),'error');throw error}})}
   catch(error){if(!destroyed)showToast(label+': '+String(error.message||error));return null}
   finally{busy=false;if(!destroyed){render();schedule()}}
  }
  async function pick(){
   if(!requireNative(true))return;
   return action('Alegere joc GPU',async()=>{
    const before=$('gpuActionStatus').textContent,beforeTone=$('gpuActionStatus').dataset.tone;
    message('Alege executabilul care pornește jocul…');
    const result=await api.gpuPick();if(destroyed)return;if(result.cancelled){message(before,beforeTone);return}
    selectedName=result.name||'';const next=await refreshStatus();if(!next.selected)throw Error('Executabilul nu a fost păstrat. Alege din nou jocul.');
    message('Joc selectat. '+(next.backup?'Există un original salvat; îl poți restaura.':next.highPerformance?'Preferința performantă era deja activă.':'Poți solicita preferința performantă pentru acest joc.'));
   });
  }
  async function apply(){
   if(!requireNative()||!statusKnown||!status.selected||status.backup||status.highPerformance)return;
   return action('Preferință GPU pentru joc',async()=>{
    if(!await confirmDialog('Folosești GPU-ul performant pentru acest joc?', 'Windows primește preferința pentru executabilul selectat.',selectedName||status.name||status.exe||'', 'Pe laptop poate crește consumul. Windows și jocul aleg adaptorul disponibil; efectul se verifică în joc.','APLICĂ PREFERINȚA')||destroyed)return;
    message('Se salvează originalul și se aplică preferința Windows…');
    const result=await api.gpuApply();if(result?.success!==true)throw Error(result?.message||'Windows nu a confirmat aplicarea.');
    const next=await refreshStatus();if(next.highPerformance!==true)throw Error('Preferința performantă nu este confirmată la recitire. Verifică originalul înainte de o nouă aplicare.');
    message(result.message||'Preferință performantă verificată. Repornește jocul pentru a o folosi.','success');return result;
   });
  }
  async function restore(){
   if(!requireNative(true)||!statusKnown||!status.selected||!status.backup)return;
   return action('Restaurare preferință GPU',async()=>{
    if(!await confirmDialog('Restaurezi preferința acestui joc?','Revine exact valoarea salvată înainte de aplicare.',selectedName||status.name||status.exe||'','Repornește jocul după restaurare.','RESTAUREAZĂ')||destroyed)return;
    message('Se restaurează originalul și se verifică rezultatul…');
    const result=await api.gpuRestore();if(result?.success!==true)throw Error(result?.message||'Restaurarea GPU nu a fost confirmată.');
    const next=await refreshStatus();if(next.backup)throw Error('Originalul este încă activ. Restaurarea trebuie reverificată.');
    message(result.message||'Preferința originală a fost restaurată și verificată.','success');return result;
   });
  }
  function sync(){clearPoll();if(visible()){refreshSensors().finally(schedule)}else sensorEpoch++}
  function destroy(){if(destroyed)return;destroyed=true;statusEpoch++;inventoryEpoch++;sensorEpoch++;clearPoll();observer?.disconnect();for(const [target,name,fn] of listeners)target?.removeEventListener(name,fn);samples.length=0}
  const Observer=win?.MutationObserver,observer=Observer?new Observer(sync):null;observer?.observe(page,{attributes:true,attributeFilter:['class']});
  listen(doc,'visibilitychange',sync);listen(win,'pagehide',destroy);
  $('gpuRefresh').onclick=()=>{if(requireNative(true))return load()};$('pickGpuExe').onclick=pick;$('gpuSetHigh').onclick=apply;$('gpuUndo').onclick=restore;
  $('gpuSettings').onclick=async()=>{if(!api)return requireNative(true);try{await api.openSettings('graphics')}catch(error){message(String(error.message||error),'error');showToast(String(error.message||error))}};
  render();return {load,destroy,refreshStatus,getState:()=>({busy,statusKnown,status:{...status},samples:samples.length,destroyed})};
 }
 return {mount,metric};
});
