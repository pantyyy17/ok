'use strict';
window.CarpatiaRecovery={mount({api,task,confirmDialog,requireNative,showToast}){
 const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n};
 const active=x=>['prepared','applied','failed'].includes(x.state)&&x.reversible!==false;
 const categories={CPU:'CPU',GPU:'GPU',Network:'Internet',RAM:'Memorie',Windows:'Windows',Services:'Servicii',Storage:'Stocare',Input:'Periferice',Privacy:'Confidențialitate'};
 const states={applied:'Aplicat',prepared:'Întrerupt',failed:'Necesită verificare',restored:'Restaurat',complete:'Finalizat',partial:'Parțial',running:'Întrerupt sau în curs',captured:'Salvat',skipped:'Omis',undone:'Anulat',undoing:'Anulare întreruptă sau în curs',invalid:'Necesită diagnostic',empty:'Fără scrieri'};
 const date=v=>v&&!Number.isNaN(new Date(v).getTime())?new Date(v).toLocaleString('ro-RO'):'Dată indisponibilă';
 let focusId=null,selectedGroup=null,inventory=null,loadId=0;
 function report(message,details=''){$('recoveryReport').textContent=message;$('recoveryReport').hidden=!message;$('recoveryReportDetails').textContent=details;$('recoveryReportMore').hidden=!details}
 async function restoreProfile(group){
  if(!requireNative(true))return;
  return task('Restaurare profil',async()=>{
   if(!await confirmDialog('Restaurezi profilul '+group.toUpperCase()+'?','Se verifică originalele profilului și se restaurează numai pașii salvați.','','O sesiune deja restaurată va fi finalizată fără a inventa sau șterge originale.','RESTAUREAZĂ PROFILUL'))return;
   const r=await api.dashboardRestore(group);report(r.message,(r.results||[]).map(x=>x.id+': '+(x.success?'Restaurat':x.message)).join('\n'));await load();return r;
  });
 }
 function renderOverview(s,all){
  const profiles=s.profiles||[],stats=$('recoveryStats'),root=$('recoveryProfiles');
  if(stats){stats.replaceChildren();for(const [label,value,attention] of [['Originale active',all.length,false],['Profiluri active',profiles.filter(x=>x.active).length,false],['Copii manuale',s.history.filter(x=>x.type==='manual-snapshot'&&x.restorable!==false).length,false],['Necesită atenție',s.errors.length+(s.historyErrors||[]).length+(s.transactions||[]).filter(x=>!['complete','undone','empty'].includes(x.state)).length,true]]){const card=el('div','','recovery-stat'),number=el('strong',String(value));if(attention&&value)number.className='attention';card.append(el('small',label),number);stats.append(card)}}
  if(root){root.replaceChildren();if(!profiles.length)root.append(el('p','Starea profilurilor nu a fost încă citită.'));
   for(const p of profiles){const card=el('article','','recovery-profile');card.append(el('h3',p.group==='internet'?'Internet':p.group.toUpperCase()));
    card.append(el('p',p.error||(!p.active?'Niciun profil de restaurat.':(p.level||'Profil').toUpperCase()+' · '+p.remaining+' pași salvați')));
    if(p.active){const b=el('button',p.recoverable===false?'DIAGNOSTIC NECESAR':'RESTAUREAZĂ PROFILUL','action outline');b.disabled=p.recoverable===false;b.onclick=()=>restoreProfile(p.group);card.append(b)}else card.append(el('span','Disponibil pentru analiză','profile-idle'));root.append(card)}
  }
 }
 function render(){
  const s=inventory,root=$('recoveryRows'),category=$('recoveryCategory');root.replaceChildren();
  const all=s.items.filter(active),selected=all.filter(x=>(!selectedGroup||x.group===selectedGroup)&&(!category.value||x.category===category.value));
  renderOverview(s,all);
  $('recoverySummary').textContent=s.errors.length?'Unele backupuri nu pot fi citite. Vezi detaliile de mai jos.':all.length?`${all.length} setări au valori originale salvate.`:'Nicio modificare de restaurat.';
  $('recoveryRestore').disabled=!selected.length||!!s.errors.length;
  $('recoveryRestore').textContent=selectedGroup?'RESTAUREAZĂ PROFILUL '+selectedGroup.toUpperCase():category.value?'RESTAUREAZĂ '+(categories[category.value]||category.value).toUpperCase():'RESTAUREAZĂ TOT';
  $('recoveryErrors').hidden=!s.errors.length&&!(s.historyErrors||[]).length;$('recoveryErrorText').textContent=[...s.errors,...(s.historyErrors||[]).map(x=>'Istoric: '+x)].join('\n');
  if(!selected.length)root.append(el('p',category.value?'Nu există modificări de restaurat în această categorie.':'Când aplici setări prin Carpatia, valorile originale sunt salvate automat și apar aici.','recovery-empty'));
  for(const item of selected){
   const row=el('article','','recovery-card');row.dataset.recoveryId=item.id;
   const info=el('div','','recovery-item-info');info.append(el('h3',item.title),el('small',`${categories[item.category]||item.category} · ${states[item.state]||'De verificat'} · ${date(item.date)}`));row.append(info);
   const b=el('button','RESTAUREAZĂ','action outline');b.disabled=!!s.errors.length;b.onclick=()=>preview({id:item.id});row.append(b);root.append(row);
  }
  $('recoveryIndividualSummary').textContent=`Alege o singură setare (${selected.length})`;
  const history=$('recoveryHistory');history.replaceChildren();
  const entries=[...(s.transactions||[]),...s.history,...s.items.filter(x=>x.state==='restored')].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  if(!entries.length)history.append(el('p','Nu există încă operații salvate.','recovery-empty'));
  for(const h of entries){
   const d=el('details',''),kind=h.type==='manual-snapshot'?'Copie manuală':h.type==='snapshot-restore'?'Restaurare copie manuală':h.type==='restore'?'Restaurare':h.title||'Backup anterior';
   d.append(el('summary',`${kind} · ${date(h.date)} · ${states[h.state]||'Salvat'}`));
   if(h.type==='manual-snapshot'&&h.id&&h.restorable!==false){const restore=el('button','RESTAUREAZĂ ACEASTĂ COPIE','action outline');restore.onclick=()=>restoreSnapshot(h.id);d.append(restore)}
   if(h.error)d.append(el('p',h.error));
   if(h.type==='snapshot-restore'&&h.state!=='undone'&&h.recoverable!==false){if(h.state!=='complete'){const retry=el('button',h.direction==='undo'?'REIA ANULAREA':'REIA RESTAURAREA','action outline');retry.onclick=()=>resumeSnapshot(h.id,h.direction==='undo');d.append(retry)}const undo=el('button','REVINO ÎNAINTE DE RESTAURARE','action outline');undo.onclick=()=>resumeSnapshot(h.id,true);d.append(undo)}
   for(const r of h.results||h.rows||[])d.append(el('p',`${r.title||'Setare'} — ${states[r.status]||r.status||'De verificat'}${r.message?' · '+r.message:''}`));
   const technical=el('details','');technical.append(el('summary','Detalii tehnice'),el('pre',JSON.stringify(h,null,2)));d.append(technical);history.append(d);
  }
  if(focusId){const row=[...root.children].find(x=>x.dataset?.recoveryId===focusId);if(row){$('recoveryIndividual').open=true;row.scrollIntoView({block:'center'});row.classList.add('recovery-focus')}focusId=null}
 }
 async function load({category:requestedCategory}={}){
  if(!api)return;const request=++loadId;const s=await api.recoveryInventory();if(request!==loadId)return;inventory=s;
  const category=$('recoveryCategory'),old=requestedCategory??category.value;category.replaceChildren(new Option('Toate setările',''));
  for(const c of [...new Set(s.items.filter(active).map(x=>x.category))].sort())category.append(new Option(categories[c]||c,c));category.value=[...s.items.filter(active)].some(x=>x.category===old)?old:'';render();
 }
 async function preview(selection){
  if(!requireNative(true))return;
  return task('Restaurare',async()=>{
   const plan=await api.recoveryPrepare(selection);
   const detail=plan.rows.map(x=>'• '+x.title+(x.restart?' — necesită restart':'')).join('\n');
   if(!await confirmDialog('Revii la setările anterioare?',`Vor fi restaurate ${plan.rows.length} setări din valorile salvate de Carpatia.`,detail,'Setările modificate ulterior din exterior pot necesita verificare. Backupurile nereușite sunt păstrate.','RESTAUREAZĂ'))return;
   report('Restaurare în curs…');
   try{const r=await api.recoveryCommit(plan.token);report(`${r.succeeded} restaurate · ${r.failed} nereușite · ${r.skipped} omise${r.restartRequired?' · Repornește Windows.':''}`,r.results.map(x=>x.title+': '+(states[x.status]||x.status)+' — '+(x.message||'')).join('\n'));await load();return r}
   catch(e){report('Restaurarea nu s-a încheiat.',e.message);throw e}
  });
 }
 $('recoveryRefresh').onclick=()=>task('Citire backupuri',load);
 $('recoveryCategory').onchange=()=>{selectedGroup=null;if(inventory)render()};
 $('recoveryRestore').onclick=()=>preview(selectedGroup?{group:selectedGroup}:$('recoveryCategory').value?{category:$('recoveryCategory').value}:{});
 $('recoverySnapshot').onclick=()=>{if(!requireNative(true))return;return task('Backup manual',async()=>{
  if(!await confirmDialog('Salvezi o copie manuală?','Copia păstrează starea actuală a setărilor gestionate. Nu modifică Windows.','','O poți restaura din Istoric. Mai întâi trebuie restaurate modificările cu backup automat, pentru a păstra originalele.','SALVEAZĂ COPIA'))return;
  report('Se salvează copia. Operația poate dura câteva minute…');
  try{const r=await api.recoverySnapshot();report(r.success?'Copia a fost salvată.':'Copia a fost salvată parțial. Vezi istoricul.',r.message);await load();return r}catch(e){report('Copia nu a fost finalizată.',e.message);throw e}
 })};
 async function restoreSnapshot(id){if(!requireNative(true))return;return task('Restaurare copie',async()=>{
  const plan=await api.snapshotPrepare(id),changed=plan.rows.filter(x=>x.changed);
  const warning=(plan.partial?'Copia este parțială; se restaurează numai valorile salvate cu succes. ':'')+(plan.legacy?'Copie veche, fără identificarea calculatorului. Confirmă numai dacă a fost creată pe acest PC și în acest cont. ':'')+(plan.rows.some(x=>['security','boot'].includes(x.impact))?'Include setări de securitate sau de pornire. ':'')+'Se salvează starea curentă pentru revenire. Rețeaua se poate întrerupe.';
  if(!await confirmDialog('Restaurezi copia manuală?',`${changed.length} valori diferă de copia salvată.`,[...new Set(changed.map(x=>x.title))].join('\n'),warning,'RESTAUREAZĂ COPIA'))return;
  const r=await api.snapshotCommit(plan.token);reportSnapshot(r);await load();return r;
 })}
 function reportSnapshot(r){report(`${r.succeeded} restaurate · ${r.failed} nereușite · ${r.skipped} deja corecte${r.restartRequired?' · Necesită restart.':''}`,r.rows.map(x=>x.title+': '+(states[x.status]||x.status)+' '+(x.message||'')).join('\n'))}
 async function resumeSnapshot(id,undo){if(!requireNative(true))return;return task('Recuperare copie',async()=>{if(!await confirmDialog(undo?'Revii înainte de restaurare?':'Reiei restaurarea?',undo?'Se folosesc valorile salvate înainte de restaurarea copiei.':'Se verifică din nou starea fiecărei valori.','','Modificările externe nu sunt suprascrise automat.','CONFIRMĂ'))return;const r=await api.snapshotResume(id,undo);reportSnapshot(r);await load();return r})}
 api?.onBackupProgress?.(event=>report('Copie de backup în curs…',event.detail));
 return {load,open(selection={}){selectedGroup=selection.group||null;focusId=selection.id||null;return load({category:selection.category||''})},focus(id){focusId=id;load().catch(e=>showToast(e.message))}};
}};
