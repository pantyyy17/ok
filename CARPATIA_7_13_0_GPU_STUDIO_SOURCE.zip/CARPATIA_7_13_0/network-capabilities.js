'use strict';
// Mirror the native engines' actual writable fields, not a single driver property.
function capabilitiesFor(adapter,{tcp,power,advanced}){
 const pick=result=>result?.success===true?result.adapters?.find(x=>x.name===adapter):null;
 const t=pick(tcp),p=pick(power),a=pick(advanced);
 const valid=value=>['Enabled','Disabled'].includes(value);
 const supported={
  tcp:!!(tcp?.admin&&t?.supported),
  nicPower:!!(power?.admin&&p&&!p.error&&(valid(p.selectiveSuspend)||valid(p.deviceSleepOnDisconnect))),
  interrupt:!!(advanced?.admin&&a?.interrupt),
  eee:!!(advanced?.admin&&a?.eee)
 };
 const reasons={
  tcp:supported.tcp?'Disponibil':'TCP: suportul sau drepturile de administrator nu au fost confirmate.',
  nicPower:supported.nicPower?'Disponibil':'NIC Power: driverul nu expune Selective Suspend / Device Sleep modificabile, ori citirea a eșuat.',
  interrupt:supported.interrupt?'Disponibil':'Interrupt Moderation: proprietate indisponibilă sau drepturi insuficiente.',
  eee:supported.eee?'Disponibil':'Energy Efficient Ethernet: proprietate indisponibilă sau drepturi insuficiente.'
 };
 return {adapter,supported,reasons};
}
module.exports={capabilitiesFor};
