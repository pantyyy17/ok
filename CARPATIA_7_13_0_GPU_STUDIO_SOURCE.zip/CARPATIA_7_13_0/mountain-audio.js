'use strict';
// A short, locally synthesized wind/metal sweep. No media files or audio loop.
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.CarpatiaMountainAudio=Object.freeze(factory());
})(typeof window==='object'?window:globalThis,function(){
 const STORAGE_KEY='carpatia.mountainSound';
 const IDS=['heroDebloat','heroUltra','heroNetwork'];
 // Shared with offline audio rendering for preview/verification. The caller
 // supplies its context; this function never opens an audio device itself.
 function synthesizeWind(context,destination=context.destination,{index=0,random=Math.random,noise=null,volume=.045}={}){
  index=Number.isInteger(index)?Math.max(0,Math.min(2,index)):0;
  volume=Number.isFinite(volume)?Math.max(.0001,Math.min(.12,volume)):.045;
  if(!noise){
   noise=context.createBuffer(1,Math.ceil(context.sampleRate*.42),context.sampleRate);
   const samples=noise.getChannelData(0);for(let i=0;i<samples.length;i++)samples[i]=random()*2-1;
  }
  const source=context.createBufferSource(),high=context.createBiquadFilter(),sweep=context.createBiquadFilter();
  const gain=context.createGain(),tone=context.createOscillator(),metal=context.createGain();
  const voice={source,tone,nodes:[source,high,sweep,gain,tone,metal],noise};
  const indexStart=context.currentTime,end=indexStart+.34+index*.025;
  source.buffer=noise;high.type='highpass';high.frequency.setValueAtTime(220,indexStart);
  sweep.type='bandpass';sweep.Q.setValueAtTime(1.4,indexStart);
  sweep.frequency.setValueAtTime(5200+index*450,indexStart);sweep.frequency.exponentialRampToValueAtTime(800,end);
  gain.gain.setValueAtTime(.0001,indexStart);gain.gain.exponentialRampToValueAtTime(volume,indexStart+.018);gain.gain.exponentialRampToValueAtTime(.0001,end);
  tone.type='triangle';tone.frequency.setValueAtTime(3900+index*250,indexStart);tone.frequency.exponentialRampToValueAtTime(1500,end);metal.gain.setValueAtTime(.045,indexStart);
  source.connect(high);high.connect(sweep);sweep.connect(gain);tone.connect(metal);metal.connect(gain);gain.connect(destination);
  source.start(indexStart);tone.start(indexStart);source.stop(end);tone.stop(end);
  return {...voice,duration:end-indexStart};
 }
 function mount({document:doc=globalThis.document,window:win=globalThis.window,AudioContext,storage,now=()=>Date.now(),random=Math.random}={}){
  const Audio=AudioContext||win?.AudioContext||win?.webkitAudioContext;
  const toggle=doc.getElementById('mountainSound'),status=doc.getElementById('mountainSoundStatus');
  const mountains=IDS.map(id=>doc.getElementById(id)).filter(Boolean),listeners=[];
  let preferences=storage,enabled=true,destroyed=false,unlocked=false,unavailable=!Audio,keyboard=false;
  let context=null,noise=null,arming=null,pending=0,generation=0,lastSound=-Infinity;
  const voices=new Set();
  try{if(preferences===undefined)preferences=win?.localStorage;enabled=preferences?.getItem(STORAGE_KEY)!=='off'}catch{}
  const listen=(target,type,handler,options)=>{target?.addEventListener(type,handler,options);listeners.push([target,type,handler,options])};
  function render(){
   if(toggle){
    if(toggle.type==='checkbox')toggle.checked=enabled;
    else{toggle.textContent=enabled?'SUNET ACTIV':'SUNET OPRIT';toggle.setAttribute('aria-pressed',String(enabled))}
    toggle.setAttribute('aria-label',enabled?'Oprește sunetul munților':'Activează sunetul munților');
   }
   if(status)status.textContent=!enabled?'Efectele sonore sunt oprite.':unavailable?'Efectele sonore nu sunt disponibile în această sesiune.':unlocked?'Vânt metalic discret la atingerea munților.':'Sunetul pornește după primul clic sau prima tastă.';
  }
  function suspendIdle(){if(context&&!destroyed&&pending===0&&voices.size===0&&context.state==='running')try{Promise.resolve(context.suspend()).catch(()=>{})}catch{}}
  function clean(voice,stop=false){
   if(!voices.delete(voice))return;
   voice.source.onended=null;
   if(stop)for(const source of [voice.source,voice.tone])try{source.stop()}catch{}
   for(const node of voice.nodes)try{node.disconnect()}catch{}
   suspendIdle();
  }
  function stop(){generation++;for(const voice of [...voices])clean(voice,true);suspendIdle()}
  function usable(button){
   const panel=button?.closest?.('.view');
   return !destroyed&&enabled&&!unavailable&&!doc.hidden&&doc.visibilityState!=='hidden'&&button&&!button.disabled&&
    (!panel||panel.classList.contains('active'))&&!button.closest?.('[inert]')&&(!button.getClientRects||button.getClientRects().length>0);
  }
  function arm(event){
   if(destroyed||!enabled||unavailable||event?.isTrusted!==true)return Promise.resolve(false);
   if(arming)return arming;
   try{
    if(!context)context=new Audio();
    // Call resume inside the real input handler, before its user activation ends.
    const ready=context.state==='running'?Promise.resolve():Promise.resolve(context.resume());
    arming=ready.then(()=>{
     if(destroyed)return false;
     unlocked=context.state==='running';render();return unlocked;
    },()=>{unlocked=false;render();return false}).finally(()=>{arming=null;suspendIdle()});
    return arming;
   }catch{unavailable=true;unlocked=false;render();return Promise.resolve(false)}
  }
  async function play(button,event){
   if(event?.isTrusted!==true||!usable(button)||now()-lastSound<180)return;
   // Hover may resume an already-unlocked context, but cannot unlock it itself.
   if(!unlocked&&!arming)return;
   const request=generation;pending++;
   try{
    if(arming)await arming;
    else if(context.state!=='running')await context.resume();
    if(request!==generation||!unlocked||!usable(button)||now()-lastSound<180)return;
    lastSound=now();for(const old of [...voices])clean(old,true);
    const voice=synthesizeWind(context,context.destination,{noise,index:mountains.indexOf(button),random});noise=voice.noise;voices.add(voice);
    voice.source.onended=()=>clean(voice);
   }catch{for(const voice of [...voices])clean(voice,true)}
   finally{pending--;suspendIdle()}
  }
  function setEnabled(value){
   enabled=Boolean(value);if(!enabled)stop();
   try{preferences?.setItem(STORAGE_KEY,enabled?'on':'off')}catch{}
   render();
  }
  function pointer(event){keyboard=false;arm(event)}
  function key(event){
   if(event.isTrusted!==true||event.repeat||event.ctrlKey||event.metaKey||event.altKey)return;
   keyboard=true;arm(event);
   if(['Enter',' '].includes(event.key)&&mountains.includes(event.target))play(event.target,event);
  }
  for(const button of mountains){
   listen(button,'pointerenter',event=>play(button,event));
   listen(button,'pointerdown',event=>{if(event.button===undefined||event.button===0)play(button,event)});
   listen(button,'focus',event=>{if(keyboard)play(button,event)});
  }
  listen(doc,'pointerdown',pointer,true);listen(doc,'keydown',key,true);
  listen(doc,'visibilitychange',()=>{if(doc.hidden||doc.visibilityState==='hidden')stop()});
  listen(win,'blur',stop);listen(win,'pagehide',destroy,{once:true});
  if(toggle)listen(toggle,toggle.type==='checkbox'?'change':'click',event=>{setEnabled(toggle.type==='checkbox'?toggle.checked:!enabled);if(enabled)arm(event)});
  function destroy(){
   if(destroyed)return;stop();destroyed=true;
   for(const [target,type,handler,options] of listeners)target?.removeEventListener(type,handler,options);
   listeners.length=0;noise=null;unlocked=false;
   if(context)try{Promise.resolve(context.close()).catch(()=>{})}catch{}
  }
  render();return {setEnabled,destroy,getState:()=>({enabled,unlocked,available:!unavailable,active:voices.size,destroyed})};
 }
 return {mount,STORAGE_KEY,synthesizeWind};
});
