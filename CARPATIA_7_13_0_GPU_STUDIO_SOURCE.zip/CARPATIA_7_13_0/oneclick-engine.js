'use strict';
// CARPATIA 0.39. Safe preparation + isolated rollback semantics. No shell arguments from renderer.
function planOneClick(profile,request,powerStatus,servicesStatus){
 if(!profile || !Array.isArray(profile.suggestions))throw Error('Analiza hardware nu este disponibilă.');
 if(profile.profileBlocked)throw Error('Profil blocat: verifică diagnosticul Windows și backupurile; folosește Restaurare dacă există un backup activ.');
 if(request?.power===true&&(powerStatus?.success!==true||typeof powerStatus.active!=='string'))throw Error('Planul de alimentare nu a putut fi verificat.');
 const power=request?.power===true&&powerStatus.active.toLowerCase()!=='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';
 const sysmain=request?.sysmain===true;
 const captureOff=request?.captureOff===true;
 const max=request?.max===true;
 if(max && request?.riskAcknowledged!==true)throw Error('Pentru ULTRA MAX confirma separat riscurile setarilor avansate.');
 if(power && powerStatus?.backup)throw Error('Un Power Plan are deja backup. Restaurează-l înainte de alt BOOST.');
 if(sysmain){
  const row=servicesStatus?.items?.find(x=>x.id==='sysmain');
  if(!servicesStatus?.elevated)throw Error('SysMain necesită lansarea ca administrator. Nu s-a modificat nimic.');
  if(!row?.installed || row?.backup || row?.disabled)throw Error('SysMain nu poate fi dezactivat: absent, deja dezactivat sau backup existent.');
 }
 let ids=[];
 if(max){
  if(!Array.isArray(profile.maxSuggestions)||!profile.maxSuggestions.length)throw Error('Catalogul ULTRA MAX nu a putut fi verificat.');
  const eligible=new Set(profile.maxSuggestions.filter(x=>x.decision==='max').map(x=>x.id));
  const requested=request?.ids;
  if(requested!==undefined){
   if(!Array.isArray(requested)||requested.some(id=>typeof id!=='string'||!eligible.has(id)))throw Error('Selectie ULTRA MAX diferita de catalogul validat. Reanalizeaza PC-ul.');
   ids=[...requested];
  } else ids=[...eligible];
 } else {
  ids=profile.suggestions.filter(x=>x.checked===true&&x.decision==='recommended'&&x.risk==='low').map(x=>x.id);
  // Capture settings require an explicit opt-in from the user.
  if(captureOff){for(const id of ['game_dvr','gamebar_history']){const item=profile.suggestions.find(x=>x.id===id);if(item&&item.decision==='review'&&item.risk==='medium')ids.push(id);}}
 }
 if(new Set(ids).size!==ids.length)throw Error('Recomandările conțin ID-uri duplicate.');
 if(!ids.length&&!power&&!sysmain)throw Error('Nu există optimizări noi de aplicat pentru acest PC.');
 return {ids,power,sysmain,captureOff,max};
}
async function executeOneClick(plan,ops,onProgress=()=>{}){
 const applied=[],steps=[],rolledBack=[];
 const send=(phase,detail)=>{try{onProgress({phase,detail})}catch{}};
 const rollback=async()=>{
  send('rollback','O etapă nu a reușit. Verific backupurile și încerc restaurarea în ordine inversă.');
  for(const kind of [...steps].reverse()){
   send('restoring','Restaurez '+kind+'…');
   try{
    const exists=await ops.hasBackup(kind);
    if(!exists){rolledBack.push({kind,success:false,message:'Backup absent: restaurarea nu poate fi confirmată.'});continue;}
    const result=await ops.restore(kind);
    const success=result?.success===true && (typeof ops.verifyRestored!=='function'||await ops.verifyRestored(kind)===true);
    rolledBack.push({kind,success,message:String(result?.message||'')});
    send(success?'restored':'restore-error',(success?'Restaurat: ':'Restaurare nereușită: ')+kind);
   }catch(e){rolledBack.push({kind,success:false,message:String(e?.message||e)});send('restore-error','Restaurare nereușită: '+kind)}
  }
 };
 const step=async(kind,task,details)=>{
  steps.push(kind);send('applying',details);
  const result=await task();
  if(result?.success!==true)throw Error('Aplicare nereușită '+kind+': '+JSON.stringify(result?.errors||result?.message||''));
  if(typeof ops.verify==='function'){
   send('verifying','Verific starea din Windows: '+kind+'…');
   const verified=await ops.verify(kind,plan);
   if(verified!==true)throw Error('Windows nu confirmă toate setările pentru '+kind+'.');
  }
  applied.push(kind==='registry'?{kind,count:result.applied?.length||0}:{kind});
  send('applied','Confirmat: '+kind+'.');
 };
 try{
  if(plan.ids.length)await step('registry',()=>ops.applyRegistry(plan.ids),'Aplic tweak-urile Registry aprobate și salvez valorile inițiale…');
  if(plan.power)await step('power',()=>ops.applyPower(),'Activez Power Plan-ul aprobat…');
  if(plan.sysmain)await step('sysmain',()=>ops.applySysmain(),'Aplic modificarea SysMain aprobată…');
  send('complete','Toate modificările au fost verificate. Compară FPS înainte și după.');
  return {success:true,applied,rolledBack:[],message:'Modificările confirmate au fost aplicate și verificate în Windows.'};
 }catch(e){
  await rollback();
  const failed=rolledBack.filter(x=>!x.success);
  const suffix=failed.length?' ATENȚIE: '+failed.length+' restaurări nu au reușit. Folosește Restaurare.':' Restaurarea componentelor începute a fost verificată prin răspunsul motorului.';
  send('failed','Aplicarea a eșuat. '+suffix);
  return {success:false,applied,rolledBack,message:'Aplicare întreruptă: '+String(e?.message||e)+'.'+suffix};
 }
}
module.exports={planOneClick,executeOneClick};
