'use strict';
const {spawn}=require('node:child_process');
const path=require('node:path');

// One runner owns process limits and the uncertain-termination latch.
function createWindowsRunner({spawnProcess=spawn,platform=process.platform,systemRoot=process.env.SystemRoot||'C:\\Windows',schedule=setTimeout,cancel=clearTimeout}={}){
 let blocked=false;
 const system32=path.win32.join(systemRoot,'System32');
 return function runPowerShell(args,timeout=70000){
  if(platform!=='win32')return Promise.reject(Error('Comenzile native necesită Windows 10 sau 11.'));
  if(blocked)return Promise.reject(Error('Oprirea unei comenzi Windows nu a fost confirmată. Repornește Windows înainte de alte operații CARPATIA.'));
  if(!Array.isArray(args)||args.some(x=>typeof x!=='string'||x.includes('\0'))||!Number.isFinite(timeout)||timeout<=0)return Promise.reject(Error('Parametri de execuție invalizi.'));
  return new Promise((resolve,reject)=>{
   let child,out='',err='',done=false,stopping=false,timer;
   function finish(error,result){if(done)return;done=true;cancel(timer);error?reject(error):resolve(result)}
   function abort(problem){
    if(done||stopping)return;stopping=true;cancel(timer);
    // Keep the caller's mutation lock until taskkill has finished, including children.
    if(!Number.isInteger(child.pid)||child.pid<=0){blocked=true;finish(problem);return}
    let killer,stopTimer,settled=false;
    function stopped(confirmed){
     if(settled)return;settled=true;cancel(stopTimer);
     if(!confirmed){blocked=true;problem=new Error(problem.message+' Oprirea completă nu este confirmată. Repornește Windows înainte de alte operații.');}
     finish(problem);
    }
    try{
     killer=spawnProcess(path.win32.join(system32,'taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore',shell:false});
     stopTimer=schedule(()=>{try{killer.kill()}catch{}stopped(false)},10000);
     killer.once('error',()=>stopped(false));killer.once('close',code=>stopped(code===0));
    }catch{stopped(false)}
   }
   try{
    child=spawnProcess(path.win32.join(system32,'WindowsPowerShell','v1.0','powershell.exe'),['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',...args],{windowsHide:true,stdio:['ignore','pipe','pipe'],shell:false});
   }catch(e){finish(e);return}
   timer=schedule(()=>abort(Error('Windows nu a răspuns la timp. Verifică jurnalul și restaurarea.')),timeout);
   child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
   child.on('error',e=>{if(!stopping)finish(e)});
   child.stdout.on('error',e=>abort(Error('Citirea PowerShell a eșuat: '+e.message)));
   child.stderr.on('error',e=>abort(Error('Citirea diagnosticului PowerShell a eșuat: '+e.message)));
   child.stdout.on('data',chunk=>{
    if(done||stopping)return;out+=chunk;
    if(out.length>750000)abort(Error('Ieșire PowerShell prea mare. Verifică jurnalul și restaurarea.'));
   });
   child.stderr.on('data',chunk=>{if(!done&&!stopping)err=(err+String(chunk).slice(-4500)).slice(-4500)});
   child.on('close',code=>{
    if(done||stopping)return;
    if(code!==0){finish(Error((err||out||'Operația Windows a eșuat.').slice(0,1500)));return}
    try{const result=JSON.parse(out.trim().replace(/^\uFEFF/,''));if(!result||typeof result!=='object'||Array.isArray(result))throw Error('Răspunsul nu este un obiect.');finish(null,result)}catch{finish(Error('PowerShell a întors date nevalide: '+out.slice(0,220)))}
   });
  });
 };
}
module.exports={createWindowsRunner};
