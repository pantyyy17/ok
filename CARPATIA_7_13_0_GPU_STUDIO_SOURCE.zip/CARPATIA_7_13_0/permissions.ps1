﻿$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$user=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($user)
$admin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
@{success=$true;admin=[bool]$admin;user=[string]$user.Name} | ConvertTo-Json -Compress
