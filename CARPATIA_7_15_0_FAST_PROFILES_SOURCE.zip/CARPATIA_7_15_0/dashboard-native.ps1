﻿param([string]$RequestFile='',[Parameter(Mandatory=$true)][string]$DataDir,[switch]$Worker)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
[Console]::InputEncoding=New-Object Text.UTF8Encoding($false)
$script:DashboardRoot=$PSScriptRoot
$script:RequestLimit=16384
if([string]::IsNullOrWhiteSpace($DataDir) -or -not [IO.Path]::IsPathRooted($DataDir)){throw 'Directorul de date Dashboard trebuie să fie absolut.'}
if($Worker -and $RequestFile){throw 'Modurile de solicitare Dashboard nu pot fi combinate.'}
if(-not $Worker -and -not $RequestFile){throw 'Lipsește solicitarea Dashboard.'}
$script:DashboardDataDir=[IO.Path]::GetFullPath($DataDir)
$catalog=Get-Content -LiteralPath (Join-Path $script:DashboardRoot 'tweak-library.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$script:DashboardRules=New-Object 'Collections.Generic.Dictionary[string,object]' ([StringComparer]::Ordinal)
foreach($rule in $catalog){
 if($rule.id -isnot [string] -or $script:DashboardRules.ContainsKey($rule.id)){throw 'Catalog Dashboard invalid.'}
 $script:DashboardRules.Add($rule.id,$rule)
}
function Assert-DashboardObject($value,$allowed,$required){
 if($null -eq $value -or $value -isnot [pscustomobject]){throw 'Solicitare Dashboard invalidă.'}
 $names=@($value.PSObject.Properties.Name)
 foreach($name in $names){if($name -cnotin $allowed){throw 'Câmp Dashboard nepermis.'}}
 foreach($name in $required){if($name -cnotin $names){throw 'Solicitare Dashboard incompletă.'}}
}
function Convert-DashboardRequest([string]$line){
 if([string]::IsNullOrWhiteSpace($line) -or [Text.Encoding]::UTF8.GetByteCount($line) -gt $script:RequestLimit){throw 'Solicitare Dashboard goală sau prea mare.'}
 # Requests contain only allowlisted field names. Reject escaped/duplicate keys
 # before ConvertFrom-Json can silently replace an earlier field.
 $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
 foreach($match in [regex]::Matches($line,'"(?<key>(?:[^"\\]|\\.)+)"\s*:')){
  $key=$match.Groups['key'].Value
  if($key.Contains('\') -or -not $seen.Add($key)){throw 'Câmp Dashboard duplicat sau codificat.'}
 }
 try{$value=ConvertFrom-Json -InputObject $line -ErrorAction Stop}catch{throw 'JSON Dashboard invalid.'}
 if($null -eq $value -or $value -isnot [pscustomobject]){throw 'Solicitarea Dashboard trebuie să fie un obiect.'}
 return $value
}
function Resolve-DashboardRule($id){
 if($id -isnot [string] -or $id.Length -gt 128 -or $id -cnotmatch '^library-[a-z0-9-]+$' -or -not $script:DashboardRules.ContainsKey($id)){throw 'ID Dashboard nepermis.'}
 $rule=$script:DashboardRules[$id]
 if($rule.status -cnotin @('registry','native')){throw 'Operațiile ireversibile nu sunt admise în Dashboard.'}
 return $rule
}
function Assert-DashboardAdapter($value){
 if($value -isnot [string]){throw 'Identitatea adaptorului Dashboard este invalidă.'}
 if($value -and $value -cnotmatch '^(?:[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}|\{[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}\})$'){throw 'GUID Dashboard invalid.'}
}
function Invoke-DashboardScript([string]$name,$parameters){
 # The caller supplies only literal filenames selected by this dispatcher.
 $global:LASTEXITCODE=0
 $records=@(& (Join-Path $script:DashboardRoot $name) @parameters 3>&1 4>&1 5>&1 6>&1)
 $warnings=@($records | Where-Object {$_ -is [Management.Automation.WarningRecord]} | Select-Object -First 8 | ForEach-Object {([string]$_.Message).Substring(0,[Math]::Min(300,([string]$_.Message).Length))})
 $output=@($records | Where-Object {$_ -isnot [Management.Automation.WarningRecord] -and $_ -isnot [Management.Automation.VerboseRecord] -and $_ -isnot [Management.Automation.DebugRecord] -and $_ -isnot [Management.Automation.InformationRecord]})
 $code=$global:LASTEXITCODE
 $json=($output | ForEach-Object {[string]$_}) -join "`n"
 if($json.Length -gt 750000){throw 'Răspunsul motorului Dashboard este prea mare.'}
 try{$result=ConvertFrom-Json -InputObject $json -ErrorAction Stop}catch{throw ('Răspuns invalid de la '+$name+'.')}
 if($null -eq $result -or $result -isnot [pscustomobject] -or $result.success -isnot [bool]){throw ('Răspuns incomplet de la '+$name+'.')}
 if($code -ne 0 -and $result.success){throw ('Procesul '+$name+' nu a confirmat finalizarea.')}
 if($warnings.Count){$result | Add-Member -NotePropertyName warnings -NotePropertyValue @($warnings) -Force}
 return $result
}
function Invoke-DashboardOne($rule,[string]$operation,[string]$adapter){
 if($operation -cnotin @('Check','Apply','Restore')){throw 'Operație Dashboard nepermisă.'}
 if($operation -ceq 'Apply' -and -not [string]::IsNullOrWhiteSpace([string]$rule.applyBlocked)){throw ([string]$rule.applyBlocked)}
 $parameters=@{Action=$operation;Id=$rule.id;DataDir=$script:DashboardDataDir}
 $engine='tweak-library.ps1'
 if($rule.status -ceq 'native'){$engine='tweak-native.ps1';$parameters.AdapterGuid=$adapter}
 return Invoke-DashboardScript $engine $parameters
}
function Invoke-DashboardRequest($request){
 if($request.action -isnot [string]){throw 'Acțiune Dashboard invalidă.'}
 switch -CaseSensitive ($request.action){
  'CheckMany' {
   Assert-DashboardObject $request @('action','ids','adapterGuid') @('action','ids')
   $adapter='';if($request.PSObject.Properties.Name -ccontains 'adapterGuid'){$adapter=$request.adapterGuid;Assert-DashboardAdapter $adapter}
   if($request.ids -isnot [array] -or $request.ids.Count -lt 1 -or $request.ids.Count -gt 64){throw 'Selecție Dashboard invalidă.'}
   $rules=@();$ids=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
   foreach($id in $request.ids){$rule=Resolve-DashboardRule $id;if(-not $ids.Add($id)){throw 'ID Dashboard duplicat.'};$rules+=$rule}
   $results=@()
   foreach($rule in $rules){
    try{
     $value=Invoke-DashboardOne $rule 'Check' $adapter
     $row=@{id=$rule.id};foreach($property in $value.PSObject.Properties){if($property.Name -ceq 'id' -and $property.Value -cne $rule.id){throw 'Identitatea rezultatului Dashboard nu corespunde.'};$row[$property.Name]=$property.Value};$row.id=$rule.id
     $results+=$row
    }catch{$results+=@{id=$rule.id;success=$false;message=$_.Exception.Message.Substring(0,[Math]::Min(1500,$_.Exception.Message.Length))}}
   }
   return @{success=$true;results=@($results)}
  }
  'InvokeOne' {
   Assert-DashboardObject $request @('action','id','operation','adapterGuid') @('action','id','operation')
   if($request.operation -isnot [string] -or $request.operation -cnotin @('Check','Apply','Restore')){throw 'Operație Dashboard nepermisă.'}
   $rule=Resolve-DashboardRule $request.id
   $adapter='';if($request.PSObject.Properties.Name -ccontains 'adapterGuid'){$adapter=$request.adapterGuid;Assert-DashboardAdapter $adapter}
   return Invoke-DashboardOne $rule $request.operation $adapter
  }
  'Inventory' {
   Assert-DashboardObject $request @('action') @('action')
   $states=@();$errors=@()
   foreach($engine in @('tweak-library.ps1','tweak-native.ps1')){
    try{
     $value=Invoke-DashboardScript $engine @{Action='Status';DataDir=$script:DashboardDataDir}
     if($value.states -isnot [array]){throw 'Inventar Dashboard incomplet.'}
     $states+=@($value.states)
     if(-not $value.success){$errors+=($engine+': '+(@($value.errors) -join ' | '))}
    }catch{$errors+=($engine+': '+$_.Exception.Message)}
   }
   return @{success=($errors.Count -eq 0);states=@($states);errors=@($errors)}
  }
  'Snapshot' {
   Assert-DashboardObject $request @('action') @('action')
   $hardware=Invoke-DashboardScript 'profile-hardware.ps1' @{}
   $admin=Invoke-DashboardScript 'permissions.ps1' @{}
   $registry=Invoke-DashboardScript 'engine.ps1' @{Action='Status'}
   $power=Invoke-DashboardScript 'power.ps1' @{Action='Status'}
   return @{success=($hardware.success -and $admin.success -and $admin.admin -eq $true -and $registry.success -and $power.success);hardware=$hardware;admin=$admin;registry=$registry;power=$power}
  }
  'Context' {
   Assert-DashboardObject $request @('action') @('action')
   return Invoke-DashboardScript 'tweak-native.ps1' @{Action='Context';DataDir=$script:DashboardDataDir}
  }
  default {throw 'Acțiune Dashboard nepermisă.'}
 }
}
function Read-DashboardLine {
 $builder=New-Object Text.StringBuilder
 while($true){
  $next=[Console]::In.Read()
  if($next -eq -1){if($builder.Length -eq 0){return $null};break}
  if($next -eq 10){break}
  if($builder.Length -ge $script:RequestLimit){throw 'Linie Dashboard prea mare.'}
  [void]$builder.Append([char]$next)
 }
 return $builder.ToString().TrimEnd([char]13)
}
if($Worker){
 while($true){
  $requestId=$null
  try{
   $line=Read-DashboardLine;if($null -eq $line){break}
   $envelope=Convert-DashboardRequest $line
   Assert-DashboardObject $envelope @('requestId','payload') @('requestId','payload')
   if(($envelope.requestId -isnot [int] -and $envelope.requestId -isnot [long]) -or $envelope.requestId -lt 1 -or $envelope.requestId -gt 2147483647){throw 'ID-ul solicitării Dashboard este invalid.'}
   $requestId=$envelope.requestId
   Assert-DashboardObject $envelope.payload @('action','ids','adapterGuid','id','operation') @('action')
   $result=Invoke-DashboardRequest $envelope.payload
   $reply=@{requestId=$requestId;result=$result}
  }catch{$reply=@{requestId=$requestId;error=$_.Exception.Message.Substring(0,[Math]::Min(1500,$_.Exception.Message.Length))}}
  [Console]::Out.WriteLine(($reply | ConvertTo-Json -Depth 32 -Compress));[Console]::Out.Flush()
  if($null -eq $requestId){break}
 }
 exit
}
$file=Get-Item -LiteralPath $RequestFile -ErrorAction Stop
if($file.PSIsContainer -or $file.Length -gt $script:RequestLimit -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Fișier Dashboard invalid.'}
$request=Convert-DashboardRequest (Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8)
Invoke-DashboardRequest $request | ConvertTo-Json -Depth 32 -Compress
