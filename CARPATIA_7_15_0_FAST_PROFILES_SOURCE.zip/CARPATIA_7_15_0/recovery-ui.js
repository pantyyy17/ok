'use strict';
window.CarpatiaRecovery={mount({api,task,confirmDialog,requireNative,showToast}){
 const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n};
 const active=x=>['prepared','applied','failed'].includes(x.state)&&x.reversible!==false;
 const categories={CPU:'CPU',GPU:'GPU',Network:'Internet',RAM:'Memorie',Windows:'Windows',Services:'Servicii',Storage:'Stocare',Input:'Periferice',Privacy:'Confidențialitate'};
 const states={applied:'Aplicat',prepared:'Întrerupt',failed:'Necesită verificare',restored:'Restaurat',complete:'Finalizat',partial:'Parțial',running:'Întrerupt sau în curs',captured:'Salvat',skipped:'Omis',undone:'Anulat',undoing:'Anulare întreruptă sau în curs',invalid:'Necesită diagnostic',empty:'Fără scrieri'};
 const date=v=>v&&!Number.isNaN(new Date(v).getTime())?new Date(v).toLocaleString('ro-RO'):'Dată indisponibilă';
 let focusId=null,selectedGroup=null,inventory=null,loadFlight=null,categoryIntent=null,loading=false,working=false,inventoryValid=false,selectedCount=0,managed=[];
 function report(message,details=''){$('recoveryReport').textContent=message;$('recoveryReport').hidden=!message;$('recoveryReportDetails').textContent=details;$('recoveryReportMore').hidden=!details}
 const errorText=error=>String(error?.message||error||'Operația nu a fost confirmată.').replace(/^Error invoking remote method '[^']+':\s*Error:\s*/,'');
 function controls(){
  const busy=loading||working;
  $('recoveryRows').setAttribute?.('aria-busy',String(busy));
  $('recoveryRefresh').disabled=busy;
  $('recoveryCategory').disabled=busy||!inventoryValid;
  $('recoveryRestore').disabled=busy||!inventoryValid||!selectedCount||!!inventory?.errors.length;
  $('recoverySnapshot').disabled=busy||!inventoryValid;
  for(const [button,blocked] of managed)button.disabled=busy||!inventoryValid||blocked;
 }
 function manage(button,blocked=false){managed.push([button,blocked]);button.disabled=loading||working||!inventoryValid||blocked;return button}
 async function action(label,run){
  if(working||loading)return null;
  working=true;controls();
  try{return await task(label,async()=>{try{return await run()}catch(error){report(label+' nu s-a încheiat.',errorText(error));throw error}})}
  finally{working=false;controls()}
 }
 async function reload(){
  try{await load({afterMutation:true})}
  catch(error){const detail=errorText(error);report($('recoveryReport').textContent+' Starea curentă nu poate fi reîncărcată.',$('recoveryReportDetails').textContent+'\n'+detail);showToast('Reîncarcă backupurile: '+detail)}
 }
 async function restoreProfile(group){
  if(!requireNative(true))return;
  return action('Restaurare profil',async()=>{
   if(!await confirmDialog('Restaurezi profilul '+group.toUpperCase()+'?','Se verifică originalele profilului și se restaurează numai pașii salvați.','','O sesiune deja restaurată va fi finalizată fără a inventa sau șterge originale.','RESTAUREAZĂ PROFILUL'))return;
   report('Se restaurează profilul '+group.toUpperCase()+'…');
   try{const r=await api.dashboardRestore(group);report(r.message,(r.results||[]).map(x=>x.id+': '+(x.success?'Restaurat':x.message)).join('\n'));return r}
   finally{await reload()}
  });
 }
 function renderOverview(s,all){
  const profiles=s.profiles||[],stats=$('recoveryStats'),root=$('recoveryProfiles');
  if(stats){stats.replaceChildren();for(const [label,value,attention] of [['Originale active',all.length,false],['Profiluri active',profiles.filter(x=>x.active).length,false],['Copii manuale',s.history.filter(x=>x.type==='manual-snapshot'&&x.restorable!==false).length,false],['Necesită atenție',s.errors.length+(s.historyErrors||[]).length+(s.transactions||[]).filter(x=>!['complete','undone','empty'].includes(x.state)).length,true]]){const card=el('div','','recovery-stat'),number=el('strong',String(value));if(attention&&value)number.className='attention';card.append(el('small',label),number);stats.append(card)}}
  if(root){root.replaceChildren();if(!profiles.length)root.append(el('p','Starea profilurilor nu a fost încă citită.'));
   for(const p of profiles){const card=el('article','','recovery-profile');card.append(el('h3',p.group==='internet'?'Internet':p.group.toUpperCase()));
    card.append(el('p',p.error||(!p.active?'Niciun profil de restaurat.':(p.level||'Profil').toUpperCase()+' · '+p.remaining+' pași salvați')));
    if(p.active){const b=manage(el('button',p.recoverable===false?'DIAGNOSTIC NECESAR':'RESTAUREAZĂ PROFILUL','action outline'),p.recoverable===false);b.onclick=()=>restoreProfile(p.group);card.append(b)}else card.append(el('span','Disponibil pentru analiză','profile-idle'));root.append(card)}
  }
 }
 function render(){
  const s=inventory,root=$('recoveryRows'),category=$('recoveryCategory');root.replaceChildren();managed=[];
  const all=s.items.filter(active),selected=all.filter(x=>(!selectedGroup||x.group===selectedGroup)&&(!category.value||x.category===category.value));
  renderOverview(s,all);
  $('recoverySummary').textContent=s.errors.length?'Unele backupuri nu pot fi citite. Vezi detaliile de mai jos.':all.length?`${all.length} setări au valori originale salvate.`:'Nicio modificare de restaurat.';
  selectedCount=selected.length;
  $('recoveryRestore').textContent=selectedGroup?'RESTAUREAZĂ PROFILUL '+selectedGroup.toUpperCase():category.value?'RESTAUREAZĂ '+(categories[category.value]||category.value).toUpperCase():'RESTAUREAZĂ TOT';
  $('recoveryErrors').hidden=!s.errors.length&&!(s.historyErrors||[]).length;$('recoveryErrorText').textContent=[...s.errors,...(s.historyErrors||[]).map(x=>'Istoric: '+x)].join('\n');
  if(!selected.length)root.append(el('p',category.value?'Nu există modificări de restaurat în această categorie.':'Când aplici setări prin Carpatia, valorile originale sunt salvate automat și apar aici.','recovery-empty'));
  for(const item of selected){
   const row=el('article','','recovery-card');row.dataset.recoveryId=item.id;
   const info=el('div','','recovery-item-info');info.append(el('h3',item.title),el('small',`${categories[item.category]||item.category} · ${states[item.state]||'De verificat'} · ${date(item.date)}`));row.append(info);
   const b=manage(el('button','RESTAUREAZĂ','action outline'),!!s.errors.length);b.onclick=()=>preview({id:item.id});row.append(b);root.append(row);
  }
  $('recoveryIndividualSummary').textContent=`Alege o singură setare (${selected.length})`;
  const history=$('recoveryHistory');history.replaceChildren();
  const entries=[...(s.transactions||[]),...s.history,...s.items.filter(x=>x.state==='restored')].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  if(!entries.length)history.append(el('p','Nu există încă operații salvate.','recovery-empty'));
  for(const h of entries){
   const d=el('details',''),kind=h.type==='manual-snapshot'?'Copie manuală':h.type==='snapshot-restore'?'Restaurare copie manuală':h.type==='restore'?'Restaurare':h.title||'Backup anterior';
   d.append(el('summary',`${kind} · ${date(h.date)} · ${states[h.state]||'Salvat'}`));
   if(h.type==='manual-snapshot'&&h.id&&h.restorable!==false){const restore=manage(el('button','RESTAUREAZĂ ACEASTĂ COPIE','action outline'));restore.onclick=()=>restoreSnapshot(h.id);d.append(restore)}
   if(h.error)d.append(el('p',h.error));
   if(h.type==='snapshot-restore'&&!['undone','empty','invalid'].includes(h.state)&&h.recoverable!==false){if(h.state!=='complete'){const retry=manage(el('button',h.direction==='undo'?'REIA ANULAREA':'REIA RESTAURAREA','action outline'));retry.onclick=()=>resumeSnapshot(h.id,h.direction==='undo');d.append(retry)}const undo=manage(el('button','REVINO ÎNAINTE DE RESTAURARE','action outline'));undo.onclick=()=>resumeSnapshot(h.id,true);d.append(undo)}
   for(const r of h.results||h.rows||[])d.append(el('p',`${r.title||'Setare'} — ${states[r.status]||r.status||'De verificat'}${r.message?' · '+r.message:''}`));
   const technical=el('details','');technical.append(el('summary','Detalii tehnice'),el('pre',JSON.stringify(h,null,2)));d.append(technical);history.append(d);
  }
  if(focusId){const row=[...root.children].find(x=>x.dataset?.recoveryId===focusId);if(row){$('recoveryIndividual').open=true;row.scrollIntoView({block:'center'});row.classList.add('recovery-focus')}focusId=null}
  controls();
 }
 async function load(options={}){
  if(!api)return;
  if(Object.hasOwn(options,'category'))categoryIntent=options.category;
  if(working&&!options.afterMutation)return inventory;
  if(loadFlight)return loadFlight;
  loading=true;controls();$('recoverySummary').textContent='Se citesc backupurile salvate…';
  const flight=Promise.resolve().then(()=>api.recoveryInventory()).then(s=>{
   if(!s||!Array.isArray(s.items)||!Array.isArray(s.errors)||!Array.isArray(s.history))throw Error('Inventarul backupurilor este incomplet.');
   inventory=s;inventoryValid=true;
   const category=$('recoveryCategory'),old=categoryIntent??category.value;categoryIntent=null;category.replaceChildren(new Option('Toate setările',''));
   for(const c of [...new Set(s.items.filter(active).map(x=>x.category))].sort())category.append(new Option(categories[c]||c,c));category.value=s.items.some(x=>active(x)&&x.category===old)?old:'';render();return s;
  }).catch(error=>{inventoryValid=false;selectedCount=0;$('recoverySummary').textContent='Starea backupurilor nu poate fi verificată. Actualizează pentru a reîncerca.';throw error})
   .finally(()=>{loading=false;if(loadFlight===flight)loadFlight=null;controls()});
  loadFlight=flight;return flight;
 }
 async function preview(selection){
  if(!requireNative(true))return;
  return action('Restaurare',async()=>{
   report('Se verifică originalele selectate…');
   const plan=await api.recoveryPrepare(selection);
   const detail=plan.rows.map(x=>'• '+x.title+(x.restart?' — necesită restart':'')).join('\n');
   if(!await confirmDialog('Revii la setările anterioare?',`Vor fi restaurate ${plan.rows.length} setări din valorile salvate de Carpatia.`,detail,'Setările modificate ulterior din exterior pot necesita verificare. Backupurile nereușite sunt păstrate.','RESTAUREAZĂ')){report('Restaurare anulată. Nu s-a modificat nimic.');return}
   report('Restaurare în curs…');
   try{const r=await api.recoveryCommit(plan.token);report(`${r.succeeded} restaurate · ${r.failed} nereușite · ${r.skipped} omise${r.restartRequired?' · Repornește Windows.':''}`,r.results.map(x=>x.title+': '+(states[x.status]||x.status)+' — '+(x.message||'')).join('\n'));return r}
   finally{await reload()}
  });
 }
 $('recoveryRefresh').onclick=()=>task('Citire backupuri',load);
 $('recoveryCategory').onchange=()=>{selectedGroup=null;if(inventory)render()};
 $('recoveryRestore').onclick=()=>preview(selectedGroup?{group:selectedGroup}:$('recoveryCategory').value?{category:$('recoveryCategory').value}:{});
 $('recoverySnapshot').onclick=()=>{if(!requireNative(true))return;return action('Backup manual',async()=>{
  if(!await confirmDialog('Salvezi o copie manuală?','Copia păstrează starea actuală a setărilor gestionate. Nu modifică Windows.','','O poți restaura din Istoric. Mai întâi trebuie restaurate modificările cu backup automat, pentru a păstra originalele.','SALVEAZĂ COPIA'))return;
  report('Se salvează copia. Operația poate dura câteva minute…');
  try{const r=await api.recoverySnapshot();report(r.success?'Copia a fost salvată.':'Copia a fost salvată parțial. Vezi istoricul.',r.message);return r}finally{await reload()}
 })};
 async function restoreSnapshot(id){if(!requireNative(true))return;return action('Restaurare copie',async()=>{
  report('Se verifică copia și valorile curente…');
  const plan=await api.snapshotPrepare(id),changed=plan.rows.filter(x=>x.changed);
  const warning=(plan.partial?'Copia este parțială; se restaurează numai valorile salvate cu succes. ':'')+(plan.legacy?'Copie veche, fără identificarea calculatorului. Confirmă numai dacă a fost creată pe acest PC și în acest cont. ':'')+(plan.rows.some(x=>['security','boot'].includes(x.impact))?'Include setări de securitate sau de pornire. ':'')+'Se salvează starea curentă pentru revenire. Rețeaua se poate întrerupe.';
  if(!await confirmDialog('Restaurezi copia manuală?',`${changed.length} valori diferă de copia salvată.`,[...new Set(changed.map(x=>x.title))].join('\n'),warning,'RESTAUREAZĂ COPIA')){report('Restaurare anulată. Nu s-a modificat nimic.');return}
  report('Se restaurează copia manuală…');
  try{const r=await api.snapshotCommit(plan.token);reportSnapshot(r);return r}finally{await reload()}
 })}
 function reportSnapshot(r){report(`${r.succeeded} ${r.direction==='undo'?'anulate':'restaurate'} · ${r.failed} nereușite · ${r.skipped} deja corecte${r.restartRequired?' · Necesită restart.':''}`,r.rows.map(x=>x.title+': '+(states[x.status]||x.status)+' '+(x.message||'')).join('\n'))}
 async function resumeSnapshot(id,undo){if(!requireNative(true))return;return action('Recuperare copie',async()=>{if(!await confirmDialog(undo?'Revii înainte de restaurare?':'Reiei restaurarea?',undo?'Se folosesc valorile salvate înainte de restaurarea copiei.':'Se verifică din nou starea fiecărei valori.','','Modificările externe nu sunt suprascrise automat.','CONFIRMĂ'))return;report(undo?'Se anulează restaurarea copiei…':'Se reia restaurarea copiei…');try{const r=await api.snapshotResume(id,undo);reportSnapshot(r);return r}finally{await reload()}})}
 api?.onBackupProgress?.(event=>report('Copie de backup în curs…',event.detail));
 return {load,open(selection={}){selectedGroup=selection.group||null;focusId=selection.id||null;return load({category:selection.category||''})},focus(id){focusId=id;load().catch(e=>showToast(e.message))}};
}};
