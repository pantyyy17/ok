'use strict';
window.CarpatiaDashboardProfiles={mount({api,task,requireNative,confirmDialog,showToast,onOwner}){
 const $=id=>document.getElementById(id);
 let adaptersLoaded=false,lastConflict='',loadId=0,generation=0,statusFlight=null,adapterFlight=null,lastStatus=null,operation=null,destroyed=false;
 const groups={cpu:['CPU','heroDebloat'],gpu:['GPU','heroUltra'],internet:['INTERNET','heroNetwork']};
 const hints={cpu:{low:'Planificare foreground și priorități multimedia.',medium:'LOW + procesor maxim 100% la priză.',high:'MEDIUM + plan performant, EPP și cache de sistem.',ultra:'HIGH + boost, nuclee, USB și limite CPU pe AC; adaptat hardware-ului.'},gpu:{low:'Game Mode și oprirea capturii Game DVR.',medium:'LOW + captură continuă/audio și aplicații UWP în fundal.',high:'MEDIUM + preferințe fullscreen.',ultra:'HIGH + Game Mode automat, HAGS și politica PCIe pe AC.'},internet:{low:'DNS ales și oprirea distribuirii P2P.',medium:'LOW + RSS și auto-tuning TCP Normal.',high:'MEDIUM + Fast Open și limitarea multimedia.',ultra:'HIGH + temporizare TCP, proxy și reglaje NIC suportate.'}};
 const errorText=error=>String(error?.message||error).replace(/^Error invoking remote method '[^']+':\s*Error:\s*/,'');
 const node=(tag,text)=>{const n=document.createElement(tag);n.textContent=text;return n};
 function tierHint(group){const target=$('profileHint-'+group);if(target)target.textContent=hints[group][$('profileLevel-'+group).value]||''}
 function message(value){if(!destroyed)$('heroOpStatus').textContent=value}
 function summaryText(summary){
  if(!summary||['changed','already','reused','skipped'].some(key=>!Number.isInteger(summary[key])||summary[key]<0||summary[key]>1000))return '';
  return `${summary.changed} modificate · ${summary.already} deja configurate · ${summary.reused} reutilizate · ${summary.skipped} omise`;
 }
 function controls(){
  if(destroyed)return;
  for(const [group,[,id]] of Object.entries(groups)){
   const state=lastStatus?.find(row=>row.group===group),button=$(id),working=operation?.group===group;
   button.disabled=!!operation;
   button.setAttribute?.('aria-busy',String(working));
   const primaryAction=state?.active?state.recoverable===false?'diagnostic':'restore':'apply';
   if(state?.active)button.classList?.add('is-active');else button.classList?.remove('is-active');
   button.setAttribute?.('aria-label',(primaryAction==='diagnostic'?'Verifică backupul pentru':primaryAction==='restore'?'Restaurează':'Analizează')+' profilul '+groups[group][0]);
   if(button.dataset){button.dataset.profileAction=primaryAction;if(working)button.dataset.profilePhase=operation.phase;else delete button.dataset.profilePhase}
   const caption=button.querySelector?.('.reactor-face small');if(caption)caption.textContent=working?operation.label:primaryAction==='diagnostic'?'VEZI BACKUPUL':primaryAction==='restore'?'RESTAUREAZĂ':'ANALIZEAZĂ';
   const legacyRestore=$('restoreProfile-'+group);if(legacyRestore)legacyRestore.disabled=!!operation||!state?.active||state.recoverable===false;
   $('profileLevel-'+group).disabled=working;
   if($('profileAuxiliary-'+group))$('profileAuxiliary-'+group).disabled=working;
   if(working){
    const hint=button.querySelector?.('.reactor-state');if(hint)hint.textContent=operation.label;
    $('profileState-'+group).textContent=operation.detail;
   }
  }
  $('refreshProfiles').disabled=!!operation;
  $('dashboardAdapter').disabled=!!adapterFlight||operation?.group==='internet';
 }
 function render(){
  if(destroyed)return;
  const recovery=$('dashboardRecovery');recovery?.replaceChildren();
  for(const [group,[label,buttonId]] of Object.entries(groups)){
   const state=lastStatus?.find(row=>row.group===group);
   if(!state){$('profileState-'+group).textContent='Starea profilului nu a fost citită.';continue}
   const hint=$(buttonId).querySelector?.('.reactor-state');
   if(hint)hint.textContent=state.observed==='active'?'ACTIV':state.observed==='partial'?'PARȚIAL':state.observed==='unknown'?'NEVERIFICAT':state.active?'SALVAT':'';
   let description=state.active?`${(state.level||'profil').toUpperCase()} · ${state.state!=='applied'?'NECESITĂ RECUPERARE':({active:'ACTIV · VERIFICAT',partial:'PARȚIAL ACTIV',inactive:'INACTIV · BACKUP PĂSTRAT',unknown:'STARE NECUNOSCUTĂ'})[state.observed]||'APLICAT · BACKUP PĂSTRAT'}`:'Niciun profil activ';
   if(state.active&&state.state==='applied'){
    const summary=summaryText(state.summary);if(summary)description+=' · La aplicare: '+summary;
    if(state.observed&&Number.isInteger(state.matching)&&Number.isInteger(state.total)&&state.total>0&&state.matching>=0&&state.matching<=state.total)description+=` · Potriviri citite acum: ${state.matching}/${state.total}`;
   }
   $('profileState-'+group).textContent=description;
   if(recovery&&state.active&&state.recoverable!==false){const b=node('button','RESTAUREAZĂ '+label+' · '+(state.level||'profil').toUpperCase());b.className='action outline';b.disabled=!!operation;b.onclick=()=>restore(group);recovery.append(b)}
  }
  if($('dashboardBackupCount'))$('dashboardBackupCount').textContent=lastStatus?lastStatus.filter(row=>row.active).length+' profiluri cu backup':'Backupuri necitite';
  if(recovery&&lastConflict&&onOwner){const b=node('button','DESCHIDE BACKUP & RESTORE');b.className='action outline';b.disabled=!!operation;b.onclick=()=>onOwner({id:lastConflict,route:'tweaks'});recovery.append(b)}
  if(recovery&&!recovery.children.length)recovery.append(node('p',lastStatus?'Nu există profiluri Dashboard active.':'Starea backupurilor nu a fost citită.'));
  controls();
 }
 function readStatus(verify){
  if(statusFlight&&statusFlight.generation===generation&&(statusFlight.verify||!verify))return statusFlight.promise;
  const request=++loadId,currentGeneration=generation;
  const reader=!verify&&typeof api.dashboardSummary==='function'?api.dashboardSummary:api.dashboardStatus;
  if(typeof reader!=='function')return Promise.reject(Error('Starea profilurilor nu poate fi citită.'));
  const entry={generation:currentGeneration,verify};
  entry.promise=Promise.resolve().then(()=>reader.call(api)).then(status=>{
   if(!Array.isArray(status)||Object.keys(groups).some(group=>typeof status.find(row=>row?.group===group)?.active!=='boolean'))throw Error('Stare Dashboard incompletă.');
   if(!destroyed&&request===loadId&&currentGeneration===generation){lastStatus=status;render()}
   return status;
  }).finally(()=>{if(statusFlight===entry)statusFlight=null});
  statusFlight=entry;return entry.promise;
 }
 function readAdapters(refresh){
  if(adapterFlight)return adapterFlight;
  if(adaptersLoaded&&!refresh)return Promise.resolve();
  const reader=typeof api.dashboardContext==='function'?api.dashboardContext:api.tweakLibraryContext;
  if(typeof reader!=='function')return Promise.resolve();
  const pending=Promise.resolve().then(()=>reader.call(api)).then(context=>{
   if(destroyed)return;
   const select=$('dashboardAdapter'),old=select.value;
   select.replaceChildren();const placeholder=node('option','Alege adaptorul…');placeholder.value='';select.append(placeholder);
   for(const adapter of context.adapters||[]){const option=node('option',adapter.name+' · '+adapter.status);option.value=adapter.guid;select.append(option)}
   select.value=old;adaptersLoaded=true;
  }).catch(error=>{if(!destroyed)showToast('Adaptoarele nu au fost încărcate: '+errorText(error))})
   .finally(()=>{if(adapterFlight===pending)adapterFlight=null;controls()});
  adapterFlight=pending;controls();return pending;
 }
 async function load({refreshAdapters=false,skipAdapters=false,verify=false,internal=false}={}){
  if(!api||destroyed)return;
  if(operation&&!internal)return lastStatus;
  const status=await readStatus(verify);
  if(!skipAdapters&&!destroyed&&!operation)await readAdapters(refreshAdapters);
  return status;
 }
 function phase(group,name,detail){
  if(destroyed||operation?.group!==group)return;
  operation.phase=name;operation.label=({prepare:'ANALIZEZ',confirm:'CONFIRMĂ',apply:'APLIC',restore:'RESTAUREZ',refresh:'ACTUALIZEZ'})[name]||'VERIFIC';
  operation.detail=detail;message(detail);controls();
 }
 async function action(group,label,initialPhase,detail,run){
  if(destroyed)return;
  if(operation){showToast('Profilul '+groups[operation.group][0]+' este în curs. Urmărește progresul afișat.');return null}
  const previousMessage=$('heroOpStatus').textContent;let entered=false;
  operation={group,phase:initialPhase,label:'',detail};++generation;++loadId;
  const button=$(groups[group][1]);button.classList?.remove('is-error','is-complete');button.classList?.add('is-working');
  phase(group,initialPhase,detail);
  try{return await task(label,()=>{entered=true;return run()},groups[group][1])}
  finally{
   if(!destroyed){operation=null;++generation;++loadId;button.classList?.remove('is-working');render();if(!entered)message(previousMessage)}
  }
 }
 async function refreshAfterAction(group){
  const detail=operation?.detail;
  phase(group,'refresh','Actualizez starea salvată a profilului…');
  try{await load({skipAdapters:true,internal:true})}catch(error){showToast('Reîncarcă starea profilurilor: '+errorText(error))}
  if(detail)message(detail);
 }
 async function run(group){
  if(!Object.hasOwn(groups,group)||destroyed)return;
  const state=lastStatus?.find(row=>row.group===group);
  if(state?.active){if(state.recoverable===false){message(state.error||'Jurnalul profilului necesită diagnostic în Backup & Restore.');showToast(state.error||'Jurnalul profilului necesită diagnostic în Backup & Restore.');onOwner?.({group,route:'dashboard'});return}return restore(group)}
  if(!requireNative())return;
  const level=$('profileLevel-'+group).value,adapterGuid=group==='internet'?$('dashboardAdapter').value:'';
  if(group==='internet'&&!adapterGuid){const select=$('dashboardAdapter'),options=select.closest?.('details');if(options)options.open=true;select.focus?.();showToast('Alege adaptorul Internet înainte de analiză.');return}
  return action(group,'Profil '+groups[group][0],'prepare','Analizez profilul '+groups[group][0]+' și originalele păstrate…',async()=>{
   let refreshNeeded=false;
   try{
    lastConflict='';
    const options={auxiliary:$('profileAuxiliary-'+group)?.checked===true};if(group==='internet')options.dns=$('profileDns')?.value||'google';
    const request={group,level,adapterGuid};if(options.auxiliary||options.dns)request.options=options;
    const prepared=await api.dashboardPrepare(request);if(destroyed)return;
    const plan=prepared.plan;
    const skipped=(plan.skipped||[]).map(step=>'• '+step.title+': '+step.reason);
    const details=plan.steps.map((step,i)=>`${i+1}. ${step.title}${plan.reuse?.includes(step.id)?' · deja aplicat; se păstrează originalul existent':''}${step.restart?' · restart':''}`).join('\n')+(skipped.length?'\n\nOMISE PENTRU ACEST PC:\n'+skipped.join('\n'):'')+(adapterGuid?'\nAdaptor: '+($('dashboardAdapter').selectedOptions?.[0]?.textContent||adapterGuid):'');
    phase(group,'confirm',`${plan.steps.length} opțiuni disponibile${skipped.length?' · '+skipped.length+' omise pentru compatibilitate':''}. Aștept confirmarea.`);
    if(!await confirmDialog('Aplici '+plan.title+'?',`${plan.steps.length} opțiuni disponibile. Fiecare modificare păstrează originalul pentru restaurare.`,details,plan.warning+' Performanța depinde de hardware și trebuie măsurată.','APLICĂ PROFILUL')||destroyed){message('Anulat. Nicio modificare aplicată.');return}
    refreshNeeded=true;phase(group,'apply','Aplic profilul '+groups[group][0]+'; originalele sunt păstrate…');
    const result=await api.dashboardCommit(prepared.token),summary=result.success===true?summaryText(result.summary):'';
    const detail=result.message+(summary?' Rezultat: '+summary+'.':'')+(result.restartRequired?' Repornește Windows pentru efectele care cer restart.':'');
    operation.detail=detail;message(detail);showToast(result.message);return result;
   }catch(error){
    const detail=errorText(error);refreshNeeded=true;
    if(/Conflict real:|backup|recuperare|jurnal/i.test(detail))lastConflict=detail.match(/library-[a-z0-9-]+/)?.[0]||'recovery';
    operation.detail=detail;message(detail);throw error;
   }finally{if(refreshNeeded)await refreshAfterAction(group)}
  });
 }
 async function restore(group){
  if(!Object.hasOwn(groups,group)||!requireNative(true))return;
  return action(group,'Restaurare '+groups[group][0],'confirm','Confirmă restaurarea profilului '+groups[group][0]+'.',async()=>{
   if(!await confirmDialog('Restaurezi '+groups[group][0]+'?','Se revin în ordine inversă setările profilului la valorile salvate înainte de aplicare.','','Originalele sunt verificate înainte de restaurare. Conflictele sunt raportate și păstrate pentru diagnostic. Rețeaua se poate întrerupe; unele setări necesită restart.','RESTAUREAZĂ')||destroyed){message('Restaurare anulată. Nicio modificare aplicată.');return}
   try{
    phase(group,'restore','Restaurez profilul '+groups[group][0]+' din originalele păstrate…');
    const result=await api.dashboardRestore(group);operation.detail=result.message;message(result.message);showToast(result.message);return result;
   }catch(error){operation.detail=errorText(error);message(operation.detail);throw error}
   finally{await refreshAfterAction(group)}
  });
 }
 for(const group of Object.keys(groups)){const legacyRestore=$('restoreProfile-'+group);if(legacyRestore)legacyRestore.onclick=()=>restore(group);$('profileLevel-'+group).addEventListener?.('change',()=>tierHint(group));tierHint(group)}
 $('refreshProfiles').onclick=()=>task('Stare profiluri',()=>load({refreshAdapters:true,verify:true}));
 const unsubscribe=api?.onDashboardProgress?.(event=>{
  if(!operation||destroyed||!event||event.group&&event.group!==operation.group||['analyze','status'].includes(event.phase)||typeof event.detail!=='string')return;
  const count=Number.isInteger(event.completed)&&Number.isInteger(event.total)&&event.completed>=0&&event.total>0&&event.completed<=event.total?` (${event.completed}/${event.total})`:'';
  phase(operation.group,event.phase==='apply'?'apply':event.phase==='restore'?'restore':operation.phase,event.detail+count);
 });
 return {run,load,restore,destroy(){destroyed=true;++generation;++loadId;if(typeof unsubscribe==='function')unsubscribe()}};
}};
