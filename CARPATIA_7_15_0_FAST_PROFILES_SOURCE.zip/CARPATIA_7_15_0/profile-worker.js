'use strict';
const {spawn}=require('node:child_process');
const path=require('node:path');

// A worker lives for one profile operation. Requests remain sequential so the
// caller can durably save each step's intent before asking Windows to write it.
function createProfileWorkerRunner({spawnProcess=spawn,platform=process.platform,systemRoot=process.env.SystemRoot||'C:\\Windows',schedule=setTimeout,cancel=clearTimeout,guard={blocked:false}}={}){
 const system32=path.win32.join(systemRoot,'System32');
 const blocked=()=>Error('Oprirea unei comenzi Windows nu a fost confirmată. Repornește Windows înainte de alte operații CARPATIA.');
 return function start(args){
  if(platform!=='win32')throw Error('Comenzile native necesită Windows 10 sau 11.');
  if(guard.blocked)throw blocked();
  if(!Array.isArray(args)||args.some(value=>typeof value!=='string'||value.includes('\0')))throw Error('Parametri de execuție invalizi.');
  const child=spawnProcess(path.win32.join(system32,'WindowsPowerShell','v1.0','powershell.exe'),['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',...args],{windowsHide:true,stdio:['pipe','pipe','pipe'],shell:false});
  let pending=null,serial=0,buffer='',diagnostic='',timer=null,closeTimer=null,ended=false,closing=false,stopping=false,terminalError=null,complete;
  const completion=new Promise(resolve=>{complete=resolve});
  function clearTimers(){cancel(timer);cancel(closeTimer);timer=null;closeTimer=null}
  function finish(error){
   if(ended)return;ended=true;clearTimers();terminalError=error||null;
   const item=pending;pending=null;
   if(item)item.reject(error||Error('Sesiunea Windows s-a închis fără rezultatul solicitat.'));
   complete(terminalError);
  }
  function abort(problem){
   if(ended||stopping)return;stopping=true;clearTimers();terminalError=problem;
   // Do not release a caller's mutation lock while the original process tree
   // might still be writing. A shared guard also blocks the one-shot runner.
   if(!Number.isInteger(child.pid)||child.pid<=0){guard.blocked=true;finish(blocked());return}
   let killer,killTimer,settled=false;
   function stopped(confirmed){
    if(settled)return;settled=true;cancel(killTimer);
    if(!confirmed){guard.blocked=true;problem=Error(problem.message+' Oprirea completă nu este confirmată. Repornește Windows înainte de alte operații.')}
    finish(problem);
   }
   try{
    killer=spawnProcess(path.win32.join(system32,'taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore',shell:false});
    killTimer=schedule(()=>{try{killer.kill()}catch{}stopped(false)},10000);
    killer.once('error',()=>stopped(false));killer.once('close',code=>stopped(code===0));
   }catch{stopped(false)}
  }
  function invalidReply(){abort(Error('PowerShell a întors un răspuns de profil invalid. Verifică jurnalul și restaurarea.'))}
  function readLine(line){
   if(!line.trim())return;
   let reply;try{reply=JSON.parse(line.trim().replace(/^\uFEFF/,''))}catch{invalidReply();return}
   const keys=reply&&typeof reply==='object'&&!Array.isArray(reply)?Object.keys(reply):[];
   if(!pending||keys.length!==2||!Number.isSafeInteger(reply?.requestId)||reply.requestId!==pending.id||!keys.includes('requestId')){invalidReply();return}
   const result=Object.hasOwn(reply,'result'),error=Object.hasOwn(reply,'error');
   if(result===error||result&&(!reply.result||typeof reply.result!=='object'||Array.isArray(reply.result))||error&&(typeof reply.error!=='string'||!reply.error||reply.error.length>4500)){invalidReply();return}
   const item=pending;pending=null;cancel(timer);timer=null;
   error?item.reject(Error(reply.error)):item.resolve(reply.result);
  }
  child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
  child.stdout.on('data',chunk=>{
   if(ended||stopping)return;buffer+=String(chunk);
   if(buffer.length>750000){abort(Error('Ieșire PowerShell prea mare. Verifică jurnalul și restaurarea.'));return}
   let newline;
   while(!ended&&!stopping&&(newline=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,newline);buffer=buffer.slice(newline+1);readLine(line)}
  });
  child.stderr.on('data',chunk=>{if(!ended&&!stopping)diagnostic=(diagnostic+String(chunk).slice(-4500)).slice(-4500)});
  child.stdout.on('error',error=>abort(Error('Citirea PowerShell a eșuat: '+error.message)));
  child.stderr.on('error',error=>abort(Error('Citirea diagnosticului PowerShell a eșuat: '+error.message)));
  child.stdin.on('error',error=>abort(Error('Trimiterea solicitării PowerShell a eșuat: '+error.message)));
  child.on('error',error=>{
   if(ended||stopping)return;
   if(!Number.isInteger(child.pid)||child.pid<=0)finish(error);else abort(error);
  });
  child.on('close',code=>{
   if(ended||stopping)return;
   if(closing&&!pending&&code===0&&!buffer.trim()){finish(null);return}
   finish(Error((diagnostic||'Sesiunea Windows s-a închis înainte de finalizarea verificărilor.').slice(0,1500)));
  });
  function request(payload,timeout=180000){
   if(guard.blocked)return Promise.reject(blocked());
   if(ended||closing||stopping)return Promise.reject(terminalError||Error('Sesiunea Windows este închisă.'));
   if(pending)return Promise.reject(Error('Așteaptă finalizarea solicitării Windows curente.'));
   if(!payload||typeof payload!=='object'||Array.isArray(payload)||!Number.isFinite(timeout)||timeout<=0)return Promise.reject(Error('Solicitare de profil invalidă.'));
   let input;try{input=JSON.stringify({requestId:serial+1,payload})}catch{return Promise.reject(Error('Solicitare de profil invalidă.'))}
   if(Buffer.byteLength(input,'utf8')>16384)return Promise.reject(Error('Solicitarea de profil este prea mare.'));
   return new Promise((resolve,reject)=>{
    pending={id:++serial,resolve,reject};diagnostic='';
    timer=schedule(()=>abort(Error('Windows nu a răspuns la timp. Verifică jurnalul și restaurarea.')),timeout);
    try{child.stdin.write(input+'\n','utf8',error=>{if(error)abort(Error('Trimiterea solicitării PowerShell a eșuat: '+error.message))})}
    catch(error){abort(Error('Trimiterea solicitării PowerShell a eșuat: '+error.message))}
   });
  }
  function close(){
   if(!ended&&!closing&&!stopping){
    closing=true;
    if(pending)abort(Error('Sesiunea Windows a fost închisă în timpul unei operații. Verifică jurnalul și restaurarea.'));
    else{
     closeTimer=schedule(()=>abort(Error('Sesiunea Windows nu s-a închis la timp.')),5000);
     try{child.stdin.end()}catch(error){abort(Error('Închiderea sesiunii Windows a eșuat: '+error.message))}
    }
   }
   return completion.then(error=>{if(error)throw error});
  }
  return {request,close};
 };
}
module.exports={createProfileWorkerRunner};
