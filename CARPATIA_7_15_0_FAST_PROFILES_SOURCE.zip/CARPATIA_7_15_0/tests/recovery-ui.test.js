'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function harness(confirm,overrides={}){
 class E{constructor(text=''){this.textContent=text;this.children=[];this.value='';this.dataset={};this.classList={add(){}}}append(...x){this.children.push(...x)}replaceChildren(...x){this.children=x}scrollIntoView(){}}
 const nodes={},calls=[],window={};
 const item={id:'library-cpu-035',title:'Kernel paging',category:'CPU',state:'applied',date:'2026-10-27',original:0,live:{current:1},restart:true};
 const api={recoveryInventory:async()=>({items:[item],errors:[],history:[]}),recoveryPrepare:async s=>{calls.push(['prepare',s]);return {token:'token',rows:[item]}},recoveryCommit:async token=>{calls.push(['commit',token]);return {success:true,succeeded:1,failed:0,skipped:0,restartRequired:true,results:[{title:item.title,status:'restored'}]}},...overrides};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../recovery-ui.js'),'utf8'),{window,document:{getElementById:id=>nodes[id]??=new E(),createElement:()=>new E()},Option:class extends E{constructor(t,v){super(t);this.value=v}}});
 const page=window.CarpatiaRecovery.mount({api,task:(_,fn)=>fn(),confirmDialog:async()=>confirm,requireNative:()=>true,showToast:()=>{}});return {page,nodes,calls,api,item};
}
test('recovery renders named item and confirmed individual restore, with report',async()=>{const h=harness(true);await h.page.load();const row=h.nodes.recoveryRows.children[0];await row.children.find(x=>x.textContent==='RESTAUREAZĂ').onclick();assert.equal(h.calls[0][1].id,'library-cpu-035');assert.deepEqual(h.calls[1],['commit','token']);assert.match(h.nodes.recoveryReport.textContent,/1 restaurate/)});
test('canceling restore never invokes commit',async()=>{const h=harness(false);await h.page.load();await h.nodes.recoveryRestore.onclick();assert.equal(h.calls.length,1)});
test('simultaneous navigation shares one inventory read and keeps the latest category intent',async()=>{
 let resolve,reads=0;const pending=new Promise(r=>resolve=r),h=harness(true,{recoveryInventory:()=>{reads++;return pending}});
 const first=h.page.load(),second=h.page.open({category:'GPU'});assert.equal(h.nodes.recoveryRestore.disabled,true);assert.match(h.nodes.recoverySummary.textContent,/citesc/);
 await Promise.resolve();assert.equal(reads,1);
 resolve({items:[h.item,{...h.item,id:'gpu',category:'GPU'}],errors:[],history:[]});await Promise.all([first,second]);
 assert.equal(h.nodes.recoveryCategory.value,'GPU');assert.equal(h.nodes.recoveryRows.children.length,1);assert.equal(h.nodes.recoveryRefresh.disabled,false);
});
test('pending preview gives immediate feedback and ignores repeated restore clicks',async()=>{
 let resolve,prepares=0;const pending=new Promise(r=>resolve=r),h=harness(false,{recoveryPrepare:()=>{prepares++;return pending}});await h.page.load();
 const first=h.nodes.recoveryRestore.onclick();assert.match(h.nodes.recoveryReport.textContent,/verifică originalele/);assert.equal(h.nodes.recoveryRestore.disabled,true);
 await h.nodes.recoveryRestore.onclick();assert.equal(prepares,1);resolve({token:'cancelled',rows:[h.item]});await first;
 assert.match(h.nodes.recoveryReport.textContent,/anulată/);assert.equal(h.nodes.recoveryRestore.disabled,false);assert.equal(h.calls.length,0);
});
test('failed native restoration refreshes retained originals and exposes a retry',async()=>{
 let reads=0;const h=harness(true,{recoveryInventory:async()=>{reads++;return {items:[{id:'kept',category:'CPU',title:'Original păstrat',state:'failed'}],errors:[],history:[]}},recoveryCommit:async()=>{throw Error('Original retained: access denied')}});await h.page.load();
 await assert.rejects(h.nodes.recoveryRestore.onclick(),/access denied/);
 assert.equal(reads,2);assert.match(h.nodes.recoveryReportDetails.textContent,/Original retained/);assert.equal(h.nodes.recoveryRestore.disabled,false);assert.equal(h.nodes.recoveryRows.children[0].children[1].disabled,false);
});
test('successful restore report survives a failed refresh while stale controls stay blocked',async()=>{
 let reads=0;const h=harness(true,{recoveryInventory:async()=>{if(++reads>1)throw Error('Status unavailable');return {items:[{id:'a',category:'CPU',title:'CPU',state:'applied'}],errors:[],history:[]}}});await h.page.load();
 const r=await h.nodes.recoveryRestore.onclick();assert.equal(r.success,true);assert.match(h.nodes.recoveryReport.textContent,/1 restaurate/);assert.match(h.nodes.recoveryReportDetails.textContent,/Status unavailable/);assert.equal(h.nodes.recoveryRestore.disabled,true);assert.equal(h.nodes.recoveryRefresh.disabled,false);
});
test('empty and invalid manual-copy transactions do not advertise retry or undo',async()=>{
 const h=harness(true,{recoveryInventory:async()=>({items:[],errors:[],history:[],transactions:[{id:'empty',type:'snapshot-restore',state:'empty'},{id:'invalid',type:'snapshot-restore',state:'invalid'}]})});await h.page.load();
 const texts=[];function visit(node){texts.push(node.textContent);for(const child of node.children)visit(child)}visit(h.nodes.recoveryHistory);
 assert(!texts.some(text=>/^REIA|^REVINO/.test(text)));
});
