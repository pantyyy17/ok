'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {descriptor}=require('../dashboard-profiles');
function ui({confirm=true,active=false,prepareError=null,summary=null,matching,total,observed='active',commitResult=null,lightweight=false,task:runTask=null,legacy=true}={}){
 class Element{constructor(){this.children=[];this.value='';this.textContent='';this.dataset={};this.attributes={};this.state={textContent:''};this.caption={textContent:''};this.classes=new Set();this.classList={add:(...tokens)=>tokens.forEach(token=>this.classes.add(token)),remove:(...tokens)=>tokens.forEach(token=>this.classes.delete(token))}}append(x){this.children.push(x)}replaceChildren(...x){this.children=x}setAttribute(name,value){this.attributes[name]=value}querySelector(selector){return selector==='.reactor-state'?this.state:selector==='.reactor-face small'?this.caption:null}}
 const ids=Object.fromEntries(['heroDebloat','heroUltra','heroNetwork','heroOpStatus','dashboardAdapter','dashboardRecovery','refreshProfiles',...['cpu','gpu','internet'].flatMap(g=>['restoreProfile-'+g,'profileLevel-'+g,'profileState-'+g])].map(id=>[id,new Element()]));
 for(const g of ['cpu','gpu','internet'])ids['profileLevel-'+g].value='low';
 if(!legacy)for(const group of ['cpu','gpu','internet'])delete ids['restoreProfile-'+group];
 const calls=[],recovery=[],toasts=[],reads={adapters:0,status:0,summary:0},listeners={};
 const status=()=>['cpu','gpu','internet'].map(group=>({group,active:active&&group==='cpu',state:'applied',level:'high',observed,...(group==='cpu'?{summary,matching,total}:{})}));
 const api={dashboardStatus:async()=>{reads.status++;return status()},tweakLibraryContext:async()=>{reads.adapters++;return {adapters:[]}},dashboardPrepare:async r=>{if(prepareError)throw Error(prepareError);calls.push(['prepare',r]);return {token:'abc',plan:descriptor(r.group,r.level,r.adapterGuid)}},dashboardCommit:async t=>{calls.push(['commit',t]);return commitResult||{success:true,message:'applied'}},dashboardRestore:async g=>{calls.push(['restore',g]);return {success:true,message:'restored'}},onDashboardProgress:listener=>{listeners.progress=listener;return ()=>{delete listeners.progress}}};
 if(lightweight)api.dashboardSummary=async()=>{reads.summary++;return status().map(({observed,matching,total,...row})=>row)};
 const window={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../dashboard-profiles-ui.js'),'utf8'),{window,document:{getElementById:id=>ids[id],createElement:()=>new Element()}});
 const page=window.CarpatiaDashboardProfiles.mount({api,task:runTask||((_,f)=>f()),requireNative:r=>{recovery.push(!!r);return true},confirmDialog:async()=>confirm,onOwner:o=>calls.push(['owner',o.id||o.group]),showToast:t=>toasts.push(t)});
 return {ids,calls,recovery,toasts,page,reads,api,listeners,status,progress:event=>listeners.progress?.(event)};
}
test('dashboard sends selected subsystem and level, then commits only returned token',async()=>{
 const x=ui();x.ids['profileLevel-gpu'].value='ultra';await x.page.run('gpu');assert.deepEqual(JSON.parse(JSON.stringify(x.calls)),[['prepare',{group:'gpu',level:'ultra',adapterGuid:''}],['commit','abc']]);assert.equal(x.ids.heroOpStatus.textContent,'applied');
});
test('cancelled dashboard confirmation never commits',async()=>{
 const x=ui({confirm:false});await x.page.run('cpu');assert.equal(x.calls.length,1);assert.match(x.ids.heroOpStatus.textContent,/Anulat/);
});
test('Internet requires explicit adapter before contacting mutation API',async()=>{
 const x=ui();await x.page.run('internet');assert.equal(x.calls.length,0);assert.match(x.toasts[0],/adaptorul/);
});
test('active profile changes the same mountain into license-independent restoration',async()=>{
 const x=ui({active:true});await x.page.load();assert.equal(x.ids.heroDebloat.disabled,false);assert.equal(x.ids.heroDebloat.dataset.profileAction,'restore');assert.equal(x.ids.heroDebloat.caption.textContent,'RESTAUREAZĂ');assert.equal(x.ids['restoreProfile-cpu'].disabled,false);
 await x.page.run('cpu');assert.deepEqual(x.calls,[['restore','cpu']]);assert.equal(x.recovery[0],true);
});
test('an invalid profile opens backup diagnostics through the same mountain instead of a dead button',async()=>{
 const x=ui({active:true,legacy:false});x.api.dashboardSummary=async()=>x.status().map(row=>row.group==='cpu'?{...row,recoverable:false,state:'invalid',error:'Jurnal invalid; păstrează originalele.'}:row);
 await x.page.load();assert.equal(x.ids.heroDebloat.disabled,false);assert.equal(x.ids.heroDebloat.dataset.profileAction,'diagnostic');assert.equal(x.ids.heroDebloat.caption.textContent,'VEZI BACKUPUL');
 await x.page.run('cpu');assert.deepEqual(x.calls,[['owner','cpu']]);assert.match(x.ids.heroOpStatus.textContent,/păstrează originalele/);assert.equal(x.recovery.length,0);
});
test('profile controls and script order are present in shipped HTML',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
 for(const g of ['cpu','gpu','internet'])for(const prefix of ['profileLevel-','profileState-'])assert.ok(html.includes('id="'+prefix+g+'"'));
 assert.ok(html.indexOf('src="dashboard-profiles-ui.js"')<html.indexOf('src="ui.js"'));
});

test('profile status refresh reuses adapter inventory until explicit refresh',async()=>{
 const x=ui();await x.page.load();await x.page.load();assert.equal(x.reads.adapters,1);
 await x.ids.refreshProfiles.onclick();assert.equal(x.reads.adapters,2);
});

test('apply and restore never inventory adapters while holding the mutation task',async()=>{
 const x=ui();await x.page.run('cpu');await x.page.restore('cpu');assert.equal(x.reads.adapters,0);
});

test('real conflict offers owner navigation without automatic restore or apply',async()=>{
 const x=ui({prepareError:'Conflict real: HAGS [library-cpu-013]. Restaureaza acest tweak.'});
 await assert.rejects(x.page.run('gpu'),/Conflict real/);
 const b=x.ids.dashboardRecovery.children.find(x=>x.textContent.includes('DESCHIDE BACKUP'));
 assert.ok(b);b.onclick();assert.deepEqual(x.calls,[['owner','library-cpu-013']]);
});
test('profile state separates saved application counts from the current hardware readback',async()=>{
 const x=ui({active:true,summary:{changed:4,already:1,reused:1,skipped:2},matching:3,total:6,observed:'partial'});await x.page.load({skipAdapters:true});
 const text=x.ids['profileState-cpu'].textContent;assert.match(text,/PARȚIAL ACTIV/);assert.match(text,/La aplicare: 4 modificate · 1 deja configurate · 1 reutilizate · 2 omise/);assert.match(text,/Potriviri citite acum: 3\/6/);
});
test('successful commit shows concrete counts while failed rollback never presents them as completed gains',async()=>{
 const summary={changed:1,already:1,reused:0,skipped:0};
 const good=ui({commitResult:{success:true,message:'Aplicat',summary}});await good.page.run('cpu');assert.match(good.ids.heroOpStatus.textContent,/Rezultat: 1 modificate · 1 deja configurate · 0 reutilizate · 0 omise/);
 const failed=ui({commitResult:{success:false,message:'Aplicare anulată și restaurată',summary}});await failed.page.run('cpu');assert.equal(failed.ids.heroOpStatus.textContent,'Aplicare anulată și restaurată');
});

const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r});return {promise,resolve}};
const flush=()=>new Promise(setImmediate);
test('a pending analysis immediately marks only its mountain busy and rejects repeat profile actions',async()=>{
 const x=ui({confirm:false}),pending=deferred();let prepares=0;
 x.api.dashboardPrepare=request=>{prepares++;return pending.promise};
 const first=x.page.run('cpu');
 assert.equal(x.ids.heroDebloat.attributes['aria-busy'],'true');assert.equal(x.ids.heroDebloat.dataset.profilePhase,'prepare');assert.equal(x.ids.heroDebloat.caption.textContent,'ANALIZEZ');assert.equal(x.ids.heroUltra.attributes['aria-busy'],'false');assert.equal(x.ids.heroDebloat.disabled,true);assert.match(x.ids.heroOpStatus.textContent,/Analizez profilul CPU/);
 await x.page.run('gpu');assert.equal(prepares,1);assert.match(x.toasts.at(-1),/CPU este în curs/);
 pending.resolve({token:'later',plan:descriptor('cpu','low','')});await first;
 assert.equal(x.ids.heroDebloat.attributes['aria-busy'],'false');assert.equal(x.ids.heroDebloat.disabled,false);assert.equal(x.ids.heroDebloat.caption.textContent,'ANALIZEAZĂ');assert.equal(x.reads.status,0);
});
test('lightweight saved summaries and adapter context are preferred while explicit verification remains available',async()=>{
 const x=ui({active:true,lightweight:true});let contexts=0;
 x.api.dashboardContext=async()=>{contexts++;return {adapters:[]}};
 await x.page.load();assert.equal(x.reads.summary,1);assert.equal(x.reads.status,0);assert.equal(x.reads.adapters,0);assert.equal(contexts,1);
 assert.match(x.ids['profileState-cpu'].textContent,/APLICAT · BACKUP PĂSTRAT/);assert.doesNotMatch(x.ids['profileState-cpu'].textContent,/VERIFICAT|Potriviri citite acum/);
 await x.ids.refreshProfiles.onclick();assert.equal(x.reads.status,1);assert.equal(contexts,2);assert.match(x.ids['profileState-cpu'].textContent,/ACTIV · VERIFICAT/);
});
test('simultaneous dashboard loads share one status read and one adapter inventory',async()=>{
 const x=ui({lightweight:true}),pending=deferred();let reads=0;
 x.api.dashboardSummary=()=>{reads++;return pending.promise};
 const first=x.page.load(),second=x.page.load();await flush();assert.equal(reads,1);
 pending.resolve(x.status());await Promise.all([first,second]);assert.equal(x.reads.adapters,1);
});
test('a late startup response cannot unlock or overwrite the feedback for an active analysis',async()=>{
 const x=ui({confirm:false,lightweight:true}),old=deferred(),analysis=deferred();
 x.api.dashboardSummary=()=>old.promise;x.api.dashboardPrepare=()=>analysis.promise;
 const startup=x.page.load({skipAdapters:true});await flush();const action=x.page.run('cpu');
 old.resolve(x.status());await startup;assert.equal(x.ids.heroDebloat.disabled,true);assert.equal(x.ids.heroDebloat.dataset.profilePhase,'prepare');assert.match(x.ids['profileState-cpu'].textContent,/Analizez/);
 analysis.resolve({token:'later',plan:descriptor('cpu','low','')});await action;
});
test('canceling apply or restore never rereads profiles or adapters and never commits',async()=>{
 const x=ui({confirm:false,lightweight:true});await x.page.run('cpu');await x.page.restore('gpu');
 assert.equal(x.reads.summary,0);assert.equal(x.reads.status,0);assert.equal(x.reads.adapters,0);assert.equal(x.calls.filter(row=>row[0]==='commit'||row[0]==='restore').length,0);assert.match(x.ids.heroOpStatus.textContent,/Restaurare anulată/);
});
test('restore failures remain visible and the same mountain retains the recovery action',async()=>{
 const x=ui({active:true,lightweight:true,legacy:false});await x.page.load({skipAdapters:true});
 x.api.dashboardRestore=async()=>{throw Error("Error invoking remote method 'dashboardRestore': Error: Originalul nu poate fi citit")};
 await assert.rejects(x.page.run('cpu'),/Originalul/);assert.equal(x.ids.heroOpStatus.textContent,'Originalul nu poate fi citit');assert.equal(x.ids.heroDebloat.dataset.profileAction,'restore');assert.equal(x.ids.heroDebloat.disabled,false);assert.equal(x.reads.status,0);assert.equal(x.reads.summary,2);assert.equal(x.recovery.at(-1),true);
});
test('restore progress stays group-specific and external refresh cannot interrupt or unlock the operation',async()=>{
 const x=ui({active:true,lightweight:true,legacy:false}),pending=deferred();let active=true;
 x.api.dashboardSummary=async()=>x.status().map(row=>({...row,active:active&&row.group==='cpu'}));
 await x.page.load({skipAdapters:true});x.api.dashboardRestore=()=>pending.promise;
 const action=x.page.run('cpu');await flush();assert.equal(x.ids.heroDebloat.caption.textContent,'RESTAUREZ');
 const before=x.ids.heroOpStatus.textContent;x.progress({group:'gpu',phase:'restore',detail:'Altă operație',completed:1,total:2});assert.equal(x.ids.heroOpStatus.textContent,before);
 x.progress({group:'cpu',phase:'restore',detail:'Original CPU recitit',completed:1,total:2});assert.equal(x.ids.heroOpStatus.textContent,'Original CPU recitit (1/2)');
 await x.page.load({skipAdapters:true,verify:true});assert.equal(x.reads.status,0);assert.equal(x.ids.heroDebloat.disabled,true);assert.equal(x.ids.heroDebloat.attributes['aria-busy'],'true');
 active=false;pending.resolve({success:true,message:'Originalele au fost restaurate'});await action;
 assert.equal(x.ids.heroDebloat.dataset.profileAction,'apply');assert.equal(x.ids.heroDebloat.caption.textContent,'ANALIZEAZĂ');assert.equal(x.ids.heroDebloat.disabled,false);assert.equal(x.ids.heroOpStatus.textContent,'Originalele au fost restaurate');
});
test('one mountain applies, restores and reapplies without separate restore controls',async()=>{
 const x=ui({lightweight:true,legacy:false});let active=false;
 x.api.dashboardSummary=async()=>x.status().map(row=>({...row,active:active&&row.group==='cpu'}));
 x.api.dashboardCommit=async token=>{x.calls.push(['commit',token]);active=true;return {success:true,message:'Aplicat'}};
 x.api.dashboardRestore=async group=>{x.calls.push(['restore',group]);active=false;return {success:true,message:'Restaurat'}};
 await x.page.load({skipAdapters:true});await x.page.run('cpu');assert.equal(x.ids.heroDebloat.dataset.profileAction,'restore');assert.match(x.ids.heroDebloat.attributes['aria-label'],/Restaurează/);
 await x.page.run('cpu');assert.equal(x.ids.heroDebloat.dataset.profileAction,'apply');await x.page.run('cpu');
 assert.equal(x.calls.filter(row=>row[0]==='commit').length,2);assert.equal(x.calls.filter(row=>row[0]==='restore').length,1);assert.deepEqual(x.recovery,[false,true,false]);
});
test('a missing Internet adapter opens and focuses the advanced selector before any native operation',async()=>{
 const x=ui(),details={open:false};let focused=false;
 x.ids.dashboardAdapter.closest=selector=>selector==='details'?details:null;x.ids.dashboardAdapter.focus=()=>{focused=true};
 await x.page.run('internet');assert.equal(details.open,true);assert.equal(focused,true);assert.equal(x.calls.length,0);
});
test('the shared task lock can reject a profile without leaving false analysis feedback',async()=>{
 const x=ui({task:()=>null});x.ids.heroOpStatus.textContent='Altă operație în curs';await x.page.run('cpu');
 assert.equal(x.calls.length,0);assert.equal(x.ids.heroOpStatus.textContent,'Altă operație în curs');assert.equal(x.ids.heroDebloat.attributes['aria-busy'],'false');assert.equal(x.ids.heroDebloat.disabled,false);
});
test('destroying a pending preview removes progress listeners and never commits afterward',async()=>{
 const x=ui(),pending=deferred();x.api.dashboardPrepare=()=>pending.promise;
 const action=x.page.run('cpu');x.page.destroy();assert.equal(x.listeners.progress,undefined);
 pending.resolve({token:'late',plan:descriptor('cpu','low','')});await action;assert.equal(x.calls.length,0);assert.equal(x.reads.status,0);
});
