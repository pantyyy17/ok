'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createProfileWorkerRunner}=require('../profile-worker'),{createWindowsRunner}=require('../windows-process');
function harness(options={}){
 const calls=[],timers=new Map(),guard=options.guard||{blocked:false};let serial=0;
 const spawnProcess=(file,args,spawnOptions)=>{
  if(options.spawnFailure)throw Error('spawn denied');
  const child=new EventEmitter();child.pid=600+calls.length;
  for(const name of ['stdout','stderr','stdin']){child[name]=new EventEmitter();child[name].setEncoding=()=>{}}
  child.stdin.writes=[];child.stdin.write=(value,encoding,callback)=>{child.stdin.writes.push(value);if(options.writeFailure)callback(Error('broken pipe'));else callback();return true};
  child.stdin.end=()=>{child.stdin.ended=true};child.kill=()=>{child.killed=true};
  calls.push({file,args,options:spawnOptions,child});return child;
 };
 const schedule=(f,ms)=>{const id=++serial;timers.set(id,{f,ms});return id},cancel=id=>timers.delete(id);
 const config={platform:'win32',systemRoot:'C:\\Windows',spawnProcess,schedule,cancel,guard};
 const start=createProfileWorkerRunner(config),session=start(['-File','C:\\App Folder\\dashboard-native.ps1','-Worker','-DataDir','C:\\Data Folder']);
 const answer=(result,requestId=1)=>calls[0].child.stdout.emit('data',JSON.stringify({requestId,result})+'\n');
 return {start,session,config,calls,timers,guard,answer,fire(ms){const [id,{f}]=[...timers].find(([,v])=>ms===undefined||v.ms===ms)||[];assert(id,'expected pending timer '+ms);timers.delete(id);f()}};
}
async function cleanClose(h){const close=h.session.close();h.calls[0].child.emit('close',0);await close;assert.equal(h.timers.size,0)}
test('one PowerShell host serves sequential profile requests with correlated fragmented UTF-8 JSON replies',async()=>{
 const h=harness(),c=h.calls[0],first=h.session.request({action:'CheckMany',ids:['library-cpu-005']});
 assert.deepEqual(JSON.parse(c.child.stdin.writes[0]),{requestId:1,payload:{action:'CheckMany',ids:['library-cpu-005']}});
 c.child.stdout.emit('data','\uFEFF{"requestId":1,"result":{"success":');c.child.stdout.emit('data','true}}\r\n');assert.deepEqual(await first,{success:true});
 const second=h.session.request({action:'InvokeOne',id:'library-cpu-005',operation:'Apply'});h.answer({success:true,verified:true},2);assert.equal((await second).verified,true);
 assert.equal(h.calls.length,1);assert.equal(c.file,'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe');assert.equal(c.options.shell,false);assert.deepEqual(c.options.stdio,['pipe','pipe','pipe']);assert(c.args.includes('C:\\App Folder\\dashboard-native.ps1'));
 await cleanClose(h);assert.equal(c.child.stdin.ended,true);await assert.rejects(h.session.request({action:'Inventory'}),/închisă/);
});
test('dispatcher errors reject only that request and preserve the worker for verified recovery',async()=>{
 const h=harness(),first=h.session.request({action:'InvokeOne',operation:'Apply'});h.calls[0].child.stdout.emit('data','{"requestId":1,"error":"Originalul este păstrat."}\n');await assert.rejects(first,/Originalul/);
 const restore=h.session.request({action:'InvokeOne',operation:'Restore'});h.answer({success:false,backupAvailable:true},2);assert.equal((await restore).backupAvailable,true);assert.equal(h.calls.length,1);await cleanClose(h);
});
test('parallel, oversized and malformed requests never write to stdin',async()=>{
 const h=harness();for(const payload of [null,[],true,'text'])await assert.rejects(h.session.request(payload),/invalidă/);
 await assert.rejects(h.session.request({action:'Inventory'},0),/invalidă/);await assert.rejects(h.session.request({data:'x'.repeat(16384)}),/prea mare/);
 const circular={};circular.self=circular;await assert.rejects(h.session.request(circular),/invalidă/);
 const p=h.session.request({action:'Inventory'});await assert.rejects(h.session.request({action:'Inventory'}),/curente/);assert.equal(h.calls[0].child.stdin.writes.length,1);h.answer({success:true});await p;await cleanClose(h);
});
test('foreign, duplicate-shaped and non-object replies terminate before returning an untrusted result',async()=>{
 const bad=['not json','null','[]','{"requestId":null,"error":"bad"}','{"requestId":2,"result":{}}','{"requestId":1,"result":[]}','{"requestId":1,"result":true}','{"requestId":1,"result":{},"error":"bad"}','{"requestId":1,"result":{},"extra":true}','{"requestId":1,"error":""}'];
 for(const reply of bad){
  const h=harness(),p=h.session.request({action:'Inventory'});let settled=false;p.catch(()=>settled=true);
  h.calls[0].child.stdout.emit('data',reply+'\n');assert.equal(h.calls.length,2);await Promise.resolve();assert.equal(settled,false);
  h.calls[1].child.emit('close',0);await assert.rejects(p,/invalid/);await assert.rejects(h.session.close(),/invalid/);assert.equal(h.guard.blocked,false);assert.equal(h.timers.size,0);
 }
});
test('timeout keeps the mutation lock until the entire process tree is confirmed stopped',async()=>{
 const h=harness(),p=h.session.request({action:'InvokeOne'},90);let settled=false;p.catch(()=>settled=true);h.fire(90);
 assert.equal(h.calls.length,2);assert.deepEqual(h.calls[1].args,['/PID','600','/T','/F']);
 h.answer({success:true});h.calls[0].child.emit('close',0);await Promise.resolve();assert.equal(settled,false);
 h.calls[1].child.emit('close',0);await assert.rejects(p,/nu a răspuns/);await assert.rejects(h.session.close(),/nu a răspuns/);assert.equal(h.guard.blocked,false);assert.equal(h.timers.size,0);
 const next=h.start([]);assert.equal(h.calls.length,3);const close=next.close();h.calls[2].child.emit('close',0);await close;
});
test('unconfirmed taskkill blocks both worker and one-shot Windows launches through the shared guard',async()=>{
 const h=harness(),p=h.session.request({action:'InvokeOne'},90);h.fire(90);h.calls[1].child.emit('close',1);await assert.rejects(p,/nu este confirmată/);
 assert.equal(h.guard.blocked,true);assert.throws(()=>h.start([]),/Repornește Windows/);await assert.rejects(createWindowsRunner(h.config)([]),/Repornește Windows/);assert.equal(h.calls.length,2);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
});
test('taskkill error and a hung taskkill conservatively preserve the shared stop guard',async()=>{
 for(const mode of ['error','timeout']){
  const h=harness(),p=h.session.request({action:'Inventory'},90);h.fire(90);
  if(mode==='error')h.calls[1].child.emit('error',Error('denied'));else{h.fire(10000);assert.equal(h.calls[1].child.killed,true)}
  await assert.rejects(p,/nu este confirmată/);assert.equal(h.guard.blocked,true);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
 }
});
test('output limit and stream failures trigger only one bounded tree stop',async()=>{
 for(const mode of ['oversize','stdout','stderr','stdin']){
  const h=harness(),p=h.session.request({action:'InvokeOne'});
  if(mode==='oversize')h.calls[0].child.stdout.emit('data','x'.repeat(750001));else h.calls[0].child[mode].emit('error',Error('broken'));
  h.calls[0].child.stdout.emit('data','another\n');assert.equal(h.calls.length,2);h.calls[1].child.emit('close',0);
  await assert.rejects(p,mode==='oversize'?/prea mare/:/eșuat/);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
 }
});
test('stdin write failure waits for tree termination and reports the original failure',async()=>{
 const h=harness({writeFailure:true}),p=h.session.request({action:'Inventory'});h.calls[1].child.emit('close',0);await assert.rejects(p,/broken pipe/);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
});
test('explicit close during an active request does not release its caller before tree termination',async()=>{
 const h=harness(),p=h.session.request({action:'InvokeOne'}),close=h.session.close();let settled=false;p.catch(()=>settled=true);close.catch(()=>{});
 await Promise.resolve();assert.equal(settled,false);assert.equal(h.calls.length,2);h.calls[1].child.emit('close',0);await assert.rejects(p,/în timpul/);await assert.rejects(close,/în timpul/);assert.equal(h.timers.size,0);
});
test('idle close waits for EOF shutdown and a hung idle process is terminated with bounded cleanup',async()=>{
 const h=harness(),close=h.session.close();let settled=false;close.catch(()=>settled=true);
 assert.equal(h.calls[0].child.stdin.ended,true);h.fire(5000);assert.equal(h.calls.length,2);await Promise.resolve();assert.equal(settled,false);
 h.calls[1].child.emit('close',0);await assert.rejects(close,/nu s-a închis/);assert.equal(h.guard.blocked,false);assert.equal(h.timers.size,0);
});
test('an unexpected exit or truncated JSON cannot appear successful',async()=>{
 for(const code of [0,1]){
  const h=harness(),p=h.session.request({action:'Inventory'});h.calls[0].child.stdout.emit('data','{"requestId":1,"result":');h.calls[0].child.stderr.emit('data','x'.repeat(12000));h.calls[0].child.emit('close',code);
  await assert.rejects(p,error=>error.message.length===1500);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
 }
});
test('spawn errors and invalid start options never authorize a request',async()=>{
 assert.throws(()=>createProfileWorkerRunner({platform:'linux'})([]),/Windows 10/);assert.throws(()=>createProfileWorkerRunner({platform:'win32'})(['bad\0value']),/Parametri/);
 assert.throws(()=>harness({spawnFailure:true}),/spawn denied/);
 const h=harness();h.calls[0].child.pid=undefined;h.calls[0].child.emit('error',Error('ENOENT'));await assert.rejects(h.session.request({action:'Inventory'}),/ENOENT/);await assert.rejects(h.session.close(),/ENOENT/);assert.equal(h.calls.length,1);assert.equal(h.timers.size,0);
});
test('an unsolicited reply closes an idle worker and cannot satisfy a later request',async()=>{
 const h=harness();h.answer({success:true});assert.equal(h.calls.length,2);h.calls[1].child.emit('close',0);await assert.rejects(h.session.request({action:'Inventory'}),/invalid/);await assert.rejects(h.session.close());assert.equal(h.timers.size,0);
});
test('uncertain stop of the one-shot runner also blocks worker startup',async()=>{
 const h=harness(),close=h.session.close();h.calls[0].child.emit('close',0);await close;
 const run=createWindowsRunner(h.config),p=run([],90);h.fire(90);h.calls[2].child.emit('close',1);await assert.rejects(p,/nu este confirmată/);assert.throws(()=>h.start([]),/Repornește Windows/);
});
