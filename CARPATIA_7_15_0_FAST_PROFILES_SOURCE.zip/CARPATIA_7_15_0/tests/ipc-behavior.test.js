'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const root=path.resolve(__dirname,'..');
function boot(t,{packaged=false,dev=false,primary=true,nativeRun=null,notificationWindows=[],publicKey=null,dialog={},dataDirectory=null,gpuHelper=false}={}){
 const dir=dataDirectory||fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-ipc-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const handlers=new Map();let ready,windows=0,quit=0;
 class Window {constructor(){windows++;this.webContents={setWindowOpenHandler(){},session:{setPermissionRequestHandler(){}},on(){}}} once(){}on(){}loadFile(){} static getAllWindows(){return notificationWindows}}
 const electron={app:{isPackaged:packaged,getPath:()=>dir,requestSingleInstanceLock:()=>primary,quit:()=>quit++,on(){},whenReady:()=>({then:fn=>{ready=fn}})},BrowserWindow:Window,ipcMain:{handle:(name,fn)=>handlers.set(name,fn)},dialog,shell:{}};
 const fakeProcess={platform:'win32',env:dev?{CARPATIA_DEV_MODE:'1'}:{}};
 const appFs=Object.create(fs);appFs.readFileSync=(file,...args)=>publicKey&&file===path.join(root,'license-public.pem')?publicKey:fs.readFileSync(file,...args);
 appFs.existsSync=file=>gpuHelper&&file===path.join(root,'native','gpu-tuning','bin','carpatia-gpu-tuning.exe')?true:fs.existsSync(file);
 const workerEvents=[];
 const native=(file,action,...args)=>nativeRun(['-File',path.join(root,file),...(action?['-Action',action]:[]),...args]);
 async function dispatch(payload){
  const operation=async(id,action,adapter='')=>{const rule=require('../tweak-library-core').getRule(id);return native(require('../tweak-library-core').engineFor(id),action,'-Id',id,'-DataDir',dir,...(rule.status==='native'?['-AdapterGuid',adapter]:[]))};
  if(payload.action==='InvokeOne')return operation(payload.id,payload.operation,payload.adapterGuid);
  if(payload.action==='CheckMany'){const results=[];for(const id of payload.ids)results.push({...await operation(id,'Check',payload.adapterGuid),id});return {success:true,results}}
  if(payload.action==='Inventory'){const results=await Promise.all(['tweak-library.ps1','tweak-native.ps1'].map(file=>native(file,'Status','-DataDir',dir)));return {success:results.every(r=>r.success===true),states:results.flatMap(r=>r.states||[]),errors:results.flatMap(r=>r.errors||[])}}
  // Existing fixture hardware replies model the minimal OS/RAM/GPU snapshot too.
  if(payload.action==='Snapshot'){const [hardware,admin,registry,power]=await Promise.all([native('inspect.ps1'),native('permissions.ps1'),native('engine.ps1','Status'),native('power.ps1','Status')]);return {success:hardware.success===true&&admin.admin===true&&registry.success===true&&power.success===true,hardware,admin,registry,power}}
  if(payload.action==='Context')return native('tweak-native.ps1','Context','-DataDir',dir);
  throw Error('Unexpected profile action');
 }
 const wrappedNative=async args=>String(args[args.indexOf('-File')+1]).endsWith('dashboard-native.ps1')?dispatch(JSON.parse(fs.readFileSync(args[args.indexOf('-RequestFile')+1],'utf8'))):nativeRun(args);
 const customRequire=name=>name==='node:fs'?appFs:name==='electron'?electron:name==='./windows-process'&&nativeRun?{createWindowsRunner:()=>wrappedNative}:name==='./profile-worker'&&nativeRun?{createProfileWorkerRunner:()=>args=>{workerEvents.push({phase:'start',args});return {request:async payload=>{workerEvents.push({phase:'request',payload});return dispatch(payload)},close:async()=>{workerEvents.push({phase:'close'})}}}}:name.startsWith('./')?require(path.join(root,name)):require(name);
 vm.runInNewContext(fs.readFileSync(path.join(root,'main.js'),'utf8'),{require:customRequire,__dirname:root,process:fakeProcess,console,setTimeout,clearTimeout,URL});ready();
 const url=require('node:url').pathToFileURL(path.join(root,'index.html')).href;
 return {dir,handlers,workerEvents,event:{senderFrame:{url},sender:{getURL:()=>url}},get windows(){return windows},get quit(){return quit}};
}
test('source mode requires license unless developer explicitly opts in',t=>{
 for(const options of [{},{packaged:true,dev:true}]){const x=boot(t,options);assert.equal(x.handlers.get('licenseStatus')(x.event).active,false)}
 const d=boot(t,{dev:true});assert.equal(d.handlers.get('licenseStatus')(d.event).developer,true);
});
test('unlicensed recovery reaches argument validation but mutations are gated',async t=>{
 const x=boot(t);
 await assert.rejects(x.handlers.get('startupRestore')(x.event,''),/Nume Startup invalid/);
 await assert.rejects(x.handlers.get('gpuRestore')(x.event),/Alege .exe/);
 await assert.rejects(x.handlers.get('dashboardRestore')(x.event,'invalid'),/Modul necunoscut/);
 assert.equal((await x.handlers.get('dashboardStatus')(x.event)).length,3);
 for(const name of ['gpuApply','startupDisable','cleanupRun','tweakApply','dashboardCommit','dashboardPrepare'])await assert.rejects(x.handlers.get(name)(x.event),/licență validă/);
});
test('foreign IPC frame is rejected',t=>{
 const x=boot(t);assert.throws(()=>x.handlers.get('licenseStatus')({senderFrame:{url:'https://evil.invalid'}}),/origine/);
});
test('secondary process does not create a window',t=>{
 const x=boot(t,{primary:false});assert.equal(x.windows,0);assert.equal(x.quit,1);
});

test('service Apply already Disabled is a no-op even when called directly over IPC',async t=>{
 const calls=[];const x=boot(t,{dev:true,nativeRun:async args=>{calls.push(args);return {success:true,elevated:true,items:[{id:'search',name:'WSearch',installed:true,startMode:'Disabled',state:'Stopped',backup:false}]}}});
 const r=await x.handlers.get('servicesChange')(x.event,'Apply','search');assert.equal(r.already,true);assert.equal(calls.length,1);assert.ok(calls[0].includes('Status'));
});
test('independent tweak backup does not prevent service backend Apply and lock releases',async t=>{
 const calls=[];const x=boot(t,{dev:true,nativeRun:async args=>{calls.push(args);if(args.includes('Status'))return {success:true,elevated:true,items:[{id:'search',name:'WSearch',installed:true,startMode:'Auto',state:'Running',backup:false}]};return {success:true}}});
 const rule=require('../tweak-library.json').find(x=>x.id==='library-cpu-035'),dir=path.join(x.dir,'tweak-library-backups');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,rule.id+'.json'),JSON.stringify({version:1,id:rule.id,state:'applied',values:rule.entries.map(e=>({...e,exists:true,kind:'DWord',value:0}))}));
 assert.equal((await x.handlers.get('servicesChange')(x.event,'Apply','search')).success,true);assert.equal(calls.filter(a=>a.includes('Apply')).length,1);
 await assert.rejects(x.handlers.get('servicesChange')(x.event,'Apply','invalid'),/necunoscut/);
 assert.equal((await x.handlers.get('servicesChange')(x.event,'Apply','search')).success,true);
});
test('same-service foreign journal prevents backend Apply despite stale UI',async t=>{
 let writes=0;const x=boot(t,{dev:true,nativeRun:async args=>{if(args.includes('Apply'))writes++;return {success:true,elevated:true,items:[{id:'search',name:'WSearch',installed:true,startMode:'Auto',state:'Running',backup:false}]}}});
 const dir=path.join(x.dir,'tweak-native-backups');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'library-cpu-010.json'),JSON.stringify({version:1,id:'library-cpu-010',state:'applied',operation:{type:'service'},before:[{name:'WSearch',start:2,running:true,delayedExists:false,delayed:0}]}));
 await assert.rejects(x.handlers.get('servicesChange')(x.event,'Apply','search'),/library-cpu-010/);assert.equal(writes,0);
});

test('service Restore after restart uses existing validated legacy original without license',async t=>{
 let restores=0;const x=boot(t,{nativeRun:async args=>{if(args.includes('Restore')){restores++;return {success:true}}return {success:true,elevated:true,items:[{id:'search',name:'WSearch',installed:true,startMode:'Disabled',state:'Stopped',backup:true}]}}});
 const dir=path.join(x.dir,'TweakRomania','Backups');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,'services-search.json');const content=JSON.stringify({version:1,id:'search',name:'WSearch',before:{name:'WSearch',startMode:'Auto',state:'Running',delayedAutoStart:null}});fs.writeFileSync(file,content);
 assert.equal((await x.handlers.get('servicesChange')(x.event,'Restore','search')).success,true);assert.equal(restores,1);assert.equal(fs.readFileSync(file,'utf8'),content);
});
test('Dashboard IPC permits the reported independent adv-002 backup without deleting it',async t=>{
 const rule=require('../tweak-library.json').find(x=>x.id==='library-adv-002');const calls=[];
 const x=boot(t,{dev:true,nativeRun:async args=>{calls.push(args);const file=args.find(a=>typeof a==='string'&&a.endsWith('.ps1'))||'';
 if(file.endsWith('inspect.ps1'))return {success:true,osBuild:19044,ramGB:16,gpu:['GPU']};
 if(file.endsWith('permissions.ps1'))return {success:true,admin:true};
 if(args.includes('Status'))return {success:true,backup:false,states:file.endsWith('tweak-library.ps1')?[{id:rule.id,state:'applied'}]:[]};
 return {success:true};}});
 const dir=path.join(x.dir,'tweak-library-backups');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,rule.id+'.json');const original=JSON.stringify({version:1,id:rule.id,state:'applied',values:rule.entries.map(e=>({...e,exists:true,kind:'DWord',value:0}))});fs.writeFileSync(file,original);
 for(const group of ['cpu','gpu','internet'])assert.ok((await x.handlers.get('dashboardPrepare')(x.event,{group,level:'ultra',adapterGuid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'})).token);
 assert.equal(fs.readFileSync(file,'utf8'),original);assert.ok(!calls.some(a=>a.includes('Apply')||a.includes('Restore')));
});

test('settings route rejects inherited object property names before shell invocation',async t=>{
 const x=boot(t,{dev:true});
 for(const route of ['constructor','toString','__proto__',{},null])await assert.rejects(x.handlers.get('openSettings')(x.event,route),/Setare invalidă/);
});
test('native restoration refuses an overlapping native backup despite stale UI',async t=>{
 let writes=0;const x=boot(t,{nativeRun:async()=>{writes++;return {success:true}}});
 const dir=path.join(x.dir,'tweak-native-backups');fs.mkdirSync(dir,{recursive:true});
 const rules=require('../tweak-library.json').filter(r=>r.status==='native'&&r.operation.type==='dns');assert.ok(rules.length>1);
 const other=rules[1];fs.writeFileSync(path.join(dir,other.id+'.json'),JSON.stringify({version:1,id:other.id,state:'applied',operation:other.operation,before:{automatic:true,servers:[]}}));
 await assert.rejects(x.handlers.get('tweakLibraryRestore')(x.event,rules[0].id),/suprapus/);assert.equal(writes,0);
});

test('a malformed snapshot journal cannot deadlock unlicensed original recovery',async t=>{
 const x=boot(t);const dir=path.join(x.dir,'snapshot-transactions');fs.mkdirSync(dir);fs.writeFileSync(path.join(dir,'broken.json'),'{');
 await assert.rejects(x.handlers.get('gpuRestore')(x.event),/Alege .exe/);
 assert.equal((await x.handlers.get('dashboardRestore')(x.event,'cpu')).success,true);
 const inventory=await x.handlers.get('recoveryInventory')(x.event);
 assert.equal(inventory.transactions[0].state,'invalid');assert.equal(inventory.profiles.length,3);
});
test('legacy network original can be previewed and restored when older inventory omits success',async t=>{
 let x;const xrun=async args=>{const file=args.find(v=>typeof v==='string'&&v.endsWith('.ps1'))||'';
  if(file.endsWith('network.ps1'))return {adapters:[{name:'Ethernet',dns:['1.1.1.1'],ipv4:['192.0.2.1']}]};
  if(file.endsWith('dns.ps1')&&args.includes('Restore')){fs.rmSync(path.join(x.dir,'TweakRomania','Backups','dns-latest.json'));return {success:true}}
  if(args.includes('Status'))return {success:true,states:[]};return {success:true};};
 x=boot(t,{nativeRun:xrun});const dir=path.join(x.dir,'TweakRomania','Backups');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'dns-latest.json'),JSON.stringify({version:2,automatic:true,servers:[],guid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}));
 const plan=await x.handlers.get('recoveryPrepare')(x.event,{id:'legacy-network'});assert.equal(plan.rows[0].live.success,true);
 const result=await x.handlers.get('recoveryCommit')(x.event,plan.token);assert.equal(result.success,true);assert.equal(result.succeeded,1);
});

test('invalid historical JSON is diagnostic and cannot crash the active backup inventory',async t=>{
 const x=boot(t),dir=path.join(x.dir,'recovery-reports');fs.mkdirSync(dir);fs.writeFileSync(path.join(dir,'bad.json'),'null');
 const r=await x.handlers.get('recoveryInventory')(x.event);assert.equal(r.errors.length,0);assert.equal(r.historyErrors.length,1);assert.equal(r.profiles.length,3);
});
test('corrupt network journals remain diagnostic without hiding other recovery choices',async t=>{
 const x=boot(t);fs.writeFileSync(path.join(x.dir,'redline-network-session.json'),'{');
 const r=await x.handlers.get('recoveryInventory')(x.event);assert.match(r.errors.join(' '),/Internet/);assert.equal(r.profiles.length,3);
});
test('interrupted manual capture exposes valid saved files without requiring a final report',async t=>{
 const x=boot(t),id='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',dir=path.join(x.dir,'recovery-reports'),copy=path.join(x.dir,'recovery-snapshots',id);fs.mkdirSync(dir);fs.mkdirSync(copy,{recursive:true});
 fs.writeFileSync(path.join(dir,id+'.json'),JSON.stringify({id,type:'manual-snapshot',state:'running',restorable:false,results:[]}));
 fs.writeFileSync(path.join(copy,'manifest.json'),JSON.stringify({version:2,id,identity:'a'.repeat(64),complete:false,files:[{name:'library-cpu-035.json',sha256:'a'.repeat(64)}]}));
 const r=await x.handlers.get('recoveryInventory')(x.event);assert.equal(r.history[0].restorable,true);assert.equal(r.history[0].state,'running');
 // Restore still verifies the actual files and hashes before any Windows write.
 await assert.rejects(x.handlers.get('snapshotPrepare')(x.event,id));
});

test('empty legacy network journal can finalize while an independent catalog profile remains active',async t=>{
 const x=boot(t,{nativeRun:async args=>{const file=args.find(v=>typeof v==='string'&&v.endsWith('.ps1'))||'';if(file.endsWith('network.ps1'))return {success:true,adapters:[]};return {success:true,states:[{id:'library-cpu-035',state:'applied'}]}}});
 fs.writeFileSync(path.join(x.dir,'redline-network-session.json'),JSON.stringify({version:1,started:[]}));
 const p=await x.handlers.get('recoveryPrepare')(x.event,{id:'legacy-network'});
 assert.equal((await x.handlers.get('recoveryCommit')(x.event,p.token)).success,true);assert.equal(fs.existsSync(path.join(x.dir,'redline-network-session.json')),false);
});

test('renderer notification failure cannot turn a completed Windows operation into an IPC failure',async t=>{
 let writes=0;
 const x=boot(t,{dev:true,notificationWindows:[{isDestroyed:()=>false,webContents:{send:()=>{throw Error('Renderer crashed')}}}],nativeRun:async args=>{
  if(args.includes('Apply')){writes++;return {success:true}}
  return {success:true,elevated:true,items:[{id:'search',name:'WSearch',installed:true,startMode:'Auto',state:'Running',backup:false}]};
 }});
 assert.equal((await x.handlers.get('servicesChange')(x.event,'Apply','search')).success,true);assert.equal(writes,1);
});
test('NET BOOST refuses a different physical adapter reusing the confirmed name',async t=>{
 let reads=0,writes=0;const before='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',after='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee';
 const x=boot(t,{dev:true,nativeRun:async args=>{
  const file=args.find(v=>typeof v==='string'&&v.endsWith('.ps1'))||'';
  if(file.endsWith('network.ps1'))return {success:true,adapters:[{name:'Ethernet',guid:++reads===1?before:after,ipv4:['192.0.2.1']}]};
  if(args.includes('Flush'))writes++;
  return {success:true,states:[]};
 }});
 const p=await x.handlers.get('netPrepare')(x.event,{adapter:'Ethernet',provider:'keep',options:{nicPower:false,tcp:false,interrupt:false,eee:false}});
 assert.equal(p.plan.adapterGuid,before);await assert.rejects(x.handlers.get('netCommit')(x.event,p.token),/Adaptorul s-a schimbat/);assert.equal(writes,0);
});

test('a history path replaced by a regular file cannot hide valid backup inventory',async t=>{
 const x=boot(t);fs.writeFileSync(path.join(x.dir,'backup-history'),'preserve this diagnostic evidence');
 const r=await x.handlers.get('recoveryInventory')(x.event);assert.equal(r.profiles.length,3);assert.equal(r.historyErrors.length,1);assert.equal(fs.readFileSync(path.join(x.dir,'backup-history'),'utf8'),'preserve this diagnostic evidence');
});
test('power-value recovery preview reads the protected saved scheme instead of the active scheme',async t=>{
 let savedScheme=null;
 const x=boot(t,{nativeRun:async args=>{
  if(args.includes('Probe')){const i=args.indexOf('-RequestFile');const row=JSON.parse(fs.readFileSync(args[i+1],'utf8'));savedScheme=row.operation.scheme;return {success:true,current:77}}
  if(args.includes('Check'))throw Error('Fresh active-scheme Check is not the saved target');
  return {success:true,states:[]};
 }});
 const rule=require('../tweak-library.json').find(r=>r.status==='native'&&r.operation.type==='power-value');assert.ok(rule);
 const dir=path.join(x.dir,'tweak-native-backups'),scheme='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee';fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(path.join(dir,rule.id+'.json'),JSON.stringify({version:1,id:rule.id,state:'applied',reversible:true,operation:{...rule.operation,scheme},before:50}));
 const p=await x.handlers.get('recoveryPrepare')(x.event,{id:rule.id});assert.equal(p.rows[0].live.success,true);assert.equal(p.rows[0].live.current,77);assert.equal(savedScheme,scheme);
});

function purchasedLicense(){
 const crypto=require('node:crypto'),{createIssuerCode,PRODUCT}=require('../licensing'),pair=crypto.generateKeyPairSync('ed25519');
 const publicKey=pair.publicKey.export({type:'spki',format:'pem'}),payload={product:PRODUCT,licenseId:'buyer_123456',customer:'Cumpărător de test',issuedAt:new Date().toISOString(),expiresAt:null};
 return {publicKey,code:createIssuerCode(payload,pair.privateKey)};
}
test('purchased license unlocks a packaged client through trusted IPC and persists on disk',t=>{
 const license=purchasedLicense(),x=boot(t,{packaged:true,dev:true,publicKey:license.publicKey});
 assert.equal(x.handlers.get('licenseStatus')(x.event).active,false);
 const status=x.handlers.get('licenseActivate')(x.event,license.code.match(/.{1,54}/g).join('\n'));
 assert.equal(status.active,true);assert.equal(status.developer,false);assert.equal(status.customer,'Cumpărător de test');
 const metrics=x.handlers.get('metrics')(x.event);assert.equal(metrics.cpu===null||typeof metrics.cpu==='number',true);
 const reopened=require('../licensing').createLicenseStore({directory:x.dir,publicKey:license.publicKey});assert.equal(reopened.status().active,true);assert.equal(reopened.status().licenseId,'buyer_123456');
});
test('native text import activates a purchased license without exposing the raw code to the renderer',async t=>{
 const license=purchasedLicense();let file;const x=boot(t,{packaged:true,publicKey:license.publicKey,dialog:{showOpenDialog:async()=>({canceled:false,filePaths:[file]})}});file=path.join(x.dir,'purchased.txt');fs.writeFileSync(file,'\uFEFF'+license.code+'\r\n');
 const result=await x.handlers.get('licenseImport')(x.event);assert.equal(result.active,true);assert.equal(result.licenseId,'buyer_123456');assert.equal(Object.values(result).includes(license.code),false);
});
test('cancelled or invalid license imports preserve activation and never write unverified data',async t=>{
 const license=purchasedLicense();let selection={canceled:true,filePaths:[]};const x=boot(t,{packaged:true,publicKey:license.publicKey,dialog:{showOpenDialog:async()=>selection}});
 x.handlers.get('licenseActivate')(x.event,license.code);
 assert.equal((await x.handlers.get('licenseImport')(x.event)).cancelled,true);
 const file=path.join(x.dir,'invalid.txt');fs.writeFileSync(file,'INVALID');selection={canceled:false,filePaths:[file]};await assert.rejects(x.handlers.get('licenseImport')(x.event));
 assert.equal(x.handlers.get('licenseStatus')(x.event).active,true);
 fs.writeFileSync(file,'x'.repeat(9000));await assert.rejects(x.handlers.get('licenseImport')(x.event),/prea mare/);
 selection={canceled:false,filePaths:[path.join(x.dir,'private.pem')]};await assert.rejects(x.handlers.get('licenseImport')(x.event),/\.txt/);
});
test('foreign frames cannot open the native license importer',async t=>{
 let opened=false;const x=boot(t,{dialog:{showOpenDialog:async()=>{opened=true;return {canceled:true}}}});
 await assert.rejects(x.handlers.get('licenseImport')({senderFrame:{url:'https://evil.invalid'}}),/origine/);assert.equal(opened,false);
});
test('per-game GPU preference works alongside independent active Dashboard originals and selection survives reopen',async t=>{
 let file;const calls=[];
 const options={dev:true,dialog:{showOpenDialog:async()=>({canceled:false,filePaths:[file]})},nativeRun:async args=>{calls.push(args);return {success:true,selected:true,highPerformance:false,backup:false}}};
 const x=boot(t,options);file=path.join(x.dir,'game.exe');fs.writeFileSync(file,'fixture, never executed');
 await x.handlers.get('gpuPick')(x.event);
 const rule=require('../tweak-library.json').find(r=>r.id==='library-cpu-005'),dir=path.join(x.dir,'tweak-library-backups');fs.mkdirSync(dir);
 fs.writeFileSync(path.join(dir,rule.id+'.json'),JSON.stringify({version:1,id:rule.id,state:'applied',values:rule.entries.map(e=>({...e,exists:true,value:0}))}));
 assert.equal((await x.handlers.get('gpuApply')(x.event)).success,true);
 assert(calls.some(args=>args.includes('Apply')&&args.includes(file)));
 assert.equal(calls.filter(args=>args.includes('tweak-library.ps1')).length,0);
 const reopened=boot(t,{...options,dataDirectory:x.dir});const state=await reopened.handlers.get('gpuStatus')(reopened.event);
 assert.equal(state.selected,true);assert.equal(state.name,'game.exe');
});
test('GPU picker rejects malformed choices and foreign frames while preserving the previous selection',async t=>{
 let selection;const x=boot(t,{dev:true,dialog:{showOpenDialog:async()=>selection}}),file=path.join(x.dir,'game.exe');fs.writeFileSync(file,'fixture');
 selection={canceled:false,filePaths:[file]};await x.handlers.get('gpuPick')(x.event);
 for(const paths of [[],[file,file],[null],[path.join(x.dir,'folder.exe')]]){
  if(paths[0]&&String(paths[0]).endsWith('folder.exe'))fs.mkdirSync(paths[0]);
  selection={canceled:false,filePaths:paths};await assert.rejects(x.handlers.get('gpuPick')(x.event));
 }
 assert.equal(JSON.parse(fs.readFileSync(path.join(x.dir,'gpu-selection.json'),'utf8')).exe,file);
 await assert.rejects(x.handlers.get('gpuPick')({senderFrame:{url:'https://evil.invalid'}}),/origine/);
});
test('missing clock helper stays unavailable and unlicensed hardware writes remain gated',async t=>{
 let calls=0;const x=boot(t,{packaged:true,nativeRun:async()=>{calls++;throw Error('unexpected native call')}});
 const status=await x.handlers.get('gpuTuningStatus')(x.event);
 assert.equal(status.available,false);assert.equal(status.supported,false);assert.equal(status.gpus.length,0);assert.equal(calls,0);
 for(const name of ['gpuTuningPrepare','gpuTuningCommit'])await assert.rejects(x.handlers.get(name)(x.event,{}),/licență validă/);
 await assert.rejects(x.handlers.get('gpuTuningRestore')(x.event,'bad\nidentity'));
 for(const name of ['gpuTuningStatus','gpuTuningPrepare','gpuTuningCommit','gpuTuningRestore'])await assert.rejects(x.handlers.get(name)({senderFrame:{url:'https://evil.invalid'}}),/origine/);
});
test('clock IPC creates fixed bounded requests, confirms once, reads back and restores without a license',async t=>{
 const calls=[],gpuId='PCI\\VEN_1002&DEV_FAKE',row={gpuId,name:'FAKE AMD GPU',supported:true,backup:false,currentMhz:2000,minMhz:1500,maxMhz:2500,stepMhz:10,minOperatingMhz:1000,originalMhz:2000};let x;
 const nativeRun=async args=>{assert(args.some(a=>String(a).endsWith('gpu-tuning.ps1')));const file=args[args.indexOf('-RequestFile')+1];assert.equal(path.dirname(file),path.join(x.dir,'gpu-tuning-requests'));const request=JSON.parse(fs.readFileSync(file,'utf8'));assert.equal(request.backupDirectory,path.join(x.dir,'gpu-tuning-originals'));calls.push({request,file});
  if(request.action==='query')return {success:true,available:true,supported:true,gpus:[{...row}]};
  if(request.action==='apply'){assert.equal(request.expectedMhz,2000);row.currentMhz=request.mhz;row.backup=true;return {success:true}}
  if(request.action==='restore'){row.currentMhz=2000;row.backup=false;return {success:true}}throw Error('unexpected action');};
 x=boot(t,{dev:true,gpuHelper:true,nativeRun});
 await assert.rejects(x.handlers.get('gpuTuningPrepare')(x.event,{gpuId,mhz:2100,backupDirectory:'/foreign'}));assert.equal(calls.length,0);
 const plan=await x.handlers.get('gpuTuningPrepare')(x.event,{gpuId,mhz:2100});assert.equal(calls.filter(c=>c.request.action==='apply').length,0);
 assert.equal((await x.handlers.get('gpuTuningCommit')(x.event,plan.token)).success,true);await assert.rejects(x.handlers.get('gpuTuningCommit')(x.event,plan.token));
 assert.equal((await x.handlers.get('gpuTuningStatus')(x.event)).gpus[0].backup,true);
 x=boot(t,{packaged:true,dataDirectory:x.dir,gpuHelper:true,nativeRun});
 assert.equal((await x.handlers.get('gpuTuningRestore')(x.event,gpuId)).success,true);assert.equal(row.currentMhz,2000);assert.equal(row.backup,false);
 assert(calls.every(c=>!fs.existsSync(c.file)));assert.equal(calls.filter(c=>c.request.action==='apply').length,1);assert.equal(calls.filter(c=>c.request.action==='restore').length,1);
});
test('Dashboard summary and recovery inventory do not launch Windows scans for an active profile',async t=>{
 let calls=0;const x=boot(t,{nativeRun:async()=>{calls++;throw Error('Unexpected Windows scan')}});
 const folder=path.join(x.dir,'dashboard-profiles');fs.mkdirSync(folder);
 fs.writeFileSync(path.join(folder,'cpu.json'),JSON.stringify({version:1,group:'cpu',level:'low',adapterGuid:'',state:'applied',started:['library-cpu-005'],unchanged:[]}));
 const summary=await x.handlers.get('dashboardSummary')(x.event);assert.equal(summary[0].active,true);assert.equal(summary[0].observed,undefined);
 const inventory=await x.handlers.get('recoveryInventory')(x.event);assert.equal(inventory.profiles[0].active,true);assert.equal(calls,0);assert.equal(x.workerEvents.length,0);
});
test('Windows UTF-8 BOM does not turn a valid profile journal into an unrestorable profile',async t=>{
 const id='library-cpu-005';let state='applied';
 const x=boot(t,{nativeRun:async args=>{const file=String(args[args.indexOf('-File')+1]);if(args.includes('Restore')){state='restored';return {success:true,verified:true}}return {success:true,states:file.endsWith('tweak-library.ps1')?[{id,state}]:[]}}});
 const folder=path.join(x.dir,'dashboard-profiles');fs.mkdirSync(folder);
 fs.writeFileSync(path.join(folder,'cpu.json'),'\uFEFF'+JSON.stringify({version:1,group:'cpu',level:'low',adapterGuid:'',state:'applied',started:[id],unchanged:[]}));
 assert.equal((await x.handlers.get('dashboardSummary')(x.event))[0].recoverable,true);
 assert.equal((await x.handlers.get('dashboardRestore')(x.event,'cpu')).success,true);
 assert.equal((await x.handlers.get('dashboardSummary')(x.event))[0].active,false);
});
test('CPU Ultra keeps one worker per prepare, apply and restore while journaling each write first',async t=>{
 const states=new Map(),catalog=require('../tweak-library-core');let x;
 x=boot(t,{dev:true,nativeRun:async args=>{
  const file=String(args[args.indexOf('-File')+1]),action=args[args.indexOf('-Action')+1],id=args[args.indexOf('-Id')+1];
  if(file.endsWith('inspect.ps1'))return {success:true,osBuild:22631,ramGB:16,gpu:['Fixture GPU']};
  if(file.endsWith('permissions.ps1'))return {success:true,admin:true};
  if(action==='Status')return {success:true,backup:false,states:[...states.values()].filter(row=>file.endsWith(catalog.engineFor(row.id)))};
  if(action==='Check')return {success:true,matching:false};
  const session=JSON.parse(fs.readFileSync(path.join(x.dir,'dashboard-profiles/cpu.json'),'utf8'));assert(session.started.includes(id),'intent must exist before the native write');
  if(action==='Apply'){states.set(id,{id,state:'applied'});return {success:true,verified:true}}
  if(action==='Restore'){states.set(id,{id,state:'restored'});return {success:true,verified:true}}
  throw Error('Unexpected fixture operation');
 }});
 const prepared=await x.handlers.get('dashboardPrepare')(x.event,{group:'cpu',level:'ultra'});assert.equal(prepared.plan.steps.length,13);
 assert.equal((await x.handlers.get('dashboardCommit')(x.event,prepared.token)).success,true);
 assert.equal((await x.handlers.get('dashboardRestore')(x.event,'cpu')).success,true);
 assert.equal(x.workerEvents.filter(e=>e.phase==='start').length,3);assert.equal(x.workerEvents.filter(e=>e.phase==='close').length,3);
 assert.equal(x.workerEvents.filter(e=>e.payload?.action==='CheckMany').length,2);
 assert.equal(x.workerEvents.filter(e=>e.payload?.action==='Inventory').length,5);
 assert.equal(x.workerEvents.filter(e=>e.payload?.operation==='Apply').length,13);assert.equal(x.workerEvents.filter(e=>e.payload?.operation==='Restore').length,13);
 assert.equal((await x.handlers.get('dashboardSummary')(x.event))[0].active,false);
});
