'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawnSync}=require('node:child_process');
const executable=process.env.CARPATIA_PWSH||(process.platform==='win32'?'powershell.exe':'pwsh');
const probe=()=>spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()'],{encoding:'utf8',timeout:10000});
function fixture(t){
 const available=probe();if(available.error?.code==='ENOENT'){t.skip('PowerShell unavailable; set CARPATIA_PWSH for dispatcher regressions.');return null}
 assert.ifError(available.error);assert.equal(available.status,0,available.stderr);
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-dispatch-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const data=path.join(root,'data');fs.mkdirSync(data);
 fs.copyFileSync(path.join(__dirname,'../dashboard-native.ps1'),path.join(root,'dashboard-native.ps1'));
 const rules=[['registry','registry'],['native','native'],['unsupported','native'],['throws','registry'],['malformed','registry'],['exit-failed','registry'],['maintenance','maintenance'],['blocked','registry'],['warnings','native']].map(([name,status])=>({id:'library-test-'+name,status,...(name==='blocked'?{applyBlocked:'blocked fixture'}:{})}));
 fs.writeFileSync(path.join(root,'tweak-library.json'),JSON.stringify(rules));
 const engine=String.raw`param([string]$Action,[string]$Id='',[string]$AdapterGuid='',[string]$DataDir)
$ErrorActionPreference='Stop'
$name=[IO.Path]::GetFileName($PSCommandPath)
@{pid=$PID;script=$name;action=$Action;id=$Id;adapter=$AdapterGuid} | ConvertTo-Json -Compress | Add-Content -LiteralPath (Join-Path $DataDir 'calls.jsonl')
if($Action -eq 'Context'){@{success=$true;adapters=@(@{name='Fixture NIC';guid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';status='Up'})}|ConvertTo-Json -Depth 6 -Compress;exit}
if($Action -eq 'Status'){
 $kind=if($name -eq 'tweak-library.ps1'){'registry'}else{'native'}
 $errors=@();if(Test-Path (Join-Path $DataDir ($kind+'-invalid'))){$errors=@('fixture corrupt journal')}
 @{success=($errors.Count -eq 0);states=@(@{id=('library-test-'+$kind);state='applied'});errors=@($errors)}|ConvertTo-Json -Depth 6 -Compress;exit
}
if($Id -eq 'library-test-warnings'){Write-Warning 'Driver requested a restart.';Write-Host 'Host text must never enter JSONL.';Write-Verbose 'Diagnostic only' -Verbose;Write-Debug 'Debug only' -Debug}
if($Id -eq 'library-test-throws'){throw 'Fixture engine denied access.'}
if($Id -eq 'library-test-malformed'){'not-json';exit}
if($Id -eq 'library-test-exit-failed'){'{"success":true}';exit 1}
if($Id -eq 'library-test-unsupported'){@{success=$false;notApplicable=$true;message='Fixture driver does not support this option.'}|ConvertTo-Json -Compress;exit}
if($Action -eq 'Check'){@{success=$true;matching=($Id -eq 'library-test-registry');current=@{value=1};operation=@{type='fixture';adapterGuid=$AdapterGuid}}|ConvertTo-Json -Depth 6 -Compress;exit}
@{success=$true;verified=$true;message=('Fixture '+$Action)}|ConvertTo-Json -Compress
`;
 for(const name of ['tweak-library.ps1','tweak-native.ps1'])fs.writeFileSync(path.join(root,name),engine);
 fs.writeFileSync(path.join(root,'profile-hardware.ps1'),`@{success=$true;osBuild=22631;gpu=@('Fixture GPU');ramGB=16}|ConvertTo-Json -Compress;exit`);
 fs.writeFileSync(path.join(root,'permissions.ps1'),`@{success=$true;admin=$true}|ConvertTo-Json -Compress;exit`);
 for(const name of ['engine.ps1','power.ps1'])fs.writeFileSync(path.join(root,name),`param([string]$Action) @{success=$true;backup=$false}|ConvertTo-Json -Compress;exit`);
 const calls=()=>fs.existsSync(path.join(data,'calls.jsonl'))?fs.readFileSync(path.join(data,'calls.jsonl'),'utf8').trim().split(/\r?\n/).filter(Boolean).map(JSON.parse):[];
 const file=payload=>{const request=path.join(root,'request.json');fs.writeFileSync(request,typeof payload==='string'?payload:JSON.stringify(payload));return spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(root,'dashboard-native.ps1'),'-RequestFile',request,'-DataDir',data],{encoding:'utf8',timeout:30000})};
 const worker=payloads=>spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',path.join(root,'dashboard-native.ps1'),'-DataDir',data,'-Worker'],{input:typeof payloads==='string'?payloads:payloads.map((payload,i)=>JSON.stringify({requestId:i+1,payload})).join('\n')+'\n',encoding:'utf8',timeout:30000});
 return {root,data,calls,file,worker};
}
function parse(result){assert.ifError(result.error);assert.equal(result.status,0,result.stderr||result.stdout);return JSON.parse(result.stdout.trim().replace(/^\uFEFF/,''))}
test('one Dashboard host checks mixed engines and preserves unsupported/error results after child exit',t=>{
 const h=fixture(t);if(!h)return;
 const result=parse(h.file({action:'CheckMany',ids:['library-test-registry','library-test-native','library-test-unsupported','library-test-throws','library-test-malformed'],adapterGuid:'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'}));
 assert.equal(result.success,true);assert.equal(result.results.length,5);assert.equal(result.results[0].matching,true);assert.equal(result.results[1].operation.adapterGuid,'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee');assert.equal(result.results[2].notApplicable,true);assert.equal(result.results[3].success,false);assert.match(result.results[3].message,/denied access/);assert.equal(result.results[4].success,false);assert.match(result.results[4].message,/invalid/);
 assert.equal(new Set(h.calls().map(c=>c.pid)).size,1);assert.equal(h.calls().length,5);
});
test('Dashboard validates the entire selection and envelope before invoking any engine',t=>{
 const h=fixture(t);if(!h)return;
 const invalid=[{action:'CheckMany',ids:['library-test-registry','library-test-registry']},{action:'CheckMany',ids:['library-test-registry','library-unknown']},{action:'CheckMany',ids:['library-test-maintenance']},{action:'CheckMany',ids:'library-test-native'},{action:'CheckMany',ids:['library-test-native'],adapterGuid:'{aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'},{action:'CheckMany',ids:['library-test-native'],adapterGuid:['aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee']},{action:'CheckMany',ids:['library-test-native'],script:'other.ps1'},{action:'Inventory',DataDir:'foreign'},{action:'InvokeOne',id:'library-test-native',operation:'Remove'},{action:'InvokeOne',id:'library-test-blocked',operation:'Apply'},'{"action":"Context","action":"Inventory"}','{"\\u0061ction":"Context"}',{action:'context'},'[]',' '.repeat(17000)];
 for(const request of invalid){const result=h.file(request);assert.ifError(result.error);assert.notEqual(result.status,0,result.stdout)}
 assert.equal(h.calls().length,0);
});
test('Dashboard inventory merges diagnostics and snapshot/context preserve native response shapes',t=>{
 const h=fixture(t);if(!h)return;
 const inventory=parse(h.file({action:'Inventory'}));assert.equal(inventory.success,true);assert.deepEqual(inventory.states.map(r=>r.id),['library-test-registry','library-test-native']);
 fs.writeFileSync(path.join(h.data,'registry-invalid'),'fixture');const broken=parse(h.file({action:'Inventory'}));assert.equal(broken.success,false);assert.equal(broken.states.length,2);assert.match(broken.errors[0],/fixture corrupt journal/);
 const snapshot=parse(h.file({action:'Snapshot'}));assert.equal(snapshot.success,true);assert.equal(snapshot.hardware.osBuild,22631);assert.equal(snapshot.admin.admin,true);assert.equal(snapshot.registry.backup,false);assert.equal(snapshot.power.backup,false);
 const context=parse(h.file({action:'Context'}));assert.equal(context.adapters[0].name,'Fixture NIC');
});
test('persistent Dashboard worker survives child exit/errors and processes exact mutation requests in one host',t=>{
 const h=fixture(t);if(!h)return;
 const result=h.worker([{action:'InvokeOne',id:'library-test-native',operation:'Check'},{action:'InvokeOne',id:'library-test-throws',operation:'Apply'},{action:'InvokeOne',id:'library-test-native',operation:'Apply'},{action:'InvokeOne',id:'library-test-native',operation:'Restore'},{action:'Inventory'},{action:'InvokeOne',id:'library-test-exit-failed',operation:'Check'},{action:'Context'}]);
 assert.ifError(result.error);assert.equal(result.status,0,result.stderr);const rows=result.stdout.trim().split(/\r?\n/).map(JSON.parse);assert.equal(rows.length,7);assert.deepEqual(rows.map(r=>r.requestId),[1,2,3,4,5,6,7]);assert.equal(rows[0].result.success,true);assert.match(rows[1].error,/denied access/);assert.equal(rows[2].result.verified,true);assert.equal(rows[3].result.verified,true);assert.equal(rows[4].result.states.length,2);assert.match(rows[5].error,/finalizarea/);assert.equal(rows[6].result.adapters.length,1);
 assert.equal(new Set(h.calls().map(c=>c.pid)).size,1);assert.deepEqual(h.calls().filter(c=>c.action==='Apply'||c.action==='Restore').map(c=>c.action),['Apply','Apply','Restore']);
});
test('malformed or oversized worker input produces a bounded protocol error and never invokes an engine',t=>{
 const h=fixture(t);if(!h)return;
 for(const input of ['{"requestId":1,"requestId":2,"payload":{"action":"Context"}}\n',JSON.stringify({requestId:1.5,payload:{action:'Context'}})+'\n','x'.repeat(17000)+'\n']){const result=h.worker(input);assert.ifError(result.error);assert.equal(result.status,0,result.stderr);const rows=result.stdout.trim().split(/\r?\n/).map(JSON.parse);assert.equal(rows.length,1);assert.equal(rows[0].requestId,null);assert.equal(typeof rows[0].error,'string');assert(rows[0].error.length<=1500)}
 assert.equal(h.calls().length,0);
});
test('profile hardware reads only OS and GPU metadata and keeps unknown RAM and GPU failures explicit',t=>{
 const h=fixture(t);if(!h)return;
 fs.copyFileSync(path.join(__dirname,'../profile-hardware.ps1'),path.join(h.root,'profile-hardware.ps1'));
 const script=String.raw`$ErrorActionPreference='Stop'
$global:FixtureMode='normal';$global:FixtureQueries=@()
function global:Get-CimInstance([string]$ClassName,[string[]]$Property){
 $global:FixtureQueries+=@{class=$ClassName;properties=@($Property)}
 if($ClassName -eq 'Win32_OperatingSystem'){
  if($global:FixtureMode -eq 'os-error'){throw 'fixture OS denied'}
  $memory=16777216;if($global:FixtureMode -eq 'unknown-ram'){$memory=$null}
  return [pscustomobject]@{BuildNumber='22631';TotalVisibleMemorySize=$memory}
 }
 if($ClassName -eq 'Win32_VideoController'){
  if($global:FixtureMode -eq 'gpu-error'){throw 'fixture GPU denied'}
  return @([pscustomobject]@{Name='Fixture GPU'},[pscustomobject]@{Name='Fixture GPU'})
 }
 throw ('Unexpected expensive hardware query: '+$ClassName)
}
$results=@()
foreach($mode in @('normal','unknown-ram','gpu-error','os-error')){
 $global:FixtureMode=$mode
 $result=(& (Join-Path $PSScriptRoot 'profile-hardware.ps1'))|ConvertFrom-Json
 $results+=@{mode=$mode;result=$result}
}
@{results=@($results);queries=@($global:FixtureQueries)}|ConvertTo-Json -Depth 10 -Compress
`;
 const file=path.join(h.root,'hardware-test.ps1');fs.writeFileSync(file,script);
 const results=parse(spawnSync(executable,['-NoLogo','-NoProfile','-NonInteractive','-File',file],{encoding:'utf8',timeout:30000}));
 assert.equal(results.results[0].result.success,true);assert.equal(results.results[0].result.ramGB,16);assert.deepEqual(results.results[0].result.gpu,['Fixture GPU']);assert.equal(results.results[1].result.ramGB,null);assert.equal(results.results[2].result.success,true);assert.deepEqual(results.results[2].result.gpu,[]);assert.match(results.results[2].result.gpuError,/identificate/);assert.equal(results.results[3].result.success,false);
 assert.equal(results.queries.length,7);assert(results.queries.every(q=>['Win32_OperatingSystem','Win32_VideoController'].includes(q.class)));
 assert.deepEqual(results.queries[0].properties,['BuildNumber','TotalVisibleMemorySize']);assert.deepEqual(results.queries[1].properties,['Name']);
});

test('worker isolates engine warning and host streams from its JSONL protocol',t=>{
 const h=fixture(t);if(!h)return;
 const r=h.worker(['Check','Apply','Restore'].map(operation=>({action:'InvokeOne',id:'library-test-warnings',operation,adapterGuid:''})));
 assert.ifError(r.error);assert.equal(r.status,0,r.stderr);const rows=r.stdout.trim().split(/\r?\n/).map(JSON.parse);assert.equal(rows.length,3);
 assert(rows.every(row=>row.result.success===true&&row.result.warnings.length===1&&row.result.warnings[0]==='Driver requested a restart.'));
 assert(!r.stdout.includes('Host text must never enter JSONL.'));assert.equal(new Set(h.calls().map(call=>call.pid)).size,1);
});
