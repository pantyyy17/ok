﻿# Profile preflight needs usable RAM, the Windows build and GPU names only.
# Keep full storage/battery/enclosure diagnostics in inspect.ps1, off this path.
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
try{$os=Get-CimInstance -ClassName Win32_OperatingSystem -Property BuildNumber,TotalVisibleMemorySize -ErrorAction Stop}
catch{@{success=$false;message='Versiunea Windows nu a putut fi citită pentru profil.';osBuild=0;ramGB=$null;gpu=@()} | ConvertTo-Json -Compress;exit}
$build=0
if($null -eq $os -or -not [int]::TryParse([string]$os.BuildNumber,[ref]$build) -or $build -lt 10240){
 @{success=$false;message='Profilurile necesită un Windows 10/11 identificat.';osBuild=$build;ramGB=$null;gpu=@()} | ConvertTo-Json -Compress;exit
}
$ramGB=$null
if($null -ne $os.TotalVisibleMemorySize){
 try{
  $memory=[double]$os.TotalVisibleMemorySize
  if(-not [double]::IsNaN($memory) -and -not [double]::IsInfinity($memory) -and $memory -gt 0){$ramGB=[Math]::Round($memory/1MB,1)}
 }catch{}
}
$gpu=@();$gpuError=$null
try{$gpu=@(Get-CimInstance -ClassName Win32_VideoController -Property Name -ErrorAction Stop | Where-Object {$_.Name -is [string] -and -not [string]::IsNullOrWhiteSpace($_.Name)} | ForEach-Object {[string]$_.Name} | Select-Object -Unique)}
catch{$gpuError='Plăcile video nu au putut fi identificate.'}
@{success=$true;osBuild=$build;ramGB=$ramGB;gpu=@($gpu);gpuError=$gpuError} | ConvertTo-Json -Depth 6 -Compress
