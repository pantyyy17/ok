'use strict';
const crypto=require('node:crypto');
const localized=require('./catalog-ro.json');
const {resources}=require('./resource-targets');
const catalog=require('./tweak-library.json');
const rules=new Map(catalog.map(x=>[x.id,x]));
const LEVELS=['low','medium','high','ultra'];
// Each subsystem owns disjoint targets; no deletions, BCD or protection changes.
const GROUPS={
 cpu:{title:'CPU',steps:[
  ['cpu-005','Prioritate pentru aplicația din prim-plan'],
  ['cpu-006','Planificare multimedia Games: High',0],
  ['cpu-002','Plan de alimentare High Performance'],
  ['cpu-054','Dezactivare Power Throttling la nivel Windows'],
  ['cpu-021','Procesor: stare maximă 100% pe alimentare AC',1],
  ['cpu-004','Procesor: stare minimă 100% pe alimentare AC',3],
  ['cpu-020','Processor Boost Mode: valoarea 2 (comportament dependent de CPU)',3],
  ['ram-007','Cache de sistem: LargeSystemCache = 0',2],
  ['cpu-035','Experimental: DisablePagingExecutive = 1 (peste 8 GB RAM)',3],
  ['cpu-energy-performance','Preferință energetică CPU: performanță la priză',2],
  ['cpu-core-parking','Nuclee disponibile: 100% la priză',3],
  ['cpu-frequency-cap','Limită software de frecvență CPU eliminată la priză',3],
  ['cpu-usb-awake','USB fără suspendare selectivă la priză',3]
 ],warning:'High și Ultra pot crește consumul, temperatura și zgomotul. Ultra solicită minimum CPU 100% pe priză și Boost Mode 2. Poate crește puternic consumul și temperatura, inclusiv în repaus; comportamentul boost depinde de procesor. Nu este overclock. High include LargeSystemCache=0; Ultra adauga DisablePagingExecutive=1, numai peste 8 GB RAM. Poate creste memoria ocupata; nu garanteaza FPS.'},
 gpu:{title:'GPU',steps:[
  ['gpu-068','Activează Windows Game Mode'],
  ['cpu-012','Oprește înregistrarea Game DVR în fundal',0],
  ['gpu-036','Preferințe GameDVR pentru optimizările fullscreen'],
  ['gpu-066','Solicită hardware GPU scheduling (HAGS)'],
  ['cpu-016','Oprește activitatea de fundal a aplicațiilor UWP',1],
  ['gpu-background-capture','Oprește capturarea continuă și audio Game DVR',1],
  ['gpu-auto-game-mode','Permite activarea automată Game Mode',3],
  ['gpu-pcie-performance','PCI Express fără economisire la priză',3]
 ],warning:'Low oprește capturarea Game DVR, Medium oprește activitatea UWP în fundal (poate întârzia notificări/sincronizări). High schimbă preferințele fullscreen și poate înrăutăți unele jocuri. Ultra cere Windows 10 build 19041+ și GPU/driver compatibil HAGS; scrierea valorii nu confirmă suportul driverului. Necesită restart.'},
 internet:{title:'INTERNET',steps:[
  ['net-003','DNS Google: 8.8.8.8 / 8.8.4.4 pe adaptorul ales'],
  ['net-005','Activează Receive Side Scaling global'],
  ['net-008','Activează TCP Fast Open global'],
  ['net-032','TCP Initial RTO: 2000 ms global'],
  ['net-039','Delivery Optimization: dezactivează distribuția P2P',0],
  ['net-004','Dezactivează limitarea multimedia Network Throttling',2],
  ['net-autotuning-normal','TCP receive-window auto-tuning: Normal',1],
  ['net-001','Experimental: opreste detectarea automata proxy (WPAD)',3],
  ['net-nic-power','Adaptor fără suspendare selectivă',3],
  ['net-eee-off','Energy Efficient Ethernet oprit',3],
  ['net-interrupt-off','Interrupt Moderation oprit',3]
 ],warning:'DNS poate afecta accesul la rețele private/VPN. RSS și TCP sunt setări globale. TCP Fast Open depinde de conexiune și server; Initial RTO privește retransmisia, nu ping-ul. Low oprește distribuția P2P a actualizărilor. High elimină limitarea multimedia a rețelei. Conexiunea poate fi întreruptă. Medium adauga auto-tuning Normal; Ultra opreste detectarea automata proxy si nu este potrivit retelelor care necesita WPAD.'}
};
const DNS={google:'net-003',cloudflare:'net-dns-cloudflare',quad9:'net-dns-quad9',keep:null};
const AUXILIARY={cpu:['cpu-010'],gpu:['cpu-057'],internet:['net-049']};
function profileOptions(value={}){
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['dns','auxiliary'].includes(k)))throw Error('Opțiuni de profil necunoscute.');
 if(value.dns!==undefined&&(typeof value.dns!=='string'||!Object.hasOwn(DNS,value.dns)))throw Error('Furnizor DNS necunoscut.');
 if(value.auxiliary!==undefined&&typeof value.auxiliary!=='boolean')throw Error('Opțiunea serviciilor trebuie confirmată explicit.');
 return {dns:value.dns??'google',auxiliary:value.auxiliary===true};
}
function descriptor(group,level,adapterGuid='',options={}){
 if(!Object.hasOwn(GROUPS,group)||!LEVELS.includes(level))throw Error('Profil sau nivel necunoscut.');
 const info=GROUPS[group];
 const selected=profileOptions(options);
 if(group==='internet'&&(typeof adapterGuid!=='string'||!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(adapterGuid)))throw Error('Alege explicit adaptorul de Internet.');
 const steps=info.steps.filter((step,index)=>(step[2]??index)<=LEVELS.indexOf(level)).map(step=>group==='internet'&&step[0]==='net-003'?[DNS[selected.dns],step[1]]:step).filter(step=>step[0]);
 if(selected.auxiliary)steps.push(...AUXILIARY[group].map(ref=>[ref,'Serviciu auxiliar opțional']));
 const auxiliaryWarning=selected.auxiliary?({cpu:' Windows Search va fi oprit: căutarea și indexarea pot deveni mai lente.',gpu:' Partajarea bibliotecii Windows Media Player va fi oprită.',internet:' Descoperirea SSDP va fi oprită: unele dispozitive UPnP/DLNA pot să nu mai fie găsite.'})[group]:'';
 return {group,level,options:selected,title:info.title+' · '+level.toUpperCase(),adapterGuid:group==='internet'?adapterGuid:'',warning:info.warning+(group==='cpu'?' EPP și parcarea nucleelor se aplică numai la priză; pot crește consumul și temperatura.':'')+' Opțiunile incompatibile sunt omise explicit.'+(group==='cpu'?' Ultra elimină limita Windows de frecvență și suspendarea USB pe alimentare AC; pot crește consumul.':group==='gpu'?' Ultra dezactivează economisirea legăturilor PCIe pe alimentare AC, ceea ce poate crește consumul.':' Ultra poate dezactiva economisirea adaptorului, EEE și moderarea întreruperilor. Poate crește consumul, numărul de întreruperi și utilizarea CPU; nu este potrivit tuturor adaptoarelor. Unele schimbări cer restart.')+auxiliaryWarning,steps:steps.map(([ref,title])=>{
  const id='library-'+ref,row=rules.get(id);
  if(!row||!['registry','native'].includes(row.status)||['security','boot'].includes(row.impact))throw Error('Definiție de profil nepermisă.');
  return {id,title:localized[id]?.title||title,restart:row.restart,engine:row.status};
 })};
}
function validateSession(session,group){
 if(!session)return null;
 const plan=descriptor(group,session.level,session.adapterGuid,session.options);
 if(session.version!==1||session.group!==group||!['applying','applied','restoring','recovery','restored'].includes(session.state)||!Array.isArray(session.started)||!Array.isArray(session.unchanged)||session.unchanged.some(id=>!session.started.includes(id))||new Set(session.started).size!==session.started.length||session.started.some(id=>!plan.steps.some(s=>s.id===id)))throw Error('Jurnal Dashboard invalid. Păstrează fișierul pentru recuperare.');
 if(session.reused!==undefined&&(!Array.isArray(session.reused)||new Set(session.reused).size!==session.reused.length||session.reused.some(id=>!session.started.includes(id))))throw Error('Jurnal Dashboard invalid: reutilizare.');
 if(session.rollback!==undefined&&typeof session.rollback!=='boolean')throw Error('Jurnal Dashboard invalid: recuperare.');
 return session;
}
function active(s){return !!s&&s.state!=='restored'}
function readSummary(value,maximum){
 // This is display metadata, never authorization or restore state. Ignore an
 // unreadable summary without making valid originals harder to recover.
 const keys=['changed','already','reused','skipped'];
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)||!Number.isInteger(value[key])||value[key]<0))return null;
 const total=keys.reduce((sum,key)=>sum+value[key],0);
 return total>0&&total<=maximum?Object.fromEntries(keys.map(key=>[key,value[key]])):null;
}
function summarize(results,skipped){
 const summary={changed:0,already:0,reused:0,skipped:skipped.length};
 for(const result of results)summary[result.reused?'reused':result.already?'already':'changed']++;
 return summary;
}
function guidIdentity(value){
 if(typeof value!=='string'||!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(value))return null;
 return value.replace(/^\{|\}$/g,'').toLowerCase();
}
function sameNativeReuseTarget(plan,rule,saved,observed){
 const type=rule.operation?.type;
 if(!['dns','nic-power','nic-advanced','power-value'].includes(type))return true;
 if(saved?.type!==type||observed?.type!==type)return false;
 if(['dns','nic-power','nic-advanced'].includes(type)){
  if(type.startsWith('nic-')&&(saved.value!==rule.operation.value||observed.value!==rule.operation.value||type==='nic-advanced'&&(saved.keyword!==rule.operation.keyword||observed.keyword!==rule.operation.keyword)))return false;
  const target=guidIdentity(plan.adapterGuid);
  return target!==null&&guidIdentity(saved.adapterGuid)===target&&guidIdentity(observed.adapterGuid)===target;
 }
 for(const field of ['subgroup','setting']){
  const target=guidIdentity(rule.operation[field]);
  if(!target||guidIdentity(saved[field])!==target||guidIdentity(observed[field])!==target)return false;
 }
 const scheme=guidIdentity(saved.scheme);
 if(!scheme||guidIdentity(observed.scheme)!==scheme)return false;
 // A CPU profile may switch the active scheme before writing its AC settings.
 // Matching the current scheme does not authorize reusing an original for that
 // different future scheme.
 const power=plan.steps.map(step=>rules.get(step.id).operation).find(operation=>operation?.type==='power-active');
 return !power||guidIdentity(power.value)===scheme;
}
function createProfileService({store,ops,now=Date.now,token=crypto.randomUUID,notify=()=>{}}){
 const pending=new Map();
 const progress=event=>{try{notify(event)}catch{}};
 const read=group=>validateSession(store.read(group),group);
 async function checksFor(ids,adapterGuid=''){
  if(!ids.length)return new Map();
  if(typeof ops.checkMany!=='function'){
   const results=new Map();
   for(const id of ids){try{results.set(id,await ops.check(id,adapterGuid))}catch(error){results.set(id,{success:false,message:error.message})}}
   return results;
  }
  const response=await ops.checkMany(ids,adapterGuid);
  if(response?.success!==true||!Array.isArray(response.results))throw Error(response?.message||'Citirea grupată a profilului nu a fost confirmată.');
  const expected=new Set(ids),results=new Map();
  for(const result of response.results){
   if(!result||!expected.has(result.id)||results.has(result.id)||typeof result.success!=='boolean')throw Error('Citirea grupată a returnat o listă de setări invalidă.');
   results.set(result.id,result);
  }
  if(results.size!==expected.size)throw Error('Citirea grupată a profilului este incompletă.');
  return results;
 }
 async function inventory(message){
  const state=await ops.status();
  if(state?.success!==true||!Array.isArray(state.states))throw Error(message);
  const rows=new Map();
  for(const row of state.states){if(!row||typeof row.id!=='string'||typeof row.state!=='string'||rows.has(row.id))throw Error(message);rows.set(row.id,row)}
  return rows;
 }
 function sameCapture(id,before,after){
  // A missing journal is not evidence of a successful restore. Only a fresh,
  // typed capture matching the pre-write capture can prove an unstarted write.
  try{
   const {snapshotRows,equal}=require('./snapshot-core');
   const values=capture=>snapshotRows([{...capture,id}]).map(row=>({resource:row.resource,target:row.target,...(row.operation?{operation:row.operation}:{})})).sort((a,b)=>a.resource.localeCompare(b.resource));
   return equal(values(before),values(after));
  }catch{return false}
 }
 function status(){return Object.keys(GROUPS).map(group=>{try{const s=read(group),summary=s?readSummary(s.summary,descriptor(group,s.level,s.adapterGuid,s.options).steps.length):null;return {group,active:active(s),recoverable:true,level:s?.level||null,state:s?.state||'idle',remaining:s?.started.length||0,...(summary?{summary}:{})}}catch(e){return {group,active:true,recoverable:false,level:null,state:'invalid',remaining:0,error:e.message}}})}
 function assertClear(){if(status().some(x=>x.active))throw Error('Există profiluri Dashboard active. Restaurează-le din Dashboard înainte de tweak-uri individuale sau modulele vechi.');}
 function assertNotOwned(id){for(const group of Object.keys(GROUPS)){const s=read(group);if(active(s)&&s.started.includes(id))throw Error('Această setare aparține profilului '+GROUPS[group].title+'. Folosește Restaurare pe Dashboard.');}}
 async function preflight(plan){
  if(status().some(s=>s.active&&s.state!=='applied'))throw Error('Un profil necesită recuperare. Restaurează-l înainte de altă aplicare.');
  progress({group:plan.group,phase:'scan',completed:0,total:plan.steps.length,detail:'Verific hardware-ul și originalele profilului…'});
  const snapshot=await ops.snapshot(plan.group,plan);
  if(snapshot.success!==true)throw Error(snapshot.message||'Starea Windows nu poate fi verificată.');
  if(!Number.isInteger(snapshot.osBuild)||snapshot.osBuild<10240)throw Error('Profilurile necesită Windows 10/11.');
  if(plan.group==='gpu'&&!snapshot.gpu?.length)throw Error('Nu a fost detectat un GPU.');
  const own=read(plan.group);if(active(own))throw Error('Profilul '+plan.group+' are backup activ. Restaurează-l înainte de schimbarea nivelului.');
  const skipped=new Map((plan.skipped||[]).map(step=>[step.id,step])),candidates=[],eligible=[];
  const omit=(step,reason)=>skipped.set(step.id,{id:step.id,title:step.title,reason});
  for(const step of plan.steps){
   if(step.id==='library-cpu-035'&&(!Number.isFinite(snapshot.ramGB)||snapshot.ramGB<=8)){
    omit(step,Number.isFinite(snapshot.ramGB)&&snapshot.ramGB>0?'Necesită peste 8 GB RAM utilizabili; detectați '+snapshot.ramGB+' GB.':'Memoria RAM utilizabilă nu a putut fi confirmată; această opțiune necesită peste 8 GB.');continue;
   }
   const match=require('./compatibility').compatibility(rules.get(step.id),snapshot);
   if(match.state==='incompatible'){omit(step,match.reason);continue}
   candidates.push(step);
  }
  const checks=await checksFor(candidates.map(step=>step.id),plan.adapterGuid);
  for(const [index,step] of candidates.entries()){
   progress({group:plan.group,phase:'check',completed:index+1,total:candidates.length,detail:'Verificare '+step.title});
   try{
    const result=checks.get(step.id);
    if(result.success!==true){
     if(result.notApplicable===true){omit(step,result.message||'Opțiunea nu este disponibilă pe acest calculator.');continue}
     throw Error(result.message||'verificare nereușită');
    }
    eligible.push(step);
   }catch(e){throw Error(step.title+' ['+step.id+']: '+e.message)}
  }
  plan.steps=eligible;plan.skipped=[...skipped.values()];plan.adapted=plan.skipped.length>0;
  if(!plan.steps.length)throw Error('Nicio opțiune disponibilă pentru acest profil. '+plan.skipped.map(step=>step.title+': '+step.reason).join(' | '));
  let legacyBlockers;
  if(ops.legacyConflicts){
   legacyBlockers=await ops.legacyConflicts(plan,snapshot);
   if(!Array.isArray(legacyBlockers)||legacyBlockers.some(label=>typeof label!=='string'||!label.trim()))throw Error('Domeniul backupurilor anterioare nu poate fi confirmat. Verifică Backup & Restore.');
  }else legacyBlockers=snapshot.legacyBackup?(snapshot.legacyBlockers?.length?snapshot.legacyBlockers:['modul anterior — deschide Backup & Restore']):[];
  if(legacyBlockers.length)throw Error('Profil blocat de backupul existent: '+legacyBlockers.join('; ')+'. Restaurează originalul înainte de aplicare; nu șterge backupurile.');
  const states=await inventory('Jurnalele tweak-urilor nu pot fi citite.');
  const targets=new Set(plan.steps.flatMap(step=>resources(rules.get(step.id))));
  plan.reuse=[];
  for(const row of states.values()){
   if(!['prepared','applied','failed'].includes(row.state))continue;
   const rule=rules.get(row.id);
   if(!rule)throw Error('Domeniu necunoscut pentru backupul individual '+row.id+'. Diagnostic necesar.');
   if(resources(rule).some(r=>targets.has(r))){
    const same=plan.steps.find(s=>s.id===row.id);
    if(same&&row.state==='applied'){
     const current=checks.get(row.id);
     if(current.success===true&&current.matching===true){
      if(!sameNativeReuseTarget(plan,rule,row.operation,current.operation))throw Error('Conflict real: '+rule.title+' ['+row.id+']. Adaptorul sau planul de alimentare al backupului nu corespunde țintei profilului ori nu poate fi confirmat. Deschide Backup & Restore pentru verificarea și restaurarea originalului.');
      plan.reuse.push(row.id);continue;
     }
    }
    throw Error('Conflict real: '+rule.title+' ['+row.id+']. Un backup existent protejează aceleași valori Windows. Deschide Backup & Restore pentru previzualizare și restaurare.');
   }
  }
  if(ops.conflicts){const owners=(await ops.conflicts(plan)).filter(x=>!plan.reuse.includes(x.id));if(owners.length)throw Error('Conflict real: '+owners.map(x=>x.module+' / '+x.id).join('; ')+'. Restaureaza din modulul responsabil.');}
  return checks;
 }
 async function prepare(request){
  const plan=descriptor(request?.group,request?.level,request?.adapterGuid,request?.options);
  await preflight(plan);const value=token();pending.set(plan.group,{value,plan,expires:now()+180000});return {token:value,plan};
 }
 async function recover(session,beforeChecks=null){
  // A failed or interrupted apply owns only new writes. Reused individual
  // originals transfer to the profile only after the whole apply succeeds.
  session.rollback=session.rollback===true||session.state==='applying';
  session.state='restoring';store.write(session.group,session);const results=[],confirm=[];
  const ids=[...session.started].reverse(),forget=id=>{
   const next={...session,started:session.started.filter(x=>x!==id),unchanged:session.unchanged.filter(x=>x!==id),...(session.reused?{reused:session.reused.filter(x=>x!==id)}:{})};
   // Keep the in-memory outstanding ID until its removal is durable. A failed
   // save must not be hidden by a later successful save of the final session.
   store.write(session.group,next);Object.assign(session,next);
  };
  let initial,error;
  if(ids.some(id=>!session.unchanged.includes(id)&&!(session.rollback&&session.reused?.includes(id)))){
   try{initial=await inventory('Jurnal indisponibil.')}catch(e){error=e}
  }
  for(const [index,id] of ids.entries()){
   progress({group:session.group,phase:'restore',completed:index,total:ids.length,detail:'Restaurare '+(rules.get(id)?.title||'setare salvată')});
   try{
    if(session.unchanged.includes(id)||session.rollback&&session.reused?.includes(id)){
     forget(id);
     results.push({id,success:true,preserved:true});continue;
    }
    if(error)throw error;
    const row=initial.get(id);
    if(!row){
     const before=beforeChecks?.get(id);
     if(before&&sameCapture(id,before,(await checksFor([id],session.adapterGuid)).get(id))){forget(id);results.push({id,success:true,unchanged:true});continue}
     throw Error('Backup lipsă pentru '+id+'. Restaurarea nu poate fi confirmată.');
    }
    if(row.state!=='restored'){
     const r=await ops.restore(id);if(r.success!==true)throw Error(r.message||'Restaurare refuzată.');
    }
    confirm.push(id);
   }catch(e){results.push({id,success:false,message:e.message})}
  }
  if(confirm.length){
   let after,readError;
   try{after=await inventory('Recitirea jurnalului a eșuat.')}catch(e){readError=e}
   for(const id of confirm){try{if(readError)throw readError;if(after.get(id)?.state!=='restored')throw Error('Restaurarea nu este confirmată în jurnal.');forget(id);results.push({id,success:true})}catch(e){results.push({id,success:false,message:e.message})}}
  }
  session.state=session.started.length?'recovery':'restored';store.write(session.group,session);
  progress({group:session.group,phase:'restore',completed:ids.length,total:ids.length,detail:session.state==='restored'?'Restaurarea profilului este confirmată.':'Restaurare incompletă; originalele sunt păstrate.'});
  return {success:session.state==='restored',results,remaining:session.started.length};
 }
 async function commit(value){
  let item;
  for(const [group,p] of pending){if(p.value===value){item=p;pending.delete(group);break}}
  if(!item||now()>item.expires)throw Error('Confirmarea profilului a expirat. Analizează din nou.');
  const confirmed=item.plan.steps.map(step=>step.id).join('|');
  const beforeChecks=await preflight(item.plan);
  if(item.plan.steps.map(step=>step.id).join('|')!==confirmed)throw Error('Configurația s-a schimbat după previzualizare. Analizează din nou pentru a confirma profilul adaptat. '+item.plan.skipped.map(step=>step.title+': '+step.reason).join(' | '));
  const session={version:1,group:item.plan.group,level:item.plan.level,adapterGuid:item.plan.adapterGuid,options:item.plan.options,state:'applying',started:[],unchanged:[],reused:[],date:new Date(now()).toISOString()};
  store.write(session.group,session);const results=[];
  try{
   for(const [index,step] of item.plan.steps.entries()){
    // Earlier steps may have activated another power scheme. The rollback
    // baseline must address the scheme this setting will actually write, not
    // the scheme that happened to be active during preview.
    if(rules.get(step.id).operation?.type==='power-value'&&!item.plan.reuse.includes(step.id)&&results.some(result=>rules.get(result.id).operation?.type==='power-active'&&!result.already&&!result.reused)){
     const baseline=typeof ops.check==='function'?await ops.check(step.id,item.plan.adapterGuid):(await checksFor([step.id],item.plan.adapterGuid)).get(step.id);
     if(baseline?.success!==true)throw Error(step.title+': '+(baseline?.message||'Originalul planului activ nu poate fi citit.'));
     beforeChecks.set(step.id,baseline);
    }
    session.started.push(step.id);if(item.plan.reuse.includes(step.id))session.reused.push(step.id);store.write(session.group,session);
    progress({group:session.group,phase:'apply',completed:index,total:item.plan.steps.length,detail:step.title});
    const r=item.plan.reuse.includes(step.id)?{success:true,reused:true}:await ops.apply(step.id,item.plan.adapterGuid);if(r.success!==true)throw Error(step.title+': '+(r.message||'aplicare neconfirmată'));
    if(r.already){session.unchanged.push(step.id);store.write(session.group,session)}
    results.push({id:step.id,success:true,already:!!r.already,reused:!!r.reused});
   }
   const changed=results.filter(result=>!result.already);
   if(changed.length){const state=await inventory('Jurnalele tweak-urilor nu pot fi recitite.');for(const result of changed){if(state.get(result.id)?.state!=='applied')throw Error((rules.get(result.id)?.title||result.id)+': aplicarea nu este confirmată în jurnal.')}}
   const summary=summarize(results,item.plan.skipped);session.summary=summary;
   if(session.started.every(id=>session.unchanged.includes(id))){session.state='restored';session.started=[];session.unchanged=[];store.write(session.group,session);return {success:true,already:true,results,summary:{...summary},skipped:item.plan.skipped,restartRequired:false,message:'Setările erau deja configurate. Nicio modificare și niciun profil nou de restaurat.'}}
   session.state='applied';store.write(session.group,session);
   progress({group:session.group,phase:'apply',completed:item.plan.steps.length,total:item.plan.steps.length,detail:'Profil aplicat; originalele sunt confirmate.'});
   return {success:true,results,summary:{...summary},skipped:item.plan.skipped,restartRequired:item.plan.steps.some(x=>x.restart),message:item.plan.title+' aplicat.'+(item.plan.adapted?' Profil adaptat: '+item.plan.skipped.length+' opțiuni indisponibile au fost omise.':'')+' Backupul profilului este păstrat; efectul asupra performanței trebuie măsurat.'};
  }catch(e){
   delete session.summary;
   session.rollback=true;
   const rollback=await recover(session,beforeChecks);
   return {success:false,results,skipped:item.plan.skipped,rollback,message:e.message+(rollback.success?' Modificările începute au fost restaurate.':' Restaurare incompletă: '+rollback.results.filter(x=>!x.success).map(x=>x.id+': '+x.message).join(' | '))};
  }
 }
 async function restore(group){
  if(!Object.hasOwn(GROUPS,group))throw Error('Modul necunoscut.');
  const s=read(group);if(!active(s))return {success:true,message:'Nu există profil activ de restaurat.'};
  const r=await recover(s);return {...r,message:r.success?'Profilul a fost restaurat la starea anterioară.':'Restaurare incompletă. Backupurile rămân păstrate. '+r.results.filter(x=>!x.success).map(x=>x.id+': '+x.message).join(' | ')};
 }
 async function analyze(){
  const result=[];
  for(const state of status()){
   if(state.recoverable===false){result.push({...state,observed:'unknown',errors:[state.error]});continue}
   const s=read(state.group);
   if(!active(s)){result.push({...state,observed:'inactive'});continue}
   let matching=0;const errors=[];
   try{const checks=await checksFor(s.started,s.adapterGuid);for(const id of s.started){const r=checks.get(id);if(r.success!==true)errors.push(r.message||'Citire eșuată');else if(r.matching===true)matching++}}catch(e){errors.push(e.message)}
   result.push({...state,matching,total:s.started.length,observed:errors.length?'unknown':!s.started.length?'inactive':matching===s.started.length?'active':matching?'partial':'inactive',errors});
  }
  return result;
 }
 return {prepare,commit,restore,status,analyze,assertClear,assertNotOwned};
}
module.exports={LEVELS,GROUPS,descriptor,validateSession,createProfileService};
