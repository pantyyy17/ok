'use strict';
// Real Chromium DOM smoke test with an explicitly mocked Electron bridge.
// No Windows writes, license bypass in production, dependencies, or source rewrites.
// Usage: node tools/test-browser-smoke.js [--output-dir /tmp/carpatia-browser-smoke]
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const {spawn} = require('node:child_process');
const http = require('node:http');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const at = process.argv.indexOf('--output-dir');
if (at >= 0 && !process.argv[at + 1]) throw Error('--output-dir requires a path');
const output = path.resolve(at >= 0 ? process.argv[at + 1] : path.join(os.tmpdir(), 'carpatia-browser-smoke'));
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'carpatia-browser-'));
const files = ['index.html','ui.css','ruby-motion.css','ruby-motion.js','ui.js','tweak-library-ui.js','dashboard-profiles-ui.js','network-options-ui.js','recovery-ui.js','redline-next.css','interface-shell.js'];
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const checks = [], errors = [];
let browser, client, server;
const adapter = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
function installMock(catalog, adapter) {
 const calls = window.__smokeCalls = [];
 const startup=[{name:'Launcher test',command:'C:/Games/launcher.exe',protected:false}];
 const active = [{id:'library-cpu-035',title:'Memorie kernel',category:'CPU',state:'applied',reversible:true},{id:'library-net-003',title:'DNS test',category:'Network',state:'applied',reversible:true}];
 const ok = {success:true};
 const profiles=window.__smokeProfiles=['cpu','gpu','internet'].map(group=>({group,active:false,recoverable:true,state:'idle',level:null,remaining:0,observed:'inactive'}));
 window.carpatia = {
  licenseStatus:async()=>({active:true,developer:true,customer:'Browser smoke fixture',licenseId:'TEST'}),
  sys:async()=>({platform:'win32',cpu:'MOCK CPU',ramGB:16,cores:8,windowsVersion:'MOCK'}),admin:async()=>({admin:true}),metrics:async()=>({cpu:12,ram:34}),sensors:async()=>({available:false}),
  dashboardStatus:async()=>structuredClone(profiles),
  dashboardRestore:async group=>{calls.push({name:'dashboardRestore',group});Object.assign(profiles.find(p=>p.group===group),{active:false,state:'restored',remaining:0});return {...ok,message:'Profil restaurat'}} ,
  dashboardPrepare:async request=>{calls.push({name:'dashboardPrepare',request});return {token:'profile-token',plan:{title:'CPU LOW',steps:[{id:'library-cpu-005',title:'Prioritate CPU'}],reuse:[],warning:'Fixture'}}},
  dashboardCommit:async token=>{calls.push({name:'dashboardCommit',token});Object.assign(profiles[0],{active:true,state:'applied',level:'low',remaining:1,observed:'active'});return {...ok,message:'Profil CPU aplicat'}} ,
  tweakLibrary:async()=>catalog,tweakLibraryState:async()=>({...ok,states:[]}),tweakLibraryContext:async()=>({...ok,compatibility:{},adapters:[{guid:adapter,name:'Ethernet test',status:'Up'}]}),
  recoveryInventory:async()=>({items:active,errors:[],profiles:structuredClone(profiles),history:[],transactions:[]}),
  recoveryPrepare:async selection=>{calls.push({name:'recoveryPrepare',selection});return {token:'mock-token',rows:active.filter(x=>selection.id?x.id===selection.id:selection.category?x.category===selection.category:true)}},
  recoveryCommit:async()=>{calls.push({name:'recoveryCommit'});return {...ok,succeeded:1,failed:0,skipped:0,results:[]}},
  registryState:async()=>({...ok,backup:false}),powerState:async()=>({...ok,backup:false}),networkRecovery:async()=>({active:false,steps:[]}),services:async()=>({...ok,elevated:true,items:[]}),
  network:async()=>({...ok,adapters:[{name:'Ethernet test',ipv4:['192.0.2.1'],linkSpeed:'1 Gbps'}]}),networkCapabilities:async name=>({adapter:name,supported:{},reasons:{}}),
  debloatScan:async()=>({...ok,apps:[{id:'test-app',label:'Aplicație opțională de test',name:'TestApp',count:1}],installedAppxCount:1,classicAppsCount:2}),
  cleanupScan:async()=>({...ok,count:3,bytes:1024}),
  startupList:async()=>({...ok,entries:structuredClone(startup),disabled:[]}),
  hardware:async()=>({...ok,cpu:'MOCK CPU',gpu:['MOCK GPU'],ramGB:16,osName:'Windows fixture',osBuild:22631,hasBattery:false}),
  gpuList:async()=>({...ok,gpus:[{name:'MOCK GPU',driver:'test'}]}),
  onSettingsChanged:()=>()=>{},onDashboardProgress:()=>()=>{},onUltraProgress:()=>()=>{},onNetProgress:()=>()=>{}
 };
}
async function connect(url) {
 const socket = new WebSocket(url), pending = new Map(), events = [];
 let serial = 0;
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true})});
 socket.addEventListener('message', event => {
  const message = JSON.parse(String(event.data));
  if (message.id) {
   const item=pending.get(message.id);if(!item)return;pending.delete(message.id);clearTimeout(item.timer);
   message.error?item.reject(Error(message.error.message)):item.resolve(message.result);
  } else {
   events.push(message);
   if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails.exception?.description||message.params.exceptionDetails.text);
   if(message.method==='Log.entryAdded'&&message.params.entry.level==='error')errors.push(message.params.entry.text);
   if(message.method==='Runtime.consoleAPICalled'&&message.params.type==='error')errors.push(message.params.args.map(x=>x.value||x.description).join(' '));
  }
 });
 return {events,close:()=>socket.close(),send(method,params={}){return new Promise((resolve,reject)=>{const id=++serial,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method))},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}))})}};
}
async function evaluate(expression) {
 const r=await client.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
 if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
 return r.result.value;
}
async function waitFor(expression) {
 for(let i=0;i<100;i++){if(await evaluate(expression))return;await delay(50)}
 throw Error('DOM readiness timeout: '+expression+'; '+JSON.stringify(await evaluate(`({url:location.href,state:document.readyState,bridge:typeof window.carpatia,body:document.body?.dataset,toast:document.getElementById('toast')?.textContent,view:document.querySelector('.view.active')?.id,scripts:Array.from(document.scripts).map(x=>x.src),text:document.body?.innerText.slice(0,300)})`))); 
}
async function check(name, expression) {
 assert.equal(await evaluate(expression),true,name);checks.push(name);
}
(async()=>{
 try {
  fs.mkdirSync(output,{recursive:true});
  for(const file of files)fs.copyFileSync(path.join(root,file),path.join(temp,file));
  fs.cpSync(path.join(root,'assets'),path.join(temp,'assets'),{recursive:true});
  const html=fs.readFileSync(path.join(temp,'index.html'),'utf8').replace('<head>','<head><script src="browser-smoke-bridge.js"></script>');
  fs.writeFileSync(path.join(temp,'index.html'),html);
  fs.writeFileSync(path.join(temp,'browser-smoke-bridge.js'),`(${installMock.toString()})(${JSON.stringify(require('../tweak-library-core').publicCatalog())},${JSON.stringify(adapter)});`);
  server=http.createServer((req,res)=>{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(name==='/favicon.ico'){res.writeHead(204).end();return}const file=path.resolve(temp,'.'+name);if(!file.startsWith(temp+path.sep)){res.writeHead(403).end();return}try{const type={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon'}[path.extname(file)]||'application/octet-stream';const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':type});res.end(data)}catch{res.writeHead(404).end()}});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  browser=spawn(process.env.CHROMIUM_BIN||'chromium',['--headless','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+path.join(temp,'profile'),'--window-size=1560,980','about:blank'],{stdio:['ignore','ignore','pipe']});
  let stderr='';browser.stderr.on('data',x=>{stderr=(stderr+String(x)).slice(-10000)});
  let spawnError;browser.once('error',e=>spawnError=e);
  const devtools=path.join(temp,'profile','DevToolsActivePort');
  for(let i=0;i<100&&!fs.existsSync(devtools);i++){if(spawnError)throw spawnError;if(browser.exitCode!==null)throw Error('Chromium exited: '+stderr);await delay(50)}
  if(!fs.existsSync(devtools))throw Error('Chromium debugging startup timeout: '+stderr);
  const port=Number(fs.readFileSync(devtools,'utf8').split('\n')[0]);
  const response=await fetch('http://127.0.0.1:'+port+'/json/list');const targets=await response.json();
  const target=targets.find(t=>t.type==='page');if(!target)throw Error('No Chromium page target');
  client=await connect(target.webSocketDebuggerUrl);
  await client.send('Runtime.enable');await client.send('Log.enable');await client.send('Page.enable');
  const navigation=await client.send('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/index.html'});if(navigation.errorText)throw Error(navigation.errorText);
  await waitFor(`document.readyState==='complete'&&document.body.dataset.licensed==='yes'`);
  await check('Renderer booted with mocked Electron bridge',`document.getElementById('licenseGate').classList.contains('hidden')&&document.getElementById('valueCPU').textContent==='12%'`);
  await check('Meter default style obeys CSP',`getComputedStyle(document.getElementById('meterGPU')).getPropertyValue('--val').trim()==='0'`);
  const dashboardImage=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'dashboard.png'),Buffer.from(dashboardImage.data,'base64'));
  await evaluate(`document.querySelector('[data-view="tweaks"]').click()`);
  await waitFor(`document.querySelectorAll('#tweakRows .library-row').length===210`);
  await check('Full catalog renders in actual DOM',`document.getElementById('view-tweaks').classList.contains('active')`);
  await evaluate(`document.getElementById('tweakSearch').value='alimentare';document.getElementById('tweakSearch').dispatchEvent(new Event('input',{bubbles:true}))`);
  await check('Search filters rows',`document.querySelectorAll('#tweakRows .library-row').length>0&&document.querySelectorAll('#tweakRows .library-row').length<210`);
  await evaluate(`document.getElementById('tweakSearch').value='';document.getElementById('tweakSearch').dispatchEvent(new Event('input'));document.getElementById('tweakCategory').value='CPU';document.getElementById('tweakCategory').dispatchEvent(new Event('change'))`);
  await check('Category filter selects CPU',`document.querySelectorAll('#tweakRows .library-row').length>0&&Array.from(document.querySelectorAll('#tweakRows .library-category')).every(x=>x.textContent==='Procesor')`);
  await evaluate(`document.querySelector('[data-view="network"]').click()`);
  await waitFor(`document.getElementById('adapterSelect').value==='Ethernet test'&&!document.getElementById('netStart').disabled`);
  await evaluate(`document.getElementById('restoreInternet').click()`);
  await waitFor(`document.getElementById('recoveryCategory').value==='Network'`);
  await check('Location label follows programmatic recovery navigation',`document.getElementById('workspaceLocation').textContent==='Backup & Restore'`);
  await check('First Internet recovery navigation keeps its category',`document.getElementById('view-restore').classList.contains('active')&&document.querySelectorAll('#recoveryRows .recovery-card').length===1`);
  await evaluate(`document.getElementById('recoveryRestore').focus();document.getElementById('recoveryRestore').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Confirmation initially focuses Cancel',`document.activeElement.id==='modalCancel'`);
  await evaluate(`document.getElementById('modalCancel').dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true}))`);
  await check('Confirmation traps backward keyboard focus',`document.activeElement.id==='modalConfirm'`);
  await check('Recovery requires confirmation before commit',`window.__smokeCalls.some(x=>x.name==='recoveryPrepare'&&x.selection.category==='Network')&&!window.__smokeCalls.some(x=>x.name==='recoveryCommit')`);
  await evaluate(`document.getElementById('modalCancel').click()`);
  await waitFor(`!document.body.dataset.busy`);
  await check('Cancel restores focus to original action',`document.activeElement.id==='recoveryRestore'`);
  await check('Cancel performs no restoration',`!window.__smokeCalls.some(x=>x.name==='recoveryCommit')`);
  await evaluate(`document.getElementById('recoveryCategory').value='';document.getElementById('recoveryCategory').dispatchEvent(new Event('change'));document.getElementById('recoveryRestore').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Restore All sends an explicit empty selection object',`Object.keys(window.__smokeCalls.filter(x=>x.name==='recoveryPrepare').at(-1).selection).length===0`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`document.getElementById('recoveryReport').textContent.includes('1 restaurate')&&!document.body.dataset.busy`);
  await check('Confirmed mock restore displays its report',`window.__smokeCalls.filter(x=>x.name==='recoveryCommit').length===1`);
  await evaluate(`document.querySelector('[data-view="debloat"]').click();document.getElementById('scanDebloat').click()`);
  await waitFor(`document.querySelectorAll('#debloatRows .result-row').length===1&&!document.body.dataset.busy`);
  await check('Debloat scan renders an optional application without deleting it',`document.getElementById('debloatStatus').textContent.includes('eligibile: 1')`);
  await evaluate(`document.querySelector('[data-view="gpu"]').click()`);
  await waitFor(`document.getElementById('gpuInventory').textContent.includes('MOCK GPU')`);
  await check('GPU page shows inventory without applying preferences',`document.getElementById('gpuPicked').textContent.includes('Niciun executabil')`);
  await evaluate(`document.querySelector('[data-view="cleanup"]').click();document.getElementById('tempScan').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('tempStatus').textContent.includes('3')`);
  await check('Cleanup scan reports candidate files before confirmation',`document.getElementById('tempStatus').textContent.includes('3')`);
  await evaluate(`document.getElementById('startupScan').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('startupRows').textContent.includes('Launcher test')`);
  await check('Startup inventory exposes the real selected fixture entry',`document.getElementById('startupRows').textContent.includes('DEZACTIVEAZĂ')`);
  await evaluate(`document.querySelector('[data-view="settings"]').click();document.getElementById('diagnoseApp').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('diagnosticOutput').textContent.includes('Administrator: DA')`);
  await check('Application diagnostics display actual bridge results',`document.getElementById('diagnosticOutput').textContent.includes('MOCK CPU')`);
  await evaluate(`document.getElementById('readHardware').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('diagnosticOutput').textContent.includes('Windows fixture')`);
  await check('Hardware diagnosis renders GPU and Windows build',`document.getElementById('diagnosticOutput').textContent.includes('MOCK GPU')&&document.getElementById('diagnosticOutput').textContent.includes('22631')`);
  await evaluate(`Object.assign(window.__smokeProfiles[0],{active:true,state:'applied',level:'high',remaining:0});document.querySelector('[data-view="dashboard"]').click();document.getElementById('refreshProfiles').click()`);
  await waitFor(`document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await evaluate(`document.getElementById('restoreProfile-cpu').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Blocked profile opens direct restoration confirmation even with no individual rows',`document.getElementById('modalHeading').textContent.includes('CPU')`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`!document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await check('Profile restoration finalizes stale session and enables analysis',`window.__smokeCalls.some(x=>x.name==='dashboardRestore'&&x.group==='cpu')`);
  await evaluate(`document.getElementById('heroDebloat').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await check('Restored profile can be prepared and applied again',`window.__smokeCalls.some(x=>x.name==='dashboardCommit'&&x.token==='profile-token')`);
  await evaluate(`document.dispatchEvent(new KeyboardEvent('keydown',{key:'k',ctrlKey:true,bubbles:true}))`);
  await waitFor(`!document.getElementById('commandBackdrop').classList.contains('hidden')`);
  await evaluate(`document.getElementById('commandSearch').value='backup';document.getElementById('commandSearch').dispatchEvent(new Event('input'));document.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}))`);
  await waitFor(`document.getElementById('commandBackdrop').classList.contains('hidden')&&document.getElementById('view-restore').classList.contains('active')`);
  await check('Command palette searches and navigates by keyboard',`document.activeElement.id==='commandOpen'||document.getElementById('view-restore').classList.contains('active')`);
  await client.send('Emulation.setDeviceMetricsOverride',{width:1024,height:900,deviceScaleFactor:1,mobile:false});
  await check('Desktop minimum-width layout has no horizontal overflow',`document.documentElement.scrollWidth<=innerWidth`);
  const compact=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'compact.png'),Buffer.from(compact.data,'base64'));
  await client.send('Emulation.clearDeviceMetricsOverride');
  await delay(100);
  assert.deepEqual(errors,[],'No browser JavaScript/CSP/resource errors');checks.push('No browser JavaScript/CSP/resource errors');
  const screenshot=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'recovery.png'),Buffer.from(screenshot.data,'base64'));
  const result={success:true,scope:'Real Chromium DOM; mocked Electron bridge. No native Windows/Electron backend validation.',browserVersion:await evaluate('navigator.userAgent'),checks,errors};
  fs.writeFileSync(path.join(output,'results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({...result,output},null,2));
 } catch(error) {
  fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,'results.json'),JSON.stringify({success:false,checks,errors,error:error.stack},null,2)+'\n');
  console.error(error.stack);process.exitCode=1;
 } finally {
  client?.close();server?.closeAllConnections();if(server)await new Promise(resolve=>server.close(resolve));if(browser&&browser.exitCode===null){const closed=new Promise(resolve=>browser.once('close',resolve));browser.kill('SIGTERM');await Promise.race([closed,delay(2000)]);if(browser.exitCode===null)browser.kill('SIGKILL')}
  fs.rmSync(temp,{recursive:true,force:true,maxRetries:3,retryDelay:100});
 }
})();
