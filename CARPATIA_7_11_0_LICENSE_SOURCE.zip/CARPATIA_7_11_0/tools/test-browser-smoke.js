'use strict';
// Real Chromium DOM smoke test with an explicitly mocked Windows bridge.
// --license-flow uses real Ed25519 verification and a temporary saved-license store
// through a CDP binding. Only test keys are generated; native Windows calls stay mocked.
// Usage: node tools/test-browser-smoke.js [--license-flow] [--output-dir /tmp/carpatia-browser-smoke]
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const {spawn} = require('node:child_process');
const http = require('node:http');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {PRODUCT,createIssuerCode,createLicenseStore} = require('../licensing');
const root = path.resolve(__dirname, '..');
const at = process.argv.indexOf('--output-dir');
if (at >= 0 && !process.argv[at + 1]) throw Error('--output-dir requires a path');
const output = path.resolve(at >= 0 ? process.argv[at + 1] : path.join(os.tmpdir(), 'carpatia-browser-smoke'));
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'carpatia-browser-'));
const files = ['index.html','ui.css','ruby-motion.css','ruby-motion.js','ui.js','tweak-library-ui.js','dashboard-profiles-ui.js','network-options-ui.js','recovery-ui.js','redline-next.css','interface-shell.js','license-ui.js','license-ui.css'];
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const checks = [], errors = [];
let browser, client, server;
const licenseFlow=process.argv.includes('--license-flow');
let onBinding=()=>{};
const adapter = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
function installMock(catalog, adapter) {
 const calls = window.__smokeCalls = [];
 const startup=[{name:'Launcher test',command:'C:/Games/launcher.exe',protected:false}];
 const active = [{id:'library-cpu-035',title:'Memorie kernel',category:'CPU',state:'applied',reversible:true},{id:'library-net-003',title:'DNS test',category:'Network',state:'applied',reversible:true}];
 const ok = {success:true};
 const profiles=window.__smokeProfiles=['cpu','gpu','internet'].map(group=>({group,active:false,recoverable:true,state:'idle',level:null,remaining:0,observed:'inactive'}));
 window.carpatia = {
  licenseStatus:async()=>({active:true,developer:true,customer:'Browser smoke fixture',licenseId:'TEST'}),
  sys:async()=>({platform:'win32',cpu:'MOCK CPU',ramGB:16,cores:8,windowsVersion:'MOCK'}),admin:async()=>({admin:true}),metrics:async()=>({cpu:12,ram:34}),sensors:async()=>({available:false}),
  dashboardStatus:async()=>structuredClone(profiles),
  dashboardRestore:async group=>{calls.push({name:'dashboardRestore',group});Object.assign(profiles.find(p=>p.group===group),{active:false,state:'restored',remaining:0});return {...ok,message:'Profil restaurat'}} ,
  dashboardPrepare:async request=>{calls.push({name:'dashboardPrepare',request});return {token:'profile-token',plan:{title:'CPU LOW',steps:[{id:'library-cpu-005',title:'Prioritate CPU'}],reuse:[],warning:'Fixture'}}},
  dashboardCommit:async token=>{calls.push({name:'dashboardCommit',token});Object.assign(profiles[0],{active:true,state:'applied',level:'low',remaining:1,observed:'active'});return {...ok,message:'Profil CPU aplicat'}} ,
  tweakLibrary:async()=>catalog,tweakLibraryState:async()=>({...ok,states:[]}),tweakLibraryContext:async()=>({...ok,compatibility:{},adapters:[{guid:adapter,name:'Ethernet test',status:'Up'}]}),
  recoveryInventory:async()=>({items:active,errors:[],profiles:structuredClone(profiles),history:[],transactions:[]}),
  recoveryPrepare:async selection=>{calls.push({name:'recoveryPrepare',selection});return {token:'mock-token',rows:active.filter(x=>selection.id?x.id===selection.id:selection.category?x.category===selection.category:true)}},
  recoveryCommit:async()=>{calls.push({name:'recoveryCommit'});return {...ok,succeeded:1,failed:0,skipped:0,results:[]}},
  registryState:async()=>({...ok,backup:false}),powerState:async()=>({...ok,backup:false}),networkRecovery:async()=>({active:false,steps:[]}),services:async()=>({...ok,elevated:true,items:[]}),
  network:async()=>({...ok,adapters:[{name:'Ethernet test',ipv4:['192.0.2.1'],linkSpeed:'1 Gbps'}]}),networkCapabilities:async name=>({adapter:name,supported:{},reasons:{}}),
  debloatScan:async()=>({...ok,apps:[{id:'test-app',label:'Aplicație opțională de test',name:'TestApp',count:1}],installedAppxCount:1,classicAppsCount:2}),
  debloatRemove:async ids=>{calls.push({name:'debloatRemove',ids});return {success:false,results:ids.map(id=>({id,status:'failed',error:'Mock access denied'}))}},
  cleanupScan:async()=>({...ok,count:3,bytes:1024}),
  startupList:async()=>({...ok,entries:structuredClone(startup),disabled:[]}),
  hardware:async()=>({...ok,cpu:'MOCK CPU',gpu:['MOCK GPU'],ramGB:16,osName:'Windows fixture',osBuild:22631,hasBattery:false}),
  gpuList:async()=>({...ok,gpus:[{name:'MOCK GPU',driver:'test'}]}),
  onSettingsChanged:()=>()=>{},onDashboardProgress:()=>()=>{},onUltraProgress:()=>()=>{},onNetProgress:()=>()=>{}
 };
}
function installLicenseBridge(){
 let serial=0;
 const replies=new Map();
 window.__licenseReply=(id,result,error)=>{const item=replies.get(id);if(!item)return;replies.delete(id);error?item.reject(Error(error)):item.resolve(result)};
 function call(action,code){return new Promise((resolve,reject)=>{const id=++serial;replies.set(id,{resolve,reject});window.__licenseBridge(JSON.stringify({id,action,code}))})}
 window.carpatia.licenseStatus=()=>call('status');
 window.carpatia.licenseActivate=code=>call('activate',code);
 window.carpatia.licenseImport=()=>call('import');
}
async function connect(url) {
 const socket = new WebSocket(url), pending = new Map(), events = [];
 let serial = 0;
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true})});
 socket.addEventListener('message', event => {
  const message = JSON.parse(String(event.data));
  if (message.id) {
   const item=pending.get(message.id);if(!item)return;pending.delete(message.id);clearTimeout(item.timer);
   message.error?item.reject(Error(message.error.message)):item.resolve(message.result);
  } else {
   events.push(message);
   if(message.method==='Runtime.bindingCalled')onBinding(message.params).catch(error=>errors.push('License test bridge: '+error.message));
   if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails.exception?.description||message.params.exceptionDetails.text);
   if(message.method==='Log.entryAdded'&&message.params.entry.level==='error')errors.push(message.params.entry.text);
   if(message.method==='Runtime.consoleAPICalled'&&message.params.type==='error')errors.push(message.params.args.map(x=>x.value||x.description).join(' '));
  }
 });
 return {events,close:()=>socket.close(),send(method,params={}){return new Promise((resolve,reject)=>{const id=++serial,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout: '+method))},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}))})}};
}
async function evaluate(expression) {
 const r=await client.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
 if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);
 return r.result.value;
}
async function waitFor(expression) {
 for(let i=0;i<100;i++){if(await evaluate(expression))return;await delay(50)}
 throw Error('DOM readiness timeout: '+expression+'; '+JSON.stringify(await evaluate(`({url:location.href,state:document.readyState,bridge:typeof window.carpatia,body:document.body?.dataset,toast:document.getElementById('toast')?.textContent,view:document.querySelector('.view.active')?.id,scripts:Array.from(document.scripts).map(x=>x.src),text:document.body?.innerText.slice(0,300)})`))); 
}
async function check(name, expression) {
 assert.equal(await evaluate(expression),true,name);checks.push(name);
}
(async()=>{
 try {
  fs.mkdirSync(output,{recursive:true});
  for(const file of files)fs.copyFileSync(path.join(root,file),path.join(temp,file));
  fs.cpSync(path.join(root,'assets'),path.join(temp,'assets'),{recursive:true});
  const html=fs.readFileSync(path.join(temp,'index.html'),'utf8').replace('<head>','<head><script src="browser-smoke-bridge.js"></script>');
  fs.writeFileSync(path.join(temp,'index.html'),html);
  fs.writeFileSync(path.join(temp,'browser-smoke-bridge.js'),`(${installMock.toString()})(${JSON.stringify(require('../tweak-library-core').publicCatalog())},${JSON.stringify(adapter)});`);
  if(licenseFlow)fs.appendFileSync(path.join(temp,'browser-smoke-bridge.js'),`\n(${installLicenseBridge.toString()})();\n`);
  server=http.createServer((req,res)=>{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(name==='/favicon.ico'){res.writeHead(204).end();return}const file=path.resolve(temp,'.'+name);if(!file.startsWith(temp+path.sep)){res.writeHead(403).end();return}try{const type={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon'}[path.extname(file)]||'application/octet-stream';const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':type});res.end(data)}catch{res.writeHead(404).end()}});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  browser=spawn(process.env.CHROMIUM_BIN||'chromium',['--headless','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+path.join(temp,'profile'),'--window-size=1560,980','about:blank'],{stdio:['ignore','ignore','pipe']});
  let stderr='';browser.stderr.on('data',x=>{stderr=(stderr+String(x)).slice(-10000)});
  let spawnError;browser.once('error',e=>spawnError=e);
  const devtools=path.join(temp,'profile','DevToolsActivePort');
  for(let i=0;i<100&&!fs.existsSync(devtools);i++){if(spawnError)throw spawnError;if(browser.exitCode!==null)throw Error('Chromium exited: '+stderr);await delay(50)}
  if(!fs.existsSync(devtools))throw Error('Chromium debugging startup timeout: '+stderr);
  const port=Number(fs.readFileSync(devtools,'utf8').split('\n')[0]);
  const response=await fetch('http://127.0.0.1:'+port+'/json/list');const targets=await response.json();
  const target=targets.find(t=>t.type==='page');if(!target)throw Error('No Chromium page target');
  client=await connect(target.webSocketDebuggerUrl);
  await client.send('Runtime.enable');await client.send('Log.enable');await client.send('Page.enable');
  let licenseFixture;
  if(licenseFlow){
   const {publicKey,privateKey}=crypto.generateKeyPairSync('ed25519');
   const directory=path.join(temp,'customer-license');
   const code=customer=>createIssuerCode({product:PRODUCT,licenseId:crypto.randomUUID(),customer,issuedAt:new Date().toISOString(),expiresAt:new Date(Date.now()+90*86400000).toISOString()},privateKey);
   licenseFixture={directory,publicKey,code:code('Client CARPATIA de test'),imported:code('Client import .txt'),cancelImport:false};
   licenseFixture.store=createLicenseStore({directory,publicKey});
   onBinding=async({name,payload})=>{
    if(name!=='__licenseBridge')return;
    const request=JSON.parse(payload);let result,error;
    try{
     if(request.action==='status')result=licenseFixture.store.status();
     else if(request.action==='activate')result=licenseFixture.store.activate(request.code);
     else if(request.action==='import')result=licenseFixture.cancelImport?{cancelled:true}:licenseFixture.store.activate(licenseFixture.imported);
     else throw Error('Unknown test action');
    }catch(caught){error=caught.message}
    await client.send('Runtime.evaluate',{expression:`window.__licenseReply(${JSON.stringify(request.id)},${JSON.stringify(result??null)},${JSON.stringify(error??null)})`});
   };
   await client.send('Runtime.addBinding',{name:'__licenseBridge'});
  }
  const navigation=await client.send('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/index.html'});if(navigation.errorText)throw Error(navigation.errorText);
  if(licenseFlow){
   await waitFor(`document.readyState==='complete'&&document.getElementById('licenseGate')?.dataset.state==='missing_license'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   await check('First launch requires a license and preserves recovery access',`document.body.dataset.licensed==='no'&&!document.getElementById('licenseGate').classList.contains('hidden')&&!document.getElementById('licenseRecovery').disabled`);
   const screenshot=async name=>{const shot=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,name+'.png'),Buffer.from(shot.data,'base64'))};
   await screenshot('activation');
   await client.send('Emulation.setDeviceMetricsOverride',{width:1024,height:700,deviceScaleFactor:1,mobile:false});
   await check('Activation fits compact windows without horizontal overflow',`document.documentElement.scrollWidth<=innerWidth&&document.getElementById('licenseDialog').getBoundingClientRect().bottom<=innerHeight`);
   await screenshot('activation-compact');
   await client.send('Emulation.clearDeviceMetricsOverride');
   await evaluate(`document.dispatchEvent(new KeyboardEvent('keydown',{key:'k',ctrlKey:true,bubbles:true}))`);
   await check('Activation dialog keeps command search closed',`document.getElementById('commandBackdrop').classList.contains('hidden')`);
   await evaluate(`document.getElementById('licenseCode').value='CARPATIA-V1.invalid.invalid';document.getElementById('licenseActivate').click()`);
   await waitFor(`document.getElementById('licenseMessage').dataset.tone==='error'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   assert.equal(licenseFixture.store.status().active,false);checks.push('Invalid pasted code never creates a saved entitlement');
   const wrapped=licenseFixture.code.match(/.{1,65}/g).join('\n');
   await evaluate(`document.getElementById('licenseCode').value=${JSON.stringify(wrapped)};document.getElementById('licenseActivate').click()`);
   await waitFor(`document.getElementById('licenseGate').dataset.state==='active'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   await check('Real signed email-wrapped code activates and shows customer details',`document.getElementById('licenseCustomer').textContent==='Client CARPATIA de test'&&!document.getElementById('licenseClose').classList.contains('hidden')&&document.getElementById('licenseCode').value===''`);
   await check('Successful activation shows compact details with explicit entry focus',`document.getElementById('licenseEntry').classList.contains('hidden')&&document.activeElement.id==='licenseClose'`);
   assert.equal(licenseFixture.store.status().developer,false);checks.push('Activation uses a verified customer entitlement, with developer mode disabled');
   await screenshot('activation-success');
   await evaluate(`document.getElementById('licenseClose').click()`);
   await waitFor(`document.getElementById('licenseGate').classList.contains('hidden')`);
   await client.send('Page.reload');
   await waitFor(`document.readyState==='complete'&&document.body?.dataset.licensed==='yes'&&document.getElementById('licenseGate')?.classList.contains('hidden')`);
   assert.equal(createLicenseStore({directory:licenseFixture.directory,publicKey:licenseFixture.publicKey}).status().active,true);checks.push('Saved license is reverified after reload and opens CARPATIA directly');
   await evaluate(`document.getElementById('licenseButton').click();document.getElementById('licenseReplace').click();document.getElementById('licenseCode').value='wrong replacement';document.getElementById('licenseActivate').click()`);
   await waitFor(`document.getElementById('licenseMessage').dataset.tone==='error'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   assert.equal(licenseFixture.store.status().customer,'Client CARPATIA de test');
   await check('Failed replacement preserves the active customer license',`document.body.dataset.licensed==='yes'&&document.getElementById('licenseCode').value==='wrong replacement'`);
   licenseFixture.cancelImport=true;
   const before=await evaluate(`document.getElementById('licenseMessage').textContent`);
   await evaluate(`document.getElementById('licenseImport').click()`);
   await waitFor(`document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   assert.equal(await evaluate(`document.getElementById('licenseMessage').textContent`),before);checks.push('Canceled file import preserves the existing license and message');
   fs.unlinkSync(path.join(licenseFixture.directory,'carpatia-license.txt'));
   licenseFixture.cancelImport=false;
   await client.send('Page.reload');
   await waitFor(`document.getElementById('licenseGate')?.dataset.state==='missing_license'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   await evaluate(`document.getElementById('licenseImport').click()`);
   await waitFor(`document.getElementById('licenseCustomer').textContent==='Client import .txt'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   assert.equal(licenseFixture.store.status().customer,'Client import .txt');checks.push('Imported signed fixture verifies and persists through the real license store');
   licenseFixture.store=createLicenseStore({directory:licenseFixture.directory,publicKey:null});
   await client.send('Page.reload');
   await waitFor(`document.getElementById('licenseGate')?.dataset.state==='missing_publisher_key'&&document.getElementById('licenseDialog').getAttribute('aria-busy')==='false'`);
   await check('Unconfigured build explains activation and disables invalid attempts',`document.getElementById('licenseCode').disabled&&document.getElementById('licenseActivate').disabled&&document.getElementById('licenseImport').disabled&&!document.getElementById('licenseRefresh').disabled`);
   await evaluate(`document.getElementById('licenseRecovery').click()`);
   await waitFor(`document.getElementById('view-restore').classList.contains('active')&&document.getElementById('licenseGate').classList.contains('hidden')`);
   checks.push('Recovery remains reachable without a configured publisher key');
   licenseFixture.store=createLicenseStore({directory:licenseFixture.directory,publicKey:licenseFixture.publicKey});
   await client.send('Page.reload');
  }
  await waitFor(`document.readyState==='complete'&&document.body?.dataset.licensed==='yes'`);
  await check('Renderer booted with mocked Electron bridge',`document.getElementById('licenseGate').classList.contains('hidden')&&document.getElementById('valueCPU').textContent==='12%'`);
  await check('Meter default style obeys CSP',`getComputedStyle(document.getElementById('meterGPU')).getPropertyValue('--val').trim()==='0'`);
  const dashboardImage=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'dashboard.png'),Buffer.from(dashboardImage.data,'base64'));
  const mountains=await evaluate(`Array.from(document.querySelectorAll('.mountain-reactor')).map(b=>({id:b.id,clip:getComputedStyle(b).clipPath,button:b.tagName,described:!!document.getElementById(b.getAttribute('aria-describedby').split(' ')[0]),rect:(()=>{const r=b.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()}))`);
  if(mountains.length){
   assert.equal(mountains.length,3);assert(mountains.every(b=>b.button==='BUTTON'&&b.clip.startsWith('polygon(')&&b.described));
   checks.push('Mountain controls preserve native buttons, triangular hit areas and descriptions');
   await waitFor(`!document.getElementById('heroDebloat').classList.contains('motion-paused')`);
   await check('Mountain vector highlights animate while the dashboard is visible',`getComputedStyle(document.querySelector('#heroDebloat .mountain-tracer')).animationName==='summitTrace'&&getComputedStyle(document.querySelector('#heroDebloat .mountain-tracer')).animationPlayState==='running'`);
   const firstOffset=await evaluate(`getComputedStyle(document.querySelector('#heroDebloat .mountain-tracer')).strokeDashoffset`);await delay(200);
   assert.notEqual(await evaluate(`getComputedStyle(document.querySelector('#heroDebloat .mountain-tracer')).strokeDashoffset`),firstOffset);checks.push('Mountain highlight position changes over time');
   await check('Working mountain increases animation speed without animating its label',`(()=>{const b=document.getElementById('heroDebloat');b.classList.add('is-working');const ok=getComputedStyle(b.querySelector('.mountain-tracer')).animationDuration==='1.4s'&&getComputedStyle(b.querySelector('strong')).animationName==='none';b.classList.remove('is-working');return ok})()`);

   const geometry=await evaluate(`(()=>{const b=document.getElementById('heroDebloat'),r=b.getBoundingClientRect();return {corner:document.elementFromPoint(r.x+2,r.y+2)?.closest('.mountain-reactor')?.id||null,center:document.elementFromPoint(r.x+r.width/2,r.y+r.height*.75)?.closest('.mountain-reactor')?.id}})()`);
   assert.equal(geometry.corner,null);assert.equal(geometry.center,'heroDebloat');checks.push('Mountain hit testing excludes transparent rectangular corners');
   const area=await evaluate(`(()=>{const r=document.querySelector('.dashboard-reactors').getBoundingClientRect();return {x:r.x+scrollX,y:r.y+scrollY,width:r.width,height:r.height,scale:1}})()`);
   if(process.argv.includes('--capture-animation')){
    const frameRoot=path.join(output,'animation-frames');fs.mkdirSync(frameRoot,{recursive:true});
    const started=Date.now();for(let frame=0;frame<48;frame++){
     await delay(Math.max(0,started+frame*125-Date.now()));
     const r=await client.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:area});
     fs.writeFileSync(path.join(frameRoot,String(frame).padStart(3,'0')+'.png'),Buffer.from(r.data,'base64'));
    }
   }
   const crop=await client.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:area});fs.writeFileSync(path.join(output,'mountains.png'),Buffer.from(crop.data,'base64'));
   await client.send('Emulation.setDeviceMetricsOverride',{width:1024,height:900,deviceScaleFactor:1,mobile:false});
   await check('Compact mountain dashboard has no horizontal overflow',`document.documentElement.scrollWidth<=innerWidth`);
   const narrow=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'dashboard-compact.png'),Buffer.from(narrow.data,'base64'));
   await client.send('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
   await check('Mountain working animation respects reduced motion',`(()=>{const b=document.getElementById('heroDebloat');b.classList.add('is-working');const ok=getComputedStyle(b).animationName==='none';b.classList.remove('is-working');return ok})()`);
   await check('Reduced motion stops every mountain highlight',`Array.from(document.querySelectorAll('#heroDebloat .mountain-art *')).every(n=>getComputedStyle(n).animationName==='none')`);
   await client.send('Emulation.setEmulatedMedia',{features:[]});await client.send('Emulation.clearDeviceMetricsOverride');
  }

  await evaluate(`document.querySelector('[data-view="tweaks"]').click()`);
  await waitFor(`document.querySelectorAll('#tweakRows .library-row').length===210`);
  if(mountains.length)await check('Mountain animation pauses outside the dashboard',`getComputedStyle(document.querySelector('#heroDebloat .mountain-tracer')).animationPlayState==='paused'`);
  await check('Full catalog renders in actual DOM',`document.getElementById('view-tweaks').classList.contains('active')`);
  await evaluate(`document.getElementById('tweakSearch').value='alimentare';document.getElementById('tweakSearch').dispatchEvent(new Event('input',{bubbles:true}))`);
  await check('Search filters rows',`document.querySelectorAll('#tweakRows .library-row').length>0&&document.querySelectorAll('#tweakRows .library-row').length<210`);
  await evaluate(`document.getElementById('tweakSearch').value='';document.getElementById('tweakSearch').dispatchEvent(new Event('input'));document.getElementById('tweakCategory').value='CPU';document.getElementById('tweakCategory').dispatchEvent(new Event('change'))`);
  await check('Category filter selects CPU',`document.querySelectorAll('#tweakRows .library-row').length>0&&Array.from(document.querySelectorAll('#tweakRows .library-category')).every(x=>x.textContent==='Procesor')`);
  await evaluate(`document.getElementById('commandOpen').click();document.getElementById('commandSearch').value='DNS';document.getElementById('commandSearch').dispatchEvent(new Event('input'));document.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));`);
  await evaluate(`Array.from(document.querySelectorAll('#commandResults button')).find(b=>b.textContent.includes('Caută în catalog')).click()`);
  await waitFor(`document.getElementById('tweakCategory').value===''&&document.querySelectorAll('#tweakRows .library-row').length>0`);
  await check('Global catalog search clears a previous unrelated category',`document.getElementById('tweakSearch').value==='DNS'&&document.getElementById('tweakCategory').value===''`);
  await evaluate(`document.querySelector('[data-view="network"]').click()`);
  await waitFor(`document.getElementById('adapterSelect').value==='Ethernet test'&&!document.getElementById('netStart').disabled`);
  await evaluate(`document.getElementById('restoreInternet').click()`);
  await waitFor(`document.getElementById('recoveryCategory').value==='Network'`);
  await check('Location label follows programmatic recovery navigation',`document.getElementById('workspaceLocation').textContent==='Backup & Restore'`);
  await check('First Internet recovery navigation keeps its category',`document.getElementById('view-restore').classList.contains('active')&&document.querySelectorAll('#recoveryRows .recovery-card').length===1`);
  await evaluate(`document.getElementById('recoveryRestore').focus();document.getElementById('recoveryRestore').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Confirmation initially focuses Cancel',`document.activeElement.id==='modalCancel'`);
  await evaluate(`document.getElementById('modalCancel').dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true}))`);
  await check('Confirmation traps backward keyboard focus',`document.activeElement.id==='modalConfirm'`);
  await check('Recovery requires confirmation before commit',`window.__smokeCalls.some(x=>x.name==='recoveryPrepare'&&x.selection.category==='Network')&&!window.__smokeCalls.some(x=>x.name==='recoveryCommit')`);
  await evaluate(`document.getElementById('modalCancel').click()`);
  await waitFor(`!document.body.dataset.busy`);
  await check('Cancel restores focus to original action',`document.activeElement.id==='recoveryRestore'`);
  await check('Cancel performs no restoration',`!window.__smokeCalls.some(x=>x.name==='recoveryCommit')`);
  await evaluate(`document.getElementById('recoveryCategory').value='';document.getElementById('recoveryCategory').dispatchEvent(new Event('change'));document.getElementById('recoveryRestore').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Restore All sends an explicit empty selection object',`Object.keys(window.__smokeCalls.filter(x=>x.name==='recoveryPrepare').at(-1).selection).length===0`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`document.getElementById('recoveryReport').textContent.includes('1 restaurate')&&!document.body.dataset.busy`);
  await check('Confirmed mock restore displays its report',`window.__smokeCalls.filter(x=>x.name==='recoveryCommit').length===1`);
  await evaluate(`document.querySelector('[data-view="debloat"]').click();document.getElementById('scanDebloat').click()`);
  await waitFor(`document.querySelectorAll('#debloatRows .result-row').length===1&&!document.body.dataset.busy`);
  await check('Debloat scan renders an optional application without deleting it',`document.getElementById('debloatStatus').textContent.includes('eligibile: 1')`);
  await evaluate(`document.querySelector('.debloatPick').checked=true;document.getElementById('removeDebloat').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Debloat removal requires confirmation',`!window.__smokeCalls.some(x=>x.name==='debloatRemove')`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`!document.body.dataset.busy&&!document.getElementById('debloatResults').hidden`);
  await check('Partial Debloat failure preserves an actionable per-application report',`document.getElementById('debloatResultsRows').textContent.includes('Mock access denied')&&document.getElementById('debloatStatus').textContent.includes('incompletă')`);
  await evaluate(`document.querySelector('[data-view="gpu"]').click()`);
  await waitFor(`document.getElementById('gpuInventory').textContent.includes('MOCK GPU')`);
  await check('GPU page shows inventory without applying preferences',`document.getElementById('gpuPicked').textContent.includes('Niciun executabil')`);
  await evaluate(`document.querySelector('[data-view="cleanup"]').click();document.getElementById('tempScan').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('tempStatus').textContent.includes('3')`);
  await check('Cleanup scan reports candidate files before confirmation',`document.getElementById('tempStatus').textContent.includes('3')`);
  await evaluate(`document.getElementById('startupScan').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('startupRows').textContent.includes('Launcher test')`);
  await check('Startup inventory exposes the real selected fixture entry',`document.getElementById('startupRows').textContent.includes('DEZACTIVEAZĂ')`);
  await evaluate(`document.querySelector('[data-view="settings"]').click();document.getElementById('diagnoseApp').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('diagnosticOutput').textContent.includes('Administrator: DA')`);
  await check('Application diagnostics display actual bridge results',`document.getElementById('diagnosticOutput').textContent.includes('MOCK CPU')`);
  await evaluate(`document.getElementById('readHardware').click()`);
  await waitFor(`!document.body.dataset.busy&&document.getElementById('diagnosticOutput').textContent.includes('Windows fixture')`);
  await check('Hardware diagnosis renders GPU and Windows build',`document.getElementById('diagnosticOutput').textContent.includes('MOCK GPU')&&document.getElementById('diagnosticOutput').textContent.includes('22631')`);
  await evaluate(`Object.assign(window.__smokeProfiles[0],{active:true,state:'applied',level:'high',remaining:0});document.querySelector('[data-view="dashboard"]').click();document.getElementById('refreshProfiles').click()`);
  await waitFor(`document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await evaluate(`document.getElementById('restoreProfile-cpu').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await check('Blocked profile opens direct restoration confirmation even with no individual rows',`document.getElementById('modalHeading').textContent.includes('CPU')`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`!document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await check('Profile restoration finalizes stale session and enables analysis',`window.__smokeCalls.some(x=>x.name==='dashboardRestore'&&x.group==='cpu')`);
  await evaluate(`document.getElementById('heroDebloat').click()`);
  await waitFor(`!document.getElementById('modalBackdrop').classList.contains('hidden')`);
  await evaluate(`document.getElementById('modalConfirm').click()`);
  await waitFor(`document.getElementById('heroDebloat').disabled&&!document.body.dataset.busy`);
  await check('Restored profile can be prepared and applied again',`window.__smokeCalls.some(x=>x.name==='dashboardCommit'&&x.token==='profile-token')`);
  await evaluate(`document.dispatchEvent(new KeyboardEvent('keydown',{key:'k',ctrlKey:true,bubbles:true}))`);
  await waitFor(`!document.getElementById('commandBackdrop').classList.contains('hidden')`);
  await evaluate(`document.getElementById('commandSearch').value='backup';document.getElementById('commandSearch').dispatchEvent(new Event('input'));document.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}))`);
  await waitFor(`document.getElementById('commandBackdrop').classList.contains('hidden')&&document.getElementById('view-restore').classList.contains('active')`);
  await check('Command palette searches and navigates by keyboard',`document.activeElement.id==='commandOpen'||document.getElementById('view-restore').classList.contains('active')`);
  await client.send('Emulation.setDeviceMetricsOverride',{width:1024,height:900,deviceScaleFactor:1,mobile:false});
  await check('Desktop minimum-width layout has no horizontal overflow',`document.documentElement.scrollWidth<=innerWidth`);
  const compact=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'compact.png'),Buffer.from(compact.data,'base64'));
  await client.send('Emulation.clearDeviceMetricsOverride');
  await delay(100);
  assert.deepEqual(errors,[],'No browser JavaScript/CSP/resource errors');checks.push('No browser JavaScript/CSP/resource errors');
  const screenshot=await client.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(output,'recovery.png'),Buffer.from(screenshot.data,'base64'));
  const result={success:true,scope:licenseFlow?'Real Chromium DOM + real Ed25519 activation/persistence using ephemeral test keys through CDP; native Windows bridge and file dialog mocked. No live payment/email or native Windows/Electron validation.':'Real Chromium DOM; mocked Electron bridge. No native Windows/Electron backend validation.',browserVersion:await evaluate('navigator.userAgent'),checks,errors};
  fs.writeFileSync(path.join(output,'results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({...result,output},null,2));
 } catch(error) {
  fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,'results.json'),JSON.stringify({success:false,checks,errors,error:error.stack},null,2)+'\n');
  console.error(error.stack);process.exitCode=1;
 } finally {
  client?.close();server?.closeAllConnections();if(server)await new Promise(resolve=>server.close(resolve));if(browser&&browser.exitCode===null){const closed=new Promise(resolve=>browser.once('close',resolve));browser.kill('SIGTERM');await Promise.race([closed,delay(2000)]);if(browser.exitCode===null)browser.kill('SIGKILL')}
  fs.rmSync(temp,{recursive:true,force:true,maxRetries:3,retryDelay:100});
 }
})();
