'use strict';
const crypto=require('node:crypto');
const localized=require('./catalog-ro.json');
const {resources}=require('./resource-targets');
const catalog=require('./tweak-library.json');
const rules=new Map(catalog.map(x=>[x.id,x]));
const LEVELS=['low','medium','high','ultra'];
// Each subsystem owns disjoint targets; no deletions, BCD or protection changes.
const GROUPS={
 cpu:{title:'CPU',steps:[
  ['cpu-005','Prioritate pentru aplicația din prim-plan'],
  ['cpu-006','Planificare multimedia Games: High',0],
  ['cpu-002','Plan de alimentare High Performance'],
  ['cpu-054','Dezactivare Power Throttling la nivel Windows'],
  ['cpu-021','Procesor: stare maximă 100% pe alimentare AC',1],
  ['cpu-004','Procesor: stare minimă 100% pe alimentare AC',3],
  ['cpu-020','Processor Boost Mode: valoarea 2 (comportament dependent de CPU)',3],
  ['ram-007','Cache de sistem: LargeSystemCache = 0',2],
  ['cpu-035','Experimental: DisablePagingExecutive = 1 (peste 8 GB RAM)',3]
 ],warning:'High și Ultra pot crește consumul, temperatura și zgomotul. Ultra solicită minimum CPU 100% pe priză și Boost Mode 2. Poate crește puternic consumul și temperatura, inclusiv în repaus; comportamentul boost depinde de procesor. Nu este overclock. High include LargeSystemCache=0; Ultra adauga DisablePagingExecutive=1, numai peste 8 GB RAM. Poate creste memoria ocupata; nu garanteaza FPS.'},
 gpu:{title:'GPU',steps:[
  ['gpu-068','Activează Windows Game Mode'],
  ['cpu-012','Oprește înregistrarea Game DVR în fundal',0],
  ['gpu-036','Preferințe GameDVR pentru optimizările fullscreen'],
  ['gpu-066','Solicită hardware GPU scheduling (HAGS)'],
  ['cpu-016','Oprește activitatea de fundal a aplicațiilor UWP',1]
 ],warning:'Low oprește capturarea Game DVR, Medium oprește activitatea UWP în fundal (poate întârzia notificări/sincronizări). High schimbă preferințele fullscreen și poate înrăutăți unele jocuri. Ultra cere Windows 10 build 19041+ și GPU/driver compatibil HAGS; scrierea valorii nu confirmă suportul driverului. Necesită restart.'},
 internet:{title:'INTERNET',steps:[
  ['net-003','DNS Google: 8.8.8.8 / 8.8.4.4 pe adaptorul ales'],
  ['net-005','Activează Receive Side Scaling global'],
  ['net-008','Activează TCP Fast Open global'],
  ['net-032','TCP Initial RTO: 2000 ms global'],
  ['net-039','Delivery Optimization: dezactivează distribuția P2P',0],
  ['net-004','Dezactivează limitarea multimedia Network Throttling',2],
  ['net-autotuning-normal','TCP receive-window auto-tuning: Normal',1],
  ['net-001','Experimental: opreste detectarea automata proxy (WPAD)',3]
 ],warning:'DNS poate afecta accesul la rețele private/VPN. RSS și TCP sunt setări globale. TCP Fast Open depinde de conexiune și server; Initial RTO privește retransmisia, nu ping-ul. Low oprește distribuția P2P a actualizărilor. High elimină limitarea multimedia a rețelei. Conexiunea poate fi întreruptă. Medium adauga auto-tuning Normal; Ultra opreste detectarea automata proxy si nu este potrivit retelelor care necesita WPAD.'}
};
function descriptor(group,level,adapterGuid=''){
 if(!Object.hasOwn(GROUPS,group)||!LEVELS.includes(level))throw Error('Profil sau nivel necunoscut.');
 const info=GROUPS[group];
 if(group==='internet'&&(typeof adapterGuid!=='string'||!/^(?:[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}|\{[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\})$/i.test(adapterGuid)))throw Error('Alege explicit adaptorul de Internet.');
 return {group,level,title:info.title+' · '+level.toUpperCase(),adapterGuid:group==='internet'?adapterGuid:'',warning:info.warning,steps:info.steps.filter((step,index)=>(step[2]??index)<=LEVELS.indexOf(level)).map(([ref,title])=>{
  const id='library-'+ref,row=rules.get(id);
  if(!row||!['registry','native'].includes(row.status)||['security','boot'].includes(row.impact))throw Error('Definiție de profil nepermisă.');
  return {id,title:localized[id]?.title||title,restart:row.restart,engine:row.status};
 })};
}
function validateSession(session,group){
 if(!session)return null;
 const plan=descriptor(group,session.level,session.adapterGuid);
 if(session.version!==1||session.group!==group||!['applying','applied','restoring','recovery','restored'].includes(session.state)||!Array.isArray(session.started)||!Array.isArray(session.unchanged)||session.unchanged.some(id=>!session.started.includes(id))||new Set(session.started).size!==session.started.length||session.started.some(id=>!plan.steps.some(s=>s.id===id)))throw Error('Jurnal Dashboard invalid. Păstrează fișierul pentru recuperare.');
 if(session.reused!==undefined&&(!Array.isArray(session.reused)||new Set(session.reused).size!==session.reused.length||session.reused.some(id=>!session.started.includes(id))))throw Error('Jurnal Dashboard invalid: reutilizare.');
 if(session.rollback!==undefined&&typeof session.rollback!=='boolean')throw Error('Jurnal Dashboard invalid: recuperare.');
 return session;
}
function active(s){return !!s&&s.state!=='restored'}
function createProfileService({store,ops,now=Date.now,token=crypto.randomUUID,notify=()=>{}}){
 const pending=new Map();
 const progress=event=>{try{notify(event)}catch{}};
 const read=group=>validateSession(store.read(group),group);
 function status(){return Object.keys(GROUPS).map(group=>{try{const s=read(group);return {group,active:active(s),recoverable:true,level:s?.level||null,state:s?.state||'idle',remaining:s?.started.length||0}}catch(e){return {group,active:true,recoverable:false,level:null,state:'invalid',remaining:0,error:e.message}}})}
 function assertClear(){if(status().some(x=>x.active))throw Error('Există profiluri Dashboard active. Restaurează-le din Dashboard înainte de tweak-uri individuale sau modulele vechi.');}
 function assertNotOwned(id){for(const group of Object.keys(GROUPS)){const s=read(group);if(active(s)&&s.started.includes(id))throw Error('Această setare aparține profilului '+GROUPS[group].title+'. Folosește Restaurare pe Dashboard.');}}
 async function preflight(plan){
  if(status().some(s=>s.active&&s.state!=='applied'))throw Error('Un profil necesită recuperare. Restaurează-l înainte de altă aplicare.');
  const snapshot=await ops.snapshot(plan.group,plan);
  if(snapshot.success!==true)throw Error(snapshot.message||'Starea Windows nu poate fi verificată.');
  for(const step of plan.steps){const match=require('./compatibility').compatibility(rules.get(step.id),snapshot);if(match.state==='incompatible')throw Error(step.title+': '+match.reason)}
  if(!Number.isInteger(snapshot.osBuild)||snapshot.osBuild<10240)throw Error('Profilurile necesită Windows 10/11.');
  if(plan.group==='gpu'&&plan.level==='ultra'&&snapshot.osBuild<19041)throw Error('HAGS necesită Windows build 19041 sau ulterior.');
  if(plan.group==='gpu'&&!snapshot.gpu?.length)throw Error('Nu a fost detectat un GPU.');
  if(snapshot.legacyBackup)throw Error('Profil blocat de backupul existent: '+(snapshot.legacyBlockers?.join('; ')||'modul anterior — deschide Backup & Restore')+'. Restaurează originalul înainte de aplicare; nu șterge backupurile.');
  if(plan.steps.some(x=>x.id==='library-cpu-035')&&(!Number.isFinite(snapshot.ramGB)||snapshot.ramGB<=8))throw Error('CPU Ultra necesita peste 8 GB RAM pentru DisablePagingExecutive. Foloseste High sau verifica detectarea RAM.');
  const own=read(plan.group);if(active(own))throw Error('Profilul '+plan.group+' are backup activ. Restaurează-l înainte de schimbarea nivelului.');
  const states=await ops.status();if(states.success!==true||!Array.isArray(states.states))throw Error('Jurnalele tweak-urilor nu pot fi citite.');
  const targets=new Set(plan.steps.flatMap(step=>resources(rules.get(step.id))));
  plan.reuse=[];
  for(const row of states.states||[]){
   if(!['prepared','applied','failed'].includes(row.state))continue;
   const rule=rules.get(row.id);
   if(!rule)throw Error('Domeniu necunoscut pentru backupul individual '+row.id+'. Diagnostic necesar.');
   if(resources(rule).some(r=>targets.has(r))){
    const same=plan.steps.find(s=>s.id===row.id);
    if(same&&row.state==='applied'){
     const current=await ops.check(row.id,plan.adapterGuid);
     if(current.success===true&&current.matching===true){plan.reuse.push(row.id);continue}
    }
    throw Error('Conflict real: '+rule.title+' ['+row.id+']. Un backup existent protejează aceleași valori Windows. Deschide Backup & Restore pentru previzualizare și restaurare.');
   }
  }
  if(ops.conflicts){const owners=(await ops.conflicts(plan)).filter(x=>!plan.reuse.includes(x.id));if(owners.length)throw Error('Conflict real: '+owners.map(x=>x.module+' / '+x.id).join('; ')+'. Restaureaza din modulul responsabil.');}
  for(const step of plan.steps){try{const r=await ops.check(step.id,plan.adapterGuid);if(r.success!==true)throw Error(r.message||'verificare nereușită')}catch(e){throw Error(step.title+' ['+step.id+']: '+e.message)}}
 }
 async function prepare(request){
  const plan=descriptor(request?.group,request?.level,request?.adapterGuid);
  await preflight(plan);const value=token();pending.set(plan.group,{value,plan,expires:now()+180000});return {token:value,plan};
 }
 async function recover(session){
  // A failed or interrupted apply owns only new writes. Reused individual
  // originals transfer to the profile only after the whole apply succeeds.
  session.rollback=session.rollback===true||session.state==='applying';
  session.state='restoring';store.write(session.group,session);const results=[];
  for(const id of [...session.started].reverse()){
   progress({phase:'restore',detail:'Restaurare '+(rules.get(id)?.title||'setare salvată')});
   try{
    if(session.rollback&&session.reused?.includes(id)){
     session.started=session.started.filter(x=>x!==id);session.reused=session.reused.filter(x=>x!==id);store.write(session.group,session);
     results.push({id,success:true,preserved:true});continue;
    }
    let state=await ops.status();if(state.success!==true)throw Error('Jurnal indisponibil.');
    let row=state.states?.find(x=>x.id===id);
    // A prepared session is persisted before each call: no tweak journal can mean no write began.
    if(!row&&!session.unchanged?.includes(id))throw Error('Backup lipsă pentru '+id+'. Restaurarea nu poate fi confirmată.');
    if(row&&row.state!=='restored'){
     const r=await ops.restore(id);if(r.success!==true)throw Error(r.message||'Restaurare refuzată.');
     state=await ops.status();if(state.success!==true)throw Error('Recitirea jurnalului a eșuat.');
     row=state.states?.find(x=>x.id===id);if(!row||row.state!=='restored')throw Error('Restaurarea nu este confirmată în jurnal.');
    }
    session.started=session.started.filter(x=>x!==id);session.unchanged=session.unchanged.filter(x=>x!==id);if(session.reused)session.reused=session.reused.filter(x=>x!==id);store.write(session.group,session);results.push({id,success:true});
   }catch(e){results.push({id,success:false,message:e.message})}
  }
  session.state=session.started.length?'recovery':'restored';store.write(session.group,session);
  return {success:session.state==='restored',results,remaining:session.started.length};
 }
 async function commit(value){
  let item;
  for(const [group,p] of pending){if(p.value===value){item=p;pending.delete(group);break}}
  if(!item||now()>item.expires)throw Error('Confirmarea profilului a expirat. Analizează din nou.');
  await preflight(item.plan);
  const session={version:1,group:item.plan.group,level:item.plan.level,adapterGuid:item.plan.adapterGuid,state:'applying',started:[],unchanged:[],reused:[],date:new Date(now()).toISOString()};
  store.write(session.group,session);const results=[];
  try{
   for(const step of item.plan.steps){
    session.started.push(step.id);if(item.plan.reuse.includes(step.id))session.reused.push(step.id);store.write(session.group,session);
    progress({phase:'apply',detail:step.title});
    const r=item.plan.reuse.includes(step.id)?{success:true,reused:true}:await ops.apply(step.id,item.plan.adapterGuid);if(r.success!==true)throw Error(step.title+': '+(r.message||'aplicare neconfirmată'));
    if(r.already){session.unchanged.push(step.id);store.write(session.group,session)}
    else{const state=await ops.status();if(state.success!==true||!Array.isArray(state.states)||state.states.find(x=>x.id===step.id)?.state!=='applied')throw Error(step.title+': aplicarea nu este confirmată în jurnal.');}
    results.push({id:step.id,success:true,already:!!r.already});
   }
   if(session.started.every(id=>session.unchanged.includes(id))){session.state='restored';session.started=[];session.unchanged=[];store.write(session.group,session);return {success:true,already:true,results,restartRequired:false,message:'Setările erau deja configurate. Nicio modificare și niciun profil nou de restaurat.'}}
   session.state='applied';store.write(session.group,session);
   return {success:true,results,restartRequired:item.plan.steps.some(x=>x.restart),message:item.plan.title+' aplicat. Backupul profilului este păstrat; efectul asupra performanței trebuie măsurat.'};
  }catch(e){
   const rollback=await recover(session);
   return {success:false,results,rollback,message:e.message+(rollback.success?' Modificările începute au fost restaurate.':' Restaurare incompletă: '+rollback.results.filter(x=>!x.success).map(x=>x.id+': '+x.message).join(' | '))};
  }
 }
 async function restore(group){
  if(!Object.hasOwn(GROUPS,group))throw Error('Modul necunoscut.');
  const s=read(group);if(!active(s))return {success:true,message:'Nu există profil activ de restaurat.'};
  const r=await recover(s);return {...r,message:r.success?'Profilul a fost restaurat la starea anterioară.':'Restaurare incompletă. Backupurile rămân păstrate. '+r.results.filter(x=>!x.success).map(x=>x.id+': '+x.message).join(' | ')};
 }
 async function analyze(){
  const result=[];
  for(const state of status()){
   if(state.recoverable===false){result.push({...state,observed:'unknown',errors:[state.error]});continue}
   const s=read(state.group);
   if(!active(s)){result.push({...state,observed:'inactive'});continue}
   let matching=0;const errors=[];
   for(const id of s.started){try{const r=await ops.check(id,s.adapterGuid);if(r.success!==true)errors.push(r.message||'Citire eșuată');else if(r.matching===true)matching++}catch(e){errors.push(e.message)}}
   result.push({...state,matching,total:s.started.length,observed:errors.length?'unknown':!s.started.length?'inactive':matching===s.started.length?'active':matching?'partial':'inactive',errors});
  }
  return result;
 }
 return {prepare,commit,restore,status,analyze,assertClear,assertNotOwned};
}
module.exports={LEVELS,GROUPS,descriptor,validateSession,createProfileService};
