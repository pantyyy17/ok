'use strict';
// Seller-only utilities. This module and its manager must NOT be shipped in the client installer.
const fs=require('node:fs');
const path=require('node:path');
const {generateKeyPairSync,randomBytes,createPrivateKey,createPublicKey}=require('node:crypto');
const {createIssuerCode,PRODUCT}=require('../licensing');
const {externalPath}=require('./private-path');
const projectRoot=path.resolve(__dirname,'..');
function mustBeExternal(dir){
 return externalPath(dir,projectRoot);
}
function files(dir){const d=mustBeExternal(dir);return {dir:d,privateFile:path.join(d,'carpatia-private.pem'),publicFile:path.join(d,'carpatia-public.pem'),historyFile:path.join(d,'issued-licenses.json')};}
function readHistory(filename){
 if(!fs.existsSync(filename))return [];
 let records;
 try{records=JSON.parse(fs.readFileSync(filename,'utf8'))}catch{throw Error('Istoricul licențelor este invalid; păstrează fișierul pentru recuperare.')}
 const ids=new Set();
 if(!Array.isArray(records)||records.some(r=>{
  if(!r||typeof r!=='object'||Array.isArray(r)||typeof r.id!=='string'||!/^[a-zA-Z0-9_-]{6,100}$/.test(r.id)||ids.has(r.id)||typeof r.customer!=='string'||!r.customer.trim()||r.customer.length>180||typeof r.issuedAt!=='string')return true;
  ids.add(r.id);
  const issue=Date.parse(r.issuedAt);
  return !Number.isFinite(issue)||(r.expiresAt!==null&&(typeof r.expiresAt!=='string'||!Number.isFinite(Date.parse(r.expiresAt))||Date.parse(r.expiresAt)<=issue));
 }))throw Error('Istoricul licențelor este invalid; păstrează fișierul pentru recuperare.');
 return records;
}
function issuerStatus(directory){
 const p=files(directory),hasPrivate=fs.existsSync(p.privateFile),hasPublic=fs.existsSync(p.publicFile);
 let records=[],error=null;
 try{
  records=readHistory(p.historyFile);
  if(hasPrivate&&hasPublic)getKeys(directory);
 }catch(e){records=[];error=e.message}
 return {ready:hasPrivate&&hasPublic&&!error,partial:hasPrivate!==hasPublic,error,configured:fs.existsSync(path.join(projectRoot,'license-public.pem')),issuedCount:records.length,records:records.slice(-40).reverse().map(({id,customer,issuedAt,expiresAt})=>({id,customer,issuedAt,expiresAt}))};
}
function initialize(directory){
 const p=files(directory);if(fs.existsSync(p.privateFile)||fs.existsSync(p.publicFile))throw Error('Cheile există deja sau setul este incomplet. Nu le suprascriem.');
 fs.mkdirSync(p.dir,{recursive:true,mode:0o700});
 const {privateKey,publicKey}=generateKeyPairSync('ed25519');
 fs.writeFileSync(p.privateFile,privateKey.export({type:'pkcs8',format:'pem'}),{flag:'wx',mode:0o600});
 try{fs.writeFileSync(p.publicFile,publicKey.export({type:'spki',format:'pem'}),{flag:'wx',mode:0o644})}catch(e){throw Error('Cheia publică nu s-a putut scrie. Cheia privată a fost păstrată pentru recuperare manuală: '+e.message)}
 return issuerStatus(directory);
}
function getKeys(directory){
 const p=files(directory);if(!fs.existsSync(p.privateFile)||!fs.existsSync(p.publicFile))throw Error('Cheile nu există; creează-le mai întâi.');
 const privateText=fs.readFileSync(p.privateFile,'utf8');const pubText=fs.readFileSync(p.publicFile,'utf8');
 const key=createPrivateKey(privateText),publicKey=createPublicKey(pubText);
 if(key.asymmetricKeyType!=='ed25519'||publicKey.asymmetricKeyType!=='ed25519')throw Error('Cheie de semnare incompatibilă: este necesară Ed25519.');
 const actualPublic=createPublicKey(key).export({format:'der',type:'spki'});
 if(!actualPublic.equals(publicKey.export({format:'der',type:'spki'})))throw Error('Cheia publică nu corespunde cheii private. Operația a fost oprită.');
 return {...p,privateText,pubText};
}
function configurePublicKey(directory){
 const p=getKeys(directory),dest=path.join(projectRoot,'license-public.pem');
 if(fs.existsSync(dest)){
  let matches=false;
  try{matches=createPublicKey(fs.readFileSync(dest,'utf8')).export({type:'spki',format:'der'}).equals(createPublicKey(p.pubText).export({type:'spki',format:'der'}))}catch{}
  if(!matches)throw Error('Proiectul are ALTĂ cheie publică sau una invalidă. Nu suprascriem cheia unei alte ediții.');
 }
 if(!fs.existsSync(dest))fs.writeFileSync(dest,p.pubText,{flag:'wx',mode:0o644});
 return {configured:true,message:'Cheia publică a editorului este pregătită pentru installer. Cheia PRIVATĂ a rămas separată.'};
}
function issueLicense(directory,{customer,days=null}={}){
 const p=getKeys(directory);
 if(typeof customer!=='string'||customer.trim().length<2||customer.trim().length>100||/[\r\n<>]/.test(customer))throw Error('Numele clientului trebuie să aibă între 2 și 100 caractere și să nu conțină caractere speciale HTML.');
 if(days!==null&&(!Number.isSafeInteger(days)||days<1||days>3650))throw Error('Durată invalidă. Alege permanent sau 1–3650 zile.');
 const now=new Date();const licenseId='crp_'+randomBytes(12).toString('hex');
 const expiresAt=days===null?null:new Date(now.getTime()+days*86400000).toISOString();
 const payload={product:PRODUCT,licenseId,customer:customer.trim(),issuedAt:now.toISOString(),expiresAt};
 const code=createIssuerCode(payload,p.privateText);
 // Validate the ledger BEFORE writing a new license to avoid orphaned codes on corrupted history.
 const history=readHistory(p.historyFile);
 const output=path.join(p.dir,licenseId+'.txt');fs.writeFileSync(output,code+'\n',{flag:'wx',mode:0o600});
 // History contains metadata only, not signing secrets or license codes.
 history.push({id:licenseId,customer:payload.customer,issuedAt:payload.issuedAt,expiresAt});
 const temp=p.historyFile+'.'+randomBytes(5).toString('hex')+'.tmp';
 let ownsTemp=false;
 try{
  const fd=fs.openSync(temp,'wx',0o600);ownsTemp=true;
  try{fs.writeFileSync(fd,JSON.stringify(history,null,2))}finally{fs.closeSync(fd)}
  fs.renameSync(temp,p.historyFile);
 }catch(error){
  // The caller must never receive a failed issue with a new, unrecorded code left behind.
  if(ownsTemp)try{fs.unlinkSync(temp)}catch{}
  try{fs.unlinkSync(output)}catch{}
  throw error;
 }
 return {code,id:licenseId,customer:payload.customer,expiresAt,filename:path.basename(output)};
}
module.exports={mustBeExternal,issuerStatus,initialize,configurePublicKey,issueLicense};
