'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {createIssuerCode,inspectLicense,createLicenseStore,PRODUCT}=require('../licensing');
const {createShopifyService,verifyHmac}=require('../seller/shopify-core');
const {initialize,issuerStatus,mustBeExternal,issueLicense}=require('../tools/issuer-core');
const pair=crypto.generateKeyPairSync('ed25519');
const privateKey=pair.privateKey.export({type:'pkcs8',format:'pem'});
const publicKey=pair.publicKey.export({type:'spki',format:'pem'});
const payload={product:PRODUCT,licenseId:'audit_client',customer:'Client Test',issuedAt:new Date(Date.now()-1000).toISOString(),expiresAt:null};
function temporary(t,dispose=()=>{}){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-commerce-'));t.after(()=>{dispose();fs.rmSync(dir,{recursive:true,force:true})});return dir}

test('Ed25519 key objects sign and verify; other signature algorithms cannot issue CARPATIA codes',()=>{
 const code=createIssuerCode(payload,pair.privateKey);
 assert.equal(inspectLicense(code,pair.publicKey).licenseId,payload.licenseId);
 const other=crypto.generateKeyPairSync('ed448');
 assert.throws(()=>createIssuerCode(payload,other.privateKey),/Ed25519/);
 const body=Buffer.from(JSON.stringify(payload)).toString('base64url'),message='CARPATIA-V1.'+body;
 const forged=message+'.'+crypto.sign(null,Buffer.from(message),other.privateKey).toString('base64url');
 assert.throws(()=>inspectLicense(forged,other.publicKey),/Semnătura/);
});

test('noncanonical base64url signatures are rejected even when they decode to signed bytes',()=>{
 const code=createIssuerCode(payload,privateKey),parts=code.split('.');
 const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
 const last=alphabet.indexOf(parts[2].at(-1));
 parts[2]=parts[2].slice(0,-1)+alphabet[last+1];
 assert.deepEqual(Buffer.from(parts[2],'base64url'),Buffer.from(code.split('.')[2],'base64url'));
 assert.throws(()=>inspectLicense(parts.join('.'),publicKey),/Semnătura/);
});

test('corrupt or oversized persisted license fails closed with a useful status',t=>{
 const dir=temporary(t),store=createLicenseStore({directory:dir,publicKey});
 fs.writeFileSync(path.join(dir,'carpatia-license.txt'),'x'.repeat(9000));
 assert.equal(store.status().active,false);assert.match(store.status().error,/lung/);
 assert.equal(store.activate(createIssuerCode(payload,privateKey)).active,true);
 assert.equal(store.licensed(),true);
});

test('HMAC parser rejects garbage or padding aliases instead of silently decoding them',()=>{
 const body=Buffer.from('{}'),signature=crypto.createHmac('sha256','secret').update(body).digest('base64');
 assert.equal(verifyHmac(body,signature,'secret'),true);
 assert.equal(verifyHmac(body,signature+'garbage','secret'),false);
 assert.equal(verifyHmac(body,signature.replace('=',''),'secret'),false);
});

test('Shopify 64-bit order, variant and line IDs remain exact and retries deduplicate',async t=>{
 let service;const dir=temporary(t,()=>service?.close());
 service=createShopifyService({database:path.join(dir,'db.sqlite'),privateKey,secret:'secret',shop:'audit.myshopify.com',variantId:'9007199254740993'});
 const event=id=>{
  const body=Buffer.from(`{"id":${id},"email":"buyer@example.com","financial_status":"paid","line_items":[{"id":9007199254740995,"variant_id":9007199254740993,"quantity":1}]}`);
  return [body,{'x-shopify-hmac-sha256':crypto.createHmac('sha256','secret').update(body).digest('base64'),'x-shopify-shop-domain':'audit.myshopify.com','x-shopify-topic':'orders/paid'}];
 };
 assert.equal(service.accept(...event('9007199254740992')).issued,1);
 assert.equal(service.accept(...event('9007199254740993')).issued,1);
 assert.equal(service.accept(...event('9007199254740993')).issued,0);
 const sent=[];await service.deliver(async mail=>{sent.push(mail);return {id:mail.id}});
 assert.equal(sent.length,2);assert.notEqual(sent[0].id,sent[1].id);
 for(const mail of sent)assert.equal(inspectLicense(mail.text.split('\n').find(x=>x.startsWith('CARPATIA-V1.')),publicKey).customer,'buyer@example.com');
});

test('missing headers and malformed Shopify shop configuration fail without issuing',t=>{
 let service;const dir=temporary(t,()=>service?.close()),config={database:path.join(dir,'db.sqlite'),privateKey,secret:'secret',shop:'audit.myshopify.com',variantId:'1'};
 assert.throws(()=>createShopifyService({...config,shop:'https://audit.myshopify.com'}),/Configurare/);
 service=createShopifyService(config);
 assert.equal(service.accept(Buffer.from('{}')).status,401);
 assert.equal(service.accept(Buffer.from('{}'),null).status,401);
});

test('issuer detects corrupted signing keys/history instead of reporting ready',t=>{
 const dir=temporary(t);initialize(dir);assert.equal(issuerStatus(dir).ready,true);
 fs.writeFileSync(path.join(dir,'issued-licenses.json'),'[null]');
 assert.equal(issuerStatus(dir).ready,false);assert.match(issuerStatus(dir).error,/Istoricul/);
 fs.unlinkSync(path.join(dir,'issued-licenses.json'));
 fs.writeFileSync(path.join(dir,'carpatia-private.pem'),'broken');
 assert.equal(issuerStatus(dir).ready,false);assert.ok(issuerStatus(dir).error);
});

test('external directory symlink cannot redirect signing secrets into the project',t=>{
 const dir=temporary(t),link=path.join(dir,'project-link');
 fs.symlinkSync(path.resolve(__dirname,'..'),link,process.platform==='win32'?'junction':'dir');
 assert.throws(()=>mustBeExternal(path.join(link,'not-yet-created','keys')),/AFARA/);
 assert.throws(()=>mustBeExternal(link),/AFARA/);
 assert.equal(mustBeExternal(path.join(dir,'new','keys')),path.join(fs.realpathSync(dir),'new','keys'));
});

test('signed license expiry must be a date string and customers cannot be blank',()=>{
 for(const overrides of [{customer:'  '},{expiresAt:['2999-01-01T00:00:00.000Z']}]){
  const invalid={...payload,...overrides};
  assert.throws(()=>createIssuerCode(invalid,privateKey),/invalide|invalidă/);
  const message='CARPATIA-V1.'+Buffer.from(JSON.stringify(invalid)).toString('base64url');
  const code=message+'.'+crypto.sign(null,Buffer.from(message),pair.privateKey).toString('base64url');
  assert.throws(()=>inspectLicense(code,publicKey),/invalide|invalidă/);
 }
});

test('corrupt history is rejected consistently by status and issuance without creating a code',t=>{
 const dir=temporary(t);initialize(dir);
 const history=path.join(dir,'issued-licenses.json');
 const valid={id:'crp_history',customer:'Client',issuedAt:'2020-01-01T00:00:00.000Z',expiresAt:'2021-01-01T00:00:00.000Z'};
 // Past expiry is valid historical metadata; malformed rows cannot reach the dashboard.
 fs.writeFileSync(history,JSON.stringify([valid]));assert.equal(issuerStatus(dir).ready,true);
 for(const rows of [[null],[{}],[{...valid,expiresAt:123}],[{...valid,issuedAt:'invalid'}],[valid,valid]]){
  const original=JSON.stringify(rows);fs.writeFileSync(history,original);
  const before=fs.readdirSync(dir).sort();
  assert.equal(issuerStatus(dir).ready,false);assert.match(issuerStatus(dir).error,/Istoricul/);
  assert.throws(()=>issueLicense(dir,{customer:'Client nou'}),/Istoricul/);
  assert.equal(fs.readFileSync(history,'utf8'),original);
  assert.deepEqual(fs.readdirSync(dir).sort(),before);
 }
});

test('failed history commit removes the unrecorded code and temporary ledger',t=>{
 const dir=temporary(t);initialize(dir);issueLicense(dir,{customer:'Primul client'});
 const history=path.join(dir,'issued-licenses.json'),original=fs.readFileSync(history,'utf8'),before=fs.readdirSync(dir).sort();
 const rename=fs.renameSync;
 try{
  fs.renameSync=(source,dest)=>{if(dest===history)throw Error('History write failed');return rename(source,dest)};
  assert.throws(()=>issueLicense(dir,{customer:'Al doilea client'}),/History write failed/);
 }finally{fs.renameSync=rename}
 assert.equal(fs.readFileSync(history,'utf8'),original);
 assert.deepEqual(fs.readdirSync(dir).sort(),before);
 assert.equal(issuerStatus(dir).issuedCount,1);
});

test('Shopify rejects malformed recipients before persisting a license or mail',async t=>{
 let service;const dir=temporary(t,()=>service?.close());
 service=createShopifyService({database:path.join(dir,'db.sqlite'),privateKey,secret:'secret',shop:'audit.myshopify.com',variantId:'1'});
 for(const email of ['buyer@@example.com','buyer@one@example.com']){
  const raw=Buffer.from(JSON.stringify({id:1,email,financial_status:'paid',line_items:[{id:2,variant_id:1,quantity:1}]}));
  const headers={'x-shopify-hmac-sha256':crypto.createHmac('sha256','secret').update(raw).digest('base64'),'x-shopify-shop-domain':'audit.myshopify.com','x-shopify-topic':'orders/paid'};
  assert.equal(service.accept(raw,headers).status,422);
 }
 let sent=0;await service.deliver(async()=>{sent++;return {id:'unexpected'}});assert.equal(sent,0);
});
