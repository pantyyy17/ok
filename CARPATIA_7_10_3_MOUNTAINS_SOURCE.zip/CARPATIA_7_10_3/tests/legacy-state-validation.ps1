$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$script:assertions=0
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$failed=$false;try{& $operation}catch{$failed=$true};Assert $failed $label}
function Parse-Script($name){
 $tokens=$null;$errors=$null
 $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $root $name),[ref]$tokens,[ref]$errors)
 if(@($errors).Count){throw ('Parse errors in '+$name)}
 return $ast
}
function Import-Function($ast,$name){
 $definition=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 if($null -eq $definition){throw ('Missing function '+$name)}
 $parameters=(@($definition.Parameters | ForEach-Object {$_.Extent.Text}) -join ',')
 $body=$definition.Body.Extent.Text
 Set-Item -Path ('Function:script:'+$name) -Value ([scriptblock]::Create(('param('+ $parameters +')'+$body.Substring(1,$body.Length-2))))
}

$gpu=Parse-Script 'gpu-lab.ps1'
Import-Function $gpu 'Get-Preference'
$registryKey='HKCU:\MockGpuPreferences';$target='C:\Games\game.exe'
$script:mockKind='String';$script:mockValue='AutoHDREnable=1;GpuPreference=1;';$script:mockNames=@($target)
$mockKey=[pscustomobject]@{}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValueNames -Value {return $script:mockNames}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValueKind -Value {param($name) return $script:mockKind}
$mockKey | Add-Member -MemberType ScriptMethod -Name GetValue -Value {param($name,$default,$flags) $script:readFlags=$flags;return $script:mockValue}
function Test-Path {param($LiteralPath) return $true}
function Get-Item {param($LiteralPath,$ErrorAction) return $mockKey}
$actual=Get-Preference $target
Assert ($actual.present -and $actual.raw -ceq $script:mockValue) 'REG_SZ GPU preferences are read exactly'
Assert ($script:readFlags -eq [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) 'GPU strings are read without environment expansion'
foreach($kind in @('ExpandString','DWord','QWord','Binary','MultiString')){
 $script:mockKind=$kind
 Reject {Get-Preference $target} ('GPU '+$kind+' originals cannot be overwritten with REG_SZ')
}
$script:mockNames=@()
Assert (-not (Get-Preference $target).present) 'missing GPU value remains absent'

# Run the actual Apply write/readback block with every Registry operation mocked.
# Having GpuPreference=2 is insufficient if another original token disappeared.
$writeBlock=$gpu.Find({param($n) $n -is [Management.Automation.Language.TryStatementAst] -and $n.Body.Extent.Text.Contains('New-ItemProperty -Path $registryKey') -and $n.Body.Extent.Text.Contains('$newRaw')},$true)
Assert ($null -ne $writeBlock) 'actual GPU Apply write block located'
$apply=[scriptblock]::Create($writeBlock.Extent.Text)
$newRaw='AutoHDREnable=1;GpuPreference=2;';$script:actualRaw='GpuPreference=2;'
function New-ItemProperty {param($Path,$Name,$PropertyType,$Value,[switch]$Force,$ErrorAction) $script:wrote=$Value}
function Get-Preference {param($target) return @{present=$true;raw=$script:actualRaw}}
Reject {& $apply} 'GPU Apply cannot claim success after losing another original preference'
$script:actualRaw=$newRaw
& $apply
Assert ($script:wrote -ceq $newRaw) 'GPU Apply accepts exact Registry readback'

$startup=Parse-Script 'startup.ps1'
Import-Function $startup 'Backups'
$file='mock-startup.json'
function Get-Content {param($LiteralPath,[switch]$Raw,$Encoding) return $script:backupJson}
function Set-Backup($items){$script:backupJson=(@{version=1;items=$items}|ConvertTo-Json -Depth 8 -Compress)}
$entry=@{name='Example';value='C:\Apps\example.exe';kind='String'}
Set-Backup @($entry)
Assert (@(Backups).Count -eq 1) 'valid single Startup original loads as one entry'
Set-Backup @()
Assert (@(Backups).Count -eq 0) 'empty Startup journal remains valid'
foreach($bad in @(
 @{name='Other';kind='String'},
 @{name='Other';kind='String';value=12},
 @{name='Other';kind='Binary';value='command'},
 @{name="Other`nEntry";kind='String';value='command'},
 @{name='example';kind='String';value='different command'}
)){
 Set-Backup @($entry,$bad)
 Reject {Backups} 'malformed later Startup original rejects entire journal before restore'
}
Set-Backup $entry
Reject {Backups} 'Startup items must be an explicit array'

# Every service original captured by Current must be accepted by the restore
# journal validator. Unexpected delayed-start values used to be saved, disabled,
# then rejected permanently by Read-ServiceBackup on Restore.
$services=Parse-Script 'services-lab.ps1'
Import-Function $services 'Current'
$serviceNames=@{sysmain='SysMain'}
function BackupFile($id){return 'mock-service.json'}
function Get-CimInstance {param($ClassName,$Filter,$ErrorAction) return @{State='Running';StartMode='Auto'}}
$script:mockNames=@('DelayedAutoStart');$script:mockKind='DWord';$script:mockValue=1
Assert ((Current 'sysmain').delayedAutoStart -eq 1) 'documented service delayed start captures a restorable original'
$script:mockValue=2
Reject {Current 'sysmain'} 'unsupported delayed start is rejected before service backup or disable'
$script:mockValue=1;$script:mockKind='String'
Reject {Current 'sysmain'} 'non-DWORD delayed start cannot silently lose its original kind'
@{success=$true;assertions=$script:assertions}|ConvertTo-Json -Compress
