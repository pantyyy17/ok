﻿param(
 [ValidateSet('Status','Apply','Restore')][string]$Action='Status',
 [string]$Adapter=''
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
$file=Join-Path $dir 'tcp-latency.json'
$root='Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
$fields=@('TcpAckFrequency','TCPNoDelay')
function Administrator { $id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=[Security.Principal.WindowsPrincipal]$id; return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
function Get-RegState([string]$key){
 $output=@{}
 foreach($name in $fields){
  $exists=$false;$value=$null;$kind=$null
  if(Test-Path -LiteralPath $key){
   $rk=Get-Item -LiteralPath $key
   $exists=$rk.GetValueNames() -contains $name
   if($exists){$value=$rk.GetValue($name);$kind=[string]$rk.GetValueKind($name)}
  }
  $output[$name]=@{exists=$exists;value=$value;kind=$kind}
 }
 return $output
}
function Validate-TcpState($state){
 foreach($name in $fields){
  $p=$state.$name
  if($null -eq $p -or $p.exists -isnot [bool]){throw 'Backup TCP incomplet.'}
  if($p.exists -and ($p.kind -cne 'DWord' -or ($p.value -isnot [int] -and $p.value -isnot [long]) -or [long]$p.value -lt -2147483648 -or [long]$p.value -gt 4294967295)){throw 'Original TCP invalid.'}
 }
}
function Same-TcpValue($actual,$expected){
 if($actual.exists -ne $expected.exists){return $false}
 if(-not $expected.exists){return $true}
 return ($actual.kind -ceq $expected.kind -and (([long]$actual.value -band 4294967295) -eq ([long]$expected.value -band 4294967295)))
}
function Assert-TcpRestored([string]$key,$state){
 $actual=Get-RegState $key
 foreach($name in $fields){if(-not (Same-TcpValue $actual[$name] $state.$name)){throw "Restaurare TCP neconfirmată pentru $name. Backup păstrat."}}
}
function Put-Previous([string]$key,$state){
 Validate-TcpState $state
 foreach($name in $fields){
  $p=$state.$name
  if($p.exists){
   if($p.kind -ne 'DWord'){throw "Backup contine tip incompatibil pentru $name"}
   $value=[long]$p.value
   if($value -gt [int]::MaxValue){$value=[BitConverter]::ToInt32([BitConverter]::GetBytes([uint32]$value),0)}
   New-ItemProperty -LiteralPath $key -Name $name -Value ([int]$value) -PropertyType DWord -Force -ErrorAction Stop|Out-Null
  }else{Remove-ItemProperty -LiteralPath $key -Name $name -ErrorAction SilentlyContinue}
 }
}
function Resolve-Adapter([string]$name){
 $a=@(Get-NetAdapter -ErrorAction Stop | Where-Object {$_.Name -eq $name})
 if(@($a).Count -ne 1){throw 'Alege un singur adaptor.'}
 $a=$a[0]
 if($a.Status -ne 'Up'){throw 'Adaptorul selectat nu este activ.'}
 $guid=[string]$a.InterfaceGuid
 if($guid -notmatch '^[{]?[0-9a-fA-F-]{36}[}]?$'){throw 'Identificator adaptor invalid.'}
 $key=Join-Path $root ($guid.Trim('{}').ToUpperInvariant())
 if(!(Test-Path -LiteralPath $key)){
  $key=Join-Path $root ('{'+$guid.Trim('{}').ToUpperInvariant()+'}')
 }
 if(!(Test-Path -LiteralPath $key)){throw 'Cheia TCP/IP a adaptorului nu exista.'}
 return @{name=$a.Name;guid=$guid;key=$key;index=$a.ifIndex}
}
if($Action -eq 'Status'){
 $adapters=@(Get-NetAdapter -ErrorAction Stop|Where-Object {$_.Status -eq 'Up' -and (-not $Adapter -or $_.Name -eq $Adapter)}|ForEach-Object{
  $adapterRow=$_;try{$target=Resolve-Adapter $adapterRow.Name;$state=Get-RegState $target.key
   @{name=$target.name;guid=$target.guid;ipv4=@(Get-NetIPAddress -InterfaceIndex $target.index -AddressFamily IPv4 -ErrorAction SilentlyContinue|Select-Object -ExpandProperty IPAddress);supported=$true;tcpAckFrequency=$state.TcpAckFrequency.value;tcpNoDelay=$state.TCPNoDelay.value}
  }catch{@{name=$adapterRow.Name;guid=[string]$adapterRow.InterfaceGuid;supported=$false;reason=$_.Exception.Message}}
 })
 $backup=$null
 if(Test-Path -LiteralPath $file){$b=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json;$backup=@{adapter=$b.name;guid=$b.guid;timestamp=$b.timestamp}}
 @{success=$true;admin=(Administrator);adapters=$adapters;backup=$backup}|ConvertTo-Json -Depth 6 -Compress;exit 0
}
if(!(Administrator)){throw 'Sunt necesare drepturi de administrator. Porneste START_ADMIN_OPTIONAL.bat ca administrator.'}
New-Item -ItemType Directory -Force -Path $dir|Out-Null
if($Action -eq 'Apply'){
 if(Test-Path -LiteralPath $file){throw 'Exista un backup TCP activ. Restaureaza-l inainte de o alta aplicare.'}
 if([string]::IsNullOrWhiteSpace($Adapter)){throw 'Alege adaptorul activ.'}
 $target=Resolve-Adapter $Adapter
 $previous=Get-RegState $target.key
 foreach($name in $fields){if($previous[$name].exists -and $previous[$name].kind -ne 'DWord'){throw "Tipul existent pentru $name nu este DWORD. Nu modific nimic."}}
 $backup=@{guid=$target.guid;name=$target.name;key=$target.key;timestamp=(Get-Date).ToString('o');state=$previous}
 $backup|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $file -Encoding UTF8
 try{
  foreach($name in $fields){New-ItemProperty -LiteralPath $target.key -Name $name -Value 1 -PropertyType DWord -Force -ErrorAction Stop|Out-Null}
  $after=Get-RegState $target.key
  foreach($name in $fields){if(-not $after[$name].exists -or [int]$after[$name].value -ne 1){throw "Verificarea registrului a esuat pentru $name"}}
 }catch{
  $errorText=$_.Exception.Message
  try{Put-Previous $target.key $backup.state;Assert-TcpRestored $target.key $backup.state;Remove-Item -LiteralPath $file -Force -ErrorAction Stop}catch{throw "Aplicarea a esuat: $errorText. Restaurarea automata a esuat: $($_.Exception.Message). Backup pastrat."}
  throw "Aplicarea a esuat si modificarile au fost anulate: $errorText"
 }
 @{success=$true;message='Valorile TCP sunt setate pentru adaptorul ales. Necesita uneori restart. Nu afecteaza UDP. Testeaza inainte/dupa.';adapter=$target.name;backup=$true;restartRecommended=$true}|ConvertTo-Json -Compress;exit 0
}
if(!(Test-Path -LiteralPath $file)){throw 'Nu exista backup TCP de restaurat.'}
$b=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json
$originalGuid=[guid]::Empty
if(-not [guid]::TryParse([string]$b.guid,[ref]$originalGuid)){throw 'Identitatea adaptorului din backup este invalida.'}
$matches=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop | Where-Object {([guid]$_.InterfaceGuid) -eq $originalGuid})
if($matches.Count -ne 1){throw 'Adaptorul original nu mai este disponibil. Backup pastrat.'}
$a=$matches[0]
# Never trust registry paths from user-writable backup files while running elevated.
# Reconstruct the only permitted HKLM interface key from the adapter verified above.
$normalized=([string]$a.InterfaceGuid).Trim('{}').ToUpperInvariant()
$trustedKey=Join-Path $root $normalized
if(!(Test-Path -LiteralPath $trustedKey)){$trustedKey=Join-Path $root ('{'+$normalized+'}')}
if(!(Test-Path -LiteralPath $trustedKey)){throw 'Cheia de registry a adaptorului original nu mai exista.'}
if([string]$b.key -ine $trustedKey){throw 'Cheia backupului nu corespunde adaptorului verificat. Nimic nu a fost schimbat.'}
if($null -eq $b.state -or $null -eq $b.state.TcpAckFrequency -or $null -eq $b.state.TCPNoDelay){throw 'Backup TCP incomplet. Nimic nu a fost schimbat.'}
Validate-TcpState $b.state
$actual=Get-RegState $trustedKey
foreach($name in $fields){
 $desired=@{exists=$true;kind='DWord';value=1}
 if(-not (Same-TcpValue $actual[$name] $b.state.$name) -and -not (Same-TcpValue $actual[$name] $desired)){throw "Modificare TCP externă pentru $name. Backup păstrat."}
}
Put-Previous $trustedKey $b.state
Assert-TcpRestored $trustedKey $b.state
$archive=Join-Path $dir ('tcp-restored-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
Move-Item -LiteralPath $file -Destination $archive -Force
@{success=$true;message='Valorile TCP originale au fost restaurate si verificate. Uneori este necesar restart.';restartRecommended=$true}|ConvertTo-Json -Compress
