'use strict';
// CARPATIA REDLINE: lean renderer, no frameworks, trackers, game profiles, or fake FPS.
(()=>{
 const api=window.carpatia||null;
 const networkOptions=window.CarpatiaNetworkOptions.mount({api,document});
 const motion=window.CarpatiaMotion?.createMotionController({document,Observer:window.IntersectionObserver});
 window.addEventListener('pagehide',()=>motion?.destroy(),{once:true});
 const $=id=>document.getElementById(id),$$=q=>Array.from(document.querySelectorAll(q));
 const el=(tag,cls,content)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(content!==undefined)node.textContent=String(content);return node};
 const text=(id,value)=>{const node=$(id);if(node)node.textContent=String(value??'—')};
 let activeTaskLabel='',activeTaskSince=0;
 let view='dashboard',modalResolver=null,modalPreviousFocus=null,mutationBusy=false,catalogCache=[],debloatCache=[],sensorLast=0,licensed=false,dashboardPending=false;
 function showToast(message){const node=$('toast');node.textContent=String(message);node.classList.remove('hidden');setTimeout(()=>{if(node.textContent===String(message))node.classList.add('hidden')},6500)}
 function errorMessage(e){return String(e?.message||e).replace(/^Error invoking remote method '[^']+':\s*Error:\s*/,'')}
 function reactorState(id,state){
  const button=$(id);if(!button)return;
  button.classList.remove('is-working','is-complete','is-error');
  if(state==='working'||state==='complete'||state==='error')button.classList.add('is-'+state);
  button.setAttribute('aria-busy',state==='working'?'true':'false');
  const hint=button.querySelector('.reactor-state');
  if(hint)hint.textContent=({working:'ÎN CURS',complete:'VERIFICAT',error:'EROARE'})[state]||'';
 }
 async function task(label,fn,reactorId=null){
  if(mutationBusy){showToast(`Operația ${activeTaskLabel} este în curs de ${Math.floor((Date.now()-activeTaskSince)/1000)} secunde. Verifică și fereastra de confirmare.`);return null}
  mutationBusy=true;activeTaskLabel=label;activeTaskSince=Date.now();document.body.dataset.busy='true';
  if(reactorId)reactorState(reactorId,'working');
  try{
   const result=await fn();
   if(reactorId)reactorState(reactorId,result?.success===true?'complete':result?.success===false?'error':'idle');
   return result;
  }catch(e){if(label.startsWith('Restore'))text('restoreResult',label+': '+errorMessage(e));if(reactorId){reactorState(reactorId,'error');text('heroOpStatus','⚠ '+errorMessage(e))}showToast(`${label}: ${errorMessage(e)}`);return null}
  finally{mutationBusy=false;delete document.body.dataset.busy;flushSettingsRefresh()}
 }
 let settingsDirty=false;
 api?.onSettingsChanged?.(()=>{settingsDirty=true;if(!mutationBusy)flushSettingsRefresh()});
 function flushSettingsRefresh(){
  if(!settingsDirty)return;settingsDirty=false;
  Promise.allSettled([dashboardPage.load({skipAdapters:true}),libraryPage.load(),recoveryPage.load()]).then(results=>{for(const r of results)if(r.status==='rejected')showToast('Actualizare stare: '+errorMessage(r.reason))});
 }
 function requireNative(recovery=false){
  if(!api){showToast('Previzualizare HTML: operațiile Windows funcționează numai în aplicația Electron.');return false}
  if(!licensed&&!recovery){$('licenseGate').classList.remove('hidden');text('licenseMessage','Activează o licență validă pentru a folosi funcțiile Windows.');return false}
  return true;
 }
 function setLicenseState(info){
  licensed=Boolean(info?.active);
  $('licenseGate').classList.toggle('hidden',licensed);
  $('licenseClose').classList.toggle('hidden',!licensed);
  document.body.dataset.licensed=licensed?'yes':'no';
  text('licenseButton',licensed?(info.developer?'MOD DEZVOLTARE':'LICENȚĂ ACTIVĂ'):'INTRODU LICENȚA');
  text('licenseMessage',licensed?`Activată pentru ${info.customer||'client'} · ${info.licenseId||''}${info.expiresAt?' · Valabilă până la '+info.expiresAt.slice(0,10):' · PERMANENTĂ'}`:info?.error||'Introdu codul achiziționat pentru deblocare.');
 }
 async function initLicense(){
  if(!api){$('licenseGate').classList.add('hidden');$('licenseButton').classList.add('hidden');return}
  try{setLicenseState(await api.licenseStatus());if(licensed)refreshDashboard(true)}
  catch(e){setLicenseState({active:false,error:'Verificarea licenței nu a reușit: '+errorMessage(e)})}
 }
 $('licenseButton').onclick=()=>{if(!api)return;if(licensed){$('licenseGate').classList.remove('hidden');$('licenseClose').classList.remove('hidden')}else $('licenseGate').classList.remove('hidden')};
 $('licenseClose').onclick=()=>{if(licensed)$('licenseGate').classList.add('hidden')};
 $('licenseRecovery').onclick=()=>{if(!api)return;$('licenseGate').classList.add('hidden');navigate('restore')};
 $('licenseActivate').onclick=async()=>{
  if(!api)return;
  const code=$('licenseCode').value.trim();
  if(!code){text('licenseMessage','Lipește codul primit după cumpărare.');return}
  $('licenseActivate').disabled=true;
  text('licenseMessage','Verific semnătura digitală…');
  try{setLicenseState(await api.licenseActivate(code));$('licenseCode').value='';showToast('Licența CARPATIA a fost activată.');refreshDashboard(true)}
  catch(e){text('licenseMessage',errorMessage(e))}
  finally{$('licenseActivate').disabled=false}
 };

 function confirmDialog(title,message,details='',warning='',button='CONFIRMĂ'){
  if(modalResolver)return Promise.resolve(false);
  modalPreviousFocus=document.activeElement;
  text('modalHeading',title);text('modalMessage',message);text('modalDetails',details);text('modalWarning',warning);text('modalConfirm',button);
  $('modalBackdrop').classList.remove('hidden');$('modalCancel').focus();
  return new Promise(resolve=>{modalResolver=resolve});
 }
 function finishModal(value){$('modalBackdrop').classList.add('hidden');if(modalResolver){const resolve=modalResolver;modalResolver=null;(modalPreviousFocus?.isConnected?modalPreviousFocus:$$('.nav.active')[0])?.focus();modalPreviousFocus=null;resolve(!!value)}}
 $('modalCancel').addEventListener('click',()=>finishModal(false));$('modalConfirm').addEventListener('click',()=>finishModal(true));
 document.addEventListener('keydown',e=>{if(!modalResolver)return;if(e.key==='Escape'){e.preventDefault();finishModal(false)}if(e.key==='Tab'){const first=$('modalCancel'),last=$('modalConfirm');if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
 $('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))finishModal(false)});
 function navigate(name,auto=false){
  if(api&&!licensed&&!['restore','gpu','cleanup','tweaks'].includes(name)){$('licenseGate').classList.remove('hidden');return}
  if(!$("view-"+name))return;
  const location=$('workspaceLocation');if(location)location.textContent=({dashboard:'Dashboard',performance:'Performanță',network:'Rețea & DNS',gpu:'GPU Tuning',tweaks:'Sistem & Tweaks',cleanup:'Curățare',restore:'Backup & Restore',settings:'Setări',debloat:'Debloat'})[name]||name;
  view=name;$$('.view').forEach(n=>n.classList.toggle('active',n.id==='view-'+name));
  $$('.nav').forEach(n=>{const active=n.dataset.view===name;n.classList.toggle('active',active);n.setAttribute('aria-current',active?'page':'false')});
  window.scrollTo?.(0,0);motion?.sync();
  if(!api)return;
  if(name==='tweaks')loadTweaks().catch(e=>showToast(errorMessage(e)));
  if(name==='network')loadNetwork();
  if(name==='restore'){checkBackups().catch(e=>showToast(errorMessage(e)));recoveryPage.load().catch(e=>showToast(errorMessage(e)))}
  if(name==='gpu'&&licensed)loadGpu();
  if(name==='debloat'&&auto)scanDebloat();
 }
 $$('.nav').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
 $$('[data-jump]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.jump)));
 $('heroDebloat').onclick=()=>dashboardPage.run('cpu');
 $('heroUltra').onclick=()=>dashboardPage.run('gpu');
 $('heroNetwork').onclick=()=>dashboardPage.run('internet');
 $('goNetRestore').onclick=()=>navigate('restore');
 $('topRefresh').onclick=()=>{if(!requireNative())return;refreshDashboard(true)};
 $('analyzeUltra').onclick=()=>ultraStart();
 // Read-only device measurements: CPU/RAM from Node, optional local LibreHardwareMonitor.
 async function refreshDashboard(full=false){
  if(!api){text('connection','● PREVIZUALIZARE HTML');return}
  if(dashboardPending)return;dashboardPending=true;
  try{
   if(full){const sys=await api.sys();text('hardwareText',`${sys.cpu} · ${sys.ramGB} GB RAM · ${sys.cores} nuclee logice · Windows ${sys.windowsVersion}`);const a=await api.admin();$('connection').textContent=a.admin?'● WINDOWS · ADMIN':'● WINDOWS · FĂRĂ ADMIN';$('connection').classList.add('online');text('healthState', '');const state=$('healthState');state.replaceChildren(el('span',null,'◈'));const box=el('div');box.append(el('b',null,'Monitorizare disponibilă'),el('small',null,'Date citite din Windows. Acesta nu este un diagnostic al sănătății PC-ului.'));state.append(box);state.classList.remove('ok')}
   const m=await api.metrics();paintGauge('CPU',m.cpu,'%');paintGauge('RAM',m.ram,'%');
   if(full||Date.now()-sensorLast>25000){sensorLast=Date.now();const s=await api.sensors();if(s.available){paintGauge('GPU',s.gpuLoad?.value,'%');paintGauge('Temp',s.gpuTemperature?.value??s.cpuTemperature?.value,'°C',true);text('hardwareSource','SENZORI LOCALI')}else{paintGauge('GPU',null,'%');paintGauge('Temp',null,'°C');text('hardwareSource','FĂRĂ SENZOR GPU/TEMP')}}
  }catch(e){if(full)showToast('Monitorizare: '+errorMessage(e))}finally{dashboardPending=false}
 }
 function paintGauge(key,value,suffix,isTemp=false){let n=Number(value);if(value===null||value===undefined||!Number.isFinite(n)){text('value'+key,'—');$('meter'+key).style.setProperty('--val',0);return}text('value'+key,`${Math.round(n)}${suffix}`);$('meter'+key).style.setProperty('--val',Math.min(100,Math.max(0,isTemp?n: n)))}
 async function ultraStart(selectedMode){if(!requireNative())return;const mode=selectedMode||$('perfSelect').value;
  await task('ULTRA HIGH',async()=>{
   if(mode==='eco'){const r=await api.ultraAnalyze();text('ultraStatus',`Diagnostic ECO: ${r.hardware.cpu}. RAM ${r.hardware.ramGB} GB. Nicio modificare aplicată.`);return}
   text('ultraStatus','Analizez hardware-ul, Registry și backupurile…');text('heroOpStatus','◈ Analizez hardware-ul și construiesc planul ULTRA…');
   const {token,plan}=await api.ultraPrepare({mode,riskAcknowledged:mode==='ultra'});
   text('ultraStatus',`Plan pregătit: ${plan.ids.length} tweak-uri, plan de alimentare ${plan.power?'DA':'NU'}. Nicio modificare până la confirmare.`);text('heroOpStatus',`◈ Plan: ${plan.ids.length} tweak-uri · ${plan.power?'plan de alimentare':'fără schimbare de alimentare'}. Aștept confirmarea.`);
   $('ultraPlan').replaceChildren(...plan.ids.slice(0,15).map(id=>el('div','result-row',id)));
   if(plan.ids.length>15)$('ultraPlan').append(el('div','progress-text',`…și alte ${plan.ids.length-15} reguli. Lista completă este generată și validată în motor.`));
   const details=`Profil: ${mode.toUpperCase()}\nReguli Registry: ${plan.ids.length}\nPlan High Performance: ${plan.power?'Da':'Nu'}\n\n${plan.ids.join('\n')}`;
   const warning=mode==='ultra'?'ULTRA include setări cu risc mediu care pot afecta Windows și unele aplicații. Nu garantează mai multe FPS. Creează backup și confirmă numai dacă accepți riscurile.':'Unele modificări pot necesita relogare/restart. Performanța trebuie măsurată înainte/după.';
   if(!await confirmDialog('Aplici profilul '+mode.toUpperCase()+'?', 'CARPATIA va modifica doar regulile afișate mai jos și va păstra valorile anterioare pentru restaurare.',details,warning,'⚡ APLICĂ CU BACKUP')){text('ultraStatus','Anulat. Nu s-a modificat nimic.');text('heroOpStatus','◈ Anulat de utilizator. Nu s-a modificat nimic.');return}
   text('ultraProgress','Aplicare inițiată…');const r=await api.ultraCommit(token);
   text('ultraStatus',r.message||'Operațiune încheiată.');text('heroOpStatus',r.success?'✓ Optimizare confirmată de Windows; backup păstrat.':'⚠ Operație incompletă: consultă Restaurare.');text('ultraProgress',r.success?'✔ Windows a confirmat aplicarea. Verifică efectul în joc și păstrează backupul.':'⚠ Aplicare parțială sau nereușită. Verifică Restaurare.');
   if(!r.success)showToast(r.message||'Aplicare ULTRA nereușită');else showToast('Profil aplicat și verificat de motorul Windows.');
   return {success:r.success};
  });
 }
 api?.onUltraProgress?.(ev=>{text('ultraProgress',ev.detail);if(view==='dashboard')text('heroOpStatus',`◈ ${ev.detail}`)});
 // INTERNET BOOST — requires confirmation after real adapter scan and backend plan.
 async function loadNetwork(){if(!requireNative())return;try{const net=await api.network();const select=$('adapterSelect'),selected=select.value;select.replaceChildren();const choices=(net.adapters||[]).filter(x=>Array.isArray(x.ipv4)&&x.ipv4.length>0);for(const row of choices){const opt=el('option',null,`${row.name} · ${row.linkSpeed||''}`);opt.value=row.name;select.append(opt)}if(selected&&choices.some(x=>x.name===selected))select.value=selected;if(!choices.length){const option=el('option',null,'Niciun adaptor activ');option.value='';select.append(option)}await networkOptions.refresh()}catch(e){text('netStatus','Adaptorul nu a putut fi citit: '+errorMessage(e))}}
 $('netStart').onclick=()=>{if(!requireNative())return;task('INTERNET BOOST',async()=>{
  try{
  const request={adapter:$('adapterSelect').value,provider:$('dnsSelect').value,options:{nicPower:$('netNic').checked,tcp:$('netTcp').checked,interrupt:$('netInterrupt').checked,eee:$('netEee').checked}};
  text('netStatus','Verific adaptorul, administratorul și backupurile…');const {token,plan}=await api.netPrepare(request);
  const details=`Adaptor: ${plan.adapter}\nDNS: ${plan.provider}\n\n${plan.labels.map((x,i)=>`${i+1}. ${x}`).join('\n')}`;
  if(!await confirmDialog('Aplici NET BOOST?', 'Modificările vor fi aplicate în ordinea afișată. Cele avansate pot provoca întreruperi ale conexiunii.',details,'DNS nu garantează ping mai mic. TCPNoDelay nu accelerează jocurile bazate pe UDP. Backupul fiecărui pas rămâne disponibil.', '◉ APLICĂ INTERNET BOOST')){text('netStatus','Anulat. Nicio modificare.');return}
  text('netStatus','Aplic modificările de rețea…');const r=await api.netCommit(token);
  text('netStatus',r.success?'✔ INTERNET BOOST finalizat. Modificările se pot restaura.':`⚠ Aplicarea a întâmpinat erori: ${r.error||''}. Verifică secțiunea Restaurare.`);
  if(!r.success)showToast('Internet Boost nu a reușit complet. Deschide Restaurare.');
  return {success:r.success};
  }catch(e){text('netStatus',errorMessage(e));throw e}
 })};
 api?.onNetProgress?.(ev=>text('netStatus',ev.detail));
 $('netTest').onclick=()=>{if(!requireNative())return;task('Test rețea',async()=>{text('netStatus','Rulez 6 cereri ICMP către Cloudflare 1.1.1.1…');const r=await api.latency('cloudflare');text('netStatus',`1.1.1.1: medie ${r.avg??'—'} ms · jitter ${r.jitter??'—'} ms · pierdere ${r.loss??'—'}%. Aceasta nu este latența în joc.`)})};
 // Debloat—no automatic removal, including on hero button.
 async function scanDebloat(){if(!requireNative())return;await task('Debloat scan',async()=>{text('debloatStatus','Inventariez AppX din contul Windows…');const d=await api.debloatScan().catch(e=>{text('debloatStatus','Scanarea a eșuat: '+errorMessage(e));throw e});if(d.success!==true||!Array.isArray(d.apps)){text('debloatStatus',d.message||'Inventarul aplicațiilor nu a fost confirmat.');throw Error(d.message||'Inventar Debloat incomplet.')}debloatCache=d.apps||[];const target=$('debloatRows');target.replaceChildren();for(const app of debloatCache){const row=el('div','result-row'),label=el('label'),checkbox=el('input');checkbox.type='checkbox';checkbox.value=app.id;checkbox.className='debloatPick';label.append(checkbox,el('span','desc'));label.lastChild.append(el('strong',null,app.label),el('small',null,`${app.name} · ${app.count} instalată/e`));row.append(label);if(app.recommended)row.append(el('span','pill','OPȚIONAL'));target.append(row)}if(!debloatCache.length)target.append(el('div','progress-text','Nu am găsit aplicații eligibile în catalog. Nu înseamnă că inventarul tuturor programelor este gol.'));text('debloatStatus',`AppX total: ${d.installedAppxCount??'—'} · opționale eligibile: ${debloatCache.length} · programe desktop detectate: ${d.classicAppsCount??'—'}`);$('removeDebloat').classList.toggle('hidden',!debloatCache.length);return {success:d.success===true}} )}
 $('scanDebloat').onclick=scanDebloat;
 $('removeDebloat').onclick=()=>{if(!requireNative())return;task('Debloat',async()=>{
  const ids=$$('.debloatPick:checked').map(x=>x.value);if(!ids.length){showToast('Alege cel puțin o aplicație.');return}
  const names=debloatCache.filter(x=>ids.includes(x.id)).map(x=>x.label);
  if(!await confirmDialog('Elimini aceste aplicații?','Windows poate pierde datele locale ale aplicațiilor. Reinstalarea se face separat din Microsoft Store.',names.join('\n'),'Ștergerea aplicațiilor NU poate fi restaurată automat de CARPATIA.','ELIMINĂ SELECTATE'))return;
  const r=await api.debloatRemove(ids);
  if(typeof r.success!=='boolean'||!Array.isArray(r.results)||!r.results.length||r.results.some(x=>!x||!ids.includes(x.id)||!['removed','not_installed','failed'].includes(x.status))||ids.some(id=>!r.results.some(x=>x.id===id)))throw Error('Răspuns Debloat incomplet. Verifică starea aplicațiilor printr-o nouă scanare.');
  const ok=r.results.filter(x=>x.status==='removed').length,failed=r.results.filter(x=>x.status==='failed').length;
  const details=$('debloatResultsRows');details.replaceChildren();
  for(const result of r.results){const name=debloatCache.find(x=>x.id===result.id)?.label||result.id;details.append(el('div','result-row',name+': '+({removed:'Eliminată',not_installed:'Nu mai este instalată',failed:'EROARE'})[result.status]+(result.error?' — '+result.error:'')))}
  $('debloatResults').hidden=false;$('debloatResults').open=true;
  const success=r.success&&failed===0;showToast(`Debloat: ${ok} eliminări · ${failed} erori.`);
  text('debloatStatus',`${success?'Eliminare încheiată.':'Eliminare incompletă.'} ${ok} eliminări · ${failed} erori. Vezi rezultatele de mai jos și scanează pentru lista actualizată.`);
  $('debloatRows').replaceChildren();$('removeDebloat').classList.add('hidden');return {success};
 })};

 $('showAppsSettings').onclick=()=>api?api.openSettings('apps').catch(e=>showToast(errorMessage(e))):requireNative();
 // GPU: read-only inventory, optional Windows per-app preference.
 async function loadGpu(){if(!requireNative())return;try{const r=await api.gpuList();const root=$('gpuInventory');root.replaceChildren();for(const g of r.gpus||[])root.append(el('div','result-row',`${g.name} · driver ${g.driver}`));root.append(el('div','progress-text',`Hardware Accelerated GPU Scheduling: ${r.hags||'Controlat de Windows'}`))}catch(e){text('gpuInventory','GPU indisponibil: '+errorMessage(e))}}
 $('gpuRefresh').onclick=loadGpu;
 $('pickGpuExe').onclick=()=>{if(!requireNative(true))return;task('GPU Select',async()=>{const r=await api.gpuPick();if(r.cancelled)return;text('gpuPicked',`Aplicație: ${r.name}`);const s=await api.gpuStatus();text('gpuPicked',`${r.name} · High Performance ${s.highPerformance?'ACTIV':'INACTIV'} · Backup ${s.backup?'EXISTĂ':'nu există'}`)})};
 $('gpuSetHigh').onclick=()=>{if(!requireNative())return;task('GPU',async()=>{if(!await confirmDialog('Activezi preferința GPU?', 'Setează Windows Graphics Preference: High Performance pentru executabilul ales.', '', 'Nu este overclock și nu garantează FPS suplimentar.','APLICĂ GPU'))return;const r=await api.gpuApply();if(r.success!==true)throw Error(r.message||'Windows nu a confirmat schimbarea GPU');text('gpuPicked',r.message||'Preferință GPU confirmată')})};
 $('gpuUndo').onclick=()=>showResourceOwner({category:'GPU'});
 $('gpuSettings').onclick=()=>api?api.openSettings('graphics').catch(e=>showToast(errorMessage(e))):requireNative();
 // Catalog-based advanced tweaks: list is safe to inspect; no hardcoded fake operations.
 const dashboardPage=window.CarpatiaDashboardProfiles.mount({api,requireNative,task,confirmDialog,showToast,onOwner:showResourceOwner});
 dashboardPage.load().catch(e=>showToast(errorMessage(e)));
 const recoveryPage=window.CarpatiaRecovery.mount({api,task,confirmDialog,requireNative,showToast});
 function showResourceOwner(owner){navigate('restore');recoveryPage.open(owner).catch(e=>showToast(errorMessage(e)))}

 const libraryPage=window.CarpatiaTweaks.mount({api,requireNative,task,confirmDialog,showToast,onOwner:showResourceOwner});
 $('openCpuCatalog').onclick=()=>{navigate('tweaks');libraryPage.openCategory('CPU').catch(e=>showToast(errorMessage(e)))};
 $('openNetworkCatalog').onclick=()=>{navigate('tweaks');libraryPage.openCategory('Network').catch(e=>showToast(errorMessage(e)))};
 function loadTweaks(){return libraryPage.load()}

 // CLEANUP: no automatic deletion.
 $('tempScan').onclick=()=>{if(!requireNative())return;task('TEMP Scan',async()=>{const r=await api.cleanupScan();text('tempStatus',`${r.count} fișiere TEMP eligibile · ${(r.bytes/1048576).toFixed(1)} MB estimat. Nicio ștergere încă.`)})};
 $('tempClean').onclick=()=>{if(!requireNative())return;task('TEMP Clean',async()=>{const scan=await api.cleanupScan();if(!scan.count){text('tempStatus','Nu există fișiere TEMP eligibile.');return}if(!await confirmDialog('Ștergi fișiere TEMP?',`${scan.count} fișiere TEMP mai vechi de 7 zile (${(scan.bytes/1048576).toFixed(1)} MB).`,'', 'Ștergerea fișierelor este ireversibilă și nu garantează FPS.','ȘTERGE TEMP'))return;const r=await api.cleanupRun();text('tempStatus',`${r.removed} șterse · ${(r.freed/1048576).toFixed(1)} MB eliberați · ${r.failed} eșecuri.`);if(r.success===false||r.failed>0)showToast(`Curățare parțială: ${r.failed||0} fișiere nu au putut fi eliminate.`)})};
 async function loadStartup(){if(!requireNative(true))return;await task('Startup',async()=>{const r=await api.startupList();const root=$('startupRows');root.replaceChildren();for(const item of r.entries||[]){const row=el('div','result-row'),desc=el('span','desc');desc.append(el('strong',null,item.name),el('small',null,(item.command||'').slice(0,180)));row.append(desc);const btn=el('button','action outline',item.protected?'PROTEJAT':'DEZACTIVEAZĂ');btn.disabled=!!item.protected;btn.onclick=()=>changeStartup('Disable',item.name);row.append(btn);root.append(row)}for(const item of r.disabled||[]){const row=el('div','result-row',`Backup Startup: ${item.name}`),btn=el('button','action outline','RESTAUREAZĂ');btn.onclick=()=>changeStartup('Restore',item.name);row.append(btn);root.append(row)}if(!root.children.length)root.append(el('p','progress-text','Nu există intrări HKCU Run eligibile.'))})}
 async function changeStartup(action,name){if(!requireNative(action==='Restore'))return;await task('Startup',async()=>{if(!await confirmDialog(action==='Disable'?'Dezactivezi din Startup?':'Restaurezi Startup?',name,'', 'Nu afectăm drivere, antiviruși sau intrările de sistem protejate.'))return;const r=action==='Disable'?await api.startupDisable(name):await api.startupRestore(name);if(r.success!==true)throw Error(r.message||'Operația Startup nu a fost confirmată');showToast(r.message||'Finalizat');$('startupRows').replaceChildren(el('p','progress-text','Operație finalizată. Apasă Scanează pentru lista actualizată.'))})}
 $('startupScan').onclick=loadStartup;
 // Services are deliberately outside the automatic Ultra profile.
 async function drawServices(target,restoreOnly=false){
  const r=await api.services(),root=$(target);root.replaceChildren();
  for(const item of r.items||[]){
   const row=el('div','result-row'),desc=el('span','desc');
   desc.append(el('strong',null,`${item.name} · ${item.startMode||'necunoscut'}`),el('small',null,`Stare: ${item.state||'indisponibil'} · ${item.label||'DIAGNOSTIC NECESAR'}`));
   if(item.reason)desc.append(el('small',null,item.reason));row.append(desc);
   if(item.action==='restore'||item.action==='apply'&&!restoreOnly){const btn=el('button','action outline',item.label);btn.disabled=!r.elevated;btn.onclick=()=>changeService(item.action==='restore'?'Restore':'Apply',item.id);row.append(btn)}
   else if(item.action==='owner'){const owner=item.owners[0],btn=el('button','action outline',item.label);btn.onclick=()=>{showResourceOwner(owner)};row.append(btn)}
   else row.append(el('span','pill',item.label||'DIAGNOSTIC NECESAR'));
   root.append(row);
  }
  if(!r.elevated)root.append(el('div','progress-text','Pentru modificarea serviciilor este necesar administrator.'));
 }

 async function changeService(action,id){if(!requireNative(action==='Restore'))return;if(action==='Restore'){showResourceOwner({id:'services:'+id});return}await task('Serviciu',async()=>{if(!await confirmDialog(action==='Apply'?'Dezactivezi serviciul '+id+'?':'Restaurezi serviciul '+id+'?',action==='Apply'?'Această modificare poate afecta Windows Search, diagnosticarea sau încărcarea aplicațiilor.':'Restaurăm configurația salvată anterior.','',action==='Apply'?'Risc real: nu garantează FPS și unele servicii sunt folosite de aplicațiile Windows.':''))return;const r=await api.servicesChange(action,id);if(r.success!==true)throw Error(r.message||'Serviciul nu a fost actualizat');showToast(r.message||'Stare actualizată');await drawServices(view==='restore'?'restoreServices':'servicesList',view==='restore')})}
 $('loadServices').onclick=()=>requireNative()&&task('Servicii',()=>drawServices('servicesList'));
 $('restoreServicesCheck').onclick=()=>requireNative(true)&&task('Servicii',()=>drawServices('restoreServices',true));
 // BACKUPS: read-only scans must not monopolize the mutation lock. Recovery reports remain visible.
 let recoveryScanId=0;
 async function checkBackups(){
  if(!api)return;
  const scanId=++recoveryScanId;
  const scanButton=$('restoreScan');
  scanButton.disabled=true;
  try{
   // Adaptor inventory is unrelated to recovery. Do not hold up restoring ULTRA just to load it.
   let dashboardWarning='';
   try{await dashboardPage.load({skipAdapters:true})}catch(e){dashboardWarning=errorMessage(e)}
   const reads=[['ULTRA Registry',()=>api.registryState(),r=>r.backup],['Power Plan',()=>api.powerState(),r=>r.backup],['Internet DNS/TCP/NIC',()=>api.networkRecovery(),r=>r.active],['Servicii Windows',()=>api.services(),r=>r.items?.some(x=>x.backup)]];
   const results=await Promise.allSettled(reads.map(([,read])=>read()));
   if(scanId!==recoveryScanId)return;
   const root=$('restoreState');root.replaceChildren();
   if(dashboardWarning)root.append(el('div','result-row','Dashboard: '+dashboardWarning));
   results.forEach((result,index)=>{
    const [label,,active]=reads[index];
    if(result.status==='rejected'){root.append(el('div','result-row',`${label}: VERIFICARE EȘUATĂ — ${errorMessage(result.reason)}`));return}
    const state=result.value;
    if(state?.success===false){root.append(el('div','result-row',`${label}: stare neconfirmată — ${state.message||state.errors?.map(x=>x.error||x.message).join('; ')||'eroare necunoscută'}`));return}
    root.append(el('div','result-row',`${label}: ${active(state)?'BACKUP ACTIV':'fără backup activ'}`));
    if(index===2&&state.active)for(const step of state.steps||[])root.append(el('div','result-row',`${step.id}: ${step.backupExists?'backup prezent':'BACKUP LIPSĂ'}`));
   });
  }finally{if(scanId===recoveryScanId)scanButton.disabled=false}
 }
 $('restoreScan').onclick=()=>{if(!requireNative(true))return;text('restoreResult','Verific backupurile existente, fără modificări Windows…');checkBackups().catch(e=>text('restoreResult','Eroare la scanare: '+errorMessage(e)))};
 $('restoreUltra').onclick=()=>showResourceOwner({});
 $('restoreInternet').onclick=()=>showResourceOwner({category:'Network'});
 $('diagnoseApp').onclick=()=>{if(!requireNative())return;task('Diagnostic',async()=>{const [sys,priv,r,n]=await Promise.all([api.sys(),api.admin(),api.registryState(),api.networkRecovery()]);const root=$('diagnosticOutput');root.replaceChildren(...[`Platformă: ${sys.platform}`,`CPU: ${sys.cpu}`,`Memorie: ${sys.ramGB} GB`,`Administrator: ${priv.admin?'DA':'NU'}`,`Catalog Registry: ${r.catalogSize} reguli`,`Backup Registry: ${r.backup?'ACTIV':'nu există'}`,`Backup Internet: ${n.active?'ACTIV':'nu există'}`].map(x=>el('div','result-row',x)))})};
 $('readHardware').onclick=()=>{if(!requireNative())return;task('Hardware',async()=>{const h=await api.hardware();const root=$('diagnosticOutput');root.replaceChildren(...[`CPU: ${h.cpu}`,`GPU: ${(h.gpu||[]).join(', ')||'indisponibil'}`,`RAM: ${h.ramGB} GB`,`OS: ${h.osName} (build ${h.osBuild})`,`Baterie: ${h.hasBattery?'da':'nu'}`].map(x=>el('div','result-row',x)))})};
 // Only while dashboard is visible; no permanent game/process polling.
 if(api){initLicense();setInterval(()=>{if(licensed&&view==='dashboard'&&document.visibilityState==='visible'&&!mutationBusy)refreshDashboard(false)},15000)}
 else{$('connection').textContent='● PREVIZUALIZARE HTML';text('hardwareText','Monitorizarea reală necesită aplicația Windows. Valorile nu sunt simulate.');text('healthState','Stare sistem: indisponibilă în browser.')}
})();
