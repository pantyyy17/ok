# CARPATIA V7 PRO — Licențiere 7.4.0

## Recomandare comercială

Pornim cu licențe **offline semnate Ed25519** și un **License Manager local** doar pentru editor. Nu necesită un server, este simplu de testat și clientul poate folosi licența fără internet. Ulterior, pentru activare pe un număr limitat de dispozitive și revocare, construim un **serviciu online** autentic (HTTPS, bază de date, conturi, audit, suport, plăți). **În 7.4.4 există serviciul seller/ pentru emitere Shopify și email. Verificarea clientului rămâne offline, fără limită tehnică de dispozitive. Vezi GHID_SHOPIFY_7_4_4.md.**

## Utilizare pentru vânzător

1. Pe calculatorul tău cu Node.js LTS rulează `LICENTA_MANAGER.bat` din sursa CARPATIA (NU din installer).
2. Alege un folder securizat, **în afara proiectului**, pentru cheia privată și codurile emise.
3. Prima dată apasă **CREEAZĂ CHEILE**; păstrează cheia privată securizată și backup separată.
4. Apasă **PREGĂTEȘTE BUILDUL**: doar cheia publică se copiază în sursă ca `license-public.pem`.
5. Pentru fiecare plată confirmată, introdu numele clientului, selectează licență permanentă sau durată, apoi apasă **GENEREAZĂ LICENȚĂ**.
6. Copiază codul generat sau trimite fișierul `.txt` clientului; păstrează evidența privată.
7. Pe Windows rulează `BUILD_INSTALLER.bat`; distribuie clienților **doar installerul**, nu ZIP-ul sursă.

Poți continua și cu CLI-ul: `node tools/license-cli.js init ...` / `issue ...`. License Manager oferă un GUI local peste aceeași semnare criptografică.

**Securitate:** aplicația de administrare ascultă NUMAI pe `127.0.0.1` (PC-ul tău), nu pe Internet. Are token aleator pentru cereri și filtrează originile. Nu expune cheia privată prin API. Dacă muți cheia privată din folder, managerul nu mai poate genera licențe. **Nu trimite cheia privată în chat sau către clienți. Pentru automatizare, instaleaz-o numai în stocarea privată a serverului tău, în afara directorului public și a arhivei sursă.**

## Utilizare client

Clientul instalează `.exe`, primește un cod de licență semnat și îl introduce în ecranul de activare. Verificarea se face local cu `license-public.pem`. Un cod falsificat sau expirat este respins.

## Limitări și versiunea online

- Licențele offline se pot copia pe mai multe PC-uri. **Nu pretindem activare per dispozitiv, revocare sau cont online în această versiune.**
- Licența nu reprezintă activarea Windows și nu conține KMS.
- Pentru platforma online viitoare: clientul trimite prin HTTPS codul și un ID de instalare pseudonim; serverul verifică semnătura, limitează activările și emite un token de activare semnat valabil de ex. 7–14 zile offline. Necesită găzduire, domeniu, TLS, bază de date și proceduri GDPR. Revocarea poate fi verificată numai la următoarea conectare.
- Orice sistem local poate fi modificat de un atacator cu suficient acces; licențierea limitează copierea casual, nu este invulnerabilă.

## Înainte de lansare

`npm test` și `npm run release:check` (după configurarea cheii publice). Compilează pe Windows 10/11, verifică installerul, restaurarea, backupurile, Debloat, rețea, GPU și măsoară performanța înainte/după. **Nu promite un release fără buguri sau FPS în plus fără măsurători.**
