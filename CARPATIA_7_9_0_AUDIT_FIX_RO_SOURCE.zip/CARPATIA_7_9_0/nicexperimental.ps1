﻿param(
 [ValidateSet('List','Apply','Restore')][string]$Action='List',
 [ValidateSet('nic_interrupt','nic_eee')][string]$Id='nic_interrupt',
 [string]$Adapter=''
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$root=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups\Experimental'
New-Item -ItemType Directory -Path $root -Force|Out-Null
$keyById=@{nic_interrupt='*InterruptModeration';nic_eee='*EEE'}
function BackupPath([string]$id){return (Join-Path $root ($id+'.json'))}
function IsAdmin(){return (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function FindProp([string]$name,[string]$key){
 $items=@(Get-NetAdapterAdvancedProperty -Name $name -RegistryKeyword $key -ErrorAction SilentlyContinue)
 if($items.Count -ne 1 -or [string]$items[0].RegistryKeyword -cne $key){return $null}
 return $items[0]
}
if($Action -eq 'List'){
 $adapters=@()
 foreach($a in @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object {$_.Status -eq 'Up' -and (-not $Adapter -or $_.Name -eq $Adapter)})){
  $im=FindProp ([string]$a.Name) '*InterruptModeration'
  $eee=FindProp ([string]$a.Name) '*EEE'
  $adapters+=@{name=[string]$a.Name;guid=[string]$a.InterfaceGuid;description=[string]$a.InterfaceDescription;interrupt=($null -ne $im);eee=($null -ne $eee)}
 }
 @{success=$true;adapters=@($adapters);backups=@{nic_interrupt=(Test-Path -LiteralPath (BackupPath 'nic_interrupt'));nic_eee=(Test-Path -LiteralPath (BackupPath 'nic_eee'))};admin=(IsAdmin)}|ConvertTo-Json -Compress -Depth 6
 exit 0
}
if(!(IsAdmin)){throw 'Setarile avansate ale adaptorului necesita drepturi administrator.'}
$file=BackupPath $Id
$key=$keyById[$Id]
if($Action -eq 'Apply'){
 if($Adapter.Length -lt 1 -or $Adapter.Length -gt 150 -or $Adapter -match '[\r\n]'){throw 'Nume adaptor invalid.'}
 if(Test-Path -LiteralPath $file){throw 'Exista deja un backup pentru aceasta setare. Restaureaza-l mai intai.'}
 $a=Get-NetAdapter -Name $Adapter -ErrorAction Stop
 if([string]$a.Status -ne 'Up'){throw 'Adaptorul selectat nu este conectat.'}
 $p=FindProp ([string]$a.Name) $key
 if($null -eq $p){throw 'Driverul adaptorului nu suporta '+$key+'. Nu este modificat nimic.'}
 $original=@($p.RegistryValue)
 if($original.Count -ne 1 -or [string]$original[0] -notmatch '^\d+$'){throw 'Valoare de adaptor necunoscuta: nu se aplica tweak-ul.'}
 $old=[string]$original[0]
 if($old -eq '0'){@{success=$true;changed=$false;message='Driverul are deja setarea dezactivata. Nu s-a schimbat nimic.'}|ConvertTo-Json -Compress;exit 0}
 $data=@{version=1;id=$Id;guid=[string]$a.InterfaceGuid;name=[string]$a.Name;keyword=$key;old=$old;timestamp=(Get-Date).ToString('o')}
 $temp=Join-Path $root ($Id+'.'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{$data|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $temp -Encoding UTF8 -ErrorAction Stop;Move-Item -LiteralPath $temp -Destination $file -ErrorAction Stop}
 finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}}
 Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $key -RegistryValue '0' -NoRestart -ErrorAction Stop
 $verified=FindProp ([string]$a.Name) $key
 if($null -eq $verified -or [string](@($verified.RegistryValue)[0]) -ne '0'){throw 'Driverul nu confirma setarea. Backup pastrat pentru restaurare.'}
 @{success=$true;changed=$true;backup=$file;message='Setarea '+$key+' a fost scrisa (NoRestart). Driverul poate necesita reinitializarea adaptorului / restart Windows. Backup salvat.'}|ConvertTo-Json -Compress
 exit 0
}
if(!(Test-Path -LiteralPath $file)){throw 'Backup pentru NIC experimental lipsa.'}
$b=Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
if([int]$b.version -ne 1 -or [string]$b.id -ne $Id -or [string]$b.keyword -cne $key -or [string]$b.old -notmatch '^\d{1,3}$'){throw 'Backup NIC invalid.'}
$a=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop | Where-Object {([string]$_.InterfaceGuid) -eq ([string]$b.guid)})
if($a.Count -ne 1){throw 'Adaptorul original nu mai este disponibil. Backup pastrat pentru recuperare manuala.'}
$current=FindProp ([string]$a[0].Name) $key
if($null -eq $current -or @($current.RegistryValue).Count -ne 1 -or [string](@($current.RegistryValue)[0]) -notin @('0',[string]$b.old)){throw 'Proprietatea NIC a fost schimbată din exterior sau nu mai este disponibilă. Backup păstrat.'}
Set-NetAdapterAdvancedProperty -Name $a[0].Name -RegistryKeyword $key -RegistryValue ([string]$b.old) -NoRestart -ErrorAction Stop
$verified=FindProp ([string]$a[0].Name) $key
if($null -eq $verified -or [string](@($verified.RegistryValue)[0]) -ne [string]$b.old){throw 'Restaurarea proprietatii NIC nu a fost confirmata. Backup pastrat.'}
Move-Item -LiteralPath $file -Destination (Join-Path $root ($Id+'-restored-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.json')) -Force
@{success=$true;changed=$true;message='Valoarea originala a '+$key+' a fost restaurata. Driverul poate necesita restart.'}|ConvertTo-Json -Compress
