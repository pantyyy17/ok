'use strict';
// Node 24+. Run ONE server/worker instance with a persistent, private data volume.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {createHash,createPrivateKey,createPublicKey}=require('node:crypto');
const {createShopifyService}=require('./shopify-core');
const {externalPath}=require('../tools/private-path');
process.umask(0o077);
const required=['SHOPIFY_WEBHOOK_SECRET','SHOPIFY_SHOP','SHOPIFY_VARIANT_ID','LICENSE_PRIVATE_KEY_FILE','LICENSE_PUBLIC_KEY_FILE','LICENSE_DATA_DIR','RESEND_API_KEY','EMAIL_FROM','DOWNLOAD_URL'];
for(const name of required)if(!process.env[name])throw Error('Lipsește variabila '+name);
const download=new URL(process.env.DOWNLOAD_URL);
if(download.protocol!=='https:'||download.username||download.password)throw Error('DOWNLOAD_URL trebuie să fie HTTPS.');
const root=path.resolve(__dirname,'..'),data=externalPath(process.env.LICENSE_DATA_DIR,root);
const privateFile=externalPath(process.env.LICENSE_PRIVATE_KEY_FILE,root);
fs.mkdirSync(data,{recursive:true,mode:0o700});
const privateKey=fs.readFileSync(privateFile,'utf8');
const publicKey=fs.readFileSync(process.env.LICENSE_PUBLIC_KEY_FILE,'utf8');
if(!createPublicKey(createPrivateKey(privateKey)).export({type:'spki',format:'der'}).equals(createPublicKey(publicKey).export({type:'spki',format:'der'})))throw Error('Cheia de semnare nu corespunde installerului.');
const service=createShopifyService({database:path.join(data,'licenses.sqlite'),privateKey,secret:process.env.SHOPIFY_WEBHOOK_SECRET,shop:process.env.SHOPIFY_SHOP,variantId:process.env.SHOPIFY_VARIANT_ID,allowTest:process.env.SHOPIFY_ALLOW_TEST==='1'});
async function sendMail({to,text,id}){
 const response=await fetch('https://api.resend.com/emails',{method:'POST',signal:AbortSignal.timeout(15000),headers:{Authorization:'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':createHash('sha256').update(id).digest('hex')},body:JSON.stringify({from:process.env.EMAIL_FROM,to:[to],subject:'Licența ta permanentă CARPATIA',text:text+'\nDescarcă installerul: '+download.href+'\n'})});
 if(!response.ok)throw Error('Email HTTP '+response.status);
 return response.json();
}
const server=http.createServer(async(req,res)=>{
 const send=code=>{res.writeHead(code,{'Cache-Control':'no-store'});res.end()};
 if(req.method!=='POST'||req.url!=='/webhooks/shopify/orders-paid'){req.resume();return send(404)}
 const chunks=[];let bytes=0;
 try{
  for await(const chunk of req){bytes+=chunk.length;if(bytes>1048576){send(413);req.destroy();return}chunks.push(chunk)}
  const result=service.accept(Buffer.concat(chunks),req.headers);send(result.status);
 }catch{console.error('Webhook processing failed; inspect service health.');if(!res.headersSent)send(500)}
});
server.requestTimeout=20000;server.headersTimeout=10000;
const port=Number(process.env.PORT||8787);
if(!Number.isInteger(port)||port<1||port>65535)throw Error('PORT invalid.');
server.listen(port,'127.0.0.1',()=>console.log('CARPATIA seller service ready on loopback; expose via HTTPS reverse proxy.'));
const timer=setInterval(()=>service.deliver(sendMail).catch(()=>console.error('Outbox worker failed.')),10000);
service.deliver(sendMail).catch(()=>console.error('Outbox recovery failed.'));
process.on('SIGTERM',()=>{clearInterval(timer);server.close(()=>process.exit(0))});
