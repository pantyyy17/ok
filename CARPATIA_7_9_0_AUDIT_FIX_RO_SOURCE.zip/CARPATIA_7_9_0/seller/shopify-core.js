'use strict';
// Seller only: never include this directory, database or private PEM in the installer.
const {DatabaseSync}=require('node:sqlite');
const {createHmac,timingSafeEqual,randomUUID,createPrivateKey}=require('node:crypto');
const {createIssuerCode,PRODUCT}=require('../licensing');
function validId(value){return (typeof value==='string'&&/^[1-9][0-9]{0,30}$/.test(value))||(Number.isSafeInteger(value)&&value>0)}
function verifyHmac(raw,signature,secret){
 if(typeof signature!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(signature)||!secret||!Buffer.isBuffer(raw))return false;
 const actual=Buffer.from(signature,'base64'),expected=createHmac('sha256',secret).update(raw).digest();
 return actual.length===expected.length&&actual.toString('base64')===signature&&timingSafeEqual(actual,expected);
}
function createShopifyService({database,privateKey,secret,shop,variantId,allowTest=false}){
 if(typeof secret!=='string'||!secret.trim()||typeof shop!=='string'||!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)||!validId(variantId)||typeof allowTest!=='boolean')throw Error('Configurare Shopify incompletă.');
 const signingKey=createPrivateKey(privateKey);
 if(signingKey.asymmetricKeyType!=='ed25519')throw Error('Cheie de semnare incompatibilă.');
 const db=new DatabaseSync(database);
 db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS licenses (unit TEXT PRIMARY KEY, code TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS outbox (id TEXT PRIMARY KEY, recipient TEXT NOT NULL, body TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, first_attempt INTEGER, provider_id TEXT);`);
 const findLicense=db.prepare('SELECT unit FROM licenses WHERE unit=?');
 const addLicense=db.prepare('INSERT INTO licenses(unit,code) VALUES (?,?)');
 const addMail=db.prepare('INSERT INTO outbox(id,recipient,body) VALUES (?,?,?)');
 function accept(raw,headers={}){
  if(!headers||typeof headers!=='object')return {status:401};
  if(!verifyHmac(raw,headers['x-shopify-hmac-sha256'],secret))return {status:401};
  if(headers['x-shopify-shop-domain']!==shop)return {status:403};
  if(headers['x-shopify-topic']!=='orders/paid')return {status:400};
  let order;try{
   // Shopify IDs are 64-bit integers. Node 24 exposes the original JSON token
   // so adjacent IDs above MAX_SAFE_INTEGER never collide or disappear.
   order=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw),(key,value,context)=>
    ['id','variant_id'].includes(key)&&typeof value==='number'&&/^[1-9][0-9]{0,30}$/.test(context.source)?context.source:value);
  }catch{return {status:400}}
  if(!order||typeof order!=='object'||!validId(order.id)||!Array.isArray(order.line_items))return {status:400};
  if(order.financial_status!=='paid'||order.cancelled_at||(order.test===true&&!allowTest))return {status:200,ignored:true};
  const lines=order.line_items.filter(x=>x&&validId(x.variant_id)&&String(x.variant_id)===String(variantId));
  if(!lines.length)return {status:200,ignored:true};
  const email=order.email||order.contact_email;
  if(typeof email!=='string'||email.length>180||!/^\S+@[^\s@]+\.[^\s@]+$/.test(email)||/[\r\n<>]/.test(email))return {status:422};
  if(lines.length>100||lines.some(x=>!validId(x.id)||!Number.isSafeInteger(x.quantity)||x.quantity<1||x.quantity>100)||new Set(lines.map(x=>String(x.id))).size!==lines.length)return {status:422};
  if(lines.reduce((n,x)=>n+x.quantity,0)>100)return {status:422};
  db.exec('BEGIN IMMEDIATE');
  try{
   let issued=0;
   for(const line of lines){
    for(let unit=0;unit<line.quantity;unit++){
     // Order + line + unit deduplicates retries even with a different webhook ID.
     const id=`${shop}/${order.id}/${line.id}/${unit}`;
     if(findLicense.get(id))continue;
     const code=createIssuerCode({product:PRODUCT,licenseId:'crp_'+randomUUID().replaceAll('-',''),customer:email,issuedAt:new Date().toISOString(),expiresAt:null},signingKey);
     addLicense.run(id,code);
     const body=`Mulțumim pentru cumpărare!\n\nLicență CARPATIA V7 PRO permanentă, fără abonament.\nComanda: ${order.id}\n\n${code}\n\nDeschide CARPATIA → INTRODU LICENȚA și lipește întregul cod. Păstrează acest email pentru reinstalare.\n`;
     addMail.run(id,email,body);
     issued++;
    }
   }
   db.exec('COMMIT');return {status:200,issued};
  }catch(e){db.exec('ROLLBACK');throw e}
 }
 let delivering=false;
 async function deliver(sendMail,now=Date.now()){
  if(delivering)return;delivering=true;
  try{
   const rows=db.prepare("SELECT * FROM outbox WHERE state='pending' AND next_at<=? ORDER BY rowid LIMIT 20").all(now);
   for(const row of rows){
    // Provider deduplication lasts 24h. Stop ambiguous retries before that expires.
    if(row.first_attempt!==null&&now-row.first_attempt>=23*3600000){db.prepare("UPDATE outbox SET state='review' WHERE id=?").run(row.id);continue}
    db.prepare('UPDATE outbox SET first_attempt=COALESCE(first_attempt,?), attempts=attempts+1 WHERE id=?').run(now,row.id);
    try{
     const result=await sendMail({to:row.recipient,text:row.body,id:row.id});
     if(!result?.id)throw Error('Email neconfirmat');
     db.prepare("UPDATE outbox SET state='sent',provider_id=? WHERE id=?").run(result.id,row.id);
    }catch{
     const delay=Math.min(3600000,60000*2**Math.min(row.attempts,6));
     db.prepare('UPDATE outbox SET next_at=? WHERE id=?').run(now+delay,row.id);
    }
   }
  }finally{delivering=false}
 }
 return {accept,deliver,close:()=>db.close()};
}
module.exports={createShopifyService,verifyHmac};
