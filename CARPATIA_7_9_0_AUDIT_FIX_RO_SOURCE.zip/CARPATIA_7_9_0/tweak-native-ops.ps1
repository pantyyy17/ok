﻿. (Join-Path $PSScriptRoot 'power-api.ps1')
# Typed native operations. No sourceCommand string is ever evaluated.
function Invoke-Tool([string]$Name,[string[]]$Arguments){
 if($Name -notin @('powercfg','netsh','bcdedit','fsutil','ipconfig','arp','nbtstat','defrag','sc','vssadmin')){throw 'Executabil nepermis.'}
 $exe=Join-Path $env:SystemRoot ('System32\'+$Name+'.exe')
 $output=& $exe @Arguments 2>&1
 if($LASTEXITCODE -ne 0){throw ($Name+' a eșuat ('+$LASTEXITCODE+'): '+($output -join ' '))}
 return ($output -join "`n")
}
function Copy-Object($o){return ($o | ConvertTo-Json -Depth 16 | ConvertFrom-Json)}
function Get-ActivePower{
 $s=Invoke-Tool powercfg @('/getactivescheme')
 $m=[regex]::Match($s,'[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}')
 if(-not $m.Success){throw 'Planul activ nu poate fi identificat.'};return $m.Value.ToLowerInvariant()
}
function Get-AdapterByGuid($guid){
 if([string]$guid -notmatch '^\{?[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}\}?$'){throw 'Selectează explicit adaptorul de rețea.'}
 $a=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop | Where-Object {([guid]$_.InterfaceGuid) -eq ([guid]$guid)})
 if($a.Count -ne 1){throw 'Adaptorul salvat nu mai este disponibil.'};return $a[0]
}
function Get-TcpDumpValue($key){
 if($key -notin @('fastopen','autotuninglevel','initialrto')){throw 'Parametru TCP nepermis.'}
 $dump=Invoke-Tool netsh @('interface','tcp','dump')
 $m=[regex]::Match($dump,'(?im)^\s*(?:set\s+)?global\b[^\r\n]*\b'+$key+'=([a-zA-Z0-9]+)')
 if(-not $m.Success){$m=[regex]::Match($dump,'(?im)^\s*set\s+global\b[^\r\n]*\b'+$key+'=([a-zA-Z0-9]+)')}
 if(-not $m.Success){throw ('Windows nu expune starea originală pentru '+$key+'. Nicio modificare.')};return $m.Groups[1].Value.ToLowerInvariant()
}
function Get-TunnelValue($name){
 if($name -notin @('teredo','isatap')){throw 'Interfață nepermisă.'}
 $dump=Invoke-Tool netsh @('interface',$name,'dump');$param=if($name -eq 'teredo'){'type'}else{'state'}
 $m=[regex]::Match($dump,'(?im)^\s*set\s+state\s+(?:'+$param+'=)?([a-zA-Z]+)')
 if(-not $m.Success){throw 'Starea originală a tunelului nu poate fi citită.'};return $m.Groups[1].Value.ToLowerInvariant()
}
function Convert-FsutilValue([string]$property,[string]$raw){
 if($property -notin @('DisableDeleteNotify','disable8dot3','disablelastaccess','mftzone')){throw 'Parametru fsutil nepermis.'}
 if($property -ieq 'DisableDeleteNotify'){
  $matchesFound=[regex]::Matches($raw,'(?im)^\s*NTFS\s+DisableDeleteNotify\s*=\s*([01])(?:\s|$)')
 }else{
  # fsutil uses both "name = value" and "... is: value (...)" on Windows.
  # Require one numeric result line; never take an arbitrary number in prose.
  $matchesFound=[regex]::Matches($raw,'(?m)^[^\r\n=:]+[=:]\s*(\d+)(?:\s*\([^\r\n]*\))?\.?\s*$')
 }
 if($matchesFound.Count -ne 1){throw ('Rezultat fsutil ambiguu sau necunoscut pentru '+$property+'. Nicio valoare originala nu este inventata. Iesire: '+$raw)}
 $v=[long]$matchesFound[0].Groups[1].Value
 $valid=switch($property.ToLowerInvariant()){
  'disabledeletenotify' {@(0,1)}
  'disable8dot3' {@(0,1,2,3)}
  'disablelastaccess' {@(0,1,2,3)}
  'mftzone' {@(1,2,3,4)}
 }
 if($v -notin $valid){throw ('Valoare fsutil in afara domeniului pentru '+$property+': '+$v)}
 return $v
}
function Get-FsutilValue($property){
 if($property -notin @('DisableDeleteNotify','disable8dot3','disablelastaccess','mftzone')){throw 'Parametru fsutil nepermis.'}
 return Convert-FsutilValue $property (Invoke-Tool fsutil @('behavior','query',$property))
}
function Get-NativeApplicability($o){
 if($o.type -eq 'bitlocker'){
  if(-not (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue)){return @{applicable=$false;message='Nu se aplica: BitLocker nu este disponibil pe aceasta editie Windows.'}}
  $b=Get-BitLockerVolume -MountPoint $o.drive -ErrorAction Stop
  if([string]$b.VolumeStatus -ne 'FullyEncrypted'){return @{applicable=$false;message=('Nu se aplica: volumul '+$o.drive+' are starea '+[string]$b.VolumeStatus+'. Nu s-a modificat nimic.')}}
 }
 return @{applicable=$true}
}
function Resolve-Native($spec,$adapterGuid,$saved=$null){
 $o=Copy-Object $spec
 if($o.type -in @('dns','mtu','ipv6')){
  $g=if($null -ne $saved){$saved.adapterGuid}else{$adapterGuid};$a=Get-AdapterByGuid $g
  $o | Add-Member -NotePropertyName adapterGuid -NotePropertyValue ([string]$a.InterfaceGuid) -Force
 }
 if($o.type -eq 'power-value'){
  $scheme=if($null -ne $saved){[string]$saved.scheme}else{Get-ActivePower}
  if($scheme -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'Plan invalid în backup.'}
  $o | Add-Member -NotePropertyName scheme -NotePropertyValue $scheme -Force
 }
 if($o.type -in @('quota','bitlocker','maintenance')){
  $drive=if($null -ne $saved){[string]$saved.drive}else{$env:SystemDrive}
  if($drive -notmatch '^[A-Za-z]:$'){throw 'Volum invalid.'}
  $o | Add-Member -NotePropertyName drive -NotePropertyValue $drive -Force
 }
 return $o
}
function Native-Targets($o){
 switch($o.type){
  'service' {return @($o.services | ForEach-Object {'service|'+$_.name.ToLowerInvariant()})}
  'power-active' {return @('power-active')}
  'power-value' {return @(('power-value|'+$o.scheme+'|'+$o.subgroup+'|'+$o.setting).ToLowerInvariant())}
  'dns' {return @('network|'+$o.adapterGuid.ToLowerInvariant()+'|dns')}
  'mtu' {return @('network|'+$o.adapterGuid.ToLowerInvariant()+'|mtu')}
  'ipv6' {return @('network|'+$o.adapterGuid.ToLowerInvariant()+'|ipv6')}
  'tcp-global' {return @('tcp|'+$o.property.ToLowerInvariant())}
  'bcd' {return @($o.values | ForEach-Object {'bcd|'+$_.object+'|'+$_.key})}
  'fsutil' {return @('fsutil|'+$o.property.ToLowerInvariant())}
  'defender' {return @('defender|'+$o.property)}
  'task' {return @('task|'+$o.taskPath+$o.taskName)}
  'tunnel' {return @('tunnel|'+$o.name)}
  default {return @('native|'+$o.type)}
 }
}
function Capture-Native($o){
 switch($o.type){
  'service' {
   $a=@();foreach($item in $o.services){
    $svc=Get-Service -Name $item.name -ErrorAction Stop
    if($svc.Status -notin @('Running','Stopped')){throw ('Serviciul '+$item.name+' este în tranziție.')}
    $k=Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$item.name) -ErrorAction Stop
    $a+=@{name=$item.name;start=[int]$k.Start;delayedExists=($null -ne $k.DelayedAutoStart);delayed=[int]$k.DelayedAutoStart;running=($svc.Status -eq 'Running')}
   };return ,$a
  }
  'power-active' {return Get-ActivePower}
  'power-value' {
   return (Read-PowerACIndex -Scheme ([guid]$o.scheme) -Subgroup ([guid]$o.subgroup) -Setting ([guid]$o.setting))
  }
  'defender' {
   if($o.property -notin @('DisableRealtimeMonitoring','ScanOnlyIfIdleEnabled')){throw 'Preferință Defender nepermisă.'}
   $pref=Get-MpPreference -ErrorAction Stop;if($null -eq $pref.($o.property)){throw 'Preferință Defender indisponibilă.'};return [bool]$pref.($o.property)
  }
  'firewall' {return [string](Get-NetFirewallProfile -Name Private -PolicyStore PersistentStore -ErrorAction Stop).Enabled}
  'dns' {
   $a=Get-AdapterByGuid $o.adapterGuid
   $key='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\{'+([guid]$a.InterfaceGuid).ToString()+'}'
   $r=Get-ItemProperty -LiteralPath $key -ErrorAction Stop
   $ns=[string]$r.NameServer
   if([string]::IsNullOrWhiteSpace($ns)){return @{automatic=$true;servers=@()}}
   $servers=@($ns -split '[,;\s]+' | Where-Object {$_})
   foreach($ip in $servers){$v=$null;if(-not [Net.IPAddress]::TryParse($ip,[ref]$v)){throw 'DNS original invalid.'}}
   return @{automatic=$false;servers=@($servers)}
  }
  'mtu' {
   $a=Get-AdapterByGuid $o.adapterGuid
   $active=Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -PolicyStore ActiveStore -ErrorAction Stop
   $persistent=Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -PolicyStore PersistentStore -ErrorAction Stop
   return @{active=[int]$active.NlMtu; persistent=[int]$persistent.NlMtu}
  }
  'ipv6' {$a=Get-AdapterByGuid $o.adapterGuid;return [bool](Get-NetAdapterBinding -Name ([WildcardPattern]::Escape($a.Name)) -ComponentID ms_tcpip6 -ErrorAction Stop).Enabled}
  'rss' {return [string](Get-NetOffloadGlobalSetting -ErrorAction Stop).ReceiveSideScaling}
  'tcp-global' {return Get-TcpDumpValue $o.property}
  'tunnel' {return Get-TunnelValue $o.name}
  'hibernation' {
   $key=Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -ErrorAction Stop
   $values=@();foreach($name in @('HibernateEnabled','HiberFileType','HiberFileSizePercent')){$values+=@{name=$name;exists=($null -ne $key.$name);value=$key.$name}}
   if($null -eq $key.HibernateEnabled){throw 'Starea hibernării nu este disponibilă.'};if([int]$key.HibernateEnabled -ne 0 -and [int]$key.HiberFileSizePercent -lt 40){throw 'Tipul hiberfile original nu poate fi restaurat exact pe această configurație. Nicio modificare.'};return ,$values
  }
  'fsutil' {if($o.property -ieq 'disablelastaccess'){$v=Get-ItemPropertyValue -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name NtfsDisableLastAccessUpdate -ErrorAction Stop;return ([long]$v -band 4294967295)};return Get-FsutilValue $o.property}
  'quota' {
   $q=New-Object -ComObject Microsoft.DiskQuota;$q.Initialize($o.drive+'\',$false);return [int]$q.QuotaState
  }
  'task' {return [bool](Get-ScheduledTask -TaskPath $o.taskPath -TaskName $o.taskName -ErrorAction Stop).Settings.Enabled}
  'bcd' {
   $values=@();foreach($v in $o.values){
    if($v.key -notin @('useplatformtick','disabledynamictick','nx','debug','bootdebug','increaseuserva','recoveryenabled','timeout')){throw 'Cheie BCD nepermisă.'}
    $raw=Invoke-Tool bcdedit @('/enum',$v.object)
    $m=[regex]::Match($raw,'(?im)^\s*'+[regex]::Escape($v.key)+'\s+([^\r\n]+)\s*$')
    $value=if($m.Success){$m.Groups[1].Value.Trim()}else{$null}
    if($m.Success -and $value -notmatch '^(Yes|No|True|False|On|Off|AlwaysOn|AlwaysOff|OptIn|OptOut|\d+)$'){throw 'Valoare BCD originală nerecunoscută; nu se ghicește traducerea.'}
    $values+=@{key=$v.key;object=$v.object;exists=$m.Success;value=$value}
   };return ,$values
  }
  'bitlocker' {
   $b=Get-BitLockerVolume -MountPoint $o.drive -ErrorAction Stop
   if([string]$b.VolumeStatus -ne 'FullyEncrypted'){throw 'Volumul nu este complet criptat; suspendarea nu se aplică.'}
   return [string]$b.ProtectionStatus
  }
  'reserved-storage' {
   $r=Get-WindowsReservedStorageState -Online -ErrorAction Stop
   $v=if($r.ReservedStorageState){[string]$r.ReservedStorageState}else{[string]$r}
   if($v -notin @('Enabled','Disabled')){throw 'Starea spațiului rezervat nu poate fi citită.'};return $v
  }
  default {throw 'Adaptor nativ necunoscut.'}
 }
}
function Desired-Native($o,$before){
 switch($o.type){
  'service' {$a=@();for($i=0;$i -lt @($o.services).Count;$i++){$r=Copy-Object $before[$i];$r.start=[int]$o.services[$i].start;if($null -ne $o.services[$i].running){$r.running=[bool]$o.services[$i].running};$a+=$r};return ,$a}
  'firewall' {return [string][bool]$o.value}
  'dns' {return @{automatic=(@($o.value).Count -eq 0);servers=@($o.value)}}
  'mtu' {return @{active=[int]$o.value;persistent=[int]$o.value}}
  'bcd' {return ,@($o.values | ForEach-Object {@{key=$_.key;object=$_.object;exists=$true;value=$_.value}})}
  'hibernation' {$a=Copy-Object $before;($a | Where-Object {$_.name -eq 'HibernateEnabled'}).value=0;return ,$a}
  default {return $o.value}
 }
}
# Validate an entire saved state before the first OS write, including all rows.
function Assert-NativeValue($o,$v){
 switch($o.type){
  {$_ -in @('defender','ipv6','task')} {if($v -isnot [bool]){throw 'Valoare booleană invalidă.'}}
  'power-active' {if($v -isnot [string] -or $v -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'Plan de alimentare invalid.'}}
  'power-value' {if(($v -isnot [int] -and $v -isnot [long] -and $v -isnot [uint32]) -or $v -lt 0 -or $v -gt 4294967295){throw 'Valoare de alimentare invalidă.'}}
  'service' {
   if($v -isnot [array] -or @($v).Count -ne @($o.services).Count){throw 'Backup servicii incomplet.'}
   for($i=0;$i -lt @($v).Count;$i++){$x=$v[$i];if($x.name -cne $o.services[$i].name -or $x.start -notin @(2,3,4) -or $x.running -isnot [bool] -or $x.delayedExists -isnot [bool] -or $x.delayed -notin @(0,1)){throw 'Original serviciu invalid.'}}
  }
  'dns' {
   if($v.automatic -isnot [bool] -or $v.servers -isnot [array] -or (-not $v.automatic -and @($v.servers).Count -eq 0) -or ($v.automatic -and @($v.servers).Count -ne 0)){throw 'DNS incomplet.'}
   foreach($ip in $v.servers){$address=$null;if($ip -isnot [string] -or -not [Net.IPAddress]::TryParse($ip,[ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Adresă DNS IPv4 invalidă.'}}
  }
  'mtu' {foreach($key in @('active','persistent')){if(($v.$key -isnot [int] -and $v.$key -isnot [long]) -or $v.$key -lt 576 -or $v.$key -gt 65535){throw 'MTU invalid.'}}}
  'firewall' {if($v -isnot [string] -or $v -notin @('True','False','NotConfigured')){throw 'Stare firewall invalidă.'}}
  'rss' {if($v -isnot [string] -or $v -notin @('Enabled','Disabled')){throw 'Stare RSS invalidă.'}}
  'tcp-global' {if($v -isnot [string] -or $v -notmatch '^[a-zA-Z0-9]+$' -or ($o.property -eq 'initialrto' -and $v -notmatch '^\d+$')){throw 'Valoare TCP invalidă.'}}
  'tunnel' {if($v -isnot [string] -or $v -notmatch '^[a-zA-Z]+$'){throw 'Stare tunel invalidă.'}}
  'quota' {if(($v -isnot [int] -and $v -isnot [long]) -or $v -notin @(0,1,2)){throw 'Cotă invalidă.'}}
  'fsutil' {if(($v -isnot [int] -and $v -isnot [long] -and $v -isnot [uint32]) -or $v -lt 0 -or $v -gt 4294967295){throw 'Valoare NTFS invalidă.'}}
  'bitlocker' {if($v -isnot [string] -or $v -notin @('On','Off')){throw 'Stare BitLocker invalidă.'}}
  'reserved-storage' {if($v -isnot [string] -or $v -notin @('Enabled','Disabled')){throw 'Stare spațiu rezervat invalidă.'}}
  'hibernation' {
   if($v -isnot [array] -or @($v).Count -ne 3){throw 'Captură hibernare incompletă.'}
   $seen=@{};foreach($x in $v){
    if($x.name -notin @('HibernateEnabled','HiberFileType','HiberFileSizePercent') -or $seen.ContainsKey([string]$x.name) -or $x.exists -isnot [bool]){throw 'Captură hibernare invalidă.'};$seen[$x.name]=$true
    if($x.exists -and (($x.value -isnot [int] -and $x.value -isnot [long]) -or $x.value -lt 0 -or $x.value -gt [int]::MaxValue)){throw 'Valoare hibernare invalidă.'}
   }
  }
  'bcd' {
   if($v -isnot [array] -or @($v).Count -ne @($o.values).Count){throw 'Captură BCD incompletă.'}
   for($i=0;$i -lt @($v).Count;$i++){$x=$v[$i];if($x.key -cne $o.values[$i].key -or $x.object -cne $o.values[$i].object -or $x.exists -isnot [bool] -or ($x.exists -and ($x.value -isnot [string] -or $x.value -notmatch '^(Yes|No|True|False|On|Off|AlwaysOn|AlwaysOff|OptIn|OptOut|\d+)$'))){throw 'Valoare BCD invalidă.'}}
  }
  default {throw 'Tip nativ neacceptat pentru restaurare.'}
 }
}
# Multi-step native writes may stop between components. Allow only components
# equal to the saved original or the requested state; never accept a third value.
function Test-NativeRestoreState($o,$current,$before,$desired){
 if((Canonical-Native $current) -ceq (Canonical-Native $before) -or (Canonical-Native $current) -ceq (Canonical-Native $desired)){return $true}
 switch($o.type){
  'service' {
   try{Assert-NativeValue $o $current}catch{return $false}
   for($i=0;$i -lt @($current).Count;$i++){
    foreach($key in @('start','running','delayedExists','delayed')){
     $value=Canonical-Native $current[$i].$key
     if($value -cne (Canonical-Native $before[$i].$key) -and $value -cne (Canonical-Native $desired[$i].$key)){return $false}
    }
   };return $true
  }
  'bcd' {
   try{Assert-NativeValue $o $current}catch{return $false}
   for($i=0;$i -lt @($current).Count;$i++){
    $value=Canonical-Native $current[$i]
    if($value -cne (Canonical-Native $before[$i]) -and $value -cne (Canonical-Native $desired[$i])){return $false}
   };return $true
  }
  'mtu' {
   try{Assert-NativeValue $o $current}catch{return $false}
   foreach($key in @('active','persistent')){if($current.$key -ne $before.$key -and $current.$key -ne $desired.$key){return $false}};return $true
  }
 }
 return $false
}
function Write-Native($o,$v){
 Assert-NativeValue $o $v
 switch($o.type){
  'service' {
   if(@($v).Count -ne @($o.services).Count){throw 'Backup servicii invalid.'}
   # Validate every original before changing the first service.
   for($j=0;$j -lt @($o.services).Count;$j++){
    $row=$v[$j]
    if($row.name -cne $o.services[$j].name -or $row.start -notin @(2,3,4) -or $row.running -isnot [bool] -or $row.delayedExists -isnot [bool] -or $row.delayed -notin @(0,1)){throw 'Original serviciu incomplet/incompatibil. Nicio modificare.'}
   }
   for($i=0;$i -lt @($o.services).Count;$i++){
    $item=$v[$i];$name=$o.services[$i].name;if($item.name -cne $name){throw 'Serviciu diferit în backup.'}
    $mode=switch([int]$item.start){2 {'auto'};3 {'demand'};4 {'disabled'};default{throw 'Mod de pornire nepermis.'}}
    Invoke-Tool sc @('config',$name,'start=',$mode) | Out-Null
    $key='HKLM:\SYSTEM\CurrentControlSet\Services\'+$name
    if($item.delayedExists){New-ItemProperty -LiteralPath $key -Name DelayedAutoStart -Value ([int]$item.delayed) -PropertyType DWord -Force | Out-Null}else{Remove-ItemProperty -LiteralPath $key -Name DelayedAutoStart -ErrorAction SilentlyContinue}
    $svc=Get-Service -Name $name -ErrorAction Stop
    if($item.running -and $svc.Status -ne 'Running'){
     # A disabled service may legitimately have been running when captured.
     # Temporarily permit its start, then restore the saved startup mode even
     # if Windows refuses the start. Never leave it enabled as a side effect.
     if([int]$item.start -eq 4){Invoke-Tool sc @('config',$name,'start=','demand') | Out-Null}
     try{Start-Service -Name $name -ErrorAction Stop;$svc.WaitForStatus('Running',[TimeSpan]::FromSeconds(30))}
     finally{if([int]$item.start -eq 4){Invoke-Tool sc @('config',$name,'start=','disabled') | Out-Null}}
    }
    elseif(-not $item.running -and $svc.Status -ne 'Stopped'){Stop-Service -Name $name -ErrorAction Stop;$svc.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}
   }
  }
  'power-active' {
   if([string]$v -notmatch '^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'){throw 'GUID plan invalid.'};Invoke-Tool powercfg @('/setactive',[string]$v) | Out-Null
  }
  'power-value' {
   Invoke-Tool powercfg @('/setacvalueindex',$o.scheme,$o.subgroup,$o.setting,[string][long]$v) | Out-Null
   if((Get-ActivePower) -ieq $o.scheme){Invoke-Tool powercfg @('/setactive',$o.scheme) | Out-Null}
  }
  'defender' {$defenderArgs=@{};$defenderArgs[$o.property]=[bool]$v;Set-MpPreference @defenderArgs -ErrorAction Stop}
  'firewall' {if([string]$v -notin @('True','False','NotConfigured')){throw 'Stare firewall invalidă.'};Set-NetFirewallProfile -Name Private -PolicyStore PersistentStore -Enabled ([string]$v) -ErrorAction Stop}
  'dns' {
   $a=Get-AdapterByGuid $o.adapterGuid
   # Use IPv4 CIM input so IPv6 DNS is not changed by this IPv4-only feature.
   $dns=Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction Stop
   if($v.automatic){$dns | Set-DnsClientServerAddress -ResetServerAddresses -ErrorAction Stop}else{$dns | Set-DnsClientServerAddress -ServerAddresses ([string[]]$v.servers) -ErrorAction Stop}
  }
  'mtu' {
   $a=Get-AdapterByGuid $o.adapterGuid
   Set-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -PolicyStore PersistentStore -NlMtuBytes ([int]$v.persistent) -ErrorAction Stop
   Set-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -PolicyStore ActiveStore -NlMtuBytes ([int]$v.active) -ErrorAction Stop
  }
  'ipv6' {
   $a=Get-AdapterByGuid $o.adapterGuid
   if($v){Enable-NetAdapterBinding -Name ([WildcardPattern]::Escape($a.Name)) -ComponentID ms_tcpip6 -Confirm:$false -ErrorAction Stop}else{Disable-NetAdapterBinding -Name ([WildcardPattern]::Escape($a.Name)) -ComponentID ms_tcpip6 -Confirm:$false -ErrorAction Stop}
  }
  'rss' {Set-NetOffloadGlobalSetting -ReceiveSideScaling ([string]$v) -ErrorAction Stop}
  'tcp-global' {
   if([string]$v -notmatch '^[a-zA-Z0-9]+$'){throw 'Valoare TCP invalidă.'};Invoke-Tool netsh @('int','tcp','set','global',($o.property+'='+$v)) | Out-Null
  }
  'tunnel' {
   if([string]$v -notmatch '^[a-zA-Z]+$'){throw 'Valoare tunel invalidă.'};Invoke-Tool netsh @('interface',$o.name,'set','state',[string]$v) | Out-Null
  }
  'hibernation' {
   $enabled=@($v | Where-Object {$_.name -eq 'HibernateEnabled'});if($enabled.Count -ne 1){throw 'Backup hibernare invalid.'}
   $mode=if([int]$enabled[0].value -ne 0){'on'}else{'off'};Invoke-Tool powercfg @('/h',$mode) | Out-Null
   if($mode -eq 'on'){
    $type=@($v | Where-Object {$_.name -eq 'HiberFileType' -and $_.exists});if($type.Count){$typeName='full';Invoke-Tool powercfg @('/h','/type',$typeName) | Out-Null}
    $size=@($v | Where-Object {$_.name -eq 'HiberFileSizePercent' -and $_.exists});if($size.Count -and [int]$size[0].value -ge 40){Invoke-Tool powercfg @('/h','/size',[string]$size[0].value) | Out-Null}
   }
   foreach($item in $v){
    if($item.name -notin @('HibernateEnabled','HiberFileType','HiberFileSizePercent')){throw 'Cheie hibernare nepermisă.'}
    if($item.exists){New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name $item.name -Value ([int]$item.value) -PropertyType DWord -Force | Out-Null}else{Remove-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name $item.name -ErrorAction SilentlyContinue}
   }
  }
  'fsutil' {if($o.property -ieq 'disablelastaccess' -and [long]$v -gt 3){$signed=[BitConverter]::ToInt32([BitConverter]::GetBytes([uint32]$v),0);New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name NtfsDisableLastAccessUpdate -Value $signed -PropertyType DWord -Force | Out-Null}elseif($o.property -ieq 'DisableDeleteNotify'){Invoke-Tool fsutil @('behavior','set',$o.property,'NTFS',[string][long]$v) | Out-Null}else{Invoke-Tool fsutil @('behavior','set',$o.property,[string][long]$v) | Out-Null}}
  'quota' {$q=New-Object -ComObject Microsoft.DiskQuota;$q.Initialize($o.drive+'\',$true);$q.QuotaState=[int]$v}
  'task' {if($v){Enable-ScheduledTask -TaskPath $o.taskPath -TaskName $o.taskName -ErrorAction Stop | Out-Null}else{Disable-ScheduledTask -TaskPath $o.taskPath -TaskName $o.taskName -ErrorAction Stop | Out-Null}}
  'bcd' {
   if(@($v).Count -ne @($o.values).Count){throw 'Backup BCD invalid.'}
   for($i=0;$i -lt @($o.values).Count;$i++){
    $item=$v[$i];$spec=$o.values[$i];if($item.key -cne $spec.key -or $item.object -cne $spec.object){throw 'Țintă BCD nepermisă.'}
    if($item.exists){
     if([string]$item.value -notmatch '^(Yes|No|True|False|On|Off|AlwaysOn|AlwaysOff|OptIn|OptOut|\d+)$'){throw 'Valoare BCD invalidă.'}
     Invoke-Tool bcdedit @('/set',$spec.object,$spec.key,[string]$item.value) | Out-Null
    }else{
     $raw=Invoke-Tool bcdedit @('/enum',$spec.object)
     if($raw -match ('(?im)^\s*'+[regex]::Escape($spec.key)+'\s+')){Invoke-Tool bcdedit @('/deletevalue',$spec.object,$spec.key) | Out-Null}
    }
   }
  }
  'bitlocker' {
   if($v -eq 'On'){Resume-BitLocker -MountPoint $o.drive -ErrorAction Stop | Out-Null}
   elseif($v -eq 'Off'){Suspend-BitLocker -MountPoint $o.drive -RebootCount 1 -ErrorAction Stop | Out-Null}else{throw 'Stare BitLocker invalidă.'}
  }
  'reserved-storage' {Set-WindowsReservedStorageState -Online -State ([string]$v) -ErrorAction Stop | Out-Null}
  default {throw 'Adaptor de scriere inexistent.'}
 }
}
function Canonical-Native($v){
 if($null -eq $v){return 'null'}
 if($v -is [string]){return ('s:'+ $v.ToLowerInvariant())}
 if($v -is [bool]){return ('b:'+[string]$v)}
 if($v -is [ValueType]){return ('n:'+[string]$v)}
 if($v -is [Collections.IDictionary]){$keys=@($v.Keys | Sort-Object);return '{'+(($keys | ForEach-Object {[string]$_+':'+(Canonical-Native $v[$_])}) -join '|')+'}'}
 if($v -is [System.Management.Automation.PSCustomObject]){$keys=@($v.PSObject.Properties.Name | Sort-Object);return '{'+(($keys | ForEach-Object {[string]$_+':'+(Canonical-Native $v.$_)}) -join '|')+'}'}
 return '['+((@($v) | ForEach-Object {Canonical-Native $_}) -join '|')+']'
}
# Windows can lock active shader caches while drivers or games are using them.
# Only ERROR_SHARING_VIOLATION (32) and ERROR_LOCK_VIOLATION (33) are benign skips.
# Access denied, invalid paths and other failures must remain visible.
function Test-CacheFileLock($errorRecord){
 $e=$errorRecord.Exception
 while($null -ne $e){
  if($e -is [System.IO.IOException] -and (([long]$e.HResult -band 65535) -in @(32,33))){return $true}
  $e=$e.InnerException
 }
 # On some Windows PowerShell versions Remove-Item wraps the native error.
 $message=[string]$errorRecord.Exception.Message
 return ($message -match '(?i)(being used by another process|used by another process|utilizat de (un )?alt proces|folosit de (un )?alt proces)')
}
function Remove-CacheFiles([string[]]$Roots){
 $removed=0;$bytes=[long]0;$errors=@();$skipped=0;$locked=0;$recent=0;$links=0
 foreach($rootPath in $Roots){
  $base=[IO.Path]::GetFullPath($rootPath).TrimEnd('\')
  if(-not (Test-Path -LiteralPath $base)){continue}
  # Reject junctions anywhere in the ancestry, not just the requested root.
  try{$ancestor=Get-Item -LiteralPath $base -Force -ErrorAction Stop}catch{$errors+=($base+': '+$_.Exception.Message);continue}
  while($null -ne $ancestor){if(($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Folderul cache traversează o legătură; curățarea este blocată.'};$ancestor=$ancestor.Parent}
  $pending=New-Object 'System.Collections.Generic.Stack[string]';$pending.Push($base)
  while($pending.Count){
   $folder=$pending.Pop()
   try{$dir=Get-Item -LiteralPath $folder -Force -ErrorAction Stop}catch{$errors+=($folder+': '+$_.Exception.Message);continue}
   if(($dir.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){$skipped++;$links++;continue}
   try{$children=@(Get-ChildItem -LiteralPath $folder -Force -ErrorAction Stop)}catch{$errors+=($folder+': '+$_.Exception.Message);continue}
   foreach($item in $children){
    if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){$skipped++;$links++;continue}
    if($item.PSIsContainer){$pending.Push($item.FullName);continue}
    if($item.LastWriteTime -gt (Get-Date).AddHours(-1)){$skipped++;$recent++;continue}
    try{
     $full=[IO.Path]::GetFullPath($item.FullName);if(-not $full.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Fișier în afara folderului cache.'}
     $check=Get-Item -LiteralPath $full -Force -ErrorAction Stop
     if(($check.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Fișier legătură respins.'}
     $ancestor=$check.Directory;while($null -ne $ancestor){if(($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Folder devenit legătură.'};$ancestor=$ancestor.Parent}
     $length=$check.Length;Remove-Item -LiteralPath $full -Force -ErrorAction Stop;$removed++;$bytes+=$length
    }catch{
     if(Test-CacheFileLock $_){$skipped++;$locked++;continue}
     $errors+=($item.FullName+': '+$_.Exception.Message)
    }
   }
  }
 }
 $message=if($errors.Count -gt 0){'Curățare incompletă: au apărut erori reale. Fișierele blocate au fost omise.'}
 elseif($locked -gt 0 -and $removed -eq 0){'Niciun fișier șters. Fișierele cache folosite de alte procese au fost omise în siguranță.'}
 elseif($locked -gt 0){'Curățare parțială: fișierele folosite de alte procese au fost omise în siguranță.'}
 elseif($removed -gt 0){'Curățarea fișierelor cache eligibile s-a încheiat.'}
 else{'Nu au existat fișiere cache eligibile pentru ștergere.'}
 return @{removed=$removed;bytes=$bytes;skipped=$skipped;locked=$locked;recent=$recent;links=$links;errors=@($errors);success=($errors.Count -eq 0);message=$message}
}
function Run-Maintenance($o,$reportDir){
 switch($o.name){
  'cache-directx' {return Remove-CacheFiles @((Join-Path $env:LOCALAPPDATA 'D3DSCache'))}
  'cache-nvidia' {return Remove-CacheFiles @((Join-Path $env:LOCALAPPDATA 'NVIDIA\DXCache'))}
  'cache-amd' {return Remove-CacheFiles @((Join-Path $env:LOCALAPPDATA 'AMD\DxCache'))}
  'clean-temp' {return Remove-CacheFiles @((Join-Path $env:LOCALAPPDATA 'Temp'),(Join-Path $env:SystemRoot 'Temp'))}
  'clean-update-cache' {return Remove-CacheFiles @((Join-Path $env:SystemRoot 'SoftwareDistribution\Download'))}
  'flush-dns' {return @{success=$true;output=(Invoke-Tool ipconfig @('/flushdns'));verification='exit-code'}}
  'flush-arp' {return @{success=$true;output=(Invoke-Tool arp @('-d','*'));verification='exit-code'}}
  'flush-netbios' {return @{success=$true;output=(Invoke-Tool nbtstat @('-RR'));verification='exit-code'}}
  'reset-network' {
   # Preserve diagnostic exports, never present them as an exact reversible snapshot.
   Invoke-Tool netsh @('interface','ipv4','dump') | Set-Content -LiteralPath (Join-Path $reportDir 'ipv4-before.txt') -Encoding UTF8
   Invoke-Tool netsh @('winsock','show','catalog') | Set-Content -LiteralPath (Join-Path $reportDir 'winsock-before.txt') -Encoding UTF8
   $output=@();$output+=Invoke-Tool netsh @('winsock','reset');$output+=Invoke-Tool netsh @('int','ip','reset',(Join-Path $reportDir 'ip-reset.log'));$output+=Invoke-Tool ipconfig @('/flushdns')
   return @{success=$true;restartRequired=$true;output=($output -join "`n");verification='exit-code';reversible=$false}
  }
  'memory-diagnostic' {
   Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\mdsched.exe') -ErrorAction Stop | Out-Null
   return @{success=$true;verification='launched';message='Fereastra Windows Memory Diagnostic a fost deschisă. Testul RAM nu a fost încă executat.'}
  }
  'optimize-drive' {
   $drive=$o.drive.Substring(0,1)
   Optimize-Volume -DriveLetter $drive -Analyze -ErrorAction Stop | Out-Null
   Optimize-Volume -DriveLetter $drive -ErrorAction Stop | Out-Null
   return @{success=$true;verification='command-completed';message='Optimize-Volume s-a încheiat pentru volumul de sistem. Nu este o măsurare FPS.'}
  }
  'delete-oldest-shadow' {
   $volume=Get-CimInstance Win32_Volume -Filter ("DriveLetter='"+$o.drive+"'") -ErrorAction Stop
   $shadow=Get-CimInstance Win32_ShadowCopy -ErrorAction Stop | Where-Object {$_.VolumeName -ieq $volume.DeviceID} | Sort-Object InstallDate | Select-Object -First 1
   if($null -eq $shadow){return @{success=$true;skipped=$true;message='Nu există copii shadow pe volumul de sistem. Nimic șters.'}}
   $id=[string]$shadow.ID;if($id -notmatch '^\{[a-fA-F0-9-]{36}\}$'){throw 'ID shadow invalid.'}
   Invoke-Tool vssadmin @('delete','shadows',('/shadow='+$id),'/quiet') | Out-Null
   if(@(Get-CimInstance Win32_ShadowCopy -ErrorAction Stop | Where-Object {$_.ID -ceq $id}).Count){throw 'Copia shadow există în continuare.'}
   return @{success=$true;verification='absence-confirmed';reversible=$false;message='Cea mai veche copie shadow a volumului de sistem a fost ștearsă definitiv.'}
  }
  'uninstall-onedrive' {
   $paths=@((Join-Path $env:SystemRoot 'SysWOW64\OneDriveSetup.exe'),(Join-Path $env:SystemRoot 'System32\OneDriveSetup.exe'))
   $setup=$paths | Where-Object {Test-Path -LiteralPath $_ -PathType Leaf} | Select-Object -First 1
   if(-not $setup){throw 'Programul oficial OneDriveSetup nu este disponibil. Nimic executat.'}
   Get-Process -Name OneDrive -ErrorAction SilentlyContinue | Stop-Process -ErrorAction Stop
   $process=Start-Process -FilePath $setup -ArgumentList '/uninstall' -Wait -PassThru -ErrorAction Stop
   if($process.ExitCode -ne 0){throw ('Dezinstalarea OneDrive a eșuat: '+$process.ExitCode)}
   return @{success=$true;verification='installer-exit-code';reversible=$false;message='Dezinstalatorul OneDrive s-a încheiat. Reinstalarea necesită instalatorul Microsoft; fișierele personale nu au fost șterse de CARPATIA.'}
  }
  'uninstall-edge' {
   $apps=@(Get-AppxPackage -ErrorAction Stop | Where-Object {$_.Name -like 'Microsoft.MicrosoftEdge*' -and -not $_.NonRemovable -and -not $_.IsFramework})
   if(-not $apps.Count){return @{success=$true;skipped=$true;message='Nu există pachete Edge AppX detașabile în contul curent. Componentele protejate nu au fost modificate.'}}
   $names=@($apps.PackageFullName)
   foreach($app in $apps){Remove-AppxPackage -Package $app.PackageFullName -ErrorAction Stop}
   if(@(Get-AppxPackage -ErrorAction Stop | Where-Object {$_.PackageFullName -in $names}).Count){throw 'Unele pachete Edge sunt încă instalate.'}
   return @{success=$true;verification='absence-confirmed';reversible=$false;message='Pachetele Edge AppX detașabile au fost eliminate din contul curent. Reinstalarea nu este automată.'}
  }
  default {throw 'Operație de întreținere nepermisă.'}
 }
}
