﻿param([ValidateSet('Set','Restore','Flush')][string]$Action='Flush',[string]$Adapter='',[ValidateSet('cloudflare','google','quad9')][string]$Provider='cloudflare')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
New-Item -ItemType Directory -Path $dir -Force|Out-Null
$backup=Join-Path $dir 'dns-latest.json'
$servers=@{cloudflare=@('1.1.1.1','1.0.0.1');google=@('8.8.8.8','8.8.4.4');quad9=@('9.9.9.9','149.112.112.112')}
function Read-DnsIPv4State($a){
 $current=Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction Stop
 $registryPath='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\{'+([guid]$a.InterfaceGuid).ToString()+'}'
 # An unreadable key must not be interpreted as automatic DNS.
 $key=Get-Item -LiteralPath $registryPath -ErrorAction Stop
 try{$manual=[string]$key.GetValue('NameServer','')}finally{$key.Dispose()}
 return @{automatic=[string]::IsNullOrWhiteSpace($manual);servers=@($current.ServerAddresses | Where-Object {$_})}
}
function Same-DnsIPv4State($actual,$automatic,$addresses){
 if($actual.automatic -ne $automatic){return $false}
 return ($automatic -or (($actual.servers -join ',') -ceq (@($addresses) -join ',')))
}
if($Action -eq 'Flush'){
 Clear-DnsClientCache -ErrorAction Stop
 @{success=$true;message='Cache DNS golit. Nu modifica traseul pachetelor catre jocuri.'}|ConvertTo-Json -Compress
 exit
}
if($Action -eq 'Restore'){
 if(!(Test-Path -LiteralPath $backup)){throw 'Nu exista backup DNS.'}
 $b=Get-Content -Raw -LiteralPath $backup | ConvertFrom-Json
 if([int]$b.version -ne 2){throw 'Backup DNS incompatibil. Nu se va restaura automat.'}
 if($b.automatic -isnot [bool] -or $b.servers -isnot [array] -or (-not $b.automatic -and @($b.servers).Count -eq 0)){throw 'Original DNS incomplet.'}
 foreach($ip in $b.servers){$address=$null;if(-not [Net.IPAddress]::TryParse([string]$ip,[ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Adresse DNS IPv4 invalide în backup.'}}
 $originalGuid=[guid]::Empty
 if(-not [guid]::TryParse([string]$b.guid,[ref]$originalGuid)){throw 'Identitate DNS invalidă.'}
 $matches=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop | Where-Object {([guid]$_.InterfaceGuid) -eq $originalGuid})
 if($matches.Count -ne 1){throw 'Adaptorul original nu este disponibil. Backup păstrat.'};$a=$matches[0]
 $live=Read-DnsIPv4State $a
 $isOriginal=Same-DnsIPv4State $live $b.automatic $b.servers
 $isApplied=$false
 # Older v2 backups do not name their provider; accept only bundled DNS pairs.
 $allowedProviders=if($b.PSObject.Properties.Name -contains 'provider'){@([string]$b.provider)}else{@($servers.Keys)}
 foreach($name in $allowedProviders){if($servers.ContainsKey($name) -and (Same-DnsIPv4State $live $false $servers[$name])){$isApplied=$true}}
 if(-not $isOriginal -and -not $isApplied){throw 'DNS a fost schimbat din exterior. Restaurarea automată a fost oprită; originalul este păstrat.'}
 if([bool]$b.automatic){
  Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ResetServerAddresses -ErrorAction Stop
 }else{
  if(@($b.servers).Count -eq 0){throw 'Backup DNS fara servere explicite; verificare manuala necesara.'}
  Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses @($b.servers) -ErrorAction Stop
 }
 $check=Read-DnsIPv4State $a
 if(-not (Same-DnsIPv4State $check $b.automatic $b.servers)){throw 'DNS restaurat nu coincide cu originalul. Backup păstrat.'}
 Move-Item -LiteralPath $backup -Destination (Join-Path $dir ('dns-restored-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.json')) -Force
 @{success=$true;message='DNS restaurat. Reconecteaza aplicatiile daca este necesar.'}|ConvertTo-Json -Compress
 exit
}
if(Test-Path -LiteralPath $backup){throw 'Exista deja backup DNS nerestaurat. Restaureaza setarea precedenta.'}
$a=Get-NetAdapter -Name $Adapter -ErrorAction Stop
if(@($a).Count -ne 1 -or $a.Status -ne 'Up'){throw 'Alege un singur adaptor activ.'}
$old=Read-DnsIPv4State $a
$guid=([guid]$a.InterfaceGuid).ToString()
$automatic=$old.automatic
$prior=@($old.servers)
$temp=$backup+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
try{
 @{version=2;index=$a.ifIndex;guid=$guid;name=$a.Name;servers=@($prior);automatic=$automatic;provider=$Provider;date=(Get-Date).ToString('o')}|
  ConvertTo-Json -Depth 4|Set-Content -LiteralPath $temp -Encoding UTF8
 Move-Item -LiteralPath $temp -Destination $backup -ErrorAction Stop
}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}}
try{
 Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses $servers[$Provider] -ErrorAction Stop
 $check=Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction Stop
 if((@($check.ServerAddresses) -join ',') -ne ($servers[$Provider] -join ',')){throw 'Windows nu confirma noul DNS.'}
}catch{throw ('DNS nu a fost confirmat. Backup salvat pentru restaurare: '+$_.Exception.Message)}
@{success=$true;adapter=$a.Name;provider=$Provider;automaticBefore=$automatic;message='DNS configurat. Aceasta afecteaza rezolvarea numelor, nu rutarea traficului de joc.'}|ConvertTo-Json -Compress
