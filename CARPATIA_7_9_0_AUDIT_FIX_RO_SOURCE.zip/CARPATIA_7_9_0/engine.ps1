﻿param([ValidateSet('Apply','Restore','Status')][string]$Action='Status',[string]$Ids='')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
# All changes are per-user HKCU registry values taken from the bundled allowlist.
# Windows PowerShell 5.1 may emit an entire JSON array as ONE pipeline object.
# Never wrap Get-Content | ConvertFrom-Json directly with @(...): this can create
# a nested array and collapse the whole allowlist to one hashtable entry.
$catalogPath=Join-Path $PSScriptRoot 'tweaks.json'
$jsonText=Get-Content -Raw -Encoding UTF8 -LiteralPath $catalogPath -ErrorAction Stop
$parsedCatalog=ConvertFrom-Json -InputObject $jsonText -ErrorAction Stop
$catalog=@()
foreach($candidate in $parsedCatalog){
 if($null -eq $candidate -or $candidate -is [System.Array] -or
    $candidate.id -isnot [string] -or @($candidate.entries).Count -lt 1){
  throw 'Catalog tweak-uri invalid sau imbricat. Nu se modifica Windows.'
 }
 $catalog+= $candidate
}
if($catalog.Count -ne 59){throw ('Catalog incomplet: '+$catalog.Count+' din 59 tweak-uri. Nu se modifica Windows.')}
$rules=@{}
foreach($item in $catalog){
 if($item.id -notmatch '^[a-z_0-9]{3,50}$'){throw 'Catalog invalid: ID'}
 foreach($entry in $item.entries){
  if(-not $entry.path.StartsWith('HKCU:\') -or ($entry.type -notin @('String','DWord'))){throw 'Catalog invalid: registru'}
  if($entry.name -notmatch '^[A-Za-z0-9_-]{1,90}$'){throw 'Catalog invalid: nume'}
 }
 if($rules.ContainsKey([string]$item.id)){throw ('Catalog invalid: ID duplicat '+[string]$item.id)}
 $rules[[string]$item.id]=$item
}
if($rules.Count -ne $catalog.Count){throw ('Allowlist invalid: '+$rules.Count+' reguli pentru '+$catalog.Count+' intrari. Nu se modifica Windows.')}
$dir=Join-Path $env:LOCALAPPDATA 'TweakRomania\Backups'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$backup=Join-Path $dir 'ultra-latest.json'
. (Join-Path $PSScriptRoot 'registry-values.ps1')
if($Action -eq 'Status'){
 $pending=@()
 if(Test-Path -LiteralPath $backup){$d=Get-Content -Raw -LiteralPath $backup|ConvertFrom-Json;$pending=@($d.ids)}
 $matching=@()
 foreach($item in $catalog){
  $complete=$true
  foreach($entry in $item.entries){
   try{$val=Get-ItemPropertyValue -LiteralPath $entry.path -Name $entry.name -ErrorAction Stop
    if([string]$val -cne [string]$entry.value){$complete=$false;break}
   }catch{$complete=$false;break}
  }
  if($complete){$matching+=$item.id}
 }
 @{success=$true;backup=(Test-Path -LiteralPath $backup);pendingIds=@($pending);matchingIds=@($matching);catalogSize=$rules.Count} | ConvertTo-Json -Compress -Depth 5
 exit
}
if($Action -eq 'Restore'){
 if(!(Test-Path -LiteralPath $backup)){throw 'Nu exista backup ULTRA. Nicio modificare de restaurat.'}
 $state=Get-Content -Raw -LiteralPath $backup | ConvertFrom-Json
 if([int]$state.version -ne 2){throw 'Backup ULTRA incompatibil; nu se aplica automat.'}
 # Validate the ENTIRE backup before the first write. Never invent missing originals.
 $rows=@($state.values)
 if($rows.Count -eq 0){throw 'Backup ULTRA gol sau invalid; fisierul este pastrat.'}
 $targets=@{}
 foreach($item in $catalog){foreach($entry in $item.entries){$targets[($entry.path+'|'+$entry.name).ToLowerInvariant()]=$true}}
 $originals=@()
 foreach($r in $rows){
  if($r.existed -isnot [bool] -or -not $targets.ContainsKey(([string]$r.path+'|'+[string]$r.name).ToLowerInvariant())){throw 'Backup ULTRA invalid: valoare in afara catalogului sau stare originala absenta.'}
  if($r.existed -and ($r.type -notin @('String','ExpandString','DWord','QWord','Binary','MultiString') -or $null -eq $r.value)){throw ('Tip sau valoare originala invalida: '+$r.name)}
  $originals+=@{path=([string]$r.path).Replace('HKCU:\','HKCU\');name=[string]$r.name;exists=$r.existed;kind=$r.type;value=$r.value;id=$r.id}
 }
 foreach($r in $originals){
  Assert-RegistryValue $r
  if(-not $rules.ContainsKey([string]$r.id)){throw 'Backup ULTRA cu ID necunoscut.'}
  $entry=@($rules[[string]$r.id].entries | Where-Object {([string]$_.path).Replace('HKCU:\','HKCU\') -ieq $r.path -and $_.name -ieq $r.name})
  if($entry.Count -ne 1){throw 'Original ULTRA diferit de regula salvată.'}
  $desired=@{path=$r.path;name=$r.name;exists=$true;kind=$entry[0].type;value=$entry[0].value}
  $current=Read-Value $r
  if(-not (Same-Value $current $r) -and -not (Same-Value $current $desired)){throw ('Modificare externă detectată: '+$r.path+' / '+$r.name+'. Originalul este păstrat.')}
 }
 $ok=0;$errors=@()
 [array]::Reverse($originals)
 foreach($r in $originals){try{
  Set-Value $r
  $actual=Read-Value $r
  if(-not (Same-Value $actual $r)){throw 'Verificarea tipului/valorii originale a esuat.'}
  $ok++
 }catch{$errors+=@{id=$r.id;path=$r.path;value=$r.name;error=$_.Exception.Message}}}
 if($errors.Count -eq 0){Move-Item -LiteralPath $backup -Destination (Join-Path $dir ('ultra-restored-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.json')) -Force}
 @{success=($errors.Count -eq 0);restored=$ok;errors=@($errors);message=$(if($errors.Count){'Restaurare incompleta. Backup original pastrat.'}else{'Registry restaurat si verificat; unele efecte necesita relogare.'})}|ConvertTo-Json -Compress -Depth 6
 exit
}
$selected=@($Ids.Split(',')|Where-Object {$_})
if($selected.Count -eq 0 -or $selected.Count -gt $rules.Count){throw ('Selectie invalida: '+$selected.Count+' cerute, catalog '+$rules.Count+'. Opreste aplicarea si verifica versiunea motorului.')}
if(@($selected | Select-Object -Unique).Count -ne $selected.Count){throw 'Selectie duplicata'}
foreach($id in $selected){
 if(-not $rules.ContainsKey($id)){throw 'Tweak nepermis: '+$id}
 if($rules[$id].restoreOnly -eq $true){throw 'Modificare aspect Windows eliminata; disponibila numai pentru restaurare: '+$id}
}
if(Test-Path -LiteralPath $backup){throw 'Exista un backup nerestaurat. Restaureaza profilul vechi inainte de o noua aplicare.'}
$original=@()
foreach($id in $selected){
 foreach($entry in $rules[$id].entries){
  $target=@{path=([string]$entry.path).Replace('HKCU:\','HKCU\');name=$entry.name}
  $old=Read-Value $target
  $original+=@{id=$id;path=$entry.path;name=$entry.name;existed=$old.exists;value=$old.value;type=$old.kind}
 }
}
$state=@{version=2;date=(Get-Date).ToString('o');ids=@($selected);values=@($original)}
$temp=Join-Path $dir ('ultra-'+[guid]::NewGuid().ToString('N')+'.tmp')
$state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $temp -Encoding UTF8 -ErrorAction Stop
Move-Item -LiteralPath $temp -Destination $backup -ErrorAction Stop
$applied=@();$errors=@()
foreach($id in $selected){
 $rule=$rules[$id];$fine=$true
 foreach($entry in $rule.entries){try{
  $desired=@{path=([string]$entry.path).Replace('HKCU:\','HKCU\');name=$entry.name;exists=$true;kind=$entry.type;value=$entry.value}
  Set-Value $desired
  if(-not (Same-Value (Read-Value $desired) $desired)){throw 'Windows nu confirma valoarea aplicata.'}
 }catch{$fine=$false;$errors+=@{id=$id;value=$entry.name;error=$_.Exception.Message}}}
 if($fine){$applied+=$id}
}
@{success=($errors.Count -eq 0);applied=@($applied);errors=@($errors);backup=$backup;requested=$selected.Count;message='Backup salvat. Reporniți Explorer sau Windows unde este necesar.'}|ConvertTo-Json -Compress -Depth 8
