# CARPATIA 7.4.4 — cumpărare și licență permanentă

Stare: implementare locală testată; magazinul, serverul, emailul și installerul NU sunt conectate/publicate. Niciun mesaj real nu a fost trimis și nicio cheie de producție nu a fost creată aici.

## Cum funcționează

Shopify confirmă comanda plătită → serverul verifică semnătura webhookului și varianta exactă de produs → creează o cheie Ed25519 per unitate cumpărată → salvează cheia și emailul în aceeași tranzacție SQLite → trimite email prin Resend → clientul lipește codul în aplicație. Verificarea ulterioară funcționează offline, fără expirare sau abonament.

Prețul nu este codificat în licență: aceeași variantă de produs poate costa 15 lei în campanie și 99 lei în afara campaniei. Plata și reducerile sunt gestionate de Shopify. Se procesează numai `orders/paid`, `financial_status=paid`, produsul configurat. Nu configura abonament recurent.

## Varianta simplă, fără server

Folosește `LICENTA_MANAGER.bat`, creează/păstrează cheile într-un folder privat extern și apasă PREGĂTEȘTE BUILDUL. După verificarea manuală a plății, emite o licență PERMANENTĂ și livrează codul clientului. Această variantă nu livrează automat emailuri. Nu genera un nou set de chei dacă ai deja clienți: reutilizează perechea existentă.

## Automatizare

1. Pe PC-ul editorului configurează perechea Ed25519 prin manager. Păstrează backup securizat al cheii private. Numai `license-public.pem` intră în installer. Compilarea rămâne blocată cât timp aceasta lipsește.
2. Pe Windows, cu Node.js 24+, rulează `BUILD_INSTALLER.bat`, apoi testează installerul. Publică DOAR installerul, niciodată acest ZIP cu uneltele vânzătorului. Configurează un URL HTTPS real pentru descărcarea lui.
3. Creează produs digital Shopify, fără transport, cu email obligatoriu la checkout. Identifică ID-ul numeric al VARIANTEI, nu al produsului. Setează prețul campaniei în Shopify. Nu a fost modificat niciun preț live.
4. Pe un server Node.js 24+ cu disc persistent, copiază sursele. Pune cheia privată și baza de date în directoare private, externe proiectului; restricționează accesul la contul serviciului. Nu găzdui întregul folder ca fișiere publice.
5. Creează/configurează expeditorul verificat la Resend și cheia API. Completează variabilele din `seller/env.example` într-un fișier privat extern, de exemplu `/srv/carpatia-private/seller.env`. Nu trimite secrete în chat. `LICENSE_PUBLIC_KEY_FILE` trebuie să indice cheia publică exactă a installerului.
6. Pornește o SINGURĂ instanță: `node --env-file=/srv/carpatia-private/seller.env seller/server.js`. Serviciul ascultă pe 127.0.0.1:8787. Folosește un reverse proxy HTTPS cu limită de corp de 1 MiB și limitare de trafic. Configurează serviciul pentru restart automat.
7. În Shopify configurează webhook JSON pentru comenzi plătite (`orders/paid`) către `https://domeniul-serverului/webhooks/shopify/orders-paid`. Folosește secretul aferent metodei concrete de înregistrare a webhookului; nu confunda secretul de semnare cu tokenul Admin API. Verifică semnătura cu o livrare de test. Handlerul implementează webhookul clasic, nu noul format Shopify Events.
8. În mediu separat de test, folosește chei/date de test și `SHOPIFY_ALLOW_TEST=1`. Validează checkout, produs greșit, comandă neplătită, două bucăți, retrimitere webhook, email indisponibil, restart și activare în installer. Apoi setează `SHOPIFY_ALLOW_TEST=0` în producție.

## Operare

Baza `licenses.sqlite` conține coduri și emailuri ale clienților; nu o publica. Backupul trebuie să fie consistent SQLite, inclusiv WAL (folosește SQLite backup sau oprește serviciul înainte de copiere). Monitorizează comenzile Shopify și compară cu licențele: webhooks pot lipsi, deci reconcilierea rămâne manuală în această versiune.

Outbox are stările pending/sent/review. Reîncercările folosesc același ID și același cod. După 23h de la prima încercare, livrarea ambiguă se oprește în review; verifică istoricul Resend și livrează manual aceeași cheie dacă nu a ajuns. Nu emite alta. Statusul sent înseamnă acceptat de furnizor, nu confirmat în inbox; verifică bounce/spam în Resend. Nu modifica EMAIL_FROM sau DOWNLOAD_URL când există livrări în așteptare: se schimbă conținutul asociat cheii de idempotență.

Nu există revocare offline la refund, blocare la un PC, recuperare automată după pierderea bazei sau sincronizare automată cu comenzile ratate. Nu promite aceste funcții clienților. Licența este permanentă pentru produsul CARPATIA V7 PRO; suportul și drepturile asupra viitoarelor versiuni majore trebuie definite separat.

## Preț verificat la 24 octombrie 2026

Shopify România: 5 lei/lună primele 3 luni după 3 zile gratuite; Basic 139 lei/lună la plata lunară sau 99 lei/lună la plata anuală. Tarif standard de card afișat: 1,9% + 1,25 lei. La o vânzare de 15 lei rezultă aproximativ 13,47 lei după acest comision, înainte de taxe, abonament, email, hosting, reclame și refunduri. Nu este profit net. La acest tarif ar fi nevoie de aproximativ 11 vânzări/lună doar pentru 139 lei de abonament. Taxele și comisioanele efective depind de cont/card/plan.

99 → 15 lei înseamnă aproximativ 84,85% reducere. Nu afișa un preț de referință inventat; dacă 99 lei nu a fost un preț real, preferă „Preț de lansare: 15 lei”, până clarifici istoricul și regulile aplicabile campaniei.

Surse oficiale:
- https://www.shopify.com/ro/pricing
- https://shopify.dev/docs/apps/build/webhooks/verify-deliveries
- https://shopify.dev/docs/api/webhooks/latest
- https://resend.com/docs/api-reference/emails/send-email
- https://resend.com/docs/dashboard/emails/idempotency-keys
