﻿param([ValidateSet('Apply','Restore','Status','Context','Acknowledge','Check')][string]$Action='Status',[string]$Id='',[string]$AdapterGuid='',[Parameter(Mandatory=$true)][string]$DataDir)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
. (Join-Path $PSScriptRoot 'tweak-native-ops.ps1')
. (Join-Path $PSScriptRoot 'resource-conflicts.ps1')
$catalog=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tweak-library.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root=Join-Path $DataDir 'tweak-native-backups';New-Item -ItemType Directory -Path $root -Force | Out-Null
function Save-NativeJournal($file,$record){
 $tmp=$file+'.new';$record | ConvertTo-Json -Depth 24 | Set-Content -LiteralPath $tmp -Encoding UTF8
 if(Test-Path -LiteralPath $file){[IO.File]::Replace($tmp,$file,$file+'.previous')}else{[IO.File]::Move($tmp,$file)}
}
function Read-NativeJournal($file){
 $r=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
 if($r.version -ne 1 -or $r.reversible -isnot [bool] -or [string]$r.id -notmatch '^library-[a-z0-9-]+$' -or $r.state -notin @('prepared','applied','failed','restored','completed','maintenance-failed','acknowledged')){throw 'Jurnal nativ invalid; nu se suprascrie.'}
 if($r.state -in @('prepared','applied','failed') -and ($null -eq $r.operation -or $r.targets -isnot [array] -or @($r.targets).Count -eq 0 -or $r.PSObject.Properties.Name -notcontains 'before')){throw 'Jurnal nativ incomplet; domeniul modificarilor nu poate fi confirmat.'}
 return $r
}
if($Action -eq 'Context'){
 $adapters=@(Get-NetAdapter -ErrorAction Stop | ForEach-Object {@{guid=[string]$_.InterfaceGuid;name=$_.Name;status=[string]$_.Status}})
 @{success=$true;adapters=$adapters} | ConvertTo-Json -Depth 6 -Compress;exit
}
if($Action -eq 'Status'){
 $states=@();$errors=@();foreach($f in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)){
  try{$j=Read-NativeJournal $f.FullName;$states+=@{id=$j.id;state=$j.state;date=$j.date;reversible=[bool]$j.reversible}}
  catch{$errors+=$f.Name+': '+$_.Exception.Message}
 };@{success=($errors.Count -eq 0);states=@($states);errors=@($errors)} | ConvertTo-Json -Depth 8 -Compress;exit
}
if($Id -notmatch '^library-[a-z0-9-]+$'){throw 'ID invalid.'}
$rules=@($catalog | Where-Object {$_.id -ceq $Id});if($rules.Count -ne 1){throw 'Setare necunoscută.'};$rule=$rules[0]
if($rule.status -notin @('native','maintenance')){throw 'Această setare nu utilizează motorul nativ.'}
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Pornește CARPATIA ca administrator.'}
if([Environment]::OSVersion.Version.Build -lt 10240){throw 'Windows 10/11 este necesar.'}
if($Action -eq 'Check'){
 $o=Resolve-Native $rule.operation $AdapterGuid
 $eligibility=Get-NativeApplicability $o
 if(-not $eligibility.applicable){@{success=$false;notApplicable=$true;message=$eligibility.message} | ConvertTo-Json -Compress;exit}
 if($rule.status -ne 'native'){throw 'Operațiile ireversibile nu sunt admise în profil.'}
 $before=Capture-Native $o;Desired-Native $o $before | Out-Null
 if($o.type -eq 'power-active'){
  $plans=Invoke-Tool powercfg @('/list')
  if($plans -notmatch [regex]::Escape([string]$o.value)){throw 'Planul High Performance nu este disponibil pe acest PC.'}
 }
 @{success=$true;matching=((Canonical-Native $before) -ceq (Canonical-Native (Desired-Native $o $before)));current=$before;operation=$o;message='Citire reală, fără modificări.'} | ConvertTo-Json -Depth 24 -Compress;exit
}
$file=Join-Path $root ($Id+'.json')
if($Action -eq 'Acknowledge'){
 if($rule.status -ne 'maintenance' -or -not (Test-Path -LiteralPath $file)){throw 'Nu există o întreținere întreruptă.'}
 $j=Read-NativeJournal $file
 if($j.id -cne $Id -or $j.reversible -or $j.state -ne 'prepared'){throw 'Jurnalul nu necesită confirmarea unui rezultat necunoscut.'}
 $j.state='acknowledged';Save-NativeJournal $file $j
 @{success=$true;message='Ai confirmat verificarea manuală. Rezultatul operației precedente rămâne necunoscut; nicio restaurare nu a fost executată.'} | ConvertTo-Json -Compress;exit
}
if($Action -eq 'Restore'){
 if(-not (Test-Path -LiteralPath $file)){throw 'Backupul original lipsește.'};$journal=Read-NativeJournal $file
 if($journal.id -cne $Id -or -not $journal.reversible -or $journal.state -in @('restored','completed','maintenance-failed','acknowledged')){throw 'Acest jurnal nu poate fi restaurat.'}
 $o=Resolve-Native $rule.operation '' $journal.operation
 # Resolve from the trusted specification, accepting only validated dynamic identifiers from the backup.
 if($o.type -cne $journal.operation.type){throw 'Tipul operației nu corespunde backupului.'}
 try{
  Assert-NativeValue $o $journal.before
  Assert-NativeValue $o $journal.desired
  $current=Capture-Native $o
  if(-not (Test-NativeRestoreState $o $current $journal.before $journal.desired)){throw 'Modificare externă nativă: este necesară verificarea manuală. Backupul rămâne păstrat.'}
  Write-Native $o $journal.before
  $after=Capture-Native $o
  if((Canonical-Native $after) -cne (Canonical-Native $journal.before)){throw 'Restaurarea nu a fost confirmată prin recitire.'}
  $journal.state='restored';Save-NativeJournal $file $journal
  @{success=$true;verified=$true;message='Starea originală a fost restaurată și recitită.'} | ConvertTo-Json -Compress
 }catch{@{success=$false;backupAvailable=$true;message=$_.Exception.Message} | ConvertTo-Json -Compress};exit
}
$o=Resolve-Native $rule.operation $AdapterGuid
 $eligibility=Get-NativeApplicability $o
 if(-not $eligibility.applicable){@{success=$false;notApplicable=$true;message=$eligibility.message} | ConvertTo-Json -Compress;exit}
$targets=@(Native-Targets $o)
foreach($f in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)){
 $other=Read-NativeJournal $f.FullName
 if($other.state -in @('restored','completed','maintenance-failed','acknowledged')){continue}
 if(($o.type -like 'power-*' -and 'power' -in $other.targets) -or ($o.name -eq 'reset-network' -and @($other.targets | Where-Object {$_ -match '^(network|tcp|tunnel)\|'}).Count) -or $other.id -ceq $Id -or (Test-NativeTargetOverlap $other.targets $targets)){throw ('Există un backup activ care se suprapune: '+$other.id)}
}
$registryRoot=Join-Path $DataDir 'tweak-library-backups'
if(Test-Path -LiteralPath $registryRoot){foreach($f in @(Get-ChildItem -LiteralPath $registryRoot -Filter '*.json' -File)){
 $r=Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
 if($r.version -ne 1){throw 'Jurnal Registry invalid.'};if($r.state -eq 'restored'){continue}
 $oldRule=@($catalog | Where-Object {$_.id -ceq $r.id})
 if($oldRule.Count -ne 1){throw 'Backup Registry cu setare necunoscută.'}
 if(Test-NetworkRegistryConflict $oldRule[0] $o){throw 'Restaurează mai întâi tweak-urile Registry de rețea.'}
 foreach($v in $r.values){
  if($o.type -eq 'service'){foreach($svc in $o.services){if($v.path -ieq ('HKLM\SYSTEM\CurrentControlSet\Services\'+$svc.name)){throw 'Conflict cu backupul Registry al serviciului.'}}}
  if($o.type -eq 'hibernation' -and $v.path -ieq 'HKLM\SYSTEM\CurrentControlSet\Control\Power'){throw 'Conflict cu backupul Registry de alimentare.'}
 }
}}
if($rule.status -eq 'maintenance'){
 $journal=@{version=1;id=$Id;state='prepared';date=(Get-Date).ToString('o');reversible=$false;operation=$o;targets=$targets;before=$null;result=$null}
 Save-NativeJournal $file $journal
 $reportDir=Join-Path $root ($Id+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'));New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
 try{
  $r=Run-Maintenance $o $reportDir;$journal.state=if($r.success){'completed'}else{'maintenance-failed'};$journal.result=$r;Save-NativeJournal $file $journal
  $r | ConvertTo-Json -Depth 12 -Compress
 }catch{$journal.state='maintenance-failed';$journal.result=@{success=$false;message=$_.Exception.Message};Save-NativeJournal $file $journal;$journal.result | ConvertTo-Json -Compress};exit
}
$before=Capture-Native $o
$desired=Desired-Native $o $before
if((Canonical-Native $before) -ceq (Canonical-Native $desired)){
 @{success=$true;already=$true;verified=$true;message='Starea cerută există deja. Nu s-a creat un backup și nu s-a rescris setarea.'} | ConvertTo-Json -Compress;exit
}
if(Test-Path -LiteralPath $file){
 $history=Join-Path $DataDir 'backup-history';New-Item -ItemType Directory -Path $history -Force | Out-Null
 Copy-Item -LiteralPath $file -Destination (Join-Path $history ($Id+'-'+[guid]::NewGuid().ToString()+'.json')) -ErrorAction Stop
}
$journal=@{version=1;id=$Id;state='prepared';date=(Get-Date).ToString('o');reversible=$true;operation=$o;targets=$targets;before=$before;desired=$desired}
Save-NativeJournal $file $journal
try{
 Write-Native $o $desired
 $after=Capture-Native $o
 if((Canonical-Native $after) -cne (Canonical-Native $desired)){throw 'Windows nu confirmă starea cerută. Backupul original rămâne disponibil.'}
 $journal.state='applied';Save-NativeJournal $file $journal
 @{success=$true;verified=$true;message='Starea a fost aplicată și recitită. Aceasta nu confirmă un câștig de performanță.'} | ConvertTo-Json -Compress
}catch{
 $journal.state='failed';Save-NativeJournal $file $journal
 @{success=$false;backupAvailable=$true;message=$_.Exception.Message} | ConvertTo-Json -Compress
}
