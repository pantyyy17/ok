'use strict';
window.CarpatiaDashboardProfiles={mount({api,task,requireNative,confirmDialog,showToast,onOwner}){
 const $=id=>document.getElementById(id);let adaptersLoaded=false,lastConflict='',loadId=0;
 const groups={cpu:['CPU','heroDebloat'],gpu:['GPU','heroUltra'],internet:['INTERNET','heroNetwork']};
 const node=(tag,text)=>{const n=document.createElement(tag);n.textContent=text;return n};
 function message(value){$('heroOpStatus').textContent=value}
 async function load({refreshAdapters=false,skipAdapters=false}={}){
  if(!api)return;const request=++loadId;
  const status=await api.dashboardStatus();if(request!==loadId)return;
  const recovery=$('dashboardRecovery');recovery.replaceChildren();
  for(const [group,[label,buttonId]] of Object.entries(groups)){
   const state=status.find(x=>x.group===group);if(!state)throw Error('Stare Dashboard incompletă.');
   $(buttonId).disabled=state.active;
   $(buttonId).classList?.remove('is-error','is-complete');
   const hint=$(buttonId).querySelector?.('.reactor-state');if(hint)hint.textContent=state.observed==='active'?'ACTIV':state.observed==='partial'?'PARȚIAL':state.observed==='unknown'?'NEVERIFICAT':'';
   $('restoreProfile-'+group).disabled=!state.active;
   $('profileState-'+group).textContent=state.active?`${state.level.toUpperCase()} · ${state.state!=='applied'?'NECESITĂ RECUPERARE':({active:'ACTIV · VERIFICAT',partial:'PARȚIAL ACTIV',inactive:'INACTIV · BACKUP PĂSTRAT',unknown:'STARE NECUNOSCUTĂ'})[state.observed]||'NEVERIFICAT'}`:'Niciun profil activ';
   if(state.active){const b=node('button','RESTAUREAZĂ '+label+' · '+state.level.toUpperCase());b.className='action outline';b.onclick=()=>restore(group);recovery.append(b)}
  }
  if(lastConflict&&onOwner){const b=node('button','DESCHIDE BACKUP & RESTORE');b.className='action outline';b.onclick=()=>onOwner({id:lastConflict,route:'tweaks'});recovery.append(b)}
  if(!recovery.children.length)recovery.append(node('p','Nu există profiluri Dashboard active.'));
  if(skipAdapters||(adaptersLoaded&&!refreshAdapters))return;
  const select=$('dashboardAdapter'),old=select.value;
  try{
   const context=await api.tweakLibraryContext();if(request!==loadId)return;select.replaceChildren();const placeholder=node('option','Alege adaptorul…');placeholder.value='';select.append(placeholder);
   for(const adapter of context.adapters||[]){const option=node('option',adapter.name+' · '+adapter.status);option.value=adapter.guid;select.append(option)}
   select.value=old;adaptersLoaded=true;
  }catch(e){if(request!==loadId)return;showToast('Adaptoarele nu au fost încărcate: '+String(e.message||e))}
 }
 async function run(group){
  if(!requireNative())return;
  const level=$('profileLevel-'+group).value,adapterGuid=group==='internet'?$('dashboardAdapter').value:'';
  if(group==='internet'&&!adapterGuid){showToast('Alege adaptorul Internet înainte de analiză.');return}
  return task('Profil '+groups[group][0],async()=>{
   try{
    lastConflict='';
    message('Verific hardware-ul, stările originale și backupurile…');
    const prepared=await api.dashboardPrepare({group,level,adapterGuid});const plan=prepared.plan;
    const details=plan.steps.map((step,i)=>`${i+1}. ${step.title}${plan.reuse?.includes(step.id)?' · deja aplicat; se păstrează originalul existent':''}${step.restart?' · restart':''}`).join('\n')+(adapterGuid?'\nAdaptor: '+($('dashboardAdapter').selectedOptions?.[0]?.textContent||adapterGuid):'');
    if(!await confirmDialog('Aplici '+plan.title+'?','Se execută numai pașii de mai jos. Fiecare modificare păstrează originalul pentru restaurare.',details,plan.warning+' Profil experimental, fără benchmark de confirmare.','APLICĂ PROFILUL')){message('Anulat. Nicio modificare aplicată.');return}
    const result=await api.dashboardCommit(prepared.token);
    message(result.message+(result.restartRequired?' Repornește Windows pentru efectele care cer restart.':''));showToast(result.message);return result;
   }catch(e){const detail=String(e.message||e);if(detail.includes('Conflict real:'))lastConflict=detail.match(/library-[a-z0-9-]+/)?.[0]||'recovery';message(detail);throw e}finally{await load({skipAdapters:true}).catch(e=>showToast('Reîncarcă starea profilurilor: '+String(e.message||e)))}
  },groups[group][1]);
 }
 async function restore(group){
  if(!requireNative(true))return;
  if(onOwner){onOwner({group,route:'restore'});return}
  return task('Restaurare '+groups[group][0],async()=>{
   if(!await confirmDialog('Restaurezi '+groups[group][0]+'?','Se revin în ordine inversă setările profilului la valorile salvate înainte de aplicare.','','Modificările ulterioare ale altor programe pot fi suprascrise. Rețeaua se poate întrerupe; unele setări necesită restart.','RESTAUREAZĂ'))return;
   try{const result=await api.dashboardRestore(group);message(result.message);showToast(result.message);return result}
   finally{await load({skipAdapters:true}).catch(e=>showToast(String(e.message||e)))}
  },groups[group][1]);
 }
 for(const group of Object.keys(groups))$('restoreProfile-'+group).onclick=()=>restore(group);
 $('refreshProfiles').onclick=()=>task('Stare profiluri',()=>load({refreshAdapters:true}));
 api?.onDashboardProgress?.(event=>message(event.detail));
 return {run,load,restore};
}};
