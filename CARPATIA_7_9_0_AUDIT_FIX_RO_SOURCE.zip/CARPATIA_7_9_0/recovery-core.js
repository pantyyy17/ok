'use strict';
const crypto=require('node:crypto');
const active=new Set(['prepared','applied','failed']);
function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
 return value;
}
function fingerprint(value){return crypto.createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex')}
function createRecoveryService({inventory,inspect,restore,persist,now=Date.now,uuid=crypto.randomUUID}){
 const pending=new Map();
 function expirePlans(){for(const [token,entry] of pending)if(now()>entry.plan.expires)pending.delete(token)}
 async function prepare(selection){
  expirePlans();
  const all=await inventory();
  if(all.errors.length)throw Error('Backupuri incomplete: '+all.errors.join('; '));
  if(!selection||typeof selection!=='object'||Array.isArray(selection))throw Error('Selecție invalidă.');
  const keys=Object.keys(selection);
  if(keys.length>1||keys.some(key=>!['id','group','category'].includes(key)||typeof selection[key]!=='string'||!selection[key]))throw Error('Selecție invalidă.');
  const selected=all.items.filter(x=>active.has(x.state)&&x.reversible!==false&&(selection.id?x.id===selection.id:selection.group?x.group===selection.group:selection.category?x.category===selection.category:true));
  if(!selected.length)throw Error('Nu există backupuri active în selecție.');
  const rows=[];
  for(const item of selected){
   const live=await inspect(item);
   rows.push({...item,live});
  }
  const token=uuid(),plan={token,date:new Date(now()).toISOString(),rows,expires:now()+180000};
  if(pending.size>=32)pending.delete(pending.keys().next().value);
  pending.set(token,{plan,digest:fingerprint(all)});
  return plan;
 }
 async function commit(token){
  const entry=pending.get(token);pending.delete(token);
  if(!entry||now()>entry.plan.expires)throw Error('Previzualizarea a expirat. Verifică din nou.');
  if(fingerprint(await inventory())!==entry.digest)throw Error('Backupurile s-au schimbat după previzualizare. Verifică din nou.');
  const report={id:uuid(),date:new Date(now()).toISOString(),type:'restore',state:'running',results:[]};
  persist(report);
  for(const row of [...entry.plan.rows].reverse().sort((a,b)=>Number(!!a.legacy)-Number(!!b.legacy))){
   let result;
   try{
    if(row.live.success!==true)throw Error(row.live.message||'Citirea Windows a eșuat.');
    const current=await inspect(row);
    if(current.success!==true)throw Error(current.message||'Recitirea Windows a eșuat.');
    if(fingerprint(current)!==fingerprint(row.live))throw Error('Starea Windows s-a schimbat după previzualizare. Reia verificarea înainte de restaurare.');
    const r=await restore(row);
    if(r.success!==true)throw Error(r.message||r.errors?.join('; ')||'Windows nu confirmă restaurarea.');
    result={id:row.id,title:row.title,category:row.category,status:'restored',restartRequired:!!row.restart,message:r.message};
   }catch(e){result={id:row.id,title:row.title,category:row.category,status:'failed',message:e.message}}
   report.results.push(result);persist(report);
  }
  report.success=report.results.every(x=>x.status==='restored');report.state=report.success?'complete':'partial';
  report.succeeded=report.results.filter(x=>x.status==='restored').length;report.failed=report.results.length-report.succeeded;report.skipped=0;
  report.restartRequired=report.results.some(x=>x.status==='restored'&&x.restartRequired);persist(report);return report;
 }
 return {prepare,commit};
}
module.exports={createRecoveryService,fingerprint};
