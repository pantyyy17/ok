# Testare 7.4.5 pe Windows

1. Extrage arhiva complet într-un folder. Instalează Node.js 24+ dacă nu există.
2. Rulează `TEST_CARPATIA_WINDOWS.bat`. Acesta rulează teste JS și citiri Windows, fără aplicare de tweak-uri.
3. Rulează `TEST_UI_CARPATIA.bat`. Prima pornire instalează dependințele npm (necesită internet). Pornește în MOD DEZVOLTARE explicit; nu necesită o cheie comercială și nu aplică optimizări la pornire. Nu distribui acest mod clienților.
4. Verifică cele trei cercuri, hover/apăsare, navigarea, redimensionarea, preferința Windows pentru reducerea animațiilor și minimizarea. Încearcă anularea unei confirmări: nicio modificare nu trebuie aplicată.
5. Începe cu diagnostic și profil Balanced. Citește lista și acceptă doar modificările pe care le dorești. Apoi verifică Backup & Restore. Pentru funcțiile de rețea/servicii care cer administrator, închide aplicația și rulează launcherul de test ca administrator, păstrând același cont Windows.
6. Testul licenței reale se face separat, fără CARPATIA_DEV_MODE, după configurarea perechii Ed25519 prin manager. Licența permanentă nu are termen de expirare. Cheia privată rămâne numai la editor.

Arhiva nu conține un .exe compilat. Nu a fost executată aici pe Windows, iar câștigul de performanță nu a fost măsurat. Păstrează backupurile și notează versiunea Windows, configurația, acțiunea și mesajul exact când raportezi o problemă. Nu folosi prima verificare pe un PC critic pentru lucru.
