@echo off
setlocal
cd /d "%~dp0"
title CARPATIA V7 PRO REDLINE - Installer
where node.exe >nul 2>&1
if errorlevel 1 (echo [EROARE] Instaleaza Node.js 24 sau mai nou. & pause & exit /b 1)
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 (echo [EROARE] Este necesar Node.js 24 sau mai nou. & pause & exit /b 1)
node tools\check-release.js
if errorlevel 1 (echo [EROARE] Lipseste cheia publica originala a editorului. & pause & exit /b 1)
echo [1/3] Instalez dependentele...
call npm ci --no-audit --no-fund
if errorlevel 1 (echo [EROARE] npm ci a esuat. & pause & exit /b 1)
echo [2/3] Rulez testele...
call npm test
if errorlevel 1 (echo [EROARE] Testele au esuat. Nu creez installerul. & pause & exit /b 1)
echo [3/3] Verific cheia de licentiere si construiesc installerul Windows x64...
node tools\check-release.js
if errorlevel 1 (echo [EROARE] Licentierea comerciala nu este configurata. & pause & exit /b 1)
call npx electron-builder --win nsis --x64
if errorlevel 1 (echo [EROARE] Build-ul a esuat. Vezi mesajele de mai sus. & pause & exit /b 1)
echo [OK] Installer generat in folderul dist.
pause
endlocal
