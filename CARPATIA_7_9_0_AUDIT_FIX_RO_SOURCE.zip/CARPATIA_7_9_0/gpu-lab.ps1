﻿# CARPATIA V7 PRO Redline - per-application GPU performance preference.
# Does NOT overclock / undervolt hardware or set fan speeds.
[CmdletBinding()]
param(
  [ValidateSet('Inventory','Status','Apply','Restore')][string]$Action = 'Inventory',
  [string]$ExePath = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$registryKey = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
$backupRoot = Join-Path $env:LOCALAPPDATA 'TweakRomania\Carpatia\GpuPreferenceBackups'
function Emit($obj) { $obj | ConvertTo-Json -Compress -Depth 7 }
function Get-Preference([string]$target) {
  if (-not (Test-Path -LiteralPath $registryKey)) { return @{ present=$false; raw='' } }
  $props = Get-ItemProperty -LiteralPath $registryKey -ErrorAction Stop
  $item = $props.PSObject.Properties[$target]
  if ($null -eq $item) { return @{ present=$false; raw='' } }
  return @{present=$true;raw=[string]$item.Value}
}
function Get-BackupPath([string]$target) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes=[System.Text.Encoding]::UTF8.GetBytes($target.ToLowerInvariant())
    $hash=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()
  } finally { $sha.Dispose() }
  return Join-Path $backupRoot ($hash + '.json')
}
function Read-Backup([string]$target) {
  $file=Get-BackupPath $target
  if (-not (Test-Path -LiteralPath $file)) { return $null }
  $record=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($record.exe -ine $target -or $record.version -ne 1 -or $record.present -isnot [bool] -or $record.raw -isnot [string]) { throw 'Backupul GPU nu corespunde executabilului selectat.' }
  return $record
}
function Desired-Preference([string]$raw) {
  $tokens=@($raw.Split(';') | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch '^GpuPreference\s*=' })
  return (($tokens+@('GpuPreference=2')) -join ';')+';'
}
function Is-HighPerformance([string]$s) {
  return [bool]($s -match '(?:^|;)\s*GpuPreference\s*=\s*2\s*(?:;|$)')
}
if($Action -eq 'Inventory') {
  $gpus=@()
  try {
    $gpus=@(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Where-Object Name | ForEach-Object {
      @{ name=[string]$_.Name; driver=[string]$_.DriverVersion; videoProcessor=[string]$_.VideoProcessor; status=[string]$_.Status }
    })
  } catch { $gpuError=$_.Exception.Message }
  $hags=$null
  try {
    $hags=[int](Get-ItemPropertyValue -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction Stop)
  } catch { }
  $hagsText=if($null -eq $hags){'Controlat de Windows / driver'}elseif($hags -eq 2){'Preferință ON (poate necesita restart)'}elseif($hags -eq 1){'Preferință OFF (poate necesita restart)'}else{'Valoare '+$hags+' (driver dependent)'}
  Emit @{success=$true;gpus=@($gpus);hags=$hagsText;warning=if($gpuError){$gpuError}else{''};modified=$false}
  exit 0
}
if ([string]::IsNullOrWhiteSpace($ExePath)) { throw 'Selectează o aplicație .exe.' }
$target=[IO.Path]::GetFullPath($ExePath)
if(-not [IO.Path]::IsPathRooted($target) -or [IO.Path]::GetExtension($target) -ine '.exe') { throw 'Calea aplicației trebuie să fie un executabil Windows valid.' }
if($Action -eq 'Apply' -and -not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Executabilul ales nu mai există.' }
$prior=Get-Preference $target
$backup=Read-Backup $target
if($Action -eq 'Status') {
  Emit @{success=$true;selected=$true;exe=$target;current=if($prior.present){$prior.raw}else{''};highPerformance=(Is-HighPerformance $prior.raw);backup=($null -ne $backup);modified=$false}
  exit 0
}
if($Action -eq 'Apply') {
  if($null -ne $backup) { throw 'Există deja backup GPU pentru acest executabil. Folosește Restaurare înainte de o aplicare nouă.' }
  if(Is-HighPerformance $prior.raw) {
    Emit @{success=$true;modified=$false;alreadyEnabled=$true;message='High Performance era deja configurat. Nu a fost creat backup și nu am modificat valoarea.'}
    exit 0
  }
  if(-not (Test-Path -LiteralPath $backupRoot)) { New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null }
  $file=Get-BackupPath $target
  $record=@{version=1;exe=$target;present=[bool]$prior.present;raw=[string]$prior.raw;date=(Get-Date).ToString('o')}
  $tmp=$file+'.tmp'
  [IO.File]::WriteAllText($tmp,($record|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
  Move-Item -LiteralPath $tmp -Destination $file -ErrorAction Stop
  # Preserve other graphics tokens, e.g. Windows HDR preferences.
  $newRaw=Desired-Preference $prior.raw
  try {
    if(-not (Test-Path -LiteralPath $registryKey)) { New-Item -Path $registryKey -Force | Out-Null }
    New-ItemProperty -Path $registryKey -Name $target -PropertyType String -Value $newRaw -Force -ErrorAction Stop | Out-Null
    $actual=Get-Preference $target
    if(-not (Is-HighPerformance $actual.raw)) { throw 'Windows nu a păstrat opțiunea GPU High Performance.' }
  } catch { throw ('Aplicare GPU neconfirmată; backupul a fost păstrat pentru restaurare. '+$_.Exception.Message) }
  Emit @{success=$true;modified=$true;backup=$true;message='Preferința High Performance a fost setată și verificată. Repornește aplicația țintă.'}
  exit 0
}
if($Action -eq 'Restore') {
  if($null -eq $backup) { throw 'Niciun backup GPU pentru executabilul selectat. Nu am modificat registrul.' }
  $isOriginal=($prior.present -eq $backup.present -and (-not $backup.present -or $prior.raw -ceq $backup.raw))
  $isApplied=($prior.present -and $prior.raw -ceq (Desired-Preference $backup.raw))
  if(-not $isOriginal -and -not $isApplied){throw 'Preferința GPU a fost schimbată din exterior. Restaurarea a fost oprită; backupul rămâne păstrat.'}
  if([bool]$backup.present) {
    if(-not (Test-Path -LiteralPath $registryKey)) { New-Item -Path $registryKey -Force | Out-Null }
    New-ItemProperty -Path $registryKey -Name $target -PropertyType String -Value ([string]$backup.raw) -Force -ErrorAction Stop | Out-Null
  } else {
    if(Test-Path -LiteralPath $registryKey) { Remove-ItemProperty -LiteralPath $registryKey -Name $target -ErrorAction SilentlyContinue }
  }
  $actual=Get-Preference $target
  if(($actual.present -ne [bool]$backup.present) -or ([bool]$backup.present -and $actual.raw -cne [string]$backup.raw)) {
    throw 'Restaurarea nu a fost confirmată. Backupul rămâne disponibil.'
  }
  Remove-Item -LiteralPath (Get-BackupPath $target) -Force -ErrorAction Stop
  Emit @{success=$true;restored=$true;modified=$true;message='Preferința GPU originală a fost restaurată și verificată.'}
}
