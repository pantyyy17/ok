'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const catalog=require('./tweak-library-core');
const stable=x=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
const equal=(a,b)=>JSON.stringify(stable(a))===JSON.stringify(stable(b));
const hash=x=>crypto.createHash('sha256').update(typeof x==='string'?x:JSON.stringify(stable(x))).digest('hex');
const uuid=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
function object(value){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Obiect de backup invalid.');return value}
function registryValue(v,e){
 object(v);
 if(typeof v.path!=='string'||typeof v.name!=='string'||v.path.toLowerCase()!==e.path.toLowerCase()||v.name.toLowerCase()!==e.name.toLowerCase()||typeof v.exists!=='boolean')throw Error('Țintă Registry diferită de catalog.');
 if(v.exists){
  if(!['DWord','QWord','String','ExpandString','MultiString','Binary'].includes(v.kind)||v.value==null)throw Error('Original Registry incomplet.');
  if(['DWord','QWord'].includes(v.kind)&&!Number.isSafeInteger(v.value))throw Error('Valoare numerică Registry invalidă.');
  if(v.kind==='DWord'&&(v.value < -2147483648||v.value>4294967295))throw Error('DWord în afara intervalului de 32 biți.');
  if(['String','ExpandString'].includes(v.kind)&&typeof v.value!=='string')throw Error('Text Registry invalid.');
  if(['Binary','MultiString'].includes(v.kind)&&!Array.isArray(v.value))throw Error('Listă Registry invalidă.');
  if(v.kind==='Binary'&&v.value.some(n=>!Number.isInteger(n)||n<0||n>255))throw Error('Octet Registry invalid.');
  if(v.kind==='MultiString'&&v.value.some(n=>typeof n!=='string'))throw Error('Text multiplu Registry invalid.');
 }
 return v;
}
function validateOperation(op,spec){
 object(op);const normalized={...op};
 for(const key of ['adapterGuid','scheme','drive'])delete normalized[key];
 if(!equal(normalized,spec))throw Error('Operație nativă diferită de catalog.');
 if(['dns','mtu','ipv6'].includes(op.type)&&!uuid.test(String(op.adapterGuid||'').replace(/^\{(.+)\}$/,'$1')))throw Error('Adaptor salvat invalid.');
 if(op.type==='power-value'&&!uuid.test(op.scheme||''))throw Error('Plan de alimentare invalid.');
 if(['quota','bitlocker'].includes(op.type)&&!(/^[a-z]:$/i.test(op.drive||'')))throw Error('Volum salvat invalid.');
}
function snapshotRows(captures){
 const rows=[],seen=new Map();
 function add(row){const previous=seen.get(row.resource);if(previous){if(!equal(previous.target,row.target))throw Error('Copia conține valori contradictorii pentru aceeași setare.');return}seen.set(row.resource,row);rows.push(row)}
 for(const c of captures){
  object(c);const rule=catalog.getRule(c.id);if(c.success!==true||!Object.hasOwn(c,'current'))throw Error('Captură incompletă: '+rule.title);
  const base={id:rule.id,title:rule.title,category:rule.category,restart:!!rule.restart,impact:rule.impact};
  if(rule.status==='registry'){
   if(!Array.isArray(c.current)||c.current.length!==rule.entries.length)throw Error('Lista Registry este incompletă.');
   const own=new Set();for(const v of c.current){const index=rule.entries.findIndex(e=>e.path.toLowerCase()===String(v.path).toLowerCase()&&e.name.toLowerCase()===String(v.name).toLowerCase());if(index<0||own.has(index))throw Error('Țintă necunoscută sau duplicată.');own.add(index);registryValue(v,rule.entries[index]);add({...base,kind:'registry',index,resource:'registry:'+v.path.toLowerCase()+'|'+v.name.toLowerCase(),target:v})}
  }else if(rule.status==='native'){
   const op=object(c.operation),spec=rule.operation;
   validateOperation(op,spec);
   if(['service','bcd'].includes(op.type)){
    const specs=op.type==='service'?op.services:op.values;
    if(!Array.isArray(c.current)||c.current.length!==specs.length)throw Error('Captură nativă incompletă.');
    specs.forEach((entry,index)=>add({...base,kind:'native',operation:op,index,resource:op.type==='service'?'service:'+entry.name.toLowerCase():'bcd:'+entry.object.toLowerCase()+'|'+entry.key.toLowerCase(),target:[c.current[index]]}));
   }else add({...base,kind:'native',operation:op,resource:'native:'+op.type+':'+(op.adapterGuid||op.scheme&&op.scheme+'|'+op.subgroup+'|'+op.setting||op.property||op.name||op.taskPath&&op.taskPath+op.taskName||op.drive||'').toLowerCase(),target:c.current});
  }else throw Error('Operație ireversibilă într-o copie de stare.');
 }
 // Change the active power scheme last; power values are written to their saved scheme.
 const filtered=rows.filter(row=>{
  if(row.kind!=='registry')return true;
  const m=row.target.path.match(/\\services\\([^\\]+)$/i);
  if(m){const native=rows.find(x=>x.resource==='service:'+m[1].toLowerCase());if(native&&['start','delayedautostart'].includes(row.target.name.toLowerCase())){
   const field=row.target.name.toLowerCase()==='start'?'start':'delayed';const value=native.target[0];const exists=field==='start'?true:value.delayedExists;
   if(row.target.exists!==exists||exists&&row.target.value!==value[field])throw Error('Originale contradictorii pentru serviciu.');return false;
  }}
  return true;
 });
 return filtered.sort((a,b)=>Number(a.operation?.type==='power-active')-Number(b.operation?.type==='power-active'));
}
function createSnapshotService({dataDir,probe,write,identity,assertClear,save,now=Date.now,token=crypto.randomUUID}){
 const pending=new Map(),root=()=>path.join(dataDir(),'recovery-snapshots'),txRoot=()=>path.join(dataDir(),'snapshot-transactions');
 const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
 function safeFile(folder,name){if(path.basename(name)!==name||!name.endsWith('.json'))throw Error('Fișier de backup invalid.');const f=path.join(folder,name);if(fs.lstatSync(f).isSymbolicLink()||!fs.realpathSync(f).startsWith(fs.realpathSync(folder)+path.sep))throw Error('Legătură de fișier nepermisă.');return f}
 function loadSnapshot(id){
  if(!uuid.test(id))throw Error('Copie necunoscută.');const dir=path.join(root(),id);if(fs.lstatSync(dir).isSymbolicLink())throw Error('Director de copie invalid.');
  const mf=path.join(dir,'manifest.json'),manifest=fs.existsSync(mf)?read(safeFile(dir,'manifest.json')):null;
  const files=manifest?manifest.files:fs.readdirSync(dir).filter(n=>/^library-[a-z0-9-]+\.json$/i.test(n)).map(name=>({name}));
  if(!Array.isArray(files)||!files.length)throw Error('Copia nu conține setări restaurabile.');
  if(manifest&&(manifest.version!==2||manifest.id!==id||!/^[a-f0-9]{64}$/.test(manifest.identity||'')))throw Error('Manifestul copiei este invalid.');
  const captures=files.map(entry=>{if(manifest&&!/^[a-f0-9]{64}$/.test(entry.sha256||''))throw Error('Amprenta fișierului lipsește din manifest.');const f=safeFile(dir,entry.name),raw=fs.readFileSync(f,'utf8');if(entry.sha256&&hash(raw)!==entry.sha256)throw Error('Copia a fost modificată sau este coruptă.');return JSON.parse(raw.replace(/^\uFEFF/,''))});
  return {manifest,rows:snapshotRows(captures),digest:hash({manifest,captures})};
 }
 function validateTransaction(t,id){
  object(t);
  if(t.id!==id||!uuid.test(t.id)||!uuid.test(t.snapshotId)||t.type!=='snapshot-restore'||!/^[a-f0-9]{64}$/.test(t.identity||'')||!['prepared','running','undoing','partial','complete','undone'].includes(t.state)||t.direction!==undefined&&!['restore','undo'].includes(t.direction)||!Array.isArray(t.rows)||!t.rows.length)throw Error('Jurnal de restaurare invalid.');
  const seen=new Set();
  for(const row of t.rows){
   object(row);const rule=catalog.getRule(row.id);
   if(!Object.hasOwn(row,'before')||!Object.hasOwn(row,'target')||typeof row.resource!=='string'||seen.has(row.resource))throw Error('Original de restaurare incomplet sau duplicat.');
   seen.add(row.resource);
   if(row.kind==='registry'){
    if(rule.status!=='registry'||!Number.isInteger(row.index)||!rule.entries[row.index])throw Error('Index Registry invalid.');
    registryValue(row.target,rule.entries[row.index]);registryValue(row.before,rule.entries[row.index]);
    if(row.resource!=='registry:'+row.target.path.toLowerCase()+'|'+row.target.name.toLowerCase())throw Error('Țintă de restaurare invalidă.');
   }else if(row.kind==='native'&&rule.status==='native'){
    validateOperation(row.operation,rule.operation);
    if(['service','bcd'].includes(row.operation.type)){
     const entries=row.operation.type==='service'?row.operation.services:row.operation.values;
     if(!Number.isInteger(row.index)||!entries[row.index]||!Array.isArray(row.target)||row.target.length!==1||!Array.isArray(row.before)||row.before.length!==1)throw Error('Original nativ incomplet.');
    }else if(Object.hasOwn(row,'index'))throw Error('Index nativ nepermis.');
   }else throw Error('Tip de restaurare nepermis.');
  }
  return t;
 }
 function transactions(){if(!fs.existsSync(txRoot()))return [];return fs.readdirSync(txRoot()).filter(n=>n.endsWith('.json')).map(n=>validateTransaction(read(safeFile(txRoot(),n)),n.slice(0,-5)))}
 function blocking(){return transactions().filter(t=>!['complete','undone'].includes(t.state))}
 async function prepare(id){
  await assertClear();if(blocking().length)throw Error('Finalizează sau anulează restaurarea întreruptă din Istoric.');
  const snapshot=loadSnapshot(id),host=await identity();if(snapshot.manifest?.identity&&snapshot.manifest.identity!==host)throw Error('Copia aparține altui calculator sau altui cont Windows.');
  const rows=[];for(const row of snapshot.rows){const r=await probe(row);if(r.success!==true||!Object.hasOwn(r,'current'))throw Error(row.title+': '+(r.message||'Citire incompletă.'));rows.push({...row,before:r.current})}
  for(const [key,p] of pending)if(now()>p.expires)pending.delete(key);
  if(pending.size>=32)pending.delete(pending.keys().next().value);
  const value=token();pending.set(value,{id,digest:snapshot.digest,identity:host,rows,expires:now()+180000});
  return {token:value,snapshotId:id,legacy:!snapshot.manifest?.identity,partial:snapshot.manifest?.complete===false,rows:rows.map(({title,category,restart,impact,target,before})=>({title,category,restart,impact,changed:!equal(target,before)}))};
 }
 async function execute(t,undo=false){
  await assertClear();if(t.identity!==await identity())throw Error('Contul Windows sau calculatorul diferă de cel salvat.');
  t.direction=undo?'undo':'restore';t.state=undo?'undoing':'running';save(path.join(txRoot(),t.id+'.json'),t);
  const rows=undo?[...t.rows].reverse():t.rows;
  for(const row of rows){
   try{
    const r=await write({...row,target:undo?row.before:row.target,expected:undo?row.target:row.before});
    if(r.success!==true||r.verified!==true)throw Error(r.message||'Restaurare neconfirmată.');
    row.status=undo?'undone':r.skipped?'skipped':'restored';row.message=r.message||'';
   }catch(e){row.status='failed';row.message=e.message}
   save(path.join(txRoot(),t.id+'.json'),t);
  }
  t.failed=t.rows.filter(x=>x.status==='failed').length;t.succeeded=t.rows.filter(x=>['restored','undone'].includes(x.status)).length;t.skipped=t.rows.filter(x=>x.status==='skipped').length;t.success=t.failed===0;
  t.state=t.success?(undo?'undone':'complete'):'partial';t.restartRequired=t.rows.some(x=>x.restart&&(['restored','undone'].includes(x.status)||x.status==='skipped'&&!equal(x.before,x.target))); t.updatedAt=new Date(now()).toISOString();save(path.join(txRoot(),t.id+'.json'),t);return t;
 }
 async function commit(value){const p=pending.get(value);pending.delete(value);if(!p||now()>p.expires)throw Error('Confirmarea a expirat.');if(loadSnapshot(p.id).digest!==p.digest)throw Error('Copia s-a schimbat. Reia previzualizarea.');if(blocking().length)throw Error('Există o restaurare întreruptă.');await assertClear();const t={id:token(),snapshotId:p.id,identity:p.identity,type:'snapshot-restore',date:new Date(now()).toISOString(),state:'prepared',rows:p.rows};save(path.join(txRoot(),t.id+'.json'),t);return execute(t)}
 async function resume(id,undo=false){if(!uuid.test(id))throw Error('Operație necunoscută.');const t=validateTransaction(read(safeFile(txRoot(),id+'.json')),id);if(blocking().some(x=>x.id!==id))throw Error('Rezolvă mai întâi operația întreruptă.');if(t.state==='undone')throw Error('Operația este deja anulată.');if(t.state==='complete'&&!undo)throw Error('Restaurarea este deja completă. Poți anula operația.');if(t.direction==='undo'&&!undo)throw Error('Anularea a fost începută. Reia anularea pentru a păstra ordinea restaurării.');return execute(t,undo)}
 return {prepare,commit,resume,transactions,blocking,loadSnapshot};
}
module.exports={snapshotRows,createSnapshotService,equal,hash};
