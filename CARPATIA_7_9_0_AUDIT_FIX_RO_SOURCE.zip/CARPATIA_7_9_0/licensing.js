'use strict';
// Offline Ed25519 license verification. This file only needs the PUBLIC key.
// Private signing keys must NEVER be included in the application or its ZIP.
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const PREFIX='CARPATIA-V1';
const PRODUCT='CARPATIA_V7_PRO';
const MAX_LENGTH=8192;
const b64url=x=>Buffer.from(x).toString('base64url');
function assertLicensePayload(data){
 if(!data||typeof data!=='object'||Array.isArray(data)||data.product!==PRODUCT)throw Error('Codul nu este pentru CARPATIA V7 PRO.');
 for(const name of ['licenseId','customer','issuedAt'])if(typeof data[name]!=='string'||!data[name]||data[name].length>180)throw Error('Datele licenței sunt invalide.');
 if(!/^[a-zA-Z0-9_-]{6,100}$/.test(data.licenseId))throw Error('Identificator licență invalid.');
 const issue=Date.parse(data.issuedAt);
 if(!Number.isFinite(issue)||issue>Date.now()+1000*3600*24)throw Error('Data emiterii este invalidă.');
 if(data.expiresAt!==null&&data.expiresAt!==undefined){
  const exp=Date.parse(data.expiresAt);
  if(!Number.isFinite(exp)||exp<=issue)throw Error('Data expirării este invalidă.');
  if(exp<=Date.now())throw Error('Licența a expirat.');
 }
 return data;
}
function inspectLicense(code, publicKey){
 if(typeof code!=='string'||code.length>MAX_LENGTH)throw Error('Cod de licență prea lung sau invalid.');
 const value=code.trim();
 const pieces=value.split('.');
 if(pieces.length!==3||pieces[0]!==PREFIX||!/^[A-Za-z0-9_-]+$/.test(pieces[1])||!/^[A-Za-z0-9_-]+$/.test(pieces[2]))throw Error('Format de licență necunoscut.');
 if(!publicKey)throw Error('Aplicația nu are cheia publică configurată de editor.');
 const signed=Buffer.from(PREFIX+'.'+pieces[1],'utf8');
 let valid=false;
 try{
  const key=publicKey instanceof crypto.KeyObject&&publicKey.type==='public'?publicKey:crypto.createPublicKey(publicKey);
  const signature=Buffer.from(pieces[2],'base64url');
  valid=key.asymmetricKeyType==='ed25519'&&signature.length===64&&signature.toString('base64url')===pieces[2]&&crypto.verify(null,signed,key,signature);
 }catch{valid=false}
 if(!valid)throw Error('Semnătura licenței nu este validă.');
 let payload;
 try{payload=JSON.parse(Buffer.from(pieces[1],'base64url').toString('utf8'))}catch{throw Error('Conținutul licenței este invalid.')}
 return assertLicensePayload(payload);
}
function createIssuerCode(payload,privateKey){
 const data=assertLicensePayload(payload);
 const key=privateKey instanceof crypto.KeyObject?privateKey:crypto.createPrivateKey(privateKey);
 if(key.type!=='private'||key.asymmetricKeyType!=='ed25519')throw Error('Cheie de semnare incompatibilă: este necesară Ed25519.');
 const part=b64url(Buffer.from(JSON.stringify(data),'utf8'));
 const message=PREFIX+'.'+part;
 const signature=crypto.sign(null,Buffer.from(message,'utf8'),key);
 return `${message}.${signature.toString('base64url')}`;
}
function createLicenseStore({directory,publicKey,developer=false}){
 const filename=path.join(directory,'carpatia-license.txt');
 function readSaved(){
  try{
   const stat=fs.statSync(filename);
   if(!stat.isFile()||stat.size>MAX_LENGTH+2)throw Error('Fișier de licență prea lung sau invalid.');
   return fs.readFileSync(filename,'utf8').trim();
  }catch(e){if(e.code==='ENOENT')return '';throw e}
 }
 function validate(code){return inspectLicense(code,publicKey)}
 function status(){
  if(developer)return {active:true,developer:true,licenseId:'DEV',customer:'MOD DEZVOLTARE',expiresAt:null};
  try{
   const code=readSaved();
   if(!code)return {active:false,error:publicKey?'Introdu licența cumpărată.':'Cheia publică a editorului lipsește. Verifică distribuția.'};
   const p=validate(code);return {active:true,developer:false,licenseId:p.licenseId,customer:p.customer,expiresAt:p.expiresAt??null};
  }
  catch(e){return {active:false,error:e.message}}
 }
 function activate(code){
  const data=validate(code);
  fs.mkdirSync(directory,{recursive:true});
  // Atomic write; never persist an unverified code. Restrict Unix permissions when applicable.
  const tmp=filename+'.tmp-'+crypto.randomBytes(6).toString('hex');
  fs.writeFileSync(tmp,code.trim()+'\n',{encoding:'utf8',mode:0o600,flag:'wx'});
  try{fs.renameSync(tmp,filename)}catch(e){try{fs.unlinkSync(tmp)}catch{}throw e}
  return {active:true,developer:false,licenseId:data.licenseId,customer:data.customer,expiresAt:data.expiresAt??null};
 }
 return {status,activate,licensed:()=>status().active};
}
module.exports={PREFIX,PRODUCT,inspectLicense,createIssuerCode,createLicenseStore};
