'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {createShopifyService}=require('../seller/shopify-core');
const {inspectLicense}=require('../licensing');
const pair=crypto.generateKeyPairSync('ed25519');
const privateKey=pair.privateKey.export({type:'pkcs8',format:'pem'}),publicKey=pair.publicKey.export({type:'spki',format:'pem'});
function fixture(t){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'carpatia-shop-'));
 const config={database:path.join(dir,'db.sqlite'),privateKey,secret:'test-secret',shop:'test.myshopify.com',variantId:'123'};
 let service=createShopifyService(config);t.after(()=>{service.close();fs.rmSync(dir,{recursive:true,force:true})});
 return {get service(){return service},restart(){service.close();service=createShopifyService(config)}};
}
function event(changes={},headers={}){
 const raw=Buffer.from(JSON.stringify({id:1,email:'buyer@example.com',financial_status:'paid',test:false,line_items:[{id:2,variant_id:123,quantity:1}],...changes}));
 return [raw,{'x-shopify-shop-domain':'test.myshopify.com','x-shopify-topic':'orders/paid','x-shopify-hmac-sha256':crypto.createHmac('sha256','test-secret').update(raw).digest('base64'),...headers}];
}
test('paid Shopify order generates permanent code accepted by the client',async t=>{
 const f=fixture(t);assert.equal(f.service.accept(...event()).issued,1);
 let mail;await f.service.deliver(async x=>{mail=x;return {id:'mail-1'}});
 const code=mail.text.split('\n').find(x=>x.startsWith('CARPATIA-V1.'));
 assert.equal(inspectLicense(code,publicKey).expiresAt,null);assert.equal(mail.to,'buyer@example.com');
});
test('duplicate paid deliveries and process restart do not issue or send twice',async t=>{
 const f=fixture(t);f.service.accept(...event());f.restart();assert.equal(f.service.accept(...event()).issued,0);
 let sent=0;await f.service.deliver(async()=>{sent++;return {id:'m'}});f.restart();await f.service.deliver(async()=>{sent++;return {id:'m'}});assert.equal(sent,1);
});
test('reject forged payload, wrong shop, wrong topic and malformed JSON',t=>{
 const f=fixture(t),[body,h]=event();assert.equal(f.service.accept(Buffer.concat([body,Buffer.from(' ')]),h).status,401);
 assert.equal(f.service.accept(...event({}, {'x-shopify-shop-domain':'evil.myshopify.com'})).status,403);
 assert.equal(f.service.accept(...event({}, {'x-shopify-topic':'orders/create'})).status,400);
 assert.equal(f.service.accept(...event({}, {'x-shopify-hmac-sha256':'bad'})).status,401);
});
test('unpaid, cancelled, test and unrelated-product orders issue nothing',t=>{
 const f=fixture(t);
 for(const x of [{financial_status:'pending'},{cancelled_at:'2026-01-01'},{test:true},{line_items:[{id:2,variant_id:999,quantity:1}]}])assert.equal(f.service.accept(...event(x)).ignored,true);
});
test('quantity two produces two independent permanent licenses',async t=>{
 const f=fixture(t);assert.equal(f.service.accept(...event({line_items:[{id:2,variant_id:123,quantity:2}]})).issued,2);
 const codes=[];await f.service.deliver(async m=>{codes.push(m.text.split('\n').find(x=>x.startsWith('CARPATIA-V1.')));return {id:m.id}});assert.equal(new Set(codes).size,2);
});
test('invalid quantities and missing email fail before issuing',t=>{
 const f=fixture(t);assert.equal(f.service.accept(...event({email:null})).status,422);
 for(const q of [0,-1,1.5,101])assert.equal(f.service.accept(...event({line_items:[{id:2,variant_id:123,quantity:q}]})).status,422);
});
test('email failure survives restart and retries same content with same id',async t=>{
 const f=fixture(t);f.service.accept(...event());let first;const now=Date.now();
 await f.service.deliver(async x=>{first=x;throw Error('offline')},now);f.restart();let second;
 await f.service.deliver(async x=>{second=x;return {id:'ok'}},now+60001);assert.deepEqual(second,first);
});
test('ambiguous email is put in manual review before provider deduplication expires',async t=>{
 const f=fixture(t);f.service.accept(...event());const now=Date.now();await f.service.deliver(async()=>{throw Error('timeout')},now);
 let called=false;await f.service.deliver(async()=>{called=true;return {id:'no'}},now+24*3600000);assert.equal(called,false);
});
