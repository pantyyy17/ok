'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..'),read=name=>fs.readFileSync(path.join(root,name),'utf8');
const {planOneClick,executeOneClick}=require('../oneclick-engine');
const {planNetwork}=require('../network-boost-core');
const smart=require('../smart-engine');
const tweaks=JSON.parse(read('tweaks.json'));
const snap={hardware:{osBuild:22631,ramGB:16,gpu:['NVIDIA RTX 3060'],hasBattery:false,cpu:'Test CPU'},registry:{success:true,backup:false,matchingIds:[]},power:{success:true,backup:false,active:'381b4222-f694-41f0-9685-ff5bb260df2e'}};
test('proiectul nou nu include interfața Game Booster sau activatoare Windows',()=>{let all=read('index.html')+read('ui.js')+read('main.js');for(const token of ['boostStart','autoBoostConfigure','slmgr.vbs','kms','gamebooster.ps1','profileList','VALORANT','League of Legends'])assert(!all.includes(token),token)});
test('există exact trei butoane principale, interactive',()=>{const html=read('index.html');assert.equal((html.match(/class="reactor(?: primary-reactor)?"/g)||[]).length,3);for(const id of ['heroDebloat','heroUltra','heroNetwork'])assert(html.includes('id="'+id+'"')&&read('ui.js').includes("$('"+id+"')"))});
test('toate elementele folosite de renderer există în HTML',()=>{const html=read('index.html'),js=read('ui.js'),ids=new Set([...html.matchAll(/id="([\w-]+)"/g)].map(x=>x[1]));for(const m of js.matchAll(/\$\('([\w-]+)'\)/g))assert(ids.has(m[1]),m[1])});
test('toate comenzile din preload au handler în main',()=>{const pre=read('preload.js'),m=read('main.js'),names=pre.split('const names=')[1].split(';')[0].match(/'[^']+'/g).map(x=>x.slice(1,-1));for(const name of names)assert(new RegExp(`(?:registerRead|registerWrite|ipcMain\\.handle)\\('${name}'`).test(m),name)});
test('UI susține reduced motion și nu afișează FPS inventat',()=>{const css=read('ui.css'),js=read('ui.js');assert.match(css,/prefers-reduced-motion/);assert.match(js,/fără rezultate FPS inventate|FPS/);assert(!/innerHTML\s*=/.test(js),'fără injectare HTML')});
test('păstrăm compatibilitatea cu numele vechi al aplicației pentru jurnalul de rețea',()=>{const p=JSON.parse(read('package.json'));assert.equal(p.name,'tweak-romania-carpatia-ultra');assert.match(read('main.js'),/network-boost-session\.json/)});
test('Catalog de 59 reguli și allowlist Debloat complet',()=>{assert.equal(tweaks.length,59);assert(JSON.parse(read('debloat-catalog.json')).length>=30);assert(tweaks.every(x=>x.entries?.length))});
test('Smart Engine dă recomandări din hardware real, nu FPS estimat',()=>{const r=smart.plan(snap,tweaks);assert(r.suggestions.length>5);assert.equal(r.profileBlocked,false);assert.match(r.limitations,/nu este un benchmark/i)});
test('Balanced are numai recomandări low',()=>{const r=planOneClick(smart.plan(snap,tweaks),{power:false,sysmain:false,captureOff:false,max:false,riskAcknowledged:false},snap.power,null);assert(r.ids.length>0);assert.equal(r.power,false);assert(r.ids.every(id=>tweaks.find(x=>x.id===id).risk==='low'))});
test('Ultra Max necesită confirmare explicită a riscului',()=>{const profile=smart.plan(snap,tweaks);assert.throws(()=>planOneClick(profile,{power:true,sysmain:false,captureOff:false,max:true,riskAcknowledged:false},snap.power,null),/confirma separat/i);const r=planOneClick(profile,{power:true,sysmain:false,captureOff:false,max:true,riskAcknowledged:true},snap.power,null);assert(r.max&&r.ids.length>0);assert(r.ids.every(id=>!tweaks.find(t=>t.id===id).restoreOnly))});
test('Profilul este blocat când Registry are backup',()=>{const p=smart.plan({...snap,registry:{success:true,backup:true,matchingIds:[]}},tweaks);assert.throws(()=>planOneClick(p,{power:false,sysmain:false,captureOff:false,max:false},snap.power,null),/backup/i)});
test('Net Boost nu acceptă adaptor necunoscut sau opțiuni arbitrare',()=>{const inv={adapters:[{name:'Ethernet',ipv4:['192.168.0.2']}]};assert.throws(()=>planNetwork({adapter:'HACK',provider:'keep',options:{nicPower:false,tcp:false,interrupt:false,eee:false}},inv),/adaptor/i);assert.throws(()=>planNetwork({adapter:'Ethernet',provider:'fake',options:{nicPower:false,tcp:false,interrupt:false,eee:false}},inv),/furnizor/i)});
test('Planul de rețea explicit are DNS plus flush, opțiuni avansate nebifate',()=>{const inv={adapters:[{name:'Ethernet',ipv4:['192.168.1.5']}]};const p=planNetwork({adapter:'Ethernet',provider:'cloudflare',options:{nicPower:false,tcp:false,interrupt:false,eee:false}},inv);assert.deepEqual(p.actions,['dns','flush'])});
test('Eșec la pasul Registry declanșează rollback verificat',async()=>{let restored=false;const ops={applyRegistry:async()=>({success:false,message:'fault'}),hasBackup:async()=>true,restore:async()=>{restored=true;return {success:true}},verify:async()=>false};const r=await executeOneClick({ids:['game_mode'],power:false,sysmain:false},ops);assert.equal(r.success,false);assert(restored);assert.equal(r.rolledBack[0].success,true)});
test('Fără backup la rollback nu inventăm restaurare executată',async()=>{const ops={applyRegistry:async()=>{throw Error('failure')},hasBackup:async()=>false,restore:async()=>{throw Error('never')}};const r=await executeOneClick({ids:['game_mode'],power:false,sysmain:false},ops);assert.equal(r.success,false);assert.equal(r.rolledBack[0].success,false);assert.match(r.rolledBack[0].message,/Backup absent/i)});
test('Securitate Electron: sandbox, context isolation, no node integration',()=>{const m=read('main.js');for(const rx of [/sandbox:true/,/contextIsolation:true/,/nodeIntegration:false/,/setWindowOpenHandler/,/will-navigate/])assert.match(m,rx)});
test('Nu există comenzi de dezactivare Defender, Firewall și Windows Update',()=>{const all=read('main.js')+read('ui.js')+read('index.html');for(const rx of [/Set-MpPreference/,/DisableRealtimeMonitoring/,/Set-NetFirewallProfile/,/Stop-Service.*wuauserv/])assert.doesNotMatch(all,rx)});

test('Restaurarea ULTRA fără verificarea finală rămâne eroare, nu succes',async()=>{const ops={applyRegistry:async()=>({success:false}),hasBackup:async()=>true,restore:async()=>({success:true}),verifyRestored:async()=>false};const r=await executeOneClick({ids:['game_mode'],power:false,sysmain:false},ops);assert.equal(r.success,false);assert.equal(r.rolledBack[0].success,false)});

test('profilul este blocat dacă Registry nu a fost citit corect',()=>{
 for(const registry of [null,{success:false,backup:false,matchingIds:[]},{success:true,backup:false}]){
  const profile=smart.plan({...snap,registry},tweaks);
  assert.equal(profile.profileBlocked,true);
  assert.throws(()=>planOneClick(profile,{power:false},snap.power),/Profil blocat/);
 }
});
test('High Performance deja activ nu este rescris',()=>{
 const power={success:true,backup:false,active:'8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'};
 const r=planOneClick(smart.plan(snap,tweaks),{power:true},power);
 assert.equal(r.power,false);assert(r.ids.length>0);
});
