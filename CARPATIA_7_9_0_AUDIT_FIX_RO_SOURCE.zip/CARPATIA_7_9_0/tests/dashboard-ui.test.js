'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {descriptor}=require('../dashboard-profiles');
function ui({confirm=true,active=false,prepareError=null}={}){
 class Element{constructor(){this.children=[];this.value='';this.textContent=''}append(x){this.children.push(x)}replaceChildren(...x){this.children=x}}
 const ids=Object.fromEntries(['heroDebloat','heroUltra','heroNetwork','heroOpStatus','dashboardAdapter','dashboardRecovery','refreshProfiles',...['cpu','gpu','internet'].flatMap(g=>['restoreProfile-'+g,'profileLevel-'+g,'profileState-'+g])].map(id=>[id,new Element()]));
 for(const g of ['cpu','gpu','internet'])ids['profileLevel-'+g].value='low';
 const calls=[],recovery=[],toasts=[],reads={adapters:0};
 const api={dashboardStatus:async()=>['cpu','gpu','internet'].map(group=>({group,active:active&&group==='cpu',state:'applied',level:'high'})),tweakLibraryContext:async()=>{reads.adapters++;return {adapters:[]}},dashboardPrepare:async r=>{if(prepareError)throw Error(prepareError);calls.push(['prepare',r]);return {token:'abc',plan:descriptor(r.group,r.level,r.adapterGuid)}},dashboardCommit:async t=>{calls.push(['commit',t]);return {success:true,message:'applied'}},dashboardRestore:async g=>{calls.push(['restore',g]);return {success:true,message:'restored'}}};
 const window={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../dashboard-profiles-ui.js'),'utf8'),{window,document:{getElementById:id=>ids[id],createElement:()=>new Element()}});
 const page=window.CarpatiaDashboardProfiles.mount({api,task:async(_,f)=>f(),requireNative:r=>{recovery.push(!!r);return true},confirmDialog:async()=>confirm,onOwner:o=>calls.push(['owner',o.id||o.group]),showToast:t=>toasts.push(t)});
 return {ids,calls,recovery,toasts,page,reads};
}
test('dashboard sends selected subsystem and level, then commits only returned token',async()=>{
 const x=ui();x.ids['profileLevel-gpu'].value='ultra';await x.page.run('gpu');assert.deepEqual(JSON.parse(JSON.stringify(x.calls)),[['prepare',{group:'gpu',level:'ultra',adapterGuid:''}],['commit','abc']]);assert.equal(x.ids.heroOpStatus.textContent,'applied');
});
test('cancelled dashboard confirmation never commits',async()=>{
 const x=ui({confirm:false});await x.page.run('cpu');assert.equal(x.calls.length,1);assert.match(x.ids.heroOpStatus.textContent,/Anulat/);
});
test('Internet requires explicit adapter before contacting mutation API',async()=>{
 const x=ui();await x.page.run('internet');assert.equal(x.calls.length,0);assert.match(x.toasts[0],/adaptorul/);
});
test('active profile exposes recovery and disables reapply; restore uses license-independent path',async()=>{
 const x=ui({active:true});await x.page.load();assert.equal(x.ids.heroDebloat.disabled,true);assert.equal(x.ids['restoreProfile-cpu'].disabled,false);assert.equal(x.ids.dashboardRecovery.children.length,1);
 await x.ids.dashboardRecovery.children[0].onclick();assert.deepEqual(x.calls,[['owner','cpu']]);assert.equal(x.recovery[0],true);
});
test('profile controls and script order are present in shipped HTML',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
 for(const g of ['cpu','gpu','internet'])for(const prefix of ['profileLevel-','restoreProfile-','profileState-'])assert.ok(html.includes('id="'+prefix+g+'"'));
 assert.ok(html.indexOf('src="dashboard-profiles-ui.js"')<html.indexOf('src="ui.js"'));
});

test('profile status refresh reuses adapter inventory until explicit refresh',async()=>{
 const x=ui();await x.page.load();await x.page.load();assert.equal(x.reads.adapters,1);
 await x.ids.refreshProfiles.onclick();assert.equal(x.reads.adapters,2);
});

test('apply and restore never inventory adapters while holding the mutation task',async()=>{
 const x=ui();await x.page.run('cpu');await x.page.restore('cpu');assert.equal(x.reads.adapters,0);
});

test('real conflict offers owner navigation without automatic restore or apply',async()=>{
 const x=ui({prepareError:'Conflict real: HAGS [library-cpu-013]. Restaureaza acest tweak.'});
 await assert.rejects(x.page.run('gpu'),/Conflict real/);
 const b=x.ids.dashboardRecovery.children.find(x=>x.textContent.includes('DESCHIDE BACKUP'));
 assert.ok(b);b.onclick();assert.deepEqual(x.calls,[['owner','library-cpu-013']]);
});
