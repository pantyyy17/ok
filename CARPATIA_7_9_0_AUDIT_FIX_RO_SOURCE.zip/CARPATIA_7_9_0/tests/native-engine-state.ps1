$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../tweak-native-ops.ps1')
$script:assertions=0
$script:writes=@()
function Assert($condition,$label){if(-not $condition){throw ('Assertion failed: '+$label)};$script:assertions++}
function Reject($operation,$label){$threw=$false;try{& $operation}catch{$threw=$true};Assert $threw $label}
function Invoke-Tool($Name,$Arguments){$script:writes+=,$Name;return ''}
function New-ServiceState($name){return @{name=$name;start=2;running=$true;delayedExists=$true;delayed=1}}
$service=@{type='service';services=@(@{name='S1';start=4;running=$false},@{name='S2';start=4;running=$false})}
$before=@((New-ServiceState 'S1'),(New-ServiceState 'S2'))
$desired=Desired-Native $service $before
$current=Copy-Object $before;$current[0].start=4
Assert (Test-NativeRestoreState $service $current $before $desired) 'partial service configuration is restorable'
$current[0].running=$false
Assert (Test-NativeRestoreState $service $current $before $desired) 'one changed service and one untouched service is restorable'
$current[0].start=3
Assert (-not (Test-NativeRestoreState $service $current $before $desired)) 'external service start mode is rejected'
$current=Copy-Object $before;$current[0].name='other-service'
Assert (-not (Test-NativeRestoreState $service $current $before $desired)) 'foreign service is rejected'
$bcd=@{type='bcd';values=@(@{key='debug';object='{current}';value='no'},@{key='bootdebug';object='{current}';value='no'})}
$before=@(@{key='debug';object='{current}';exists=$false;value=$null},@{key='bootdebug';object='{current}';exists=$false;value=$null})
$desired=Desired-Native $bcd $before
$current=Copy-Object $before;$current[0]=Copy-Object $desired[0]
Assert (Test-NativeRestoreState $bcd $current $before $desired) 'partly applied BCD batch is restorable'
$current[0].value='yes'
Assert (-not (Test-NativeRestoreState $bcd $current $before $desired)) 'external BCD value is rejected'
$mtu=@{type='mtu'};$before=@{active=1400;persistent=1400};$desired=@{active=1500;persistent=1500}
Assert (Test-NativeRestoreState $mtu @{active=1400;persistent=1500} $before $desired) 'partial MTU writes are restorable'
Assert (-not (Test-NativeRestoreState $mtu @{active=1300;persistent=1500} $before $desired)) 'external MTU is rejected'
Reject {Write-Native @{type='power-active'} ('-'*36)} 'malformed power GUID rejected before writing'
Reject {Write-Native @{type='ipv6'} 'false'} 'string false cannot become true by coercion'
Reject {Write-Native @{type='power-value'} -1} 'negative power index is rejected'
Reject {Write-Native @{type='fsutil'} 4294967296} 'oversized NTFS value is rejected'
Reject {Write-Native @{type='dns'} @{automatic=$true;servers=@('8.8.8.8')}} 'contradictory automatic DNS rejected'
Reject {Write-Native @{type='dns'} @{automatic=$false;servers=@('::1')}} 'IPv6 address rejected by IPv4-only operation'
$badBcd=Desired-Native $bcd @();$badBcd[1].object='{bootmgr}'
Reject {Write-Native $bcd $badBcd} 'entire BCD batch is validated before first write'
$badService=@((New-ServiceState 'S1'),(New-ServiceState 'foreign'))
Reject {Write-Native $service $badService} 'entire service batch is validated before first write'
$hiber=@(@{name='HibernateEnabled';exists=$true;value=0},@{name='HiberFileType';exists=$true;value=2},@{name='HiberFileType';exists=$true;value=2})
Reject {Write-Native @{type='hibernation'} $hiber} 'malformed hibernation state rejected before powercfg'
Assert ($script:writes.Count -eq 0) 'all rejected states caused zero native tool writes'
# Simulate a disabled-but-running original without touching any Windows service.
$script:sequence=@();$script:startFails=$false
function Invoke-Tool($Name,$Arguments){$script:sequence+=,($Arguments -join ' ');return ''}
function New-ItemProperty {return $null}
function Get-Service {
 $svc=[pscustomobject]@{Status='Stopped'}
 $svc | Add-Member -MemberType ScriptMethod -Name WaitForStatus -Value {param($status,$timeout)}
 return $svc
}
function Start-Service {if($script:startFails){throw 'Mock start denied'};$script:sequence+=,'start'}
$o=@{type='service';services=@(@{name='S1';start=4;running=$true})}
$v=@(@{name='S1';start=4;running=$true;delayedExists=$true;delayed=1})
# The registry path is only passed to the mocked property writer.
Write-Native $o $v
Assert (($script:sequence -join '|') -eq 'config S1 start= disabled|config S1 start= demand|start|config S1 start= disabled') 'disabled-but-running service restored without permanently enabling it'
$script:sequence=@();$script:startFails=$true
Reject {Write-Native $o $v} 'failed service start remains a failure'
Assert ($script:sequence[-1] -eq 'config S1 start= disabled') 'saved disabled startup mode is retained after failed start'
@{success=$true;assertions=$script:assertions} | ConvertTo-Json -Compress
