'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createRecoveryService}=require('../recovery-core');
function harness(){let clock=0,seq=0;const data={items:[{id:'a',category:'CPU',title:'A',state:'applied',original:0,restart:true},{id:'b',category:'GPU',title:'B',state:'failed',original:1}],errors:[]},writes=[],saved=[];
 const service=createRecoveryService({inventory:async()=>structuredClone(data),inspect:async()=>({success:true,current:2}),restore:async row=>{writes.push(row.id);if(row.id==='b')return {success:false,message:'Access denied'};data.items.find(x=>x.id===row.id).state='restored';return {success:true}},persist:r=>saved.push(structuredClone(r)),now:()=>clock,uuid:()=>String(++seq)});
 return {data,writes,saved,service,expire:()=>clock=180001};}
test('preview is read-only, commit continues partial failures, persists report and originals',async()=>{const h=harness(),p=await h.service.prepare({});assert.equal(h.writes.length,0);const r=await h.service.commit(p.token);assert.equal(r.success,false);assert.equal(r.succeeded,1);assert.equal(r.failed,1);assert.equal(r.restartRequired,true);assert.equal(h.data.items[1].state,'failed');assert.equal(h.saved[0].state,'running');assert.equal(h.saved.at(-1).state,'partial');await assert.rejects(h.service.commit(p.token),/expirat/)});
test('changed journals invalidate confirmation before any write',async()=>{const h=harness(),p=await h.service.prepare({});h.data.items[0].original=9;await assert.rejects(h.service.commit(p.token),/schimbat/);assert.equal(h.writes.length,0)});
test('category selection restores only selected category',async()=>{const h=harness(),p=await h.service.prepare({category:'CPU'});assert.equal(p.rows.length,1);assert.equal((await h.service.commit(p.token)).success,true);assert.deepEqual(h.writes,['a'])});
test('expired confirmation and corrupt backups fail closed',async()=>{const h=harness(),p=await h.service.prepare({id:'a'});h.expire();await assert.rejects(h.service.commit(p.token),/expirat/);h.data.errors.push('bad JSON');await assert.rejects(h.service.prepare({}),/incomplete/);assert.equal(h.writes.length,0)});
test('recovery navigation leaves search and category unchanged',()=>{const fs=require('node:fs'),vm=require('node:vm'),s=fs.readFileSync(require('node:path').join(__dirname,'../ui.js'),'utf8');const code=s.match(/function showResourceOwner\(owner\)\{[^\n]+/)[0];const filters={search:'manual',category:'RAM'},calls=[];const ctx={navigate:v=>calls.push(v),recoveryPage:{open:owner=>{calls.push(owner.id);return Promise.resolve()}}};vm.runInNewContext(code+';showResourceOwner({id:"library-cpu-012",route:"tweaks"});',ctx);assert.deepEqual(calls,['restore','library-cpu-012']);assert.deepEqual(filters,{search:'manual',category:'RAM'});assert.ok(!/tweakSearch['"]\)\.value\s*=\s*owner/.test(s));});

test('live Windows changes after preview are rechecked and never overwritten',async()=>{
 let current=1,writes=0;
 const service=createRecoveryService({inventory:async()=>({items:[{id:'a',state:'applied',original:0}],errors:[]}),inspect:async()=>({success:true,current}),restore:async()=>{writes++;return {success:true}},persist:()=>{}});
 const plan=await service.prepare({});current=9;
 const report=await service.commit(plan.token);
 assert.equal(report.success,false);assert.equal(writes,0);assert.match(report.results[0].message,/schimbat/);
});
test('failed live reinspection retains originals and does not invoke restore',async()=>{
 let failed=false,writes=0;
 const service=createRecoveryService({inventory:async()=>({items:[{id:'a',state:'applied',original:0}],errors:[]}),inspect:async()=>failed?{success:false,message:'Access denied'}:{success:true,current:1},restore:async()=>{writes++;return {success:true}},persist:()=>{}});
 const plan=await service.prepare({});failed=true;
 const report=await service.commit(plan.token);assert.equal(report.failed,1);assert.equal(writes,0);assert.match(report.results[0].message,/Access denied/);
});
test('recovery confirmations are bounded and array selections are invalid',async()=>{
 const h=harness();await assert.rejects(h.service.prepare([]),/invalidă/);
 const first=await h.service.prepare({});for(let i=0;i<32;i++)await h.service.prepare({});
 await assert.rejects(h.service.commit(first.token),/expirat/);assert.equal(h.writes.length,0);
});

test('ambiguous or unknown recovery selectors never expand into restore all',async()=>{
 const h=harness();for(const selection of [{typo:'CPU'},{category:'CPU',id:'a'},{category:''},{group:42}])await assert.rejects(h.service.prepare(selection),/invalidă/);
 assert.equal(h.writes.length,0);
});

test('reinspection tolerates PowerShell object key order without ignoring value changes',async()=>{
 let inspections=0,writes=0;
 const service=createRecoveryService({inventory:async()=>({items:[{id:'a',state:'applied',original:0}],errors:[]}),inspect:async()=>++inspections===1?{success:true,current:{exists:true,value:1}}:{current:{value:1,exists:true},success:true},restore:async()=>{writes++;return {success:true}},persist:()=>{}});
 const p=await service.prepare({});assert.equal((await service.commit(p.token)).success,true);assert.equal(writes,1);
});
