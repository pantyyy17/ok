'use strict';
const fs=require('node:fs'),path=require('node:path');
const catalog=require('./tweak-library.json'),legacy=require('./tweaks.json');
const {validateSession}=require('./dashboard-profiles');
const byId=new Map(catalog.map(r=>[r.id,r]));
const serviceNames={sysmain:'SysMain',search:'WSearch',diagtrack:'DiagTrack'};
const active=new Set(['prepared','failed','applied']);
const {norm,resources}=require('./resource-targets');
function validateRegistryOriginal(v){
 if(!v||typeof v.exists!=='boolean')throw Error('Original Registry invalid');
 if(!v.exists)return;
 const value=v.value;
 if(!['DWord','QWord','String','ExpandString','Binary','MultiString'].includes(v.kind)||value==null)throw Error('Tip sau valoare Registry absentă');
 if(v.kind==='DWord'&&(!Number.isInteger(value)||value< -2147483648||value>4294967295))throw Error('DWord original invalid');
 if(v.kind==='QWord'&&!Number.isSafeInteger(value))throw Error('QWord original nereprezentabil fără pierderi');
 if(['String','ExpandString'].includes(v.kind)&&typeof value!=='string')throw Error('Text Registry invalid');
 if(v.kind==='Binary'&&(!Array.isArray(value)||value.some(n=>!Number.isInteger(n)||n<0||n>255)))throw Error('Octeți Registry invalizi');
 if(v.kind==='MultiString'&&(!Array.isArray(value)||value.some(s=>typeof s!=='string')))throw Error('Listă de texte Registry invalidă');
}
function validateServiceBackup(b,id){
 const s=b?.before;
 if(b?.version!==1||b.id!==id||b.name!==serviceNames[id]||s?.name!==serviceNames[id]||!['Auto','Manual','Disabled'].includes(s.startMode)||!['Running','Stopped'].includes(s.state)||!Object.hasOwn(s,'delayedAutoStart')||(s.delayedAutoStart!==null&&![0,1].includes(s.delayedAutoStart)))throw Error('Backup Services incompatibil sau incomplet: '+id);
 return b;
}
function readLedger({dataDir,backupDir}){
 const records=[],errors=[];
 function read(file,fn){try{fn(JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')))}catch(e){errors.push(path.basename(file)+': '+e.message)}}
 function files(dir){try{return fs.readdirSync(dir).filter(x=>x.endsWith('.json')).map(x=>path.join(dir,x))}catch(e){if(e.code==='ENOENT')return [];errors.push(dir+': '+e.message);return []}}
 for(const [folder,kind] of [['tweak-library-backups','registry'],['tweak-native-backups','native']])for(const file of files(path.join(dataDir,folder))){read(file,b=>{
  const rule=byId.get(b.id);if(b.version!==1||!rule||path.basename(file)!==b.id+'.json'||!['prepared','failed','applied','restored','completed','maintenance-failed','acknowledged'].includes(b.state))throw Error('Jurnal necunoscut/incompatibil');
  if(!active.has(b.state))return;
  if(kind==='registry'){
   if(rule.status!=='registry'||!Array.isArray(b.values)||b.values.length!==rule.entries.length)throw Error('Original Registry absent');
   const seen=new Set();
   for(const v of b.values){
    validateRegistryOriginal(v);
    const index=rule.entries.findIndex(e=>norm(e.path)===norm(v.path)&&e.name.toLowerCase()===String(v.name).toLowerCase());
    if(index<0||seen.has(index))throw Error('Țintă Registry necunoscută sau duplicată');
    seen.add(index);
   }
  }else{
   if(!['native','maintenance'].includes(rule.status)||b.operation?.type!==rule.operation?.type||!Object.hasOwn(b,'before'))throw Error('Original nativ absent/incompatibil');
   if(rule.operation?.type==='service'){
    if(!Array.isArray(b.before)||b.before.length!==rule.operation.services.length||new Set(b.before.map(v=>String(v?.name).toLowerCase())).size!==b.before.length||b.before.some(v=>!v||!rule.operation.services.some(s=>s.name.toLowerCase()===String(v.name).toLowerCase())||![2,3,4].includes(v.start)||typeof v.running!=='boolean'||typeof v.delayedExists!=='boolean'||![0,1].includes(v.delayed)))throw Error('Original serviciu nativ invalid');
   }
  }
  records.push({id:b.id,module:'Tweaks',route:'tweaks',resources:resources(rule),state:b.state});
 })}
 for(const [id,name] of Object.entries(serviceNames)){
  const file=path.join(backupDir,'services-'+id+'.json');if(fs.existsSync(file))read(file,b=>{validateServiceBackup(b,id);records.push({id:'services:'+id,module:'Services',route:'services',serviceId:id,resources:['service:'+name.toLowerCase()]})});
 }
 const ultra=path.join(backupDir,'ultra-latest.json');if(fs.existsSync(ultra))read(ultra,b=>{
  if(b.version!==2||!Array.isArray(b.values)||!b.values.length)throw Error('Backup ULTRA invalid');
  for(const v of b.values)if(typeof v.existed!=='boolean'||!legacy.some(r=>r.entries.some(e=>norm(e.path)===norm(v.path)&&e.name===v.name)))throw Error('Tinta ULTRA necunoscuta');
  records.push({id:'legacy-ultra',module:'ULTRA Registry',route:'restore',resources:resources({entries:b.values})});
 });
 for(const group of ['cpu','gpu','internet']){
  const file=path.join(dataDir,'dashboard-profiles',group+'.json');if(!fs.existsSync(file))continue;
  read(file,s=>{validateSession(s,group);if(s.state==='restored')return;for(const id of s.started){
   const found=records.find(r=>r.id===id);if(found){found.module='Dashboard '+group.toUpperCase();found.route='dashboard';found.group=group}
   else if(!s.unchanged.includes(id))throw Error('Backup lipsa pentru pasul Dashboard '+id);
  }});
 }
 return {records,errors};
}
function conflicts(ledger,targets,exclude){return ledger.records.filter(r=>r.id!==exclude&&r.resources.some(x=>targets.includes(x)))}
function serviceState(item,ledger){
 const owners=conflicts(ledger,['service:'+String(item.name).toLowerCase()]);
 const own=owners.filter(r=>r.id==='services:'+item.id),foreign=owners.filter(r=>r.id!=='services:'+item.id);
 const reason=ledger.errors.join(' | ')||item.error||(!item.installed?'Serviciu absent.':!['Auto','Manual','Disabled'].includes(item.startMode)||!['Running','Stopped'].includes(item.state)?'Stare serviciu necunoscuta sau in tranzitie.':'')||(Boolean(item.backup)!==Boolean(own.length)?'Evidenta backupului Services nu coincide; reia diagnosticul.':'');
 if(reason)return {...item,action:'blocked',label:'DIAGNOSTIC NECESAR',reason,owners};
 if(owners.length>1)return {...item,action:'blocked',label:'BACKUPURI SUPRAPUSE',reason:owners.map(x=>x.module+' / '+x.id).join('; '),owners};
 if(foreign.length)return {...item,action:'owner',label:'RESTAURARE ÎN '+foreign[0].module.toUpperCase(),reason:foreign[0].id,owners};
 if(own.length)return {...item,action:'restore',label:'RESTAUREAZĂ',owners};
 if(item.startMode==='Disabled')return {...item,action:'disabled',label:'DEJA DEZACTIVAT',reason:item.state==='Running'?'Startup dezactivat; serviciul inca ruleaza. Nu se reaplica automat.':'Fara backup CARPATIA; originalul nu este cunoscut.',owners};
 return {...item,action:'apply',label:'DEZACTIVEAZĂ',owners};
}
module.exports={readLedger,resources,conflicts,serviceState,validateServiceBackup,serviceNames};
