'use strict';
const fs=require('node:fs');const {createPublicKey}=require('node:crypto');
const path=require('node:path');const file=path.join(__dirname,'..','license-public.pem');
if(!fs.existsSync(file)){console.error('[BUILD BLOCAT] Lipsește license-public.pem. Adaugă cheia publică Ed25519 corespunzătoare cheii private originale a editorului; nu genera altă pereche pentru a o înlocui. Vezi LICENTIERE.md.');process.exit(1)}
try{const key=createPublicKey(fs.readFileSync(file,'utf8'));if(key.asymmetricKeyType!=='ed25519')throw Error('cheia nu este Ed25519');console.log('[OK] Licențiere Ed25519 pregătită pentru build.')}catch(e){console.error('[BUILD BLOCAT] Cheia publică invalidă:',e.message);process.exit(1)}
