'use strict';
// Run ONLY in a disposable Windows VM with a checkpoint and console access.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {createWindowsRunner}=require('../windows-process');
const {createProfileService}=require('../dashboard-profiles');
const catalog=require('../tweak-library.json');
const {parseArgs}=require('node:util');
const {values}=parseArgs({options:{'vm-test':{type:'boolean'},adapter:{type:'string'},'data-dir':{type:'string'},group:{type:'string'},resume:{type:'boolean'},'hold-for-restart':{type:'boolean'}}});
if(process.platform!=='win32'||!values['vm-test']){console.error('NOT RUN: requires Windows VM and explicit --vm-test.');process.exit(2)}
if(!values['data-dir']?.trim())throw Error('Supply a dedicated persistent --data-dir.');
const adapter=values.adapter||'',directory=path.resolve(values['data-dir']);
if(values.group&&!['cpu','gpu','internet'].includes(values.group))throw Error('Unknown --group; use cpu, gpu or internet.');
if(values.resume&&values['hold-for-restart'])throw Error('--resume and --hold-for-restart are mutually exclusive.');
if(!values.resume&&(!values.group||values.group==='internet')&&!/^\{?[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}\}?$/i.test(adapter))throw Error('Supply the explicit --adapter GUID for Internet testing.');
fs.mkdirSync(directory,{recursive:true});
const run=createWindowsRunner(),project=path.resolve(__dirname,'..');
const ps=(file,...params)=>run(['-File',path.join(project,file),...params],180000);
const op=(id,action,guid='')=>{const r=catalog.find(x=>x.id===id);return ps(r.status==='registry'?'tweak-library.ps1':'tweak-native.ps1','-Action',action,'-Id',id,'-DataDir',directory,...(r.status==='native'?['-AdapterGuid',guid]:[]))};
const store={read:g=>{const f=path.join(directory,g+'.json');return fs.existsSync(f)?JSON.parse(fs.readFileSync(f)):null},write:(g,s)=>{const f=path.join(directory,g+'.json');fs.writeFileSync(f+'.tmp',JSON.stringify(s));fs.renameSync(f+'.tmp',f)}};
const ops={snapshot:()=>ps('inspect.ps1'),status:async()=>{const r=await Promise.all(['tweak-library.ps1','tweak-native.ps1'].map(f=>ps(f,'-Action','Status','-DataDir',directory)));return {success:r.every(x=>x.success),states:r.flatMap(x=>x.states||[])}},check:(id,a)=>op(id,'Check',a),apply:(id,a)=>op(id,'Apply',a),restore:id=>op(id,'Restore')};
const reportFile=path.join(directory,'windows-test-report.json');
const log=fs.existsSync(reportFile)?JSON.parse(fs.readFileSync(reportFile,'utf8')):[];
if(!Array.isArray(log))throw Error('Existing Windows report is invalid; preserve it for diagnosis.');
const record=(scenario,result)=>{log.push({date:new Date().toISOString(),scenario,result});fs.writeFileSync(reportFile+'.tmp',JSON.stringify(log,null,2));fs.renameSync(reportFile+'.tmp',reportFile)};
(async()=>{
 const admin=await ps('permissions.ps1');assert.equal(admin.admin,true,'Administrator required');
 if(values.resume){let resumed=0;for(const group of values.group?[values.group]:['cpu','gpu','internet']){const service=createProfileService({store,ops});if(service.status().find(x=>x.group===group).active){const r=await service.restore(group);record('restore after restart: '+group,r);assert.equal(r.success,true);resumed++}}if(!resumed){record('NOT APPLICABLE: resume',{message:'No active profile in the selected test directory.'});console.error('NOT APPLICABLE: no active profile to resume.');process.exitCode=2}return}
 const groups=values.group?[values.group]:['cpu','gpu','internet'];
 for(const group of groups){for(let cycle=0;cycle<2;cycle++){
  const service=createProfileService({store,ops});const p=await service.prepare({group,level:'ultra',adapterGuid:adapter});const r=await service.commit(p.token);record(group+' ULTRA apply '+cycle,r);assert.equal(r.success,true);
  if(values['hold-for-restart']){record('pending actual Windows restart',{group});console.log('Restart Windows, then run same --data-dir with --resume. No restart was performed automatically.');return}
  const reopened=createProfileService({store,ops});const restored=await reopened.restore(group);record(group+' restore after service reopen '+cycle,restored);assert.equal(restored.success,true);
 }}
 const id='library-cpu-005';const r=await op(id,'Apply');record('individual apply',r);assert.equal(r.success,true);if(!r.already){const restored=await op(id,'Restore');record('individual restore',restored);assert.equal(restored.success,true)}
 console.log('Completed real Windows scenarios; see windows-test-report.json. Restart scenario requires separate --hold-for-restart / --resume runs.');
})().catch(e=>{record('FAILED',{message:e.message});console.error(e);process.exitCode=1});
