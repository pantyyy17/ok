'use strict';
const csrf=document.querySelector('meta[name="carpatia-token"]').content;
const $=id=>document.getElementById(id);
const feedback=message=>$('feedback').textContent=message;
async function post(route,payload={}){
 const res=await fetch('/api/'+route,{method:'POST',headers:{'Content-Type':'application/json','X-Carpatia-Token':csrf},body:JSON.stringify(payload)});
 const parsed=await res.json();if(!res.ok||!parsed.ok)throw Error(parsed.error||'Cererea a eșuat.');return parsed.result;
}
async function refresh(){
 const r=await post('status');$('keyState').textContent=r.error?'EROARE: '+r.error:r.partial?'Chei incomplete — verifică folderul înainte de continuare.':r.ready?'Cheile Ed25519 există și sunt disponibile.':'Nu au fost generate încă chei.';
 $('init').disabled=r.ready||r.partial||!!r.error;
 $('configure').disabled=!r.ready;$('issue').disabled=!r.ready;
 $('count').textContent='('+r.issuedCount+')';const history=$('history');history.replaceChildren();
 for(const entry of r.records){const row=document.createElement('div');row.className='history-row';const name=document.createElement('strong');name.textContent=entry.customer;const detail=document.createElement('small');detail.textContent=entry.id+' · '+(entry.expiresAt?'Expiră '+entry.expiresAt.slice(0,10):'Permanentă');row.append(name,detail);history.append(row)}
 if(!r.records.length)history.textContent='Nu există licențe emise.';
}
async function act(name,fn){try{feedback('Se procesează…');await fn();feedback(name+' — reușit.')}catch(e){feedback('EROARE: '+e.message)}}
$('init').onclick=()=>act('Cheile editorului',async()=>{if(!confirm('Generezi pentru prima dată cheia privată? Nu o vei putea recupera dacă o pierzi.'))return;await post('init');await refresh()});
$('configure').onclick=()=>act('Cheia publică',async()=>{const r=await post('configure');feedback(r.message);await refresh()});
$('issue').onclick=()=>act('Licență nouă',async()=>{const duration=$('duration').value;const r=await post('issue',{customer:$('customer').value,days:duration==='permanent'?null:Number(duration)});$('generated').classList.remove('hidden');$('generatedTitle').textContent=r.id+' · '+(r.expiresAt?'Valabilă până la '+r.expiresAt.slice(0,10):'Permanentă');$('licenseOutput').value=r.code;await refresh()});
$('copy').onclick=()=>act('Cod copiat',async()=>{await navigator.clipboard.writeText($('licenseOutput').value)});
refresh().catch(e=>feedback('Nu pot citi datele: '+e.message));
