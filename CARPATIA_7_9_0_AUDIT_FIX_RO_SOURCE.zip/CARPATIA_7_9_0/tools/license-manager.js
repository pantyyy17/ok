#!/usr/bin/env node
'use strict';
// Local-only seller dashboard. Binds exclusively to loopback and never exposes the private PEM.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {issuerStatus,initialize,configurePublicKey,issueLicense,mustBeExternal}=require('./issuer-core');
const i=process.argv.indexOf('--private-dir');
if(i<0||!process.argv[i+1]){console.error('Utilizare: node tools/license-manager.js --private-dir "C:\\CARPATIA_PRIVATE"');process.exit(1)}
let privateDir;
try{privateDir=mustBeExternal(process.argv[i+1])}catch(e){console.error(e.message);process.exit(1)}
const token=crypto.randomBytes(32).toString('hex');
const html=fs.readFileSync(path.join(__dirname,'manager.html'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'manager.css'));
const js=fs.readFileSync(path.join(__dirname,'manager.js'));
const server=http.createServer(async(req,res)=>{
 const origin=`http://127.0.0.1:${server.address().port}`;
 const headers={
  'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY',
  'Referrer-Policy':'no-referrer','Cross-Origin-Resource-Policy':'same-origin',
  'Content-Security-Policy':"default-src 'none'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"
 };
 function send(status,body,type='application/json; charset=utf-8'){
  res.writeHead(status,{...headers,'Content-Type':type});res.end(type.startsWith('application/json')?JSON.stringify(body):body);
 }
 const host=req.headers.host;
 if(host!==`127.0.0.1:${server.address().port}`){send(403,{error:'Host respins.'});return}
 if(req.method==='GET'&&req.url==='/'){send(200,html.replace('__TOKEN__',token),'text/html; charset=utf-8');return}
 if(req.method==='GET'&&req.url==='/manager.css'){send(200,css,'text/css; charset=utf-8');return}
 if(req.method==='GET'&&req.url==='/manager.js'){send(200,js,'application/javascript; charset=utf-8');return}
 if(req.method!=='POST'||!['/api/status','/api/init','/api/configure','/api/issue'].includes(req.url)){send(404,{error:'Rută indisponibilă.'});return}
 if(req.headers.origin!==origin||req.headers['x-carpatia-token']!==token||req.headers['content-type']?.split(';')[0]!=='application/json'){
  send(403,{error:'Cerere refuzată.'});return;
 }
 try{
  let body='';for await(const chunk of req){body+=chunk.toString();if(body.length>8192)throw Error('Cerere prea mare.')}
  const params=body?JSON.parse(body):{};
  let result;
  if(req.url==='/api/status')result=issuerStatus(privateDir);
  else if(req.url==='/api/init')result=initialize(privateDir);
  else if(req.url==='/api/configure')result=configurePublicKey(privateDir);
  else if(req.url==='/api/issue')result=issueLicense(privateDir,params);
  send(200,{ok:true,result});
 }catch(e){send(400,{ok:false,error:e.message})}
});
server.on('error',err=>{console.error('Managerul nu poate porni:',err.message);process.exitCode=1});
server.listen(0,'127.0.0.1',()=>{
 const url='http://127.0.0.1:'+server.address().port+'/';
 console.log('\nCARPATIA LICENSE MANAGER — NUMAI PE ACEST PC');
 console.log('Adresă locală:',url,'\nFolder chei:',privateDir,'\nÎnchizi managerul cu Ctrl+C.');
 if(process.platform==='win32'){
  try{const child=spawn('cmd.exe',['/c','start','',url],{windowsHide:true,stdio:'ignore'});child.on('error',()=>{});child.unref()}catch{}
 }
});
