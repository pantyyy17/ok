#!/usr/bin/env node
'use strict';
// Runs on the seller's trusted PC, NOT included in the distributed installer.
const fs=require('node:fs');
const path=require('node:path');
const {createIssuerCode,PRODUCT}=require('../licensing');
const {initialize,mustBeExternal}=require('./issuer-core');
const args=process.argv.slice(2);
function option(name,def=null){const i=args.indexOf('--'+name);return i<0?def:args[i+1]??def}
function fail(msg){console.error('\nEROARE:',msg);process.exit(1)}
try{
 if(args[0]==='init'){
  const requestedDir=option('private-dir');if(!requestedDir)fail('Utilizare: node tools/license-cli.js init --private-dir D:\\CARPATIA_PRIVATE');
  const dir=mustBeExternal(requestedDir);
  const privateFile=path.join(dir,'carpatia-private.pem'),publicFile=path.join(dir,'carpatia-public.pem');
  initialize(dir);
  console.log('CHEIE PRIVATĂ:',privateFile,'\nCHEIE PUBLICĂ:',publicFile,'\nCopiază NUMAI cheia publică în proiect ca license-public.pem. Păstrează cheia privată offline.');
 } else if(args[0]==='issue'){
  const privateFile=option('private'),customer=option('customer'),id=option('id'),out=option('out');
  const days=option('days');
  if(!privateFile||!customer||!id||!out)fail('Utilizare: node tools/license-cli.js issue --private "D:\\PRIVATE\\carpatia-private.pem" --customer "Client" --id client_001 --out "D:\\PRIVATE\\client_001.txt" [--days 365]');
  mustBeExternal(privateFile);mustBeExternal(out);
  if(customer.length>180||!/^[a-zA-Z0-9_-]{6,100}$/.test(id))fail('Client/ID invalid. ID trebuie să aibă minimum 6 caractere ASCII.');
  const issued=new Date(),n=days===null?null:Number(days);
  if(days!==null&&(!Number.isSafeInteger(n)||n<1||n>3650))fail('Zile invalide (1–3650).');
  const payload={product:PRODUCT,licenseId:id,customer,issuedAt:issued.toISOString(),expiresAt:n===null?null:new Date(issued.getTime()+n*86400000).toISOString()};
  if(fs.existsSync(out))fail('Fișierul de licență există deja. Nu îl suprascriu.');
  const code=createIssuerCode(payload,fs.readFileSync(privateFile,'utf8'));
  fs.writeFileSync(out,code+'\n',{flag:'wx',mode:0o600});
  console.log('LICENȚĂ CREATĂ:',out,'\nID:',id,'\nExpirare:',payload.expiresAt||'permanentă','\nTransmite clientului codul din fișier, niciodată cheia privată.');
 }else fail('Comenzi: init | issue');
}catch(e){fail(e.message)}
