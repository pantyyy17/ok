'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const call=(name,...args)=>ipcRenderer.invoke(name,...args);
const names=['snapshotPrepare','snapshotCommit','snapshotResume','recoveryInventory','recoveryPrepare','recoveryCommit','recoverySnapshot','networkCapabilities','dashboardStatus','dashboardPrepare','dashboardCommit','dashboardRestore','tweakLibrary','tweakLibraryContext','tweakLibraryAcknowledge','tweakLibraryState','tweakLibraryApply','tweakLibraryRestore','licenseStatus','licenseActivate','licenseImport','sys','metrics','sensors','admin','hardware','gpuList','registryState','powerState','services','network','catalog','ultraAnalyze','ultraPrepare','ultraCommit','restoreUltra','networkRecovery','netClearEmptyJournal','netPrepare','netCommit','netRestore','debloatScan','debloatRemove','cleanupScan','cleanupRun','startupList','startupDisable','startupRestore','servicesChange','tweakApply','gpuPick','gpuStatus','gpuApply','gpuRestore','openSettings','latency'];
const bridge=Object.fromEntries(names.map(name=>[name,(...args)=>call(name,...args)]));
function listener(channel,fn){if(typeof fn!=='function')return ()=>{};const cb=(_event,message)=>{if(message&&typeof message.phase==='string'&&typeof message.detail==='string')fn(message)};ipcRenderer.on(channel,cb);return ()=>ipcRenderer.removeListener(channel,cb)}
bridge.onBackupProgress=fn=>listener('backupProgress',fn);
bridge.onSettingsChanged=fn=>listener('settingsChanged',fn);
bridge.onDashboardProgress=fn=>listener('dashboardProgress',fn);
bridge.onUltraProgress=fn=>listener('ultraProgress',fn);
bridge.onNetProgress=fn=>listener('netProgress',fn);
contextBridge.exposeInMainWorld('carpatia',Object.freeze(bridge));
