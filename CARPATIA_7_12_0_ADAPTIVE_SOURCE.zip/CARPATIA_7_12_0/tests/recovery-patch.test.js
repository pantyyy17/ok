'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const read=name=>fs.readFileSync(path.join(__dirname,'..',name),'utf8');
test('Restaurare permisă și după expirarea licenței, dar aplicarea rămâne blocată',()=>{
 const m=read('main.js'),u=read('ui.js'),h=read('index.html');
 for(const n of ['restoreUltra','netRestore','netClearEmptyJournal']){
  const i=m.indexOf(`registerWrite('${n}'`);assert(i>=0);assert(m.substring(i,i+1800).includes('recovery:true'),n);
 }
 assert.match(m,/if\(action!=='Restore'\)requireActiveLicense\(\)/);
 assert.match(u,/if\(!licensed&&!recovery\)/);
 assert.match(u,/\['restore','gpu','cleanup','tweaks'\]\.includes\(name\)/);
 assert.match(h,/id="licenseRecovery"/);
});
test('În Dashboard, cele trei stări de animație reflectă răspunsul motorului, nu un timer',()=>{
 const u=read('ui.js'),h=read('index.html');
 for(const id of ['heroUltra','heroDebloat','heroNetwork'])assert.match(h,new RegExp(`id="${id}"`));
 assert.match(u,/result\?\.success===true\?'complete':result\?\.success===false\?'error'/);
 assert.match(u,/r\.success\?'✓ Optimizare confirmată/);
 assert.match(h,/id="heroOpStatus"/);
});
test('Restaurarea power și registry este verificată după comanda Windows',()=>{
 const m=read('main.js'),oc=read('oneclick-engine.js');
 assert.match(m,/verifyRestored:async kind/);
 assert.match(read('operation-core.js'),/after\.backup!==false/);
 assert.match(oc,/Backup absent: restaurarea nu poate fi confirmată/);
});
