'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {parseSensorTree,walk}=require('../sensor-core');
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
class Element{
 constructor(tag='div',text='',value=''){this.tag=tag;this.textContent=text;this.children=[];this._value=value;this.listeners={};this.dataset={};this.classList={add(){},remove(){}}}
 set value(value){this._value=this.tag==='select'&&!this.children.some(c=>c.value===value)?'':value}
 get value(){return this._value}
 get firstChild(){return this.children[0]}
 append(...items){this.children.push(...items)}
 replaceChildren(...items){this.children=items;if(this.tag==='select')this._value=items[0]?.value||''}
 addEventListener(name,fn){this.listeners[name]=fn}
 setAttribute(name,value){this[name]=value}
 scrollIntoView(){}
}
function mount(file,name,api){
 const ids={},window={},source=fs.readFileSync(path.join(__dirname,'..',file),'utf8');
 const document={getElementById:id=>ids[id]??=new Element(['recoveryCategory','tweakCategory','tweakAdapter','tweakStatus','dashboardAdapter'].includes(id)?'select':'div'),createElement:tag=>new Element(tag)};
 vm.runInNewContext(source,{window,document,Option:class extends Element{constructor(text,value){super('option',text,value)}}});
 const calls=[];const page=window[name].mount({api,requireNative:()=>true,task:(_,fn)=>fn(),confirmDialog:async()=>true,showToast:()=>{},onOwner:x=>calls.push(x)});
 return {ids,page,calls};
}
const row={id:'library-cpu-035',title:'Test',category:'CPU',status:'registry'};
function flatten(node){return [node,...node.children.flatMap(flatten)]}
test('first recovery navigation honors requested category before select options exist',async()=>{
 const items=[{...row,state:'applied'},{id:'network',category:'Network',title:'DNS',state:'applied'}],calls=[];
 const x=mount('recovery-ui.js','CarpatiaRecovery',{recoveryInventory:async()=>({items,errors:[],history:[]}),recoveryPrepare:async s=>{calls.push(s);return {token:'t',rows:[]}},recoveryCommit:async()=>({succeeded:1,failed:0,skipped:0,results:[]})});
 await x.page.open({category:'Network'});
 assert.equal(x.ids.recoveryCategory.value,'Network');assert.equal(x.ids.recoveryRows.children.length,1);assert.equal(x.ids.recoveryRows.children[0].dataset.recoveryId,'network');
 await x.ids.recoveryRestore.onclick();assert.equal(calls[0].category,'Network');
 await x.page.open({});assert.equal(x.ids.recoveryCategory.value,'');assert.equal(x.ids.recoveryRows.children.length,2);await x.ids.recoveryRestore.onclick();assert.deepEqual(Object.keys(calls[1]),[]);
});
test('interrupted snapshot undo is labeled and resumed as undo',async()=>{
 const calls=[],api={recoveryInventory:async()=>({items:[],errors:[],history:[],transactions:[{id:'tx',type:'snapshot-restore',state:'partial',direction:'undo',rows:[]}]}),snapshotResume:async(id,undo)=>{calls.push({id,undo});return {succeeded:1,failed:0,skipped:0,rows:[]}}};
 const x=mount('recovery-ui.js','CarpatiaRecovery',api);await x.page.load();const button=flatten(x.ids.recoveryHistory).find(n=>n.textContent==='REIA ANULAREA');assert.ok(button);await button.onclick();assert.deepEqual(calls,[{id:'tx',undo:true}]);
});
test('late catalog state cannot overwrite a newer active backup state',async()=>{
 const old=deferred(),latest=deferred();let reads=0;
 const x=mount('tweak-library-ui.js','CarpatiaTweaks',{tweakLibrary:async()=>[row],tweakLibraryState:()=>++reads===1?old.promise:latest.promise,tweakLibraryContext:async()=>({adapters:[],compatibility:{}})});
 const a=x.page.load();await new Promise(setImmediate);const b=x.page.load();await new Promise(setImmediate);latest.resolve({success:true,states:[{id:row.id,state:'applied'}]});await b;
 old.resolve({success:true,states:[]});await a;const apply=flatten(x.ids.tweakRows).find(n=>n.tag==='button'&&n.textContent==='APLICAT');assert.ok(apply);assert.equal(apply.disabled,true);
});
test('late dashboard state cannot enable reapply of a newer active profile',async()=>{
 const old=deferred(),latest=deferred();let reads=0;
 const x=mount('dashboard-profiles-ui.js','CarpatiaDashboardProfiles',{dashboardStatus:()=>++reads===1?old.promise:latest.promise});
 const state=active=>['cpu','gpu','internet'].map(group=>({group,active:active&&group==='cpu',state:'applied',level:'high',observed:'active'}));
 const a=x.page.load({skipAdapters:true}),b=x.page.load({skipAdapters:true});latest.resolve(state(true));await b;old.resolve(state(false));await a;
 assert.equal(x.ids.heroDebloat.disabled,true);assert.equal(x.ids['restoreProfile-cpu'].disabled,false);
});
test('sensor attribution uses nearest device and cannot confuse a CPU-named hostname with GPU',()=>{
 const tree={Text:'RYZEN PC',Children:[{Text:'NVIDIA GeForce',Children:[{Text:'GPU Core',Value:'63,5 °C'},{Text:'GPU Core',Value:'27 %'}]}]};
 const result=parseSensorTree(tree);assert.equal(result.cpuTemperature,null);assert.equal(result.gpuTemperature.value,63.5);assert.equal(result.gpuLoad.value,27);
});
test('hardware icons support customized names and exclude invalid load values',()=>{
 const tree={Text:'PC',Children:[{Text:'My processor',ImageURL:'images_icon/cpu.png',Children:[{Text:'CPU Package',Value:'51 °C'}]},{Text:'Video',ImageURL:'images_icon/nvidia.png',Children:[{Text:'GPU Core',Value:'120 %'},{Text:'GPU Core',Value:'-2 %'}]}]};
 const result=parseSensorTree(tree);assert.equal(result.cpuTemperature.value,51);assert.equal(result.gpuLoad,null);
});
test('unnamed sensor nesting and cycles are bounded independently of readable path length',()=>{
 const root={Children:[]};let parent=root;for(let i=0;i<10000;i++){const child={Children:[]};parent.Children.push(child);parent=child}parent.Children.push({Text:'GPU Core',Value:'10 %'});
 assert.equal(walk(root).length,0);const cycle={Text:'CPU'};cycle.Children=[cycle];assert.deepEqual(walk(cycle),[]);
});
test('sensor traversal caps broad payloads as well as the number of sensor readings',()=>{
 const root={Children:Array.from({length:6000},()=>({Text:'empty'}))};root.Children.push({Text:'GPU Core',Value:'10 %'});assert.equal(walk(root).length,0);
 assert.equal(walk({Text:'CPU',Children:Array.from({length:500},()=>({Text:'CPU Core',Value:'1 °C'}))}).length,400);
});

test('apply-blocked catalog rows remain disabled without compatibility context and retain restoration',async()=>{
 const blocked={...row,applyBlocked:'Ținta GPU nu a fost identificată.'};
 for(const states of [[],[{id:row.id,state:'applied'}]]){
  const x=mount('tweak-library-ui.js','CarpatiaTweaks',{tweakLibrary:async()=>[blocked],tweakLibraryState:async()=>({success:true,states}),tweakLibraryContext:async()=>{throw Error('Inventory unavailable')}});
  await x.page.load();const nodes=flatten(x.ids.tweakRows),apply=nodes.find(n=>n.tag==='button'&&['APLICĂ','APLICAT'].includes(n.textContent));assert.equal(apply.disabled,true);assert.ok(nodes.some(n=>n.textContent.includes(blocked.applyBlocked)));
  if(states.length)assert.ok(nodes.some(n=>n.tag==='button'&&n.textContent==='RESTAUREAZĂ'));
 }
});
